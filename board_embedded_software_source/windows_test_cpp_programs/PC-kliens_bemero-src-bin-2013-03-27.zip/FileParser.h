#ifndef FILE_PARSER_H
#define FILE_PARSER_H

#include <stdio.h>

enum fparCommand
{
  fpar_COMMENT,
  fpar_wait,
  fpar_renderer,                     
  fpar_loadmolecule, 
  fpar_allmolclose,
  fpar_movemolecule,
  fpar_movemoleculecenter,
  fpar_CommandCount
};

#define fparUNKNOWN_COMMAND  -5000

#define COMMAND_TO_NAME \
  case fpar_wait :                      return "wait"; \
  case fpar_renderer :                  return "renderer"; \
  case fpar_loadmolecule :              return "load_molecule"; \
  case fpar_allmolclose :               return "close_all_molecule"; \
  case fpar_movemolecule :              return "move_molecule"; \
  case fpar_movemoleculecenter:         return "move_molecule_center"; \
  
 
#define COMMAND_TO_OPCODE \
      case fpar_wait :                  return 900; \
      case fpar_COMMENT :               return 901; \
      case fpar_renderer :              return 902; \
      case fpar_loadmolecule :          return 903; \
      case fpar_allmolclose :           return 904; \
      case fpar_movemolecule  :         return 905; \
      case fpar_movemoleculecenter :    return 906; \
      

class FileParser
{
private:    
    FileParser();
protected:
    FILE*   fhandler_m;
    //char* command_to_name( fparCommand index_a );
    //int   command_to_opcode( fparCommand index_a );
    int     name_to_opcode( char *name_a );
    char    m_error[256];
    int*    m_cim_tomb;
public:
    FileParser(const char* fname_a, int* cim_tomb_a, bool& result_a);
    ~FileParser();
    int execute();
    char* get_error(){return &m_error[0];};
};
#endif
