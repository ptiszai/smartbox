#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include "FileParser.h"

extern char *StrAllTrim( const char *string, char *pcInto );

FileParser::FileParser(const char* fname_a, int* cim_tomb_a, bool& result_a) :
m_cim_tomb(cim_tomb_a)
{
    if (fname_a)
    {
        fhandler_m = fopen(fname_a,"r");
    }
    else
    {
        fhandler_m = fopen("cimek.dat","r");
    }

    result_a = (fhandler_m == NULL) ? false : true;
    m_error[0] = 0;   
}

FileParser::~FileParser()
{
    if (fhandler_m)
        fclose(fhandler_m);
}


int FileParser::execute()
{
    int itemp=-999;
    int index = 0;
    char keybuf[256], buff[256];
    while(fhandler_m && !feof(fhandler_m) && (index<128))
    {
        fscanf(fhandler_m,"%s", keybuf);
        StrAllTrim(keybuf,buff);
        itemp = atoi(buff) ;
        if ((itemp<1) || (itemp>1401))
        {
            sprintf(m_error,"Cim olvasas hiba.A cim helyett:<%s>,sor:%d", keybuf,index+1);
            m_cim_tomb[0] = 0;
            return 0;
        }
        m_cim_tomb[index] = itemp;
        ++index;
    }
    m_cim_tomb[index] = 0;
    return 1;
 }
