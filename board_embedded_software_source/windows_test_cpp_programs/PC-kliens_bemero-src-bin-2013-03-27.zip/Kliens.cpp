//---------------------------------------------------------------------------
//& ||
#include <vcl.h>
#include <stdlib.h>
#include <stdio.h>

#pragma hdrstop

#include "SzCom.h"
#include "Kliens.h"
#include "FileParser.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKliensForm *KliensForm;
SzCom*      ComThread;
/*
 *	Adas:
 *  ',',cimh,ciml,0x0x,chs		// x: D0,D1 output, es input lekerdezes.
 *  '!',0xbb,cimh,ciml,chs	    // uj fix cim kuldese PC -bol.
 *  '?',0xbb,00,00,chs	        // cim kerdese PC -bol.
 *	',',0xfe,00,0x70,chs		// test start, mindegyik allomasnal.
 *	',',0xfe,00,0x71,chs		// test stop , mindegyik allomasnal.
 *	',',0xfe,00,0x81,chs		// cim infra adas inditas.
 *	',',0xfe,00,0x82,chs		// cim infra adas leallitas.
 *  Vetel
 *	';',cimh,ciml,0x0x,chs		// x: D0,D1,D2,D3 input.
 *  '!',0xbb,cimh,ciml,chs	    // uj fix cim vetele a PC -nek.
 */

char msg[1000];
/**********************************************************************
 * Error Message:
 **********************************************************************/
 void Error_Message(char* msg)
 {
    Application->MessageBox(msg , "Error",0);
 }// void Error_Message(const char* msg)

 /**********************************************************************
 * Debug Message:
 **********************************************************************/
 void XTPrintf(const char* sText)
 {
    KliensForm->View->Lines->Add(sText);
 }//XTPrintf(..)
 //---------------------------------------------------------------------------
 char *StrAllTrim( const char *string, char *pcInto )
{
	char *p = pcInto;

	// Kihagyom az elejen levo space-eket
	for ( ; *string && isspace( *string ); ++string )
		;

	// Masolom a maradekot
	while (*string)
		*p++ = *string++;
	*p = (char) 0;

	// A vegerol lehagyom a sallangokat
	for (--p; p >= pcInto && isspace( *p ); --p)
		*p = (char) 0;

	return pcInto;

} // StrAllTrim()


/**********************************************************************
 * Warning Message:
 **********************************************************************/
 void Warning_Message(char* msg)
 {
    Application->MessageBox(msg , "Warning",0);
 }// void Warning_Message(const char* msg)

//---------------------------------------------------------------------------
__fastcall TKliensForm::TKliensForm(TComponent* Owner)
        : TForm(Owner)
{
     bSendOther = false;
     m_addr = 1;
     m_send_count=0;
     m_hurok_index=0;
    // recStop = false;
}

//---------------------------------------------------------------------------
// Send part.
//---------------------------------------------------------------------------

//------------------------------------------------------
void __fastcall TKliensForm::setGeneral()
{
     m_send_buff[0] = ',';
     m_send_buff[1] = (int)(m_addr/256);
     m_send_buff[2] = (int)(m_addr%256);
     m_send_buff[3] = 0;
     setChkSumma();
}

//------------------------------------------------------
void __fastcall TKliensForm::setTeszt()
{
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = (TesztRadioGrp->ItemIndex)?0x70:0x71;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall TKliensForm::setInfra()
{
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = (InfraRadioGrp->ItemIndex)?0x81:0x82;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall TKliensForm::setAskCim()
{
     m_send_buff[0] = '?';
     m_send_buff[1] = 0xbb;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall TKliensForm::setNewAddr(int newaddr_a)
{
     m_addr = newaddr_a;
     m_send_buff[0] = '!';
     m_send_buff[1] = 0xbb;
     m_send_buff[2] = (int)(newaddr_a/256);
     m_send_buff[3] = (int)(newaddr_a%256);
     setChkSumma();
     bSendOther = true;
     Cim1Edit->Text = AnsiString(m_addr);
     m_send_count = 0;
     ComState->Brush->Color = clWhite;
     return;
}

//------------------------------------------------------
void __fastcall TKliensForm::setChkSumma()
{
   m_send_buff[4] = m_send_buff[1] + m_send_buff[2] + m_send_buff[3];
}

//------------------------------------------------------
void __fastcall TKliensForm::setCommLed(bool isGood)
{
    if (isGood)
    {
        ComState->Brush->Color = clGreen;
        clear_send_count();
    }
    else
        ComState->Brush->Color = clRed;
}

//------------------------------------------------------
void  __fastcall TKliensForm::setAddr(int addr_a)
{
    if ((addr_a<1) || (addr_a>1401))
    {
        sprintf(msg,"Rossz a vett cim: kapott: %d",addr_a);
        return;
    }
    m_addr = addr_a;
    Cim1Edit->Text = m_addr;
}

//------------------------------------------------------
void __fastcall TKliensForm::setInStateLed(char in_a)
{
    if (in_a & 1) // toltes
        ToltesState->Brush->Color = clGreen;
    else
        ToltesState->Brush->Color = clRed;
    if (in_a & 2) // akku
        AkkuState->Brush->Color = clGreen;
    else
        AkkuState->Brush->Color = clRed;
    if (in_a & 4) // fenycso
        FenycsoState->Brush->Color = clGreen;
    else
        FenycsoState->Brush->Color = clRed;
}

//------------------------------------------------------
void __fastcall TKliensForm::clrInStateLed()
{
      ToltesState->Brush->Color = clWhite;
      AkkuState->Brush->Color = clWhite;
      FenycsoState->Brush->Color =clWhite;
}
//---------------------------------------------------------------------------
// Event part.
//---------------------------------------------------------------------------


void __fastcall TKliensForm::FormCreate(TObject *Sender)
{
    bool result_l;
    FileParser* fp = new FileParser(NULL, &m_cim_tomb[0],result_l);
    if (!result_l)
    {
       XTPrintf("<cimek.dat> file-t nem tudtam megnyitni!");
    }
    else
    {
        if (!fp->execute())
             XTPrintf(fp->get_error());
    }

    TCHAR       root_dir[MAX_PATH];
    char        full_ini_name[MAX_PATH];

    DWORD dwRet = GetCurrentDirectory(MAX_PATH, root_dir);

   if( dwRet == 0 )
   {
fc_error:
      Error_Message("Rossz a 'lamp.ini' f�jl!");
      Application->Terminate();
      return;
   }
   
    sprintf(full_ini_name,"%s\\%s",root_dir,"lamp.ini");
    com_set.Port = GetPrivateProfileInt("SERIAL","com",0, full_ini_name);
    if (com_set.Port == 0)
        goto fc_error;


    //com_set.Port    =  1;
    com_set.Baudrate=  CBR_2400;
    com_set.ByteSize=  (Byte)8;
    com_set.StopBits=  (Byte)ONESTOPBIT;
    com_set.Parity  =  (Byte)NOPARITY;

    ComThread = new SzCom(true,&com_set);
    ComThread->OnTerminate = TCom_ThreadDone;
    ComThread->Priority=tpNormal;

    ComThread->Resume();
}

//---------------------------------------------------------------------
//---------------------------------------------------------------------
void __fastcall TKliensForm::TCom_ThreadDone(TObject* Sender)
{
  //
  Sender = Sender;
}//TKalibForm::TCom_ThreadDone(..)

//---------------------------------------------------------------------------
void __fastcall TKliensForm::ExitBtnClick(TObject *Sender)
{
        Close();        
}

//---------------------------------------------------------------------------
void __fastcall TKliensForm::CimKuldBtnClick(TObject *Sender)
{
    int temp;
    char buff[5];

    StrAllTrim(CimEdit->Text.c_str(),buff);
    temp = atoi(buff) ;
    if ((temp<1) || (temp>1401))
    {
        Error_Message("Rossz az �j cim:0-1401 k�z�tt lehet!");
        return;
    }

    if (Application->MessageBox("�j cimet be�gessem?", "�j cim k�rd�s.",MB_YESNO	) == IDYES  )
    {
       setNewAddr(temp);
    }
}
//---------------------------------------------------------------------------
void __fastcall TKliensForm::KlinsTimerTimer(TObject *Sender)
{

    if (HurokCkB->State == cbChecked)
    {
        if (!m_cim_tomb[m_hurok_index])
            m_hurok_index = 0;
        m_addr = m_cim_tomb[m_hurok_index];
        Cim1Edit->Text = m_addr;
        m_hurok_index = (m_hurok_index>64)? 0:++m_hurok_index;
    }

    if ((m_addr<1) || (m_addr>1401))
    {
        clrInStateLed();
        return;
    }
        
    if (bSendOther)
    {
        bSendOther = false;
    }
    else
    {
        setGeneral();
    }
    ++m_send_count;
    if (m_send_count>1)
        setCommLed(false);
    ComThread->Send(m_send_buff,5);
}
//---------------------------------------------------------------------------
void __fastcall TKliensForm::TesztRadioGrpClick(TObject *Sender)
{
    setTeszt();
}
//---------------------------------------------------------------------------
void __fastcall TKliensForm::InfraRadioGrpClick(TObject *Sender)
{
    setInfra();
}

//---------------------------------------------------------------------------
void __fastcall TKliensForm::CimBtnClick(TObject *Sender)
{
    setAskCim();    
}
//---------------------------------------------------------------------------
void __fastcall TKliensForm::ViewDblClick(TObject *Sender)
{
    View->Clear();    
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::Cim1EditExit(TObject *Sender)
{
    int temp;
    char buff[5];

    StrAllTrim(Cim1Edit->Text.c_str(),buff);
    temp = atoi(buff) ;
    if ((temp<1) || (temp>1501))
    {
        Error_Message("Rossz az �j cim:0-1501 k�z�tt lehet!");
        return;
    }
    m_addr =  temp;
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::Cim1EditEnter(TObject *Sender)
{
    Cim1EditExit(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::Cim1EditClick(TObject *Sender)
{
    Cim1EditExit(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::TestBtClick(TObject *Sender)
{
      setTeszt();
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::HurokCkBClick(TObject *Sender)
{
    if (HurokCkB->State == cbChecked)
    {
        UjCimGrBx->Visible = false;
        CimBtn->Visible = false;
    }
    else
    {
        UjCimGrBx->Visible = true;
        CimBtn->Visible = true;
    }
    m_hurok_index = 0;
}
//---------------------------------------------------------------------------

void __fastcall TKliensForm::NoSendChckBxClick(TObject *Sender)
{
    KlinsTimer->Enabled = (NoSendChckBx->State == cbChecked) ? false: true;   
}
//---------------------------------------------------------------------------

