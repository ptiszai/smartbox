#ifndef TEST_FILE_PARSER_EXECUTE_H
#define TEST_FILE_PARSER_EXECUTE_H
#include "utils/FileParser.h"


/* enum ObjectToTransform {
                     l3dMOLECULE_OR_GRAPHICSott,
                     l3dPOLYLINEott,
                     l3dEVERYTHINGott,
                     l3dNOTHINGott };*/

//class FileParser;
class MainWindow;
class VMDinterface;

class FileParserExecutor : public FileParser
{
    private:
        VMDinterface*   vmd_if_m;
        HANDLE          hEvent_m;
        HANDLE          hThread_m;
        FileParserExecutor(); 
        static DWORD WINAPI execute( void*);
        int run();
    protected:
    public:
        FileParserExecutor(const char* fname_a, bool& result);
        ~FileParserExecutor();       
        int start_execute(VMDinterface* vmd_if_a);
        void continue_execute();    
};


#endif