//---------------------------------------------------------------------------

#ifndef KliensH
#define KliensH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class THurokForm : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *UjCimGrBx;
        TMaskEdit *CimEdit;
        TLabel *Label1;
        TButton *CimKuldBtn;
        TLabel *Label2;
        TMaskEdit *Cim1Edit;
        TShape *ComState;
        TGroupBox *GroupBox2;
        TLabel *Label3;
    TShape *ToltesState;
        TLabel *Label4;
    TShape *AkkuState;
        TLabel *Label5;
    TShape *FenycsoState;
        TTimer *KlinsTimer;
        TButton *ExitBtn;
        TRadioGroup *TesztRadioGrp;
        TRadioGroup *InfraRadioGrp;
        TMemo *View;
    TCheckBox *DumpChB;
    TButton *CimBtn;
    TButton *ResetBt;
    TCheckBox *HurokCkB;
    TCheckBox *InstallChckBx;
    TCheckBox *MessgChckBx;
    TButton *AllCimBtn;
    TCheckBox *SendChB;
    TCheckBox *RecvChB;
    TGroupBox *GroupBox1;
    TLabel *Label6;
    TMaskEdit *UCimEdit;
    TButton *UCimKuldBtn;
        void __fastcall ExitBtnClick(TObject *Sender);
        void __fastcall CimKuldBtnClick(TObject *Sender);
    void __fastcall KlinsTimerTimer(TObject *Sender);
    void __fastcall TesztRadioGrpClick(TObject *Sender);
    void __fastcall InfraRadioGrpClick(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall TCom_ThreadDone(TObject* Sender);
    void __fastcall CimBtnClick(TObject *Sender);
    void __fastcall ViewDblClick(TObject *Sender);
    void __fastcall Cim1EditExit(TObject *Sender);
    void __fastcall Cim1EditEnter(TObject *Sender);
    void __fastcall Cim1EditClick(TObject *Sender);
    void __fastcall ResetBtClick(TObject *Sender);
    void __fastcall HurokCkBClick(TObject *Sender);
    void __fastcall MessgChckBxClick(TObject *Sender);
    void __fastcall InstallChckBxClick(TObject *Sender);
    void __fastcall AllCimBtnClick(TObject *Sender);
    void __fastcall ViewClick(TObject *Sender);
    void __fastcall UCimKuldBtnClick(TObject *Sender);
private:	// User declarations
        COM_SET com_set;
       // char    m_send_buff[256];
        int     m_addr;
        bool    bSendOther;
        int     m_send_count;
        int     m_hurok_index;
        int     m_cim_tomb[129];
        int     current_timer_interval,next_timer_interval;

        void __fastcall setGeneral();
        void __fastcall setReset1Allomas();
        void __fastcall setClear1AllomasAddr();
        void __fastcall setAskAllomasAddresses();
        void __fastcall setInstall();
        void __fastcall setInfra();
        void __fastcall setTeszt();
        void __fastcall setMessg();
        void __fastcall setReset();
        void __fastcall setAskCimNum();
        void __fastcall setChkSumma();
        void __fastcall setClearAllAllomasAddr();
        void __fastcall clrInStateLed();
        void __fastcall setNewAddr(int newaddr_a);
public:		// User declarations
       struct
       {
            int all_addr;
       }allomas_data[7];
        char    m_send_buff[256];
        __fastcall THurokForm(TComponent* Owner);
        void __fastcall clear_send_count(){m_send_count=0;};
        int  __fastcall getAddr(){return m_addr;};
        void __fastcall setAddr(int addr_a);
        void __fastcall setCommLed(bool isGood);
        void __fastcall setInStateLed(char in_a);
        void __fastcall setAnswer(UCHAR data);
        void __fastcall setAskCim();
        void __fastcall setAllomasCim(int loop_addr,int all_addr)
        { allomas_data[loop_addr].all_addr = all_addr; };
};
//---------------------------------------------------------------------------
extern PACKAGE THurokForm *HurokForm;
//---------------------------------------------------------------------------
#endif
