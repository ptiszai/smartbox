//---------------------------------------------------------------------------
//& ||
#include <vcl.h>
#include <stdlib.h>
#include <stdio.h>

#pragma hdrstop

#include "SzCom.h"
#include "Hurok.h"
#include "FileParser.h"


 /*	A:',',lcim,0x00,0x0x,0x00,chs		// altalanos lekerdezes,parancsok.
 *	V:';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,acimh,aciml,data,chs		// elozoleg megkapott hiba visszajelzese.
 *	V:';',lcim,0x00,0x00,00,00,00,chs
 *
 *	A:',',lcim,0x00,0x00,0x00,chs		// altalanos lekerdezes.
 *	V:'M',num,"uzenet.."			    // szimpla uzenet, max. 20 byte.
 *
 *	A:',',lcim,acimh,aciml,0x80,chs		// reset 1 allomasnal.
 *	V:';',lcim,0x00,00,0x80,00,00,chs	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,acimh,aciml,0x90,chs		// torli az allomas cimet a hurok kartya  eepromjaban.
 *	V:';',lcim,0x00,00,0x90,00,00,chs	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,0x00,0x91,chs		// allomas cimek szamanak a lekerdezese.
 *	V:';',lcim,0x00,0x00,0x91,num,chs   // allomas cimek szama a num-ban
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,0x00,0x92,chs		// allomas cimek lekerdezese.
 *	V:'N',lcim,0x92,num,a0..an,chs      // allomas cimek.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0x83,chs		    // install bekapcsolasa.
 *	V:';',lcim,0x00,00,0x83,00,00,chs 	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0x84,chs		    // install kikapcsolasa.
 *	V:';',lcim,0x00,00,0x84,00,00,chs 	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',0xfe,0x00,00,0x81,chs		    // korparancs:cim infra adas inditas.(3x)
 *	A:',',0xfe,0x00,00,0x82,chs		    // korparancs:cim infra adas leallitas.(3x)
 *	A:',',0xfe,0x00,00,0x80,chs		    // korparancs:reset mindegyik allomasnal.(3x)
 *	A:',',0xfe,0x00,00,0x70,chs		    // korparancs:test start, mindegyik allomasnal.(3x)
 *	A:',',0xfe,0x00,00,0x71,chs		    // korparancs:test stop, mindegyik allomasnal.(3x)
 *
 *	A:',',lcim,0x00,00,0xa1,chs		    // rendszernek: uzenet kuldes mod bekapcsolva.
 *	V:';',lcim,0x00,00,0xa1,0x00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,0x00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0xa2,chs		// rendszernek: uzenet kuldes mod kikapcsolva.
 *	V:';',lcim,0x00,00,0xa2,00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0xa3,chs		// rendszernek: reset.
 *	V:';',lcim,0x00,00,0xa3,00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 */

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THurokForm *HurokForm;
SzCom*      ComThread;


char msg[1000];
/**********************************************************************
 * Error Message:
 **********************************************************************/
 void Error_Message(char* msg)
 {
    Application->MessageBox(msg , "Error",0);
 }// void Error_Message(const char* msg)

 /**********************************************************************
 * Debug Message:
 **********************************************************************/
 void XTPrintf(const char* sText)
 {
    if (!HurokForm->View->Tag)
        HurokForm->View->Lines->Add(sText);
 }//XTPrintf(..)
 //---------------------------------------------------------------------------
 char *StrAllTrim( const char *string, char *pcInto )
{
	char *p = pcInto;

	// Kihagyom az elejen levo space-eket
	for ( ; *string && isspace( *string ); ++string )
		;

	// Masolom a maradekot
	while (*string)
		*p++ = *string++;
	*p = (char) 0;

	// A vegerol lehagyom a sallangokat
	for (--p; p >= pcInto && isspace( *p ); --p)
		*p = (char) 0;

	return pcInto;

} // StrAllTrim()

/**********************************************************************
 * Warning Message:
 **********************************************************************/
 void Warning_Message(char* msg)
 {
    Application->MessageBox(msg , "Warning",0);
 }// void Warning_Message(const char* msg)

//---------------------------------------------------------------------------
__fastcall THurokForm::THurokForm(TComponent* Owner)
        : TForm(Owner)
{
     bSendOther = false;
     m_addr = 1;
     m_send_count=0;
     m_hurok_index=0;
     current_timer_interval =  1000;
     next_timer_interval =  1000;


    // recStop = false;
}

//---------------------------------------------------------------------------
// Send part.
//---------------------------------------------------------------------------

//------------------------------------------------------
void __fastcall THurokForm::setGeneral()
{ //A:',',lcim,0x00,0x00x,0x00,chs		// altalanos lekerdezes,parancsok.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0;
     ComThread->rec_max_num = 8;
     next_timer_interval = 1000;
     setChkSumma();
}

//------------------------------------------------------
void __fastcall THurokForm::setAnswer(UCHAR data)
{  //A:',',lcim,acimh,aciml,data,chs		// elozoleg megkapott hiba visszajelzese.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = (int)(allomas_data[m_addr].all_addr/256);
     m_send_buff[3] = (int)(allomas_data[m_addr].all_addr%256);
     m_send_buff[4] = data;
     setChkSumma();
   //  bSendOther = true;
     return;
}

//------------------------------------------------------
void __fastcall THurokForm::setReset1Allomas()
{  //A:',',lcim,acimh,aciml,0x80,chs		// reset 1 allomasnal.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = (int)(allomas_data[m_addr].all_addr/256);
     m_send_buff[3] = (int)(allomas_data[m_addr].all_addr%256);
     m_send_buff[4] = 80;
     setChkSumma();
      bSendOther = true;
     return;
}

//------------------------------------------------------
void __fastcall THurokForm::setClear1AllomasAddr()
{  // A:',',lcim,acimh,aciml,0x90,chs		// torli az allomas cimet a hurok kartya  eepromjaban.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = (int)(allomas_data[m_addr].all_addr/256);
     m_send_buff[3] = (int)(allomas_data[m_addr].all_addr%256);
     m_send_buff[4] = 90;
     setChkSumma();
      bSendOther = true;
     return;
}

//------------------------------------------------------
void __fastcall THurokForm::setClearAllAllomasAddr()
{  // A:',',lcim,0,0,0x90,chs		// torli az allomas cimet a hurok kartya  eepromjaban.
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0x90;
     setChkSumma();
      bSendOther = true;
     return;
}

//------------------------------------------------------
void __fastcall THurokForm::setNewAddr(int newaddr_a)
{
    // A:'!',0xbb,
     m_addr = newaddr_a;
     m_send_buff[0] = 'P';
     m_send_buff[1] = 0xbb;
     m_send_buff[2] = (char)(newaddr_a);
     m_send_buff[3] = 0;
     m_send_buff[4] = 0;
     setChkSumma();
     bSendOther = true;
     Cim1Edit->Text = AnsiString(m_addr);
     m_send_count = 0;
     ComState->Brush->Color = clWhite;
     return;
}

//------------------------------------------------------
void __fastcall THurokForm::setAskAllomasAddresses()
{ //A:',',lcim,0x00,0x00,0x82,chs		// allomas cimek lekerdezese.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0x82;
     setChkSumma();

}

//------------------------------------------------------
void __fastcall THurokForm::setInstall()
{ //A:',',lcim,0x00,00,0x83,chs		    // install bekapcsolasa.
 // A:',',lcim,0x00,00,0x84,chs		    // install kikapcsolasa.
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = (InstallChckBx->State==cbChecked)?0x83:0x84;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setTeszt()
{ //A:',',0xfe,0x00,00,0x70,chs		// korparancs:test start, mindegyik allomasnal.(3x)
  //A:',',0xfe,0x00,00,0x71,chs		// korparancs:test stop , mindegyik allomasnal.(3x)
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = (TesztRadioGrp->ItemIndex)?0x70:0x71;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setInfra()
{  //A:',',0xfe,0x00,00,0x81,chs		// korparancs:cim infra adas inditas.(3x)
   //A:',',0xfe,0x00,00,0x82,chs		// korparancs:cim infra adas leallitas.(3x)
     m_send_buff[0] = ',';
     m_send_buff[1] = 0xfe;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = (InfraRadioGrp->ItemIndex)?0x81:0x82;
     setChkSumma();
      bSendOther = true;
    // bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setMessg()
{  //A:',',lcim,0x00,00,0xa1,chs		// rendszernek: uzenet kuldes mod bekapcsolva.
   //A:',',lcim,0x00,00,0xa2,chs		// rendszernek: uzenet kuldes mod kikapcsolva.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = (MessgChckBx->State==cbChecked)?0xa1:0xa2;
     setChkSumma();
     ComThread->rec_max_num =  (MessgChckBx->State==cbChecked)?20:8;
     ComThread->Send(m_send_buff,6);
     //bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setReset()
{ //  A:',',lcim,0x00,00,0xa3,chs		// rendszernek: reset.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0xa3;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setAskCimNum()
{ // A:',',lcim,0x00,0x00,0x91,chs		// allomas cimek szamanak a lekerdezese.
     m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0x91;
     setChkSumma();
     bSendOther = true;
}

//------------------------------------------------------
void __fastcall THurokForm::setAskCim()
{  //A:',',lcim,0x00,0x00,0x92,chs		// allomas cimek lekerdezese.
      m_send_buff[0] = ',';
     m_send_buff[1] = m_addr;
     m_send_buff[2] = 0;
     m_send_buff[3] = 0;
     m_send_buff[4] = 0x92;
     setChkSumma();
     bSendOther = true;
     next_timer_interval = 5000;
}

//------------------------------------------------------
void __fastcall THurokForm::setChkSumma()
{
   m_send_buff[5] = m_send_buff[1] + m_send_buff[2] + m_send_buff[3] + m_send_buff[4];
}

//------------------------------------------------------
void __fastcall THurokForm::setCommLed(bool isGood)
{
    if (isGood)
    {
        ComState->Brush->Color = clGreen;
        clear_send_count();
    }
    else
        ComState->Brush->Color = clRed;
}

//------------------------------------------------------
void  __fastcall THurokForm::setAddr(int addr_a)
{
    if ((addr_a<1) || (addr_a>500))
    {
        sprintf(msg,"Rossz a vett cim: kapott: %d",addr_a);
        return;
    }
    m_addr = addr_a;
    Cim1Edit->Text = m_addr;
}

//------------------------------------------------------
void __fastcall THurokForm::setInStateLed(char in_a)
{
    if (HurokForm->RecvChB->State == cbChecked)
    {
       if (in_a & 1) // toltes
            XTPrintf("Toltes jo");
       else
            XTPrintf("Toltes hiba");
        if (in_a & 2) // akku
            XTPrintf("Akku jo");
        else
            XTPrintf("Akku hiba");
        if (in_a & 4) // fenycso
            XTPrintf("Fenycso jo");
        else
            XTPrintf("Fenycso hiba");
    }
    else
    {
    if (!TesztRadioGrp->ItemIndex)
    {
        if (in_a & 1) // toltes
            XTPrintf("Toltes jo");
       //ToltesState->Brush->Color = clGreen;
       else
       // ToltesState->Brush->Color = clRed;
        XTPrintf("Toltes hiba");
    }
    else
    {
        if (in_a & 2) // akku
      //  AkkuState->Brush->Color = clGreen;
            XTPrintf("Akku jo");
        else
     //   AkkuState->Brush->Color = clRed;
            XTPrintf("Akku hiba");
        if (in_a & 4) // fenycso
        //FenycsoState->Brush->Color = clGreen;
            XTPrintf("Fenycso jo");
        else
            XTPrintf("Fenycso hiba");
       // FenycsoState->Brush->Color = clRed;
    }
    }
}

//------------------------------------------------------
void __fastcall THurokForm::clrInStateLed()
{
      ToltesState->Brush->Color = clWhite;
      AkkuState->Brush->Color = clWhite;
      FenycsoState->Brush->Color =clWhite;
}

//---------------------------------------------------------------------------
// Event part.
//---------------------------------------------------------------------------
void __fastcall THurokForm::FormCreate(TObject *Sender)
{
    bool result_l;
    FileParser* fp = new FileParser(NULL, &m_cim_tomb[0],result_l);
    if (!result_l)
    {
       XTPrintf("<cimek.dat> file-t nem tudtam megnyitni!");
    }
    else
    {
        if (!fp->execute())
             XTPrintf(fp->get_error());
    }
    
    TCHAR       root_dir[MAX_PATH];
    char        buff[MAX_PATH];

    DWORD dwRet = GetCurrentDirectory(MAX_PATH, root_dir);

   if( dwRet == 0 )
   {
fc_error:
      Error_Message("Rossz a 'lamp.ini' f�jl!");
      Application->Terminate();
      return;
   }

    sprintf(buff,"%s\\%s",root_dir,"lamp.ini");
    com_set.Port = GetPrivateProfileInt("SERIAL","com",0, buff);
    if (com_set.Port == 0)
        goto fc_error;



    KlinsTimer->Interval = current_timer_interval;
   // com_set.Port    =  1;
    com_set.Baudrate=  CBR_2400;
    com_set.ByteSize=  (Byte)8;
    com_set.StopBits=  (Byte)ONESTOPBIT;
    com_set.Parity  =  (Byte)NOPARITY;

    ComThread = new SzCom(true,&com_set);
    ComThread->OnTerminate = TCom_ThreadDone;
    ComThread->Priority=tpNormal;

    ComThread->Resume();

    sprintf(buff,"Hurok bem�r�: COM%d",com_set.Port);
    Caption=buff;
}

//---------------------------------------------------------------------
void __fastcall THurokForm::TCom_ThreadDone(TObject* Sender)
{
  //
  Sender = Sender;
}//TKalibForm::TCom_ThreadDone(..)

//---------------------------------------------------------------------------
void __fastcall THurokForm::ExitBtnClick(TObject *Sender)
{
        Close();        
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::CimKuldBtnClick(TObject *Sender)
{
    int temp;
    char buff[5];

    StrAllTrim(CimEdit->Text.c_str(),buff);
    temp = atoi(buff) ;
    if ((temp<1) || (temp>501))
    {
        Error_Message("Rossz az �j cim:0-500 k�z�tt lehet!");
        return;
    }
    if (temp == 501)
    {  //osszes cim torlese.
       setClearAllAllomasAddr();
    }
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::KlinsTimerTimer(TObject *Sender)
{
  //  if (MessgChckBx->State==cbChecked)
   //     return;

    if (KlinsTimer->Interval > 1500)
        KlinsTimer->Interval = 1500;
        
    if (HurokCkB->State == cbChecked)
    {
        if (!m_cim_tomb[m_hurok_index])
            m_hurok_index = 0;
        m_addr = m_cim_tomb[m_hurok_index];
        Cim1Edit->Text = m_addr;
        m_hurok_index = (m_hurok_index>64)? 0:++m_hurok_index;
        sprintf(msg,"Timer allomas:%d",m_addr);
        XTPrintf(msg);
    }

    if ((m_addr<1) || (m_addr>500))
    {
        clrInStateLed();
        return;
    }

    if (bSendOther)
    {
        bSendOther = false;
    }
    else
    {
        setGeneral();
    }
    ++m_send_count;
    if (m_send_count>1)
        setCommLed(false);
    if (SendChB->State == cbChecked)
    {
         for (int ii=0 ;ii<250 ; ii++)
            m_send_buff[ii] = 0;
         ComThread->Send(m_send_buff,250);
         KlinsTimer->Interval = 2;
         return;
    }
    if (RecvChB->State == cbUnchecked)
        ComThread->Send(m_send_buff,6);
    current_timer_interval = next_timer_interval;
     KlinsTimer->Interval = current_timer_interval;

}

//---------------------------------------------------------------------------
void __fastcall THurokForm::TesztRadioGrpClick(TObject *Sender)
{
    setTeszt();
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::InfraRadioGrpClick(TObject *Sender)
{
    setInfra();
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::CimBtnClick(TObject *Sender)
{
    setAskCim();    
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::ViewDblClick(TObject *Sender)
{
    View->Clear();    
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::Cim1EditExit(TObject *Sender)
{
    int temp;
    char buff[5];

    StrAllTrim(Cim1Edit->Text.c_str(),buff);
    temp = atoi(buff) ;
    if ((temp<1) || (temp>1300))
    {
        Error_Message("Rossz az �j cim:0-500 k�z�tt lehet!");
        return;
    }
    m_addr =  temp;
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::Cim1EditEnter(TObject *Sender)
{
    Cim1EditExit(Sender);
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::Cim1EditClick(TObject *Sender)
{
    Cim1EditExit(Sender);
}
//---------------------------------------------------------------------------

void __fastcall THurokForm::ResetBtClick(TObject *Sender)
{
      setReset();
}

//---------------------------------------------------------------------------
void __fastcall THurokForm::HurokCkBClick(TObject *Sender)
{
    if (HurokCkB->State == cbChecked)
    {
        UjCimGrBx->Visible = false;
        CimBtn->Visible = false;
    }
    else
    {
        UjCimGrBx->Visible = true;
        CimBtn->Visible = true;
    }
    m_hurok_index = 0;
}
//---------------------------------------------------------------------------

void __fastcall THurokForm::MessgChckBxClick(TObject *Sender)
{
    setMessg();

}
//---------------------------------------------------------------------------

void __fastcall THurokForm::InstallChckBxClick(TObject *Sender)
{
    setInstall();    
}
//---------------------------------------------------------------------------

void __fastcall THurokForm::AllCimBtnClick(TObject *Sender)
{
    setAskCimNum();    
}
//---------------------------------------------------------------------------

void __fastcall THurokForm::ViewClick(TObject *Sender)
{
    View->Tag = (View->Tag) ? 0 : 1;
}
//---------------------------------------------------------------------------

void __fastcall THurokForm::UCimKuldBtnClick(TObject *Sender)
{
    int temp;
    char buff[5];

    StrAllTrim(UCimEdit->Text.c_str(),buff);
    temp = atoi(buff) ;
    if ((temp<1) || (temp>64))
    {
        Error_Message("Rossz az �j cim:0-64 k�z�tt lehet!");
        return;
    }

    if (Application->MessageBox("�j cimet be�gessem?", "�j cim k�rd�s.",MB_YESNO	) == IDYES  )
    {
       setNewAddr(temp);
    }
}
//---------------------------------------------------------------------------

