#include <direct.h>
#include "stdafx.h"
#include "l3d.h"
#include "FileParserExecutor.h"

FileParserExecutor::FileParserExecutor(const char* fname_a, bool& result_a) : 
                                                              FileParser(fname_a,result_a)
{   
    DWORD dwThreadId;  

    hThread_m = CreateThread( NULL, 
                              0, 
                              FileParserExecutor::execute, 
                              this, 
                              CREATE_SUSPENDED, 
                              &dwThreadId);

    if (hThread_m == NULL) 
    {
        char msg[100];
        result_a = false;
        sprintf(msg,"FileParserExecutor: CreateThread ,error_code:%d",GetLastError());
        LEO_ASSERT(0, msg);
        return;
    }

    if (!CreateEvent( NULL,FALSE,FALSE,_T("TESTSCRIPTEVENT") ))
    {
        char msg[100];
        result_a = false;
        sprintf(msg,"FileParserExecutor: CreateEvent ,error_code:%d",GetLastError());
        LEO_ASSERT(0, msg);
        return;
     }
     hEvent_m = OpenEvent( EVENT_ALL_ACCESS,TRUE,_T("TESTSCRIPTEVENT"));
     if(!hEvent_m)
     {
        char msg[100];
        result_a = false;
        sprintf(msg,"FileParserExecutor: OpenEvent ,error_code:%d",GetLastError());
        LEO_ASSERT(0, msg);
        return;
     }
}

FileParserExecutor::~FileParserExecutor()
{   
    CloseHandle(hEvent_m); 
    CloseHandle(hThread_m);
}

DWORD WINAPI FileParserExecutor::execute( void* thread ) 
{
    int res;
    try
    { 
      res = ((FileParserExecutor*)thread)->run(); 
    } 
    catch(...)
    { 
        char msg[100];
        sprintf(msg,"FileParserExecutor: run execute ,error_code:%d",GetLastError());
        LEO_ASSERT(0, msg);
    }
    return res;
}

int FileParserExecutor::run()
{
    LEO_ASSERT(fhandler_m != NULL, "FileParserExecutor: file handler bad!");
   
    while(fhandler_m && !feof(fhandler_m))
    {
        int typ=-999;
        char keybuf[256], szov[256];
        fscanf(fhandler_m,"%s", keybuf);                     // read code until space
        
        if ((keybuf[0] == '/') && (keybuf[1] == '/')) 
        {
            while(!feof(fhandler_m))
            {
                if (getc(fhandler_m) == 0x0a)
                    break;
            }
            continue;
        }

        if( isdigit(keybuf[0]) || keybuf[0] == '-' )
            sscanf( keybuf, "%d", &typ);
        else
        {
            typ = name_to_opcode( keybuf );
        } 

        switch(typ)
        {
            case 900:                                 //wait
            { 
                if (WaitForSingleObject(hEvent_m,INFINITE)==WAIT_ABANDONED)
                    break;
                ResetEvent(hEvent_m);
                break;
            }
            case 901:                                // comment
            {
                fgets(szov,80,fhandler_m);
                fscanf(fhandler_m,"\n");
                break;
            }
            case 902:                                //renderer
            {
                              
                break;
            }
            case 903:                                //load molecule
            {
                char arg1[256],arg2[10];
                fscanf(fhandler_m,"%s",arg1);
                fscanf(fhandler_m,"%s",arg2); 
                char path_filename[256];

                _getdcwd(_getdrive(),path_filename,256);
                strcat(path_filename,"\\");
                strcat(path_filename,arg1);

                if (vmd_if_m->load_molecule(-1,path_filename,arg2,NULL) < 0)
                {
                    return -1;
                }
                break;
            }
            case 904:                                //close all molecule
            {
                vmd_if_m->delete_all_molecules();
                break;
            }
            case 905:                                 //move molecule
            {
                int molid = 0;
                float f_xx = 0.0f;
                float f_yy = 0.0f;
                float f_zz = 0.0f;
                fscanf(fhandler_m,"%d",&molid);
                fscanf(fhandler_m,"%f",&f_xx);
                fscanf(fhandler_m,"%f",&f_yy);
                fscanf(fhandler_m,"%f",&f_zz);

                Matrix4 mm;  // unit matrix
                mm.translate(f_xx, f_yy, f_zz); 
                
                vmd_if_m->add_transform_vmd(l3dMOLECULE_OR_GRAPHICSott, 
                                                molid, 
                                                mm);
                break;
            }
            case 906:                                //move molecule center
            {
                vmd_if_m->do_zoom_all();                
                break;
            }
            case fparUNKNOWN_COMMAND:
                continue;
            
        }
    }
    return 1;
}

void FileParserExecutor::continue_execute()
{
     SetEvent(hEvent_m);
}

int FileParserExecutor::start_execute(VMDinterface* vmd_if_a)
{
    vmd_if_m = vmd_if_a;
    LEO_ASSERT((vmd_if_m!=NULL) ? true : false, 
               "FileParserExecutor VMDinterface pointer NULL!");
    return ResumeThread(hThread_m);
}

