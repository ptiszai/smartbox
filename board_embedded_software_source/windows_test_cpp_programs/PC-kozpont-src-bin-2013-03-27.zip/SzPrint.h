//---------------------------------------------------------------------------

#ifndef SzPrintH
#define SzPrintH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <QRPrntr.hpp>
#include <ExtCtrls.hpp>
#include <QuickRpt.hpp>
#include <QRCtrls.hpp>
//---------------------------------------------------------------------------
class TSzPr : public TForm
{
__published:	// IDE-managed Components
    TQRPreview *QRPreview;
    TQuickRep *QuickRep;
    TQRLabel *QRLabel1;
    TQRMemo *LogMemo;
    TQRBand *TitleBand1;
private:	// User declarations
public:		// User declarations
    __fastcall TSzPr(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSzPr *SzPr;
//---------------------------------------------------------------------------
#endif
