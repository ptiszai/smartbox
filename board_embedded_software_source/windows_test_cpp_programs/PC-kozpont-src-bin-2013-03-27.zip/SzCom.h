//---------------------------------------------------------------------------

#ifndef PicoComH
#define PicoComH
//---------------------------------------------------------------------------
#include <Classes.hpp>

#define PICO                // new pico system.
//----------------------------------------------------------------------------
#define MAXBLOCK            128
#define MAX_REC_LENGTH      1000
#define BLOCKNUM			1
#define SEND_BASE_LENGTH	10
#define BYTENUM_PLACE		7
//#define MAXLEN_TEMPSTR  81

#define RXQUEUE         	300
#define TXQUEUE         	128

#define	COM1				"COM1:"
#define	COM2				"COM2:"

// serial communication: receive command.
#define COM_FRAME_START      ':'
#define COM_FRAME_KOZP_START      '?'
#define COM_FRAME_EE_KOZP_START 'e'
#define COM_FRAME_WR_KOZP_START 'w'
#define COM_FRAME_STOP      '\x0d'

#define CMDR_V              'V'
#define CMDR_v              'v'
#define CMDR_d              'd'
#define CMDR_D              'D'
#define CMDR_B              'b'
#define CMDR_F              'f'
#define CMDR_Q              'q'
#define CMDR_C              'C'
#define CMDR_c              'c'
#define CMDR_G              'g'
#define CMDR_J              'j'
#define CMDR_I              'i'
#define CMDR_H              'h'
#define CMDR_L              'l'
#define CMDR_K              'k'
#define CMDR_m              'm'
#define CMDR_M              'M'
#define CMDR_P              'p'
#define CMDR_R              'r'
#define CMDR_A              'a'
#define CMDR_e              'e'
#define CMDR_E              'E'
#define CMDR_O              'o'
#define CMDR_S              'S'
#define CMDR_s              's'
#define CMDR_T              't'
#define CMDR_W              'w'
#define CMDR_u              'u'
#define CMDR_U              'U'
#define CMDR_Y              'Y'
#define CMDR_y              'y'
#define CMDR_X              'x'
#define CMDR_BOOT           ':'
// serial communication: send command.
#define CMDS_D              'D'
#define CMDS_d              'd'
#define CMDS_B              'B'
#define CMDS_E              'E'
#define CMDS_F              'F'
#define CMDS_J              'J'
#define CMDS_I              'I'
#define CMDS_H              'H'
#define CMDS_L              'L'
#define CMDS_K              'K'
#define CMDS_M              'M'
#define CMDS_m              'm'
#define CMDS_N              'N'
#define CMDS_O              'O'
#define CMDS_P              'P'
#define CMDS_R              'R'
#define CMDS_G              'G'
#define CMDS_V              'V'
#define CMDS_v              'v'
#define CMDS_X              'X'
#define CMDS_A              'A'
#define CMDS_S              'S'
#define CMDS_T              'T'
#define CMDS_C              'C'
#define CMDS_c              'c'
#define CMDS_Q              'Q'
#define CMDS_W              'W'
#define CMDS_U              'U'
#define CMDS_u              'u'
#define CMDS_Y              'Y'
#define CMDS_y              'y'
#define CMDS_X              'X'
#define CMDS_FELKIALTO      '!'

enum {COM_SEND_CMD_V=1,COM_SEND_CMD_v,COM_SEND_CMD_X,COM_SEND_CMD_D,COM_SEND_CMD_E,COM_SEND_CMD_S,COM_SEND_CMD_C,COM_SEND_CMD_c,
      COM_SEND_CMD_Q,COM_SEND_CMD_W,COM_SEND_CMD_B,COM_SEND_CMD_G,COM_SEND_CMD_J,COM_SEND_CMD_K,COM_SEND_CMD_L,
      COM_SEND_CMD_M,COM_SEND_CMD_P,COM_SEND_CMD_R,COM_SEND_CMD_T,COM_SEND_CMD_U,COM_SEND_CMD_u,COM_SEND_CMD_Y,
	  COM_SEND_CMD_I,COM_SEND_CMD_A,COM_SEND_BL,COM_SEND_CMD_F,COM_SEND_CMD_N,COM_SEND_CMD_FELKIALTO,COM_SEND_CMD_H,
      COM_SEND_CMD_m,COM_SEND_CMD_d,COM_SEND_CMD_O,COM_ALL_SEND_CMD,COM_KOZP_SEND_CMD,COM_KOZP_EE_SEND_CMD,COM_KOZP_WR_SEND_CMD};

typedef enum {SEND=0, RECEIVE, ALL} MODE;

#define EE_UNIT_MAX			20
#define EE_UNITS_LENGTH		64
#define EE_UNIT_TIME_BASE	10  //ms

typedef struct
{
    bool Enable;
    unsigned short Port;
    MODE Mode;
    WORD Baudrate;
    Byte ByteSize;
    Byte Parity;
    Byte StopBits;
}COM_SET;


class TUSB;

//----------------------------------------------------------------------------
class Tcom
{
	private:

        HANDLE		hPort;
        char		Port[5];
    	static const char** com_error_header;
        short       thread_num;
        bool __fastcall Rec_Checked_CHS_and_end(void);
 	public:
        static enum { COM_OPEN_ERROR=0, COM_GETSTATE_ERROR, COM_SETSTATE_ERROR,
        			  COM_PURGE_ERROR, COM_SETMASK_ERROR, COM_SETTIMEOUT_ERROR,
                      COM_SET_CONFIG_ERROR, COM_GET_CONFIG_ERROR,
                      COM_SET_TIME_ERROR, COM_GET_TIME_ERROR,
                      COM_GET_REAL_DATA_ERROR, COM_GET_TEST_DATA_ERROR,
                      COM_SET_TEST_FFFF_ERROR, COM_SET_RESET_ERROR,
                      COM_SET_DEFAULT_CONFIG_ERROR, COM_OK_ENQ_ERROR, COM_NOK_ENQ_ERROR,
                      COM_GETWARNING_ERROR,COM_NORESPONSE_ERROR,} com_error_code;
        DCB			dDCB;
        OVERLAPPED  osRead;
        OVERLAPPED  osWrite;
        DWORD	    dwBytesWritten;
        BYTE        abIn[(MAXBLOCK*BLOCKNUM)+1];
        UCHAR       recbuff[100];
        UCHAR       sendbuff[100];
        DWORD       dwLength;
  	    __fastcall Tcom(const char*,WORD, Byte, Byte, Byte, bool&);
        __fastcall ~Tcom(void);
        __fastcall HANDLE Get_hPort(void){return hPort; };
        __fastcall DWORD ReadCom( LPSTR lpszBlock, int nMaxLength );
        DWORD __fastcall WriteCom(char* buf,int len);
		bool __fastcall ClearCommErr( HANDLE hFile, LPDWORD dwErrors, LPCOMSTAT ComStat, bool);
};
//---------------------------------------------------------------------------

typedef enum { SET_CONFIG=0, GET_CONFIG, SET_TIME, GET_TIME, GET_REAL_DATA,
			   GET_TEST_DATA, SET_TEST_FFFF, SET_RESET, SET_DEFAULT_CONFIG,
               OK_ENQ, NOK_ENQ, GET_WARNING } COMMAND;

//---------------------------------------------------------------------------
class SzCom : public TThread
{            
private:
    static const char  com_frame[50];
    Tcom*       com;
    bool        bBootLoad;
    DWORD       rxBytes;
    bool	    error;
    char        errorstr[50];
protected:
    void __fastcall Execute();
    void __fastcall CompleteRequest(void);
public:
    bool bOpen, bError;
    int m_logprint, m_logindex ;
    char m_lamplog[50000];
  //  int pline;
    TUSB* usb;
    COM_SET* com_set;
    __fastcall SzCom(bool CreateSuspended, COM_SET* cs);
    void __fastcall StopThread(void);
    DWORD __fastcall Send(char* msg, int len);
    DWORD __fastcall SendNoDump(char* msg, int len);
};
//---------------------------------------------------------------------------
extern BOOL dump(  void *buf, unsigned long len );
#endif
