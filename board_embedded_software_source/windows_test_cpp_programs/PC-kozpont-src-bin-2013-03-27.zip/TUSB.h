//---------------------------------------------------------------------------

#ifndef KerUSBH
#define KerUSBH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <stdio.h>
#include <string.h>
#include "FTD2XX.h"
//#include "define.h"


//#define MAX_REC_LENGTH      50
//---------------------------------------------------------------------------

//typedef enum {SEND=0, RECEIVE, ALL} MODE;

//---------------------------------------------------------------------------

class TViewForm;

class MyException
{
  public:
  MyException(char* s = "Unknown"){ what = strdup(s);      }
  MyException(const MyException& e ){ what = strdup(e.what); }
 ~MyException()                   { delete[] what;         }
  char* msg() const             { return what;           }
private:
  char* what;

};


class TUSB
{
private:
    unsigned char* u_recbuff,*u_sendbuff;
    TViewForm *fr;
    DWORD       rxBytes;
    bool        bmode;          //start, stop.
    unsigned int uiSumUSBError;
    CRITICAL_SECTION    m_CS;
protected:
    const char* __fastcall GetDeviceSerNo(void);
public:
	bool	error;
    HANDLE  hPort;
    HANDLE  hEvent;
    bool        NotOpenUSB;
    int         u_RecLength;
	__fastcall TUSB(void);
    __fastcall ~TUSB(void);
    void __fastcall Execute();
    bool __fastcall Init(TViewForm*, unsigned char*, unsigned char*);
    void __fastcall StopThread(void);

//    DWORD __fastcall Send(int, UCHAR* data=NULL);
    void __fastcall GetDevice(void);
    void __fastcall Reset(void);
    void __fastcall IncErrorCounter(bool bClear=false, bool bView=true);
    unsigned int& __fastcall uiSumUSBErrorG(void){return uiSumUSBError;};
    void __fastcall uiSumUSBErrorS(unsigned int& uiEc){ uiSumUSBError=uiEc;};
    DWORD __fastcall u_ReadCom( int );
    DWORD __fastcall u_WriteCom(int );
    void __fastcall  ClearReadComBuffer(void);
};
extern TUSB*   usb;

//VALID GetDataValide;
//---------------------------------------------------------------------------
#endif
