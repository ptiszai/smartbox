/***
 *  SeErrorHandler.h : Definition of ErrorHandler functions and DEFINE-s
 *
 *  Revision : 1.0 (A. Tagscherer)
 *  Date     : 25/08/01
 *  Copyright (c) 2001 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/
#ifndef __SEERRORHANDLER_H_
#define __SEERRORHANDLER_H_

#include "SeCString.h"
#include "SeUtils.h"
#include <winerror.h>
#ifdef IPL_LIB_INCLUDED
    #include "ipl.h"
    #include "iplerror.h"
#endif	//IPL_LIB_INCLUDED
#ifdef IJL_LIB_INCLUDED
    #ifdef USE_IJL20
        #include "ijl20.h"
    #else
        #include "ijl.h"
    #endif
#endif	//IJL_LIB_INCLUDED

#define ERRORLOGFILENAME    _T("ErrorLog.log")
#define ERRORLOGFILEEXT     _T("ERR")

LPCTSTR __SeModuleNameFromSourceFileName(LPCTSTR SourceFileName,LPCTSTR ModuleExt,LPTSTR Buffer,long BufferSize);


class CSeErrorLogFile
{
private:
    bool                m_Created;
	bool				m_NeedToLog;
	bool				m_SimpleLog;
	CString				m_ProcessFileName;
	CString				m_ModuleFileName;
	CString				m_ModuleName;
    CString             m_FileName;
	CRITICAL_SECTION    m_CrSect;
protected:
	void AddStringLogToFile(const char *FileName,int Line,const char *Function,const TCHAR* String);
	void Init(LPCTSTR ModuleName,bool UseModuleNameAsFileName);
public:
	CSeErrorLogFile(LPCTSTR ModuleCPPName,LPCTSTR ModuleExt,bool UseModuleNameAsFileName);
    CSeErrorLogFile(LPCTSTR ModuleName,bool UseModuleNameAsFileName);
    ~CSeErrorLogFile();
	CString GetFileName() {return m_FileName; }
    void AddErrorLogToFile(const char *FileName,int Line,HRESULT Error,const char *Function = NULL);
	void AddStringFormatLogToFile(const char *FileName,int Line,LPCTSTR lpszFormat,...);
	inline bool IsErrLogActive() { return m_NeedToLog; }
	inline bool IsSimpleLogActive() { return m_SimpleLog; }
};

/////////////////////////////////////////////////////
//Global error checker
/////////////////////////////////////////////////////
//Global error checker

#if defined(_DEBUG) || defined(__ERRORLOGFILE)
    #ifdef __FUNC__
        #define HRES_DEBUGLOG(__HRES)                                               \
            g_ErrorLogFile->AddErrorLogToFile(__FILE__,__LINE__,__HRES,__FUNC__);
    #elif defined(__FUNCION__)
        #define HRES_DEBUGLOG(__HRES)                                               \
            g_ErrorLogFile->AddErrorLogToFile(__FILE__,__LINE__,__HRES,__FUNCTION__);
    #else
        #define HRES_DEBUGLOG(__HRES)                                               \
            g_ErrorLogFile->AddErrorLogToFile(__FILE__,__LINE__,__HRES);
    #endif
#else
    #define HRES_DEBUGLOG(__HRES)
#endif

#define LOGHRESULT(__HRES)                      \
	{											\
		if (__HRES != S_OK)						\
		{                                       \
			HRES_DEBUGLOG(__HRES)               \
		}										\
    }

#define CHECKHRESULT(__HRES)                    \
	{											\
		if (__HRES != S_OK)						\
		{                                       \
			HRES_DEBUGLOG(__HRES)               \
			return __HRES;                      \
		}										\
    }

#define CHECKHRES(__HRES)   					\
    {                                           \
        HRESULT __LRV = __HRES;                 \
		CHECKHRESULT(__LRV)						\
    }

#define CHECKHRESTOBOOL(__HRES)					\
	{											\
        HRESULT __LRV = __HRES;                 \
		LOGHRESULT(__LRV)						\
		if ( FAILED(__LRV) )					\
			return false;                       \
	}

#define CHECKBOOLTOHRES(__BOOLRETVAL)      		\
	{											\
		if ( !__BOOLRETVAL )                    \
			CHECKHRESULT(E_FAIL)				\
	}

#define BOOLTOHRES(__BOOLRETVAL)	    		\
	{											\
		if ( !__BOOLRETVAL )                    \
			CHECKHRESULT(E_FAIL)				\
		else									\
			return S_OK;						\
	}

#define HRESTOBOOL(__HRES)   					\
	{											\
		HRESULT __LRV = __HRES;					\
		LOGHRESULT(__LRV)						\
		if ( SUCCEEDED(__LRV))					\
			return true;                        \
		else                                    \
			return false;						\
	}

#define CHECKHRESULTANDPTR(__HRES,__POINTER)	\
	{											\
		CHECKHRESULT(__HRES)                    \
		if ((void*)__POINTER == NULL)			\
			CHECKHRESULT(E_POINTER);			\
	}

#define CHECKHRESULTANDSMARTCOM(__HRES,__COM)	\
	{											\
		CHECKHRESULT(__HRES)                    \
		if (__COM.p == NULL)					\
		CHECKHRESULT(E_FAIL);					\
	}

#define CHECKWIN32ERROR(__HRES)					\
	{											\
		if (__HRES != NO_ERROR)					\
			CHECKHRESULT(HRESULT_FROM_WIN32(__HRES)); \
	}

#define GETWIN32ERROR()                         \
    {                                           \
        DWORD __le = GetLastError();            \
        HRESULT hr = HRESULT_FROM_WIN32(__le);  \
        CHECKHRESULT(hr)                        \
    }

#ifdef IPL_LIB_INCLUDED

#define IPL_FACILITY_CODE	(0x0100)
#define IPL_TO_HRESULT(__IPL)	((__IPL) ? ((HRESULT) (((__IPL) & 0x0000FFFF) | (IPL_FACILITY_CODE << 16) | 0x80000000)) : 0 )
#define RETURNIPLERROR()						\
    {                                           \
        HRESULT hr = IPL_TO_HRESULT(iplGetErrStatus()); \
		iplSetErrStatus(IPL_StsOk);				\
        CHECKHRESULT(hr)                        \
    }
#define GETIPLERROR()							\
    IPL_TO_HRESULT(iplGetErrStatus());			\
	iplSetErrStatus(IPL_StsOk);					\

#endif	//IPL_LIB_INCLUDED

#ifdef IJL_LIB_INCLUDED

#define IJL_FACILITY_CODE	(0x0101)
#define IJL_TO_HRESULT(__IJL)	((__IJL) ? ((HRESULT) (((__IJL) & 0x0000FFFF) | (IJL_FACILITY_CODE << 16) | 0x80000000)) : 0 )
#define CHECKIJLERROR(__IJL)					\
    {                                           \
        HRESULT hr = IJL_TO_HRESULT(__IJL);		\
        CHECKHRESULT(hr)                        \
    }

#endif  //IJL_LIB_INCLUDED


//Windows hibak�db�l hibastring k�sz�t�se
bool SeFormatErrorMessage(HRESULT MsgCode,bool AlwaysGetString,CString** MsgString);
//Windows hibak�db�l hibastring k�sz�t�se, �s hibaablak megjelen�t�se a k�perny�n
bool SeShowErrorMessage(HRESULT MsgCode,bool AlwaysGetString);


/////////////////////////////////////////////////////
//Global error checker
#define CHKHRESANDSHOWMESSAGE(__HRES,RESTYPE,RESVAL) \
	{											\
		if (__HRES != S_OK)                     \
		{                                       \
			HRES_DEBUGLOG(__HRES)               \
			SeShowErrorMessage(__HRES,true);	\
			return (RESTYPE)RESVAL;             \
		}										\
	}
#define CHKHRESANDSHOWMESSAGENOTERVALUE(__HRES)	\
	{											\
		if (__HRES != S_OK)                     \
		{                                       \
			HRES_DEBUGLOG(__HRES)               \
			SeShowErrorMessage(__HRES,true);	\
			return;								\
		}										\
	}
#define CHKHRESANDSHOWMESSAGENORETURN(__HRES)	\
	{											\
		if (__HRES != S_OK)                     \
		{                                       \
			HRES_DEBUGLOG(__HRES)               \
			SeShowErrorMessage(__HRES,true);	\
		}										\
	}


extern CSeSmartPtr<CSeErrorLogFile>		g_ErrorLogFile;
//CSeSmartPtr<CSeErrorLogFile> g_ErrorLogFile = new CSeErrorLogFile(__FILE__,_T("DLL"),false);



#endif	//__SEERRORHANDLER_H_

