//---------------------------------------------------------------------------

 /*
 * altalanos lekerdezes,parancsok.
 * A:';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.
 * A:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 * szimpla uzenet, max. 20 byte.
 * A:'M',num,"uzenet.."
 *
 * allomas cimek szamanak a lekerdezese.
 * A:';',lcim,0x00,0x00,0x91,num,chs  // allomas cimek szama a num-ban
 *
 * allomas cimek lekerdezese.
 * A:'N',lcim,0x92,num,a0..an,chs  // allomas cimek.
 *
 * PC parancsok:
 * max. addres kuldese a PC-nek.
 * A:'p',lcim,0x02,max_addrl,max_addrh,chs	 
 *
 */
#include <vcl.h>
#pragma hdrstop

#include "SzHurok.h"
#include "SzCom.h"
#include "USB.h"
#include "kliens_test.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
THurokForm *HurokForm;
//---------------------------------------------------------------------------
__fastcall THurokForm::THurokForm(TComponent* Owner)
    : TForm(Owner),
    m_VeteliHibaFlag(false)
{
}
//---------------------------------------------------------------------------
void __fastcall THurokForm::ExitBtnClick(TObject *Sender)
{
    Close();    
}
//---------------------------------------------------------------------------
void __fastcall THurokForm::SendBtnClick(TObject *Sender)
{
//
    char msg[10];
    char temp = 0x0f;
    int  imax = 0;

    msg[0] = 's';
    msg[1] = 'k';
    msg[2] = (char)HAddrComboBx->ItemIndex+1;
    msg[8] = 0;
  //  msg[3] = (char)(AllomasCimEdit->Text.ToInt()/256);
  //  msg[4] = (char)(AllomasCimEdit->Text.ToInt()%256);
   /* if (SErCBox->State == cbChecked)
    {
        msg[3] = 0;
        msg[4] = 0;
        msg[5] = 0;
        msg[6] = 1;
        msg[7] = 1;
        imax = 7;
    }
    else
    {   */
        msg[3] = (char)(AllomasCimEdit->Text.ToInt()/256);
        msg[4] = (char)(AllomasCimEdit->Text.ToInt()%256);
        if (ToltesCBox->State == cbChecked)
            temp &= 0x0e;
        if (AkkuCBox->State == cbChecked)
            temp &= 0x0d;
        if (FCSCBox->State == cbChecked)
            temp &= 0x0b;
        msg[5] = temp;
        temp = 0;
     /*   switch (VeteliHibaCBox->ItemIndex)
        {
            case 1:
                temp = 0x02; //nem mukodik
                break;
            case 2:
                temp = 0x01;   //vetel hiba
             break;
            case 3:
                temp = 0x04;   //adat hiba
            break;
        }   */

        if (SErCBox->State == cbChecked)
        {
              temp = 0x02;
              m_VeteliHibaFlag = true;
        }
        else
        {
            if (m_VeteliHibaFlag)
                temp = 0x40;
            m_VeteliHibaFlag = false;
        }
        msg[6] = temp;
        msg[7] = 0;
        imax = 7;
  //  }

    for (int ii=2;ii<imax;ii++)
        msg[8] += msg[ii];
    
    ComThread->Send(msg,9);
    if (UsbThread)
        UsbThread->Send(msg,9);
}
//---------------------------------------------------------------------------

