//---------------------------------------------------------------------------

#ifndef SzHurokH
#define SzHurokH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class THurokForm : public TForm
{
__published:	// IDE-managed Components
    TButton *ExitBtn;
    TComboBox *ParancsCBox;
    TLabel *Label1;
    TButton *SendBtn;
    TLabel *Label2;
    TComboBox *HAddrComboBx;
    TGroupBox *GroupBox1;
    TEdit *AllomasCimEdit;
    TLabel *Label3;
    TCheckBox *ToltesCBox;
    TCheckBox *AkkuCBox;
    TCheckBox *FCSCBox;
    TLabel *Label4;
    TComboBox *VeteliHibaCBox;
    TLabel *Label5;
    TCheckBox *SErCBox;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall SendBtnClick(TObject *Sender);
private:	// User declarations
    bool    m_VeteliHibaFlag;
public:		// User declarations
    __fastcall THurokForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE THurokForm *HurokForm;
//---------------------------------------------------------------------------
#endif
