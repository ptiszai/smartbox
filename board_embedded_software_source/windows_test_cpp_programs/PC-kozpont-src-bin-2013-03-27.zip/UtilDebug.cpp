/***
 *  UtilDebug.cpp : Implementation of some debug utility classes
 *
 *  Revision : 1.0 (G. CSENDES)
 *  Date     : 10/07/00
 *  Copyright (c) 2000 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/
//////////////////////////////////////////////////////////////////
// UTILITY
//----------------------------------------------------------------
// File:    UtilDebug.cpp
// By:      G. CSENDES
// Content: Debug es Log class

#include "stdafx.h"
#ifndef exit
#   include <stdlib.h>
#endif
#include "UtilDebug.h"
#include <malloc.h>

#pragma hdrstop

//#ifdef _DEBUG

LogFile LF;

//////////////////////////////////////////////////////////////////
// konstruktor
LogFile::LogFile()
{
	szLogFile = NULL;
    m_Initialized = false;
}

//////////////////////////////////////////////////////////////////
// destruktor
LogFile::~LogFile()
{
	if (szLogFile)
		delete szLogFile;
	szLogFile = NULL;
}

//////////////////////////////////////////////////////////////////
// naplo file initcializalasa
bool LogFile::Init(const char *fName)
{
	szLogFile = new char[strlen(fName) + 1];
    strcpy(szLogFile, fName);
	FILE *fpLog;
    if ( (fpLog=fopen(fName,"wt")) != NULL)
	{
        fclose(fpLog);
        m_Initialized = true;
		return false;
	}
	else
    {
        m_Initialized = false;
		return true;
    }
}

bool LogFile::InitCurrTime(const char* name)
{
	char *path = (char*)_alloca(strlen(name) + 19);

	strcpy(path,name);

    SYSTEMTIME sysTime;
    GetLocalTime(&sysTime);
    wsprintf(path, "%s%02d-%02d_%02d-%02d-%02d.log", 
             (name?name:""), 
             sysTime.wMonth, sysTime.wDay, 
             sysTime.wHour, sysTime.wMinute, sysTime.wSecond);
	return Init(path);
}

//////////////////////////////////////////////////////////////////
// iras a naplo file-ba
void LogFile::Print(char *text)
{
    if (!m_Initialized)
        return;
	FILE *fpLog;
    if ( (fpLog=fopen(szLogFile,"at")) != NULL)
    {
        PrintTime(fpLog);
        fprintf(fpLog,"%s\n",text);
        fclose(fpLog);
    }
}

void LogFile::Print(char *text1, char *text2)
{
    if (!m_Initialized)
        return;
	FILE *fpLog;
    if ( (fpLog=fopen(szLogFile,"at")) != NULL)
    {
        PrintTime(fpLog);
        fprintf(fpLog,"%s%s\n",text1, text2);
        fclose(fpLog);
    }
}

void LogFile::Print(char *text, int num)
{
    if (!m_Initialized)
        return;
	FILE *fpLog;
    if ( (fpLog=fopen(szLogFile,"at")) != NULL)
    {
        PrintTime(fpLog);
        fprintf(fpLog,"%s%d\n",text, num);
        fclose(fpLog);
    }
}

void LogFile::Print(char *text, double num)
{
    if (!m_Initialized)
        return;
	FILE *fpLog;
    if ( (fpLog=fopen(szLogFile,"at")) != NULL)
    {
        PrintTime(fpLog);
        fprintf(fpLog,"%s%f\n",text, num);
        fclose(fpLog);
    }
}

void LogFile::Printf(const char* Fmt, ...)
{
    if (!m_Initialized)
        return;
	FILE *fpLog;
    va_list _ap;
    if ( (fpLog=fopen(szLogFile, "at")) != NULL)
    {
        PrintTime(fpLog);
        va_start(_ap, Fmt);
		vfprintf(fpLog,Fmt,_ap);
        fclose(fpLog);
    }
}

void LogFile::PrintTime(FILE* fp)
{
    if (!m_Initialized)
        return;
    SYSTEMTIME now;
    GetLocalTime(&now);

    fprintf(fp, "[%02u:%02u:%02u'%02u] ",
        now.wHour, now.wMinute, now.wSecond, now.wMilliseconds / 10);
}

//////////////////////////////////////////////////////////////////
// ASSERT - hiba kezelo
void SE_Assert(const char *file, int line, const char *msg)
{
    int result;
    static char buf[1024];

    sprintf(buf, "Assertion Failed  %s  line: %d   [ %s ]", file, line, msg);

    // kiirni a log filba is
    SE_DEBUG(buf);

//    if (AfxAssertFailedLine(file,line)
//		AfxDebugBreak();

       // es a kepernyore
    result = MessageBox(NULL, buf, "Assertion Failure", MB_OKCANCEL | MB_APPLMODAL | MB_ICONERROR);

    // ha cancelt nyomott, akkor viszlat
    if(result == IDCANCEL)
    {
        SE_DEBUG("Program aborted...");
#ifndef __CONSOLE
        PostQuitMessage(0);
#else
        exit(0);
#endif
    }
}

//#endif //_DEBUG

