//---------------------------------------------------------------------------

#include <vcl.h>
#include <fstream.h>
#include <stdio.h>
#pragma hdrstop

#include "SzCom.h"
#include "kliens_test.h"
#include "TUSB.h"
#include "Szprt.h"
#include "kliens_test.h"
//#include "util.h"

#pragma package(smart_init)

//#define NOT_USB
//TUSB*  USb;

extern double ElapsidTime(bool);
extern HWND    BHandle;
//extern TMainTest *MainTest;
TUSB*       usb;

//---------------------------------------------------------------------------
void PrintErrorStatus(HANDLE hand, DWORD dwErrorFlags)
{
    char msg[100];

    sprintf(msg,"COM%d: Com Error: ",usb->hPort);

    switch(dwErrorFlags)
    {
        case CE_BREAK:
            strcat(msg,"BREAK");
            break;
        case CE_DNS:
            strcat(msg,"DNS");
            break;
        case CE_FRAME:
            strcat(msg,"FRAME");
            break;
        case CE_IOE:
            strcat(msg,"IOE");
            break;
        case CE_MODE:
            strcat(msg,"MODE");
            break;
        case CE_OOP:
            strcat(msg,"OOP");
            break;
        case CE_OVERRUN:
            strcat(msg,"OVERRUN");
            break;
        case CE_PTO:
            strcat(msg,"PTO");
            break;
        case CE_RXOVER:
            strcat(msg,"RXOVER");
            break;
        case CE_RXPARITY:
            strcat(msg,"RXPARITY");
            break;
        case CE_TXFULL:
            strcat(msg,"TXFULL");
            break;
    }
    XTPrintf(msg);
    usb->IncErrorCounter();
}//void PrintErrorStatus(DWORD dwErrorFlags)


/**************************************************************************
 *    USB class part.
 *************************************************************************/

__fastcall TUSB::TUSB(void)
{
    char buff[30];
    NotOpenUSB=false;
    hPort = NULL;
    rxBytes = 5;
    IncErrorCounter(true);
    ::InitializeCriticalSection(&m_CS);

    sprintf(buff,"%d",hPort);
}

//---------------------------------------------------------------------------
void __fastcall TUSB::Execute()
{
#ifdef  NOT_USB
    return;
#endif

    FT_STATUS  ftStatus;
    DWORD RxBytes;


    if (hPort==NULL)
        return;


    if (hPort==NULL || NotOpenUSB)
        return;
         
    if (WaitForSingleObject(hEvent,INFINITE)==WAIT_ABANDONED)
            return;

    //Sleep((unsigned long)30);

    ftStatus=FT_GetQueueStatus(hPort,&RxBytes);
    
    if (!FT_SUCCESS(ftStatus))
        return;

    if (RxBytes != 8)
    {
        char msg[50];
        sprintf(msg,"vetel: 8 byte helyett %d byte",RxBytes);
        XTPrintf(msg);
        char temp;
        DWORD iBytesReadThisTime=0;
        for (int i=0;i<RxBytes; i++)
            FT_Read(hPort,&temp,1,&iBytesReadThisTime);
        //return;
    }
    else
    if ( RxBytes > 0 )
    {
        u_RecLength=u_ReadCom(RxBytes);
        if (!u_RecLength)
        {
            XTPrintf("Rec Error");
     //       IncErrorCounter();
            ClearReadComBuffer();
        }
    }
    RxBytes=0;
    ResetEvent(hEvent);
}//Execute()

//---------------------------------------------------------------------------
void __fastcall TUSB::StopThread(void)
{
    SetCommMask( hPort, 0);
}//StopThread(void)

//---------------------------------------------------------------------------

void __fastcall TUSB::IncErrorCounter(bool bClear, bool bView)
{

#ifdef  NOT_USB
    return;
#endif
    char msg[50];

    if (bView)
    {
        if (bClear)
            uiSumUSBError=0;
        else
            ++uiSumUSBError;

        sprintf(msg,"Hiba:USB:%d",uiSumUSBError);
        XTPrintf(msg);
      //  MainTest->StatusBar->Sections->Items[0]->Text=msg;
    }
    if (uiSumUSBError)
    {  // Error.
     //  MainTest->Timer->Enabled=false;
       DWORD RxBytes;
       FT_STATUS  ftStatus;
       while (true)
       {
            Sleep((unsigned long)10);
            ftStatus=FT_GetQueueStatus(hPort,&RxBytes);
            if (RxBytes > 50)
                RxBytes = 49;
            if (!FT_SUCCESS(ftStatus))
                continue;
            if (!RxBytes)
                break;
          // DWORD iBytesReadThisTime=0;
           char temp;
           for (int i=0;i<RxBytes; i++)
                FT_Read(hPort,&temp,1,NULL);
            //u_ReadCom( RxBytes);
       }
      // MainTest->Timer->Enabled=true;
    }
}//IncErrorCounter(bool bClear)

//---------------------------------------------------------------------------
void __fastcall TUSB::GetDevice(void)
{

//NotOpenUSB=true;
return;

 /*   FT_DEVICE ftDevice;
    FT_STATUS ftStatus;
    DWORD deviceID;
    char SerialNumber[16];
    char Description[64];

    ftStatus = FT_GetDeviceInfo( hPort,
		    &ftDevice,
		    &deviceID,
		    SerialNumber,
		    Description,
		    NULL);
    if (ftStatus == FT_OK)
    {
	    if (ftDevice == FT_DEVICE_BM)
		XTPrintf("USB device is FT232BM or FT245BM.");
	    else if (ftDevice == FT_DEVICE_AM)
		; // device is FT8U232AM or FT8U245AM
	    else if (ftDevice == FT_DEVICE_100AX)
		; // device is FT8U100AX
	    else
		; // unknown device (this should not happen!)
	// deviceID contains encoded device ID
	// SerialNumber, Description contain 0-terminated strings
    }
    else
    {
	// FT_GetDeviceType FAILED!
    }
    unsigned long RxBytes;
    ftStatus=FT_GetQueueStatus (hPort,&RxBytes );
    if (!FT_SUCCESS(ftStatus))
        return;
    sprintf(Description,"USB receive num:[%d]",RxBytes);
     XTPrintf(Description);
    u_ReadCom( RxBytes);
    */
}//GetDevice(..)

//---------------------------------------------------------------------------
const char* __fastcall TUSB::GetDeviceSerNo(void)
{

#ifdef  NOT_USB
   // return NULL;
#endif

    char* serno = new char(32);
    DWORD devIndex = 0;
    FT_STATUS ftStatus;
    ftStatus = FT_ListDevices((PVOID)devIndex,(PVOID)serno,FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER);
    if (!FT_SUCCESS(ftStatus))
        return NULL;
    return  serno;
}//GetDeviceSerNo(void)

/**************************************************************************
 *	Init.
 *************************************************************************/
bool __fastcall TUSB::Init(TViewForm* f,  unsigned char* rbuff, unsigned char* sbuff )
{

#ifdef  NOT_USB
 //   return true;
#endif
 //   NotOpenUSB=true;
//        return false;
    FT_STATUS ftStatus;
    hPort=NULL;
    hEvent=NULL;
    int DevNum = 0;
    char buff[20];
    const char* serno;

    fr=f;
    u_recbuff=rbuff;
    u_sendbuff=sbuff;

    if (!u_recbuff || !u_sendbuff )
        return false;

    try
    {
        serno = GetDeviceSerNo();
        if (!serno)
            throw Exception("USB: Serial number error!");
        ftStatus = FT_OpenEx((PVOID)serno,FT_OPEN_BY_SERIAL_NUMBER,&hPort);
//        ftStatus = FT_Open(DevNum,&hPort);
        if (!FT_SUCCESS(ftStatus))
              throw Exception("USB: Open error!");
        else
        {
            sprintf(buff, "%d open !!", hPort);
          //  XTPrintf(buff);
        }
        FT_ResetDevice(hPort);
        ftStatus = FT_Purge(hPort,FT_PURGE_TX | FT_PURGE_RX);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB:Buffer clear error!" );
        ftStatus = FT_SetBaudRate(hPort,FT_BAUD_9600/*,FT_BAUD_38400 */);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetBaudRate error!" );      
        ftStatus = FT_SetDataCharacteristics( hPort,FT_BITS_8,FT_STOP_BITS_1,FT_PARITY_NONE);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetDataCharacteristics error!" );
        ftStatus = FT_SetFlowControl( hPort,FT_FLOW_NONE,0,0);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetFlowControl error!" );

        hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			        FALSE, // BOOL fManualReset
			        FALSE, // BOOL fInitialState
			        "USB"); // LPTSTR lpszEventName
        if(hEvent == INVALID_HANDLE_VALUE)
            throw Exception( "USB: CreateEvent error!" );
        hEvent=OpenEvent( EVENT_ALL_ACCESS,TRUE,"USB");
        if(hEvent == INVALID_HANDLE_VALUE)
            throw Exception( "USB: OpenEvent error!" );
        ftStatus = FT_SetTimeouts(hPort,100,50);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB:Set Time out error!" );

//        FT_SetUSBParameters (hPort , 100, 100);
    }
    catch  ( const Exception &e )
    {
  /*      ShowMessage(  e.Message + "\n\n"
                  + "An exception of type " + __ThrowExceptionName()
                  + "\nwas thrown by line " + AnsiString(__ThrowLineNumber())
                  + "\nof file " + __ThrowFileName() );  */
        ShowMessage(  e.Message  );
        if (hPort)
            FT_Close(hPort);
        if (bmode)
            bmode=false;
        NotOpenUSB=true;
        if (serno)
            delete serno;
        return false;
    }
    rxBytes=2;
    u_RecLength=0;
  //if (serno)
    //  delete serno;
    return true;
}//bool Init(void)

//---------------------------------------------------------------------------
void __fastcall TUSB::Reset(void)
{
#ifdef  NOT_USB
    return;
#endif
    FT_Close(hPort);
    Sleep((unsigned long)100);
    FT_Open(0,&hPort);
    XTPrintf("DEV0");
}//Reset()

//---------------------------------------------------------------------------
__fastcall TUSB::~TUSB(void)
{
    ::DeleteCriticalSection(&m_CS);
#ifdef  NOT_USB
    return;
#endif
    FT_Close(hPort);
}/* ~com(void) */
//---------------------------------------------------------------------------
void __fastcall  TUSB::ClearReadComBuffer(void)
{
    char buff[301];
   // DWORD iBytesReadThisTime=0;
    ::EnterCriticalSection(&m_CS);
#ifndef  NOT_USB
 //   FT_Read(hPort,buff,200,&iBytesReadThisTime);
    FT_Purge ( hPort, FT_PURGE_RX );
#endif
    ::LeaveCriticalSection(&m_CS);
}
//---------------------------------------------------------------------------
DWORD __fastcall  TUSB::u_ReadCom( int nMaxLength )
{

#ifdef  NOT_USB
    return 1;
#endif

   DWORD iBytesReadThisTime=0;
  // DWORD iBytesRead=0;
   unsigned long iBytesRead=0;
   FT_STATUS  err;

    if ( nMaxLength <= 0)
        return 0;


    while (nMaxLength > 0)
    {
        ::EnterCriticalSection(&m_CS);
        err=FT_Read(hPort,u_recbuff,nMaxLength,&iBytesReadThisTime);
        if (err != FT_OK )
        {
            char msg[50];
            sprintf(msg,"USB Read error:Code=[%d]!!",err);
            XTPrintf(msg);
            IncErrorCounter(false, false);
        }
        else
        {
            nMaxLength -= iBytesReadThisTime;
            iBytesRead += iBytesReadThisTime;
        }
    }
 //  dwLength=iBytesRead;
   if (iBytesRead)
    {
        char msg[40];
        sprintf(msg,"iBytesRead[%d]!!",iBytesRead);
        XTPrintf(msg);    
        dump( u_recbuff, (unsigned long)iBytesRead);
//        dump( u_recbuff, iBytesRead,TestPrintf);
    }
    ::LeaveCriticalSection(&m_CS);
   return iBytesRead;
}/*  DWORD ReadCommBlock(..)*/

//--------------------------------------------------------------------------
DWORD __fastcall TUSB::u_WriteCom(int len)
{
#ifdef  NOT_USB
    return 1;
#endif
    DWORD write;
    FT_STATUS err;

	if (len <= 0)
		return -1;
 //    ElapsedTime(true);
     //ClearReadComBuffer();
    ::EnterCriticalSection(&m_CS);

    err=FT_Write(hPort,u_sendbuff,len,&write);
    if (err != FT_OK )
    {
        char msg[40];
        sprintf(msg,"USB:write error:Code=[%d]!!",err);
        XTPrintf(msg);
        ::LeaveCriticalSection(&m_CS);
        return 0;
    }
    if (write == 0)
    {
          XTPrintf("USB:write error:write=0!!");
    }

    ::LeaveCriticalSection(&m_CS);
    if (write)
        dump(u_sendbuff,len);
    return write;
}//DWORD WriteCom(..)


