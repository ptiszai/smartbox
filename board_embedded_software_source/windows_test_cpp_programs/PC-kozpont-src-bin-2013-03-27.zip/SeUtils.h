/***
 *  SeUtils.h : Definition & Implementation of some utility classes
 *
 *  Revision : 1.0 (A. Tagscherer)
 *  Date     : 10/07/00
 *  Copyright (c) 2000 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/
//#pragma once
#ifndef __SEUTILS_H_
#define __SEUTILS_H_

#include "UtilDebug.h"
#include "SeCString.h"
#include <typeinfo.h>
/////////////////////////////////////////////////////////////////////////////


#define UNUSED_ALWAYS(x) x

typedef struct tagdPOINT
{
    double dX;
    double dY;
} dPOINT;

typedef struct tagdRECT
{
    double dLeft;
    double dTop;
    double dRight;
    double dBottom;
} dRECT;

typedef struct tagVOXEL
{
	long x;
	long y;
	long z;
} VOXEL;

inline RECT MakeRect(long l,long t,long r,long b)
{
    RECT rect;
    rect.left = l;
    rect.top = t;
    rect.right = r;
    rect.bottom = b;
    return rect;
}

inline dRECT dMakeRect(double l,double t,double r,double b)
{
    dRECT rect;
    rect.dLeft = l;
    rect.dTop = t;
    rect.dRight = r;
    rect.dBottom = b;
    return rect;
}

inline POINT MakePoint(long x,long y)
{
    POINT pt;
    pt.x = x;
    pt.y = y;
    return pt;
}

inline dPOINT dMakePoint(double x,double y)
{
    dPOINT pt;
    pt.dX = x;
    pt.dY = y;
    return pt;
}

inline VOXEL MakeVoxel(long x,long y,long z)
{
    VOXEL v;
    v.x = x;
    v.y = y;
    v.z = z;
    return v;
}

inline VOXEL MakeVoxel(POINT pt,long z)
{
    VOXEL v;
    v.x = pt.x;
    v.y = pt.y;
    v.z = z;
    return v;
}

typedef union tagMMXData
{
    LONGLONG    MMXMem;
    DWORD       DWords[2];
    WORD        Words[4];
    BYTE        Bytes[8];
    long        Longs[2];
    short int   ShortInts[4];
    char        Chars[8];
} CMMXData;

inline CString GetModuleName()
{
    CString fn;
    DWORD len = GetModuleFileName(NULL,fn.GetBuffer(MAX_PATH),MAX_PATH);
    fn.ReleaseBuffer();
    return fn;
}

//format: YYYY.MM.DD HH24:MI:SS.MSE
inline CString SystemTimeToDateTimeStr(SYSTEMTIME dt)
{
    CString s;
    s.Format(_T("%04d.%02d.%02d %02d:%02d:%02d.%03d"),dt.wYear,dt.wMonth,dt.wDay,dt.wHour,dt.wMinute,dt.wSecond,dt.wMilliseconds);
    return s;
}

//accepted format: YYYY.MM.DD[ HH24:MI[:SS[.MSE]]]
HRESULT DateTimeStrToSystemTime(CString &dtstr,SYSTEMTIME &systime);


typedef LRESULT CALLBACK CWindowProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);

inline HWND AllocateHWND(CWindowProc Proc,HINSTANCE hInstance)
{
    static WNDCLASS UtilWindowClass = {0,DefWindowProc,0,0,hInstance,0,0,0,NULL,_T("SEUtilWindow")};
    WNDCLASS    TempClass;
    BOOL        ClassRegistered;

    ClassRegistered = GetClassInfo(hInstance,UtilWindowClass.lpszClassName,&TempClass);
    if ((!ClassRegistered) || (TempClass.lpfnWndProc != DefWindowProc))
    {
        if (ClassRegistered)
            UnregisterClass(UtilWindowClass.lpszClassName,hInstance);
        RegisterClass(&UtilWindowClass);
    }
    HWND res = CreateWindow(UtilWindowClass.lpszClassName,"",0,0,0,0,0,0,0,hInstance,NULL);
    SetWindowLong(res,GWL_WNDPROC,(long)Proc);
    return res;
}

inline void DeallocateHWND(HWND hWnd)
{
    DestroyWindow(hWnd);
}


/////////////////////////////////////////////////////
//Global classes

// CSeSmartPtr automatikus pointer felszabad�t�s
template<class __BaseType>
class CSeSmartPtr//: public CObject
{
private:
	__BaseType *p;
public:
	CSeSmartPtr()
	{
		p = NULL;
	}
	CSeSmartPtr(__BaseType *src)
	{
		p = src;
	}
	~CSeSmartPtr()
	{
		Release();
	}
	CSeSmartPtr& operator=(__BaseType* src)
	{
		Release();
		p = src;
		return *this;
	}
	operator __BaseType*()
	{
		return p;
	}
	__BaseType* operator->()
	{
        SE_ASSERT((p != NULL));
		return p;
	}
	__BaseType** operator &()
	{
        SE_ASSERT((p == NULL));
		return (__BaseType**)(&p);
	}
	__BaseType& operator *()
	{
        SE_ASSERT((p != NULL));
		return (*p);
	}
	CSeSmartPtr& Attach(__BaseType *src)
	{
		Release();
		p = src;
		return *this;
	}
	__BaseType* Detach()
	{
		__BaseType *res = p;
		p = NULL;
		return res;
	}
	void Release()
	{
		if (p != NULL)
			delete p;
		p = NULL;
	}
    bool IsNull() const
    {
        return (p == NULL);
    }
    __BaseType* P()
    {
        return p;
    }
    const __BaseType* constP() const
    {
        return p;
    }
    __BaseType** PP()
    {
        return &p;
    }
};

// CSeSmartArray automatikus t�mb felszabad�t�s
template<class __BaseType>
class CSeSmartArray//: public CObject
{
private:
	__BaseType *p;
public:
	CSeSmartArray()
	{
		p = NULL;
	}
	CSeSmartArray(__BaseType *src)
	{
		p = src;
	}
	~CSeSmartArray()
	{
		Release();
	}
	CSeSmartArray& operator=(__BaseType* src)
	{
		Release();
		p = src;
		return *this;
	}
	operator __BaseType*()
    {
	    return p;
    }
    template<class __IndexType>
	__BaseType& operator[](__IndexType Index)
	{
        SE_ASSERT((p != NULL));
		return p[Index];
	}
	__BaseType** operator &()
	{
        SE_ASSERT((p == NULL));
		return (__BaseType**)(&p);
	}
	CSeSmartArray& Attach(__BaseType *src)
	{
		Release();
		p = src;
		return *this;
	}
	__BaseType* Detach()
	{
		__BaseType *res = p;
		p = NULL;
		return res;
	}
	void Release()
	{
		if (p != NULL)
			delete [] p;
		p = NULL;
	}
    bool IsNull() const
    {
        return (p == NULL);
    }
    __BaseType* P()
    {
        return p;
    }
    const __BaseType* constP() const
    {
        return p;
    }
    __BaseType** PP()
    {
        return &p;
    }
};


//param�ter lista kezel�s�hez haszn�lhat� utility:
//      a param�ter lista elemei: {VARIANT ParamN�v, VARIANT Param�rt�k} rekordok
//HRESULT __SeCreateConfigParamArray(long indexcount,VARIANT *array);
//HRESULT __SeGetParamInConfigParamArray(const VARIANT &array,long index,BSTR *paramname,VARIANT *paramval);
//HRESULT __SeSetParamInConfigParamArray(const VARIANT &array,long index,const BSTR paramname,const VARIANT &paramval);
//HRESULT __SeFindParamInConfigParamArray(const VARIANT &array,const BSTR paramname,VARIANT *paramval,bool &found);

//VARIANT - CString konverzi�s utility:
//HRESULT __SeVariantToString(const VARIANT &Value,CString **Str);  use instead SeVariantToTypeNoLocale(VARIANT,CString)
//HRESULT __SeStringToVariant(const CString &Stri,VARTYPE *PropType,VARIANT *Value); use instead SeChangeVariantTypeNoLocale(VARIANT.vt == VT_BSTR,...)

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,CComBSTR &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,CString &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,BYTE &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,long &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,double &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,bool &OutValue);
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,IUnknown **OutValue);

HRESULT SeTypeToVariant(BSTR InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(const CString &InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(const TCHAR *InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(BYTE InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(long InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(double InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(bool InValue,CComVariant &OutValue);
HRESULT SeTypeToVariant(const IUnknown *InValue,CComVariant &OutValue);

HRESULT SeChangeVariantTypeNoLocale(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType);
HRESULT SeChangeVariantTypeCurrentLocale(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType);
HRESULT SeChangeVariantType(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType,LCID LocaleID,bool UseUserSettingsOnCP);

bool SeVariantIsEmpty(const VARIANT &Vari);

HRESULT SeDoubleToStringCurrentLocal(double Value,CString &StrValue);
HRESULT SeStringToDoubleCurrentLocal(const CString &StrValue,double &Value);

CString SeGetPrivateProfileString(LPCTSTR lpAppName,LPCTSTR lpKeyName,LPCTSTR Default,LPCTSTR lpFileName);
double SeGetPrivateProfileDouble(LPCTSTR lpAppName,LPCTSTR lpKeyName,double Default,LPCTSTR lpFileName);
bool SeGetPrivateProfileBool(LPCTSTR lpAppName,LPCTSTR lpKeyName,bool Default,bool *Exist,LPCTSTR lpFileName);

long SeSystemDeltaTimeToMS(SYSTEMTIME st);
SYSTEMTIME SeMSToSystemDeltaTime(long ms);

//if dtSrc1 < dtSrc2 -> return -1 
//if dtSrc1 == dtSrc2 -> return 0
//else return 1
long CompareDates(DATE dtSrc1, DATE dtSrc2);

void SeDelay( int DelayInMillisec);
HRESULT GetModuleDirAndFileName(HINSTANCE hInstance,CString *ModuleDir,CString *ModuleFileName);
HRESULT GetModuleDirAndFileName(CString *ModuleDir,CString *ModuleFileName);
HRESULT SeGetTempPath(CString &TempPath);

void SeShowInfoMessage(const CString &Message);
void SeShowInfoMessage(const TCHAR *Message);

#define SE_INSTANCE_DYNAMIC_INHERIT(__INSTANCE,__CLASSTYPE) \
    ((dynamic_cast<__CLASSTYPE*>(__INSTANCE) != NULL) && (typeid(__INSTANCE) != typeid(__CLASSTYPE)))

#define SE_INSTANCE_DYNAMIC_INHERIT_OR_EQUAL(__INSTANCE,__CLASSTYPE) \
    (dynamic_cast<__CLASSTYPE*>(__INSTANCE) != NULL)



#endif //__SEUTILS_H_
