#include "stdafx.h"
#include "SeDebugLog.h"

CSeDebugLog::CSeDebugLog(char *FileName,bool WriteImmediate)
{
    QueryPerformanceFrequency( &Frequency );
    slptr = 0;
    char md[MAX_PATH];
    m_WriteImmediate = WriteImmediate;
    if (!(((FileName[0] == '\\') && (FileName[1] == '\\')) || (FileName[1] == ':')))  //not full path
    {
        DWORD len = GetModuleFileName(NULL,md,MAX_PATH);
        if (len > 0)
        {
            // find last single character
            LPSTR lpsz = strrchr(md, '\\');
            // return -1 if not found, distance from beginning otherwise
            long backslash = (lpsz == NULL) ? -1 : (long)(lpsz - md);
            if (backslash >= 0)
            {
                md[backslash + 1] = '\0';
                strcat(md,FileName);
                FileName = md;
            }
        }
    }
    strcpy( DbgFName, FileName );
    if (m_WriteImmediate)
        DebugFile = NULL;
    else
        DebugFile = fopen( DbgFName, "w" );
    m_ImmediateString = NULL;
}

CSeDebugLog::~CSeDebugLog( void )
{
    if (m_WriteImmediate)
    {
        if (m_ImmediateString)
            delete m_ImmediateString;
    }
    else
    {
	    int i;
	    for( i=0; i<slptr; i++)
	    {
		    fwrite( StringList[i], 1, strlen(StringList[i]), DebugFile );
		    delete [] StringList[i];
	    }
	    fclose( DebugFile );
    }
}

void CSeDebugLog::StartProcedure( char* DbgStr )
{
    if (m_WriteImmediate)
    {
        if (m_ImmediateString)
            delete m_ImmediateString;
	    m_ImmediateString = new char [strlen( DbgStr )+32];
	    strcpy( m_ImmediateString, DbgStr );
    }
    else
    {
	    StringList[slptr] = new char [strlen( DbgStr )+32];
	    strcpy( StringList[slptr], DbgStr );
    }
    QueryPerformanceCounter( &Start );
}

void CSeDebugLog::StopProcedure( void )
{
    QueryPerformanceCounter( &Stop );
    Diff = Stop.QuadPart - Start.QuadPart;
	MilliSecCount = Diff * 1000 / (__int64)Frequency.QuadPart;
	sprintf( sTmp, " %I64d milliseconds\n", MilliSecCount );
    if (m_WriteImmediate)
    {
	    strcat( m_ImmediateString, sTmp );
        WriteImmedString();
    }
    else
    {
	    strcat( StringList[slptr], sTmp );
	    slptr++;
        CheckList();
    }
}

void CSeDebugLog::WriteMessage( char* DbgStr )
{
    if (m_WriteImmediate)
    {
        if (m_ImmediateString)
            delete m_ImmediateString;
	    m_ImmediateString = new char [strlen( DbgStr )+sizeof('\n')+sizeof('\0')];
	    sprintf( m_ImmediateString, "%s\n", DbgStr );
        WriteImmedString();
    }
    else
    {
	    StringList[slptr] = new char [strlen( DbgStr )+sizeof('\n')+sizeof('\0')];
	    sprintf( StringList[slptr], "%s\n", DbgStr );
	    slptr++;
        CheckList();
    }
}

void CSeDebugLog::WriteMessage( int DbgInt )
{
    if (m_WriteImmediate)
    {
        if (m_ImmediateString)
            delete m_ImmediateString;
        sprintf( sTmp, "%d\n", DbgInt );
        m_ImmediateString = new char [strlen( sTmp )+sizeof('\0')];
	    strcpy( m_ImmediateString, sTmp );
        WriteImmedString();
    }
    else
    {
        sprintf( sTmp, "%d\n", DbgInt );
        StringList[slptr] = new char [strlen( sTmp )+sizeof('\0')];
	    strcpy( StringList[slptr], sTmp );
	    slptr++;
        CheckList();
    }
}

void CSeDebugLog::WriteMessage(char* String, long DbgInt )
{
    if (m_WriteImmediate)
    {
        if (m_ImmediateString)
            delete m_ImmediateString;
        sprintf( sTmp, ": %d\n", DbgInt );
        m_ImmediateString = new char [strlen(String) + strlen( sTmp )+sizeof('\0')];
	    strcpy( m_ImmediateString, String );
	    strcat( m_ImmediateString, sTmp );
        WriteImmedString();
    }
    else
    {
        sprintf( sTmp, ": %d\n", DbgInt );
        StringList[slptr] = new char [strlen(String) + strlen( sTmp )+sizeof('\0')];
	    strcpy( StringList[slptr], String );
	    strcat( StringList[slptr], sTmp );
	    slptr++;
        CheckList();
    }
}

void CSeDebugLog::CheckList( void )
{
	if( slptr == 1024 )
	{
		int i;

		for( i=0; i<slptr; i++)
		{
			fwrite( StringList[i], 1, strlen(StringList[i]), DebugFile );
			delete [] StringList[i];
		}
		slptr = 0;
	}
}

void CSeDebugLog::WriteImmedString()
{
    FILE *file = fopen( DbgFName, "a" );
    fwrite( m_ImmediateString, 1, strlen(m_ImmediateString), file );
    fclose( file );
}



