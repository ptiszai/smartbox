//---------------------------------------------------------------------------

#ifndef SzReadMeH
#define SzReadMeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TReadMeForm : public TForm
{
__published:	// IDE-managed Components
    TBitBtn *ExitBtn;
    TMemo *ReadMe;
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TReadMeForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TReadMeForm *ReadMeForm;
//---------------------------------------------------------------------------
#endif
