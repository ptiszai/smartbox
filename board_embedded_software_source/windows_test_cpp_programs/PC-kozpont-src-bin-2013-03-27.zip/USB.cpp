//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#include "FTD2XX.h"
#pragma hdrstop

#include "SzCom.h"
#include "kliens_test.h"
#include "USB.h"
#include "Szprt.h"
#include "kliens_test.h"
#pragma package(smart_init)

 //---------------------------------------------------------------------------
__fastcall TUSB::TUSB(bool CreateSuspended)
    : TThread(CreateSuspended)
{
   // ::InitializeCriticalSection(&m_CS);
   if (!Init())
   {
        bOpen=false;
       // XTPrintf("USB port open error!");
   }
   else
       bOpen=true;
}

__fastcall TUSB::~TUSB()
{
      FT_Close(hPort);
}
/**************************************************************************
 *	Init.
 *************************************************************************/
bool __fastcall TUSB::Init()
{

#ifdef  NOT_USB
    return true;
#endif

    FT_STATUS ftStatus;
    hPort=NULL;
    hEvent=NULL;
 //   int DevNum = 0;
    DWORD devIndex = 0;
    char buff[50];
    char serno[64];

 /*   try
    {
        //serno = GetDeviceSerNo();
        ftStatus = FT_ListDevices((PVOID)devIndex,(PVOID)&serno[0],FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER);
        if (!FT_SUCCESS(ftStatus))
            throw Exception("USB: Open error!");

        ftStatus = FT_OpenEx((PVOID)serno,FT_OPEN_BY_SERIAL_NUMBER,&hPort);
//        ftStatus = FT_Open(DevNum,&hPort);
        if (!FT_SUCCESS(ftStatus))
              throw Exception("USB: Open error!");
        else
        {
            sprintf(buff, "USB:%d open !!", hPort);
            XTPrintf(buff);
        }
        FT_ResetDevice(hPort);
        ftStatus = FT_Purge(hPort,FT_PURGE_TX | FT_PURGE_RX);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB:Buffer clear error!" );
        ftStatus = FT_SetBaudRate(hPort,FT_BAUD_9600);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetBaudRate error!" );      
        ftStatus = FT_SetDataCharacteristics( hPort,FT_BITS_8,FT_STOP_BITS_1,FT_PARITY_NONE);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetDataCharacteristics error!" );
        ftStatus = FT_SetFlowControl( hPort,FT_FLOW_NONE,0,0);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB: SetFlowControl error!" );
      
        hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			        FALSE, // BOOL fManualReset
			        FALSE, // BOOL fInitialState
			        "USB"); // LPTSTR lpszEventName
        if(hEvent == INVALID_HANDLE_VALUE)
            throw Exception( "USB: CreateEvent error!" );
        hEvent=OpenEvent( EVENT_ALL_ACCESS,TRUE,"USB");
        if(hEvent == INVALID_HANDLE_VALUE)
            throw Exception( "USB: OpenEvent error!" );
        ftStatus = FT_SetTimeouts(hPort,100,50);
        if (!FT_SUCCESS(ftStatus))
            throw Exception( "USB:Set Time out error!" );

//        FT_SetUSBParameters (hPort , 100, 100);
    }
    catch  ( const Exception &e )
    {
        ShowMessage(  e.Message  );
        if (hPort)
            FT_Close(hPort);
        if (serno)
            delete serno;
        return false;
    }
    rxBytes=4;

    return true;
    */

    ////////////////////////
     FTTIMEOUTS  CommTimeOuts ;
     FTDCB  dDCB;
     hPort = NULL;

    try
    {
        ftStatus = FT_ListDevices(0,serno,FT_LIST_BY_INDEX|FT_OPEN_BY_SERIAL_NUMBER);
        if (!FT_SUCCESS(ftStatus))
            throw Exception("USB: Open error!");
        hPort = FT_W32_CreateFile (serno, // Port Name (Unicode compatible)
                    GENERIC_READ|GENERIC_WRITE,  // Open for Read-Write
                    0,             // COM port cannot be shared
                    NULL,          // Always NULL for Windows CE
                    OPEN_EXISTING, // For communication resource
                    FILE_FLAG_OVERLAPPED|FILE_ATTRIBUTE_NORMAL|FT_OPEN_BY_SERIAL_NUMBER,// Non-overlapped operation only
//                    0,
//                    FILE_ATTRIBUTE_NORMAL,
                    NULL);         // Always NULL for Windows CE
  		if (hPort == INVALID_HANDLE_VALUE)
            throw Exception("USB: Open error!");
 		if (!FT_W32_GetCommState(hPort,&dDCB))
            throw Exception("USB:open,but GetCommState() error was !!");

 		dDCB.BaudRate = FT_BAUD_9600;
 		dDCB.ByteSize = FT_BITS_8;
 		dDCB.Parity   = FT_PARITY_NONE;
 		dDCB.StopBits =	FT_STOP_BITS_1;
  		dDCB.fBinary = TRUE ;
        dDCB.fParity = TRUE ;
        dDCB.fAbortOnError= TRUE;

 		if (!FT_W32_SetCommState( hPort,&dDCB ))
            throw Exception("USB:open,but SetCommState() error was !!");

        
	    FT_W32_SetupComm( hPort, RXQUEUE, TXQUEUE ) ;
	    FT_W32_PurgeComm( hPort, PURGE_TXCLEAR|PURGE_RXCLEAR|
        					   PURGE_TXABORT | PURGE_RXABORT );

 //      SetDCB(FBAUDRATE,FBYTESIZE,FPARITY,FSTOPBIT);

        memset( &osRead, 0, sizeof( OVERLAPPED ) ) ;
        memset( &osWrite, 0, sizeof( OVERLAPPED ) ) ;
      // set up for overlapped I/O
        osRead.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    FALSE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName
        if(osRead.hEvent == INVALID_HANDLE_VALUE)
	        throw Exception("USB:open,but Set event error was !!");

 	    osWrite.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    TRUE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName

        if(osWrite.hEvent == INVALID_HANDLE_VALUE)
	        throw Exception("USB:open,but Set event error was !!");

      	CommTimeOuts.ReadIntervalTimeout = 40;
      	CommTimeOuts.ReadTotalTimeoutMultiplier = 1 ;
      	CommTimeOuts.ReadTotalTimeoutConstant = 0 ;
  		CommTimeOuts.WriteTotalTimeoutMultiplier =  1 ;
      	CommTimeOuts.WriteTotalTimeoutConstant = 20 ;

      	if (!FT_W32_SetCommTimeouts(hPort , &CommTimeOuts ))
            throw Exception("USB: open,but GetCommState() error was !!");


   }
   catch  ( const Exception &e )
   {
       // ShowMessage(  e.Message  );
        if (hPort)
            FT_W32_CloseHandle(hPort);
        XTPrintf(e.Message.c_str());
        bOpen = false;
        return false;
   }
 //  rxBytes=4;
   sprintf(buff, "%s open !!", serno);
   XTPrintf(buff);
   bOpen = true;
   return true;

}//bool Init(void)

//---------------------------------------------------------------------------
const char* __fastcall TUSB::GetDeviceSerNo(void)
{

#ifdef  NOT_USB
   return NULL;
#endif

    char* serno = new char(50);
    DWORD devIndex = 0;
    FT_STATUS ftStatus;
    ftStatus = FT_ListDevices((PVOID)devIndex,(PVOID)serno,FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER);
    if (!FT_SUCCESS(ftStatus))
        return NULL;
    return  serno;
}//GetDeviceSerNo(void)

//---------------------------------------------------------------------------
void __fastcall  TUSB::ClearReadComBuffer(void)
{
    char buff[301];
   // DWORD iBytesReadThisTime=0;
   // ::EnterCriticalSection(&m_CS);
#ifndef  NOT_USB
 //   FT_Read(hPort,buff,200,&iBytesReadThisTime);
    FT_Purge ( hPort, FT_PURGE_RX );
#endif
//    ::LeaveCriticalSection(&m_CS);
}

//---------------------------------------------------------------------------
void __fastcall TUSB::Execute()
{
   // FT_STATUS  ftStatus;
    DWORD RxBytes;
    DWORD       dwEvtMask;
	bool	    result=true;
    FTCOMSTAT    ComStat ;
    DWORD      dwErrorFlags;
    char msg[50];

    if (hPort==NULL)
        return;
    if (!FT_W32_SetCommMask( hPort, EV_RXCHAR|EV_ERR))
    {
  //      error = GetLastError();
   //     strcpy(errorstr,"CreateEvent");
        DoTerminate();
    }
    while(result && !Terminated)
   	{
       dwEvtMask = 0 ;
        while(ViewForm->recStop);
		if (FT_W32_WaitCommEvent(hPort, &dwEvtMask, NULL /*&osRead*/))
        {

    		switch (dwEvtMask)
        	{
         		case EV_ERR :
                    FT_W32_ClearCommError(hPort, &dwErrorFlags, &ComStat);
//                     XTPrintf("EEEE");
            		break;
				case EV_RXCHAR:
                    if (!ReadCom( recbuff, 37))
                    {
                          XTPrintf("Rec Error");
                          FT_W32_ClearCommError(hPort, &dwErrorFlags, &ComStat);
                          FT_W32_PurgeComm(hPort,PURGE_RXCLEAR);
   //                     Send(true);
                        break;
                    }

                    Synchronize(CompleteRequest);
                    ViewForm->TimerTimer->Interval = 2000;
                    ViewForm->TimerTimer->Tag = 0;
            		break;
                case EV_TXEMPTY:
                {
 //                XTPrintf("AAAA");
/*                   if (Closeflg)
                    {
                        if (com)
                            delete com;
                        Closeflg=false;
                        Sleep(100);
                    }
*/
                    break;
                }
				default:

               // sprintf(msg,"KKKKKK: %d",dwEvtMask);
        //        sprintf(msg,"KKKKKK: %d", FT_W32_GetLastError(hPort));
        //        XTPrintf(msg);
               // FT_W32_ClearCommError(hPort, &dwErrorFlags, &ComStat);
         	   		break;
        	}
 		}
    	else
		{
        	error = GetLastError();
        	strcpy(errorstr,"WaitCommEvent");
            result = false;
            DoTerminate();
    	}
	}
	if (!error)
    	DoTerminate();
}

//---------------------------------------------------------------------------
 void __fastcall TUSB::CompleteRequest(void)
 {
    if (dwLength<=0)
    {
        XTPrintf("USB Length Error!");
        return;
    }
//    com->recbuff[com->dwLength] = 0;
 //     sprintf(msg,"received: %s,",com->recbuff);
   //   XTPrintf(msg);


    if (ViewForm->DumpChB->State == cbChecked)
        dump(&recbuff[0], dwLength);
    else
    {
        char* pch;
    //    com->recbuff[com->dwLength] = 0;
     //   sprintf(msg,"%s,",com->recbuff);
        pch = strtok(recbuff,"\r\n");
        if (!strcmp("!sP",pch))
        {
            bprint = true;
            SzPr->QRStringsBand->Items->Clear();
            return;
        }
        if (!strcmp("!eP",pch))
        {
            bprint = false;

            ViewForm->PrintBtn->Enabled = true;
            return;
        }
        XTPrintf(pch);
        if (bprint)
        {
            SzPr->QRStringsBand->Items->Add(pch);
            return;
        }
       // DebugLog(pch);
        while(pch)
        {
            pch = strtok(NULL,"\0x0d");
            if (pch)
            {
                XTPrintf(pch);
           //     DebugLog(pch);
            }
        }
    }

 }

 //---------------------------------------------------------------------------
DWORD __fastcall TUSB::SendNoDump(char* msg, int len)
{
    if (hPort == NULL)
        return 0;
    return WriteCom(msg,len);

}//SendNoDump(..)

 //---------------------------------------------------------------------------
DWORD __fastcall TUSB::Send(char* msg, int len)
{
    if (!bOpen)
        return 0;
     if (hPort == NULL)
        return 0;
     bprint = false;
    dump(msg,len);
//    XTPrintf(msg);
    return WriteCom(msg,len);

}//Send(..)

//---------------------------------------------------------------------------
void __fastcall TUSB::Reset(void)
{
    FT_W32_CloseHandle(hPort);
    Sleep((unsigned long)100);
    if (Init())
    {
        FT_W32_SetCommMask( hPort, EV_RXCHAR|EV_ERR);
     //   XTPrintf("DEV0");
        Sleep((unsigned long)100);
        SendNoDump("HELLO",4);
    }
}//Reset()

 //--------------------------------------------------------------------------
DWORD __fastcall  TUSB::ReadCom(LPSTR lpszBlock, int nMaxLength )
{
   DWORD iBytesReadThisTime=0;
   DWORD iBytesRead=0;
   BOOL       fReadStat ;
   FTCOMSTAT    ComStat ;
   DWORD      dwErrorFlags;
   DWORD   dwError,dwTr;

   dwTr = nMaxLength;

   if (dwTr <= 0)
    return 0;

   memset( &osRead, 0, sizeof( OVERLAPPED ) ) ;
   while(dwTr)
   {
        fReadStat = FT_W32_ReadFile( hPort, &lpszBlock[iBytesRead], dwTr, &iBytesReadThisTime, &osRead ) ;

        if (!fReadStat && (FT_W32_GetLastError(hPort) == ERROR_IO_PENDING))
        {
                if(!FT_W32_GetOverlappedResult( hPort,&osRead, &dwTr, TRUE ))
                {
                    dwError = FT_W32_GetLastError(hPort);
                    if(dwError == ERROR_IO_INCOMPLETE)
                        continue;
                    else
                    {
                        FT_W32_ClearCommError( hPort, &dwErrorFlags, &ComStat ) ;
                        dwLength=0;
                        return 0;
                    }
                }
                iBytesRead+=dwTr;
        }
        else
        {
                FT_W32_ClearCommError( hPort, &dwErrorFlags, &ComStat) ;
                iBytesRead+=iBytesReadThisTime;
                break;
        }
    }
   FT_W32_ClearCommError( hPort, &dwErrorFlags, &ComStat) ;
   dwLength=iBytesRead;

//  if (dwLength)
//       dump(  lpszBlock, dwLength);
   return dwLength ;
}/*  DWORD __fastcall  Tcom::ReadCommBlock(..)*/

//--------------------------------------------------------------------------
DWORD __fastcall TUSB::WriteCom(char* buf,int len)
{
    DWORD write;
//	DWORD dwBytesSent=0;
	DWORD dwErrorFlags;
   	FTCOMSTAT     ComStat;
  

	if (len <= 0)
		return -1;

   // memset( &osWrite, 0, sizeof( OVERLAPPED ) ) ;
    if(!FT_W32_WriteFile(hPort,buf,len,&write,&osWrite))
 	{
   		if(FT_W32_GetLastError(hPort) == ERROR_IO_PENDING)
		{
          /*	if (FT_W32_GetOverlappedResult( hPort, &osWrite, &write, TRUE ) )
            //while(FT_W32_GetOverlappedResult( hPort, &osWrite, &write, FALSE ))
         	{
           		if (FT_W32_GetLastError(hPort) == ERROR_IO_INCOMPLETE)
            	{
               		continue;
            	}
            	else
            	{
               		FT_W32_ClearCommError( hPort, &dwErrorFlags, &ComStat ) ;
               		break;
            	} 
			}  */
      //       XTPrintf("nnnn");
		}
		else
		{
            FT_W32_ClearCommError( hPort, &dwErrorFlags, &ComStat ) ;
            
		}


    }
    return write;
};
