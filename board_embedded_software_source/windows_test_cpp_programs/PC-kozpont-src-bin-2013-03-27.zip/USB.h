//---------------------------------------------------------------------------

#ifndef USBH
#define USBH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include "FTD2XX.h"
//---------------------------------------------------------------------------
class TUSB: public TThread
{            
private:
    CRITICAL_SECTION    m_CS;
    FT_HANDLE           hPort;
    HANDLE              hEvent;
protected:
    UCHAR       recbuff[100];
    UCHAR       sendbuff[100];
    DWORD       rxBytes;
    DWORD       dwLength;
    bool	    error;
    bool        bprint;
    char        errorstr[50];
    bool        bOpen;
    OVERLAPPED  osRead;
    OVERLAPPED  osWrite;
    bool __fastcall Init();
    const char* __fastcall GetDeviceSerNo(void);
    void __fastcall  ClearReadComBuffer(void);
    void __fastcall  CompleteRequest(void);
    DWORD __fastcall  ReadCom(LPSTR lpszBlock, int nMaxLength );
    DWORD __fastcall WriteCom(char* buf,int len);
    void __fastcall Execute();
public:
    __fastcall TUSB(bool CreateSuspended);
    __fastcall ~TUSB();
    DWORD __fastcall Send(char* msg, int len);
    DWORD __fastcall SendNoDump(char* msg, int len);
    void __fastcall Reset(void);
};
//---------------------------------------------------------------------------
#endif
