//----------------------------------------------------------------------------
#ifndef SzprtH
#define SzprtH
//----------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\QuickRpt.hpp>
#include <vcl\QRCtrls.hpp>
#include <ExtCtrls.hpp>
//----------------------------------------------------------------------------
class TSzPr : public TQuickRep
{
__published:
    TQRBand *PageHeaderBand1;
    TQRLabel *QRLabel;
    TQRStringsBand *QRStringsBand;
    TQRBand *DetailBand1;
    TQRExpr *QRExpr;
private:
public:
  // __fastcall TSzPr::TQuickReport1(TComponent* Owner);
   __fastcall TSzPr(TComponent* Owner);
};
//----------------------------------------------------------------------------
extern TSzPr *SzPr;
//----------------------------------------------------------------------------
#endif