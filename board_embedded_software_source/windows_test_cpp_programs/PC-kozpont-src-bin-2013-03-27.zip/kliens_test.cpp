//---------------------------------------------------------------------------
 //&
#include <vcl.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>


#pragma hdrstop
#include "SzCom.h"
#include "USB.h"
#include "Szprt.h"
#include "kliens_test.h"
#include "SzReadMe.h"
#include "SzHurok.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TViewForm *ViewForm;

SzCom*      ComThread;
TUSB*       UsbThread;

unsigned char  k_IsGoodCheckSumma();

extern unsigned short timercount;

/**********************************************************************
 * Error Message:
 **********************************************************************/
 void Error_Message(char* msg)
 {
    Application->MessageBox(msg , "Error",0);
 }// void Error_Message(const char* msg)

/**********************************************************************
 * Warning Message:
 **********************************************************************/
 void Warning_Message(char* msg)
 {
    Application->MessageBox(msg , "Warning",0);
 }// void Warning_Message(const char* msg)

//---------------------------------------------------------------------------
__fastcall TViewForm::TViewForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

/**********************************************************************
 * Debug Message:
 **********************************************************************/
 void XTPrintf(const char* sText)
 {
    if (ViewForm->View->Tag)
    {
      //  ViewForm->View->Lines->Delimiter = 0x0d;
        ViewForm->View->Lines->Add(sText);
    }
 }//XTPrintf(..)


void __fastcall TViewForm::FormCreate(TObject *Sender)
{
    LoopAddr->ItemIndex = 0;
    oneError = false ;
    recStop = false;
    com_set.Port    =  1;
    com_set.Baudrate=  CBR_9600;
    //com_set.Baudrate=  CBR_19200;
    com_set.ByteSize=  (Byte)8;
    com_set.StopBits=  (Byte)ONESTOPBIT;
    com_set.Parity  =  (Byte)NOPARITY;

    ComThread = new SzCom(true,&com_set);
    ComThread->OnTerminate = TCom_ThreadDone;
    ComThread->Priority=tpNormal;
#ifdef USB
    UsbThread = new TUSB(true);
    UsbThread->OnTerminate = TUsb_ThreadDone;
    UsbThread->Priority=tpNormal;
#else
    UsbThread = NULL;
#endif


    ComThread->Resume();
    if (UsbThread)
        UsbThread->Resume();
}

//---------------------------------------------------------------------
void __fastcall TViewForm::TCom_ThreadDone(TObject * /*Sender*/)
{

}//TKalibForm::TCom_ThreadDone(..)

//---------------------------------------------------------------------
void __fastcall TViewForm::TUsb_ThreadDone(TObject * /*Sender*/)
{

}//TKalibForm::TCom_ThreadDone(..)


void __fastcall TViewForm::SendBtnClick(TObject *Sender)
{
    char* temp ;
    char msg[300];
    int len;
    char* pch;

    temp = new char[ SendEdit->Text.Length() + 1 ];
    strcpy( temp, SendEdit->Text.c_str() );
    if (temp[0] == 's')
    {
        msg[0] = 's';
        switch (temp[1])
        {
            case  'l':     // lcd
                {
                   // char* txt;
                    long x,y,xe,ye,flag;
                    int index = 0;
                    msg[1] = 'l';

                    len = 12;
                    pch = strtok(&temp[2]," ,");
                    while (pch != NULL)
                    {
                        switch(index)
                        {
                            case 0:
                                x = atol(pch);
                                msg[2] = (char)(x / 256);   // higth
                                msg[3] = (char)(x % 256);   // low
                                break;
                            case 1:
                                y = atol(pch);
                                msg[4] = (char)(y / 256);
                                msg[5] = (char)(y % 256);
                                break;
                            case 2:
                                xe = atol(pch);
                                msg[6] = (char)(xe / 256);
                                msg[7] = (char)(xe % 256);
                                break;
                            case 3:
                                ye = atol(pch);
                                msg[8] = (char)(ye / 256);
                                msg[9] = (char)(ye % 256);
                                break;
                            case 4:
                                flag = atol(pch);
                                msg[10] = (char)(flag / 256);
                                msg[11] = (char)(flag % 256);   
                                break;
                            case 5:
                               // txt = pch;
                                strcpy(&msg[12],pch);
                                len += strlen(pch);
                                break;
                        }
                        pch = strtok (NULL, " ,");
                        index++;
                    }
                }
                break;
             case  't':    // rtc-time
                {
                   // char* txt;
                    long hour,min,sec;
                    int index = 0;
                    msg[1] = 't';

                    len = 5;
                    pch = strtok(&temp[2]," ,");
                    while (pch != NULL)
                    {
                        switch(index)
                        {
                            case 0:
                                hour = atol(pch);
                                msg[2] = (char)(hour);
                                break;
                            case 1:
                                min = atol(pch);
                                msg[3] = (char)(min);
                                break;
                            case 2:
                                sec = atol(pch);
                                msg[4] = (char)(sec);
                                break;
                        }
                        pch = strtok (NULL, " ,");
                        index++;
                    }
                }
                break;
             case  'd':    // rtc-date
                {
                   // char* txt;
                    long day,mounth,year;
                    int index = 0;
                    msg[1] = 'd';

                    len = 5;
                    pch = strtok(&temp[2]," ,");
                    while (pch != NULL)
                    {
                        switch(index)
                        {
                            case 0:
                                day = atol(pch);
                                msg[2] = (char)(day);
                                break;
                            case 1:
                                mounth = atol(pch);
                                msg[3] = (char)(mounth);
                                break;
                            case 2:
                                year = atol(pch);
                                msg[4] = (char)(year);
                                break;
                        }
                        pch = strtok (NULL, " ,");
                        index++;
                    }
                }
                break;
                case  'p':    // port test
                {
                    len = 4;
                    msg[1] = 'p';
                    pch = strtok(&temp[2]," ,");
                    msg[2] = *pch;
                    pch = strtok (NULL, " ,");
                    msg[3] =  (char)(atol(pch));
                }
                break;
                case  'e':    // factory constans write to the eeprom.
                {
                    len = 2;
                    msg[1] = 'e';
                }
                break;
                case  'i':    // lcd init.
                {
                    len = 2;
                    msg[1] = 'i';
                }
                break;
                case  'r':    // RESET.
                {
                    len = 2;
                    msg[1] = 'r';
                }
                break;
                case  'E':    // error egy allomasnak.sE12T
                {
                    long addr,data;
                   // int index = 0;
                    len = 4;
                    msg[1] = 'E';
                    pch = strtok(&temp[2]," ,");
                    msg[2] =(char)(atol(pch));
                    pch = strtok (NULL, " ,");
                    long tem =  atol(pch);
                    msg[3] =  (char)(atol(pch));                // rossz!!!
                }
                break;

        }

    } else
    if (temp[0] == 'g')
    {
        msg[0] = 'g';
        len = 2;
        switch (temp[1])
        {
            case  't':     // rtc-time
                {
                    msg[1] = 't';
                    break;
                }
        case  'd':     // rtc-date
                {
                    msg[1] = 'd';
                    break;
                }
        case  'e':    // read eeprom.
                {
                    len = 2;
                    msg[1] = 'e';
                }
                break;
        }
    } else
    if (temp[0] == 'F')
    {  // fat16 sd/mmc
        msg[0] = 'F';
        len = 2;
        switch (temp[1])
        {
            case  't':     // touch
                {
                    msg[1] = 't';
                    pch = strtok(&temp[2]," ,");
                    strcpy(&msg[2],pch);
                    len += strlen(pch);
                    break;
                }
            case  'l':     // ls
                {
                    msg[1] = 'l';
                    break;
                }
            case  'r':     // read
                {
                    msg[1] = 'r';
                    pch = strtok(&temp[2]," ,");
                    strcpy(&msg[2],pch);
                    len += strlen(pch);
                    break;
                }
            case  'a':     // write appand
                {
                    msg[1] = 'a';
                   // pch = strtok(&temp[2]," ,");
              //      strcpy(&msg[2],pch);
                    len += strlen(&temp[2]);
                  //  &temp[2+strlen(pch)] = 0x20;
                //    pch = strtok (NULL, " ,");
                    strcpy(&msg[2],&temp[2]);
                //    len += strlen(pch);
                    break;
                }
            case  'x':     // remove
                {
                    msg[1] = 'x';
                    pch = strtok(&temp[2]," ,");
                    strcpy(&msg[2],pch);
                    len += strlen(pch);
                    break;
                }
        }
    } else
    if (temp[0] == 'A')
    {  // allomas resz.
        msg[0] = 'A';
        len = 2;
        switch (temp[1])
        {
            case  'a':    // address
                {
                   // char* txt;
                    char addr,cmd,num;
                    int index = 0;
                    msg[1] = 'a';

                    len = 5;
                    pch = strtok(&temp[2]," ,");
                    while (pch != NULL)
                    {
                        switch(index)
                        {
                            case 0:
                                addr = atol(pch);
                                msg[2] = addr;
                                break;
                            case 1:
                                cmd = atol(pch);
                                msg[3] = cmd;
                                break;
                            case 2:
                                num = atol(pch);
                                msg[4] = num;
                                break;
                        }
                        pch = strtok (NULL, " ,");
                        index++;
                    }
                }
                break;
            case  'r':     // remove  all address.
                {
                    msg[1] = 'r';
                    break;
                }
        }
    }
     msg[len] = 0;
     ++len;
    ComThread->Send(msg,len);
    if (UsbThread)
        UsbThread->Send(msg,len);
    if (temp)
        delete temp;
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::ViewDblClick(TObject *Sender)
{
    View->Clear();    
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::SetTimeBtnClick(TObject *Sender)
{
    time_t timer;
    struct tm *tblock;
    char text[100];

   timer = time(NULL);
   tblock = localtime(&timer);

   sprintf(text,"st %d,%d,%d", tblock->tm_hour, tblock->tm_min, tblock->tm_sec);
   SendEdit->Text = text;
   SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::SetDateBtnClick(TObject *Sender)
{
//
    time_t timer;
    struct tm *tblock;
    char text[100];

   timer = time(NULL);
   tblock = localtime(&timer);

   sprintf(text,"sd %d,%d,%d", tblock->tm_mday, tblock->tm_mon+1, tblock->tm_year-100);
   SendEdit->Text = text;
   SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::Button1Click(TObject *Sender)
{
//
    SendEdit->Text = "se";
    SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::ReadeLogBnClick(TObject *Sender)
{
    SendEdit->Text = "Fr lamp.log";
    SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::ViewClick(TObject *Sender)
{
     View->Tag =(View->Tag) ? 0 : 1;
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::ReadMeBtnClick(TObject *Sender)
{
    ReadMeForm->Show();    
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::RemoveLogBnClick(TObject *Sender)
{
    SendEdit->Text = "Fx lamp.log";
    SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::ResetBtnClick(TObject *Sender)
{
    SendEdit->Text = "sr";
    SendBtnClick(NULL);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::TimerTimerTimer(TObject *Sender)
{
    ++timercount;
    TimerTimer->Interval = 2000;
    if (TimerTimer->Tag > 5)
    {
     if (UsbThread)
       UsbThread->Reset();
    }
    else
    {
     if (UsbThread)
        UsbThread->SendNoDump("HELLO",4);
     }
     TimerTimer->Tag++;
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::PrintBtnClick(TObject *Sender)
{
    SzPr->Preview();
}
//---------------------------------------------------------------------------



void __fastcall TViewForm::LoopSendBnClick(TObject *Sender)
{

    if (Application->MessageBox("Mehet a loop cim sz�m be�get�se?", "Loop k�rd�s.",MB_YESNO	) == IDYES  )
    {
        char msg[3];
        msg[0] = 's';
        msg[1] = 'a';
        msg[2] = (char)(LoopAddr->ItemIndex+1);
    //  msg[3] = (LoopMsg->State==cbChecked)?'1':'0';

        ComThread->Send(msg,3);
        if (UsbThread)
            UsbThread->Send(msg,3);
    }
}
//---------------------------------------------------------------------------
/*
unsigned char  k_IsGoodCheckSumma()
{
   unsigned char k_rxBuffer[5];
   char msg[50];
   k_rxBuffer[1] = 0xfe;
   k_rxBuffer[2] = 0x70;
   k_rxBuffer[3] = 0;

   k_rxBuffer[4] = 0x6e;

   sprintf(msg,"0x%x,0x%x",((unsigned char)k_rxBuffer[1] + k_rxBuffer[2] + k_rxBuffer[3]),k_rxBuffer[4]);
   XTPrintf(msg);
	return ((unsigned char)(k_rxBuffer[1] + k_rxBuffer[2] + k_rxBuffer[3]) == k_rxBuffer[4]);
}//IsGoodCheckSumma(unsigned char* pData)
*/

void __fastcall TViewForm::LoopResetClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 'A';
    msg[1] = 's';
    msg[2] = (char)(LoopAddr->ItemIndex+1);
    msg[3] = (LoopMsg->State==cbChecked)?'1':'0';

    ComThread->Send(msg,3);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::LoopListClick(TObject *Sender)
{
  char msg[10];

    msg[0] = 'A';
    msg[1] = 'l';

    msg[2] = (char)(LoopAddr->ItemIndex+1);
    ComThread->Send(msg,3);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::LcdKUpBtnClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 's';
    msg[1] = 'k';
    msg[2] = 2;

    ComThread->Send(msg,3);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::LcdKDownBtnClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 's';
    msg[1] = 'k';
    msg[2] = 1;

    ComThread->Send(msg,3);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::FunkManualBtnClick(TObject *Sender)
{   // Manual Test
    char msg[10];

    if (Application->MessageBox("Mehet a 2 perces teszt?", "M�r�sre k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'T';
        msg[1] = 'M';

        ComThread->Send(msg,2);
        if (UsbThread)
            UsbThread->Send(msg,2);
    }
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::FunkInstallGrpClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 'T';
    msg[1] = 'P';
    msg[2] = 'I';
    msg[3] = (FunkInstallGrp->ItemIndex)?'1':'0';

    ComThread->Send(msg,4);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::FunkInfrGrpClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 'T';
    msg[1] = 'P';
    msg[2] = 'i';
    msg[3] = (FunkInfrGrp->ItemIndex)?'1':'0';

    ComThread->Send(msg,4);
    if (UsbThread)
        UsbThread->Send(msg,4);
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::FunkClrAllABtnClick(TObject *Sender)
{ // Clear all addr.
    char msg[10];

    if (Application->MessageBox("�sszes cimet t�r�ljem?", "T�rl�s k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'T';
        msg[1] = 'C';

        ComThread->Send(msg,2);
        if (UsbThread)
            UsbThread->Send(msg,2);
    }

}
//---------------------------------------------------------------------------

void __fastcall TViewForm::NextWeeklyCloseUp(TObject *Sender)
{
    unsigned short year, month, day;
    char msg[10];

    NextWeekly->Date.DecodeDate(&year,&month,&day);

    if (Application->MessageBox("Lek�ldjem?", "Date k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'T';
        msg[1] = 'w';
        msg[2] =  (char)(year - 2000);
        msg[3] =  (char)(month);
        msg[4] =  (char)(day);

        ComThread->Send(msg,5);
        if (UsbThread)
         UsbThread->Send(msg,5);
    }
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::NextAnnualCloseUp(TObject *Sender)
{
    unsigned short year, month, day;
    char msg[10];

    NextAnnual->Date.DecodeDate(&year,&month,&day);

    if (Application->MessageBox("Lek�ldjem?", "Date k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'T';
        msg[1] = 'a';
        msg[2] =  (char)(year - 2000);
        msg[3] =  (char)(month);
        msg[4] =  (char)(day);

        ComThread->Send(msg,5);
        if (UsbThread)
            UsbThread->Send(msg,5);
    }
}
//---------------------------------------------------------------------------

void __fastcall TViewForm::FunkLcdClearBtnClick(TObject *Sender)
{ // Lcd clear.
    char msg[10];

    msg[0] = 'T';
    msg[1] = 'S';

    ComThread->Send(msg,2);
    if (UsbThread)
        UsbThread->Send(msg,2);
}
//---------------------------------------------------------------------------


void __fastcall TViewForm::FunkLightSwitchBtnClick(TObject *Sender)
{
  char msg[10];

    msg[0] = 'T';
    msg[1] = 'L';

    if (FunkLightSwitchBtn->Tag)
    {
        FunkLightSwitchBtn->Tag = 0;
        msg[2] = '1';
    }
    else
    {
        FunkLightSwitchBtn->Tag = 1;
        msg[2] = '0';
    }

    ComThread->Send(msg,3);
    if (UsbThread)
        UsbThread->Send(msg,3);
}
//---------------------------------------------------------------------------
void __fastcall TViewForm::FunkGetAllABtnClick(TObject *Sender)
{
// Get All address.
    char msg[10];

    if (Application->MessageBox("Lek�rdezm az �llom�sok cimeit?", "Cimekre k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'T';
        msg[1] = 'G';

        ComThread->Send(msg,2);
        if (UsbThread)
            UsbThread->Send(msg,2);
    }
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::Button2Click(TObject *Sender)
{
    HurokForm->Show();    
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::AtoBBtnClick(TObject *Sender)
{
   char msg[10];

    msg[0] = 's';
    msg[1] = 'c';

    ComThread->Send(msg,2);
    if (UsbThread)
        UsbThread->Send(msg,2);
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::GetABBtnClick(TObject *Sender)
{
    char msg[10];

    msg[0] = 'g';
    msg[1] = 'c';

    ComThread->Send(msg,2);
    if (UsbThread)
        UsbThread->Send(msg,2);
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::ExitBtnClick(TObject *Sender)
{
    Close();    
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::SendLedBtnClick(TObject *Sender)
{
    char msg[5];

    msg[0] = 's';
    msg[1] = 'L';

    msg[2] = (ALARMLedRGrp->ItemIndex) ? 0 : 0xff;
    msg[3] = (OUTRGrp->ItemIndex) ? 0 : 0xff;

    ComThread->Send(msg,4);
    if (UsbThread)
        UsbThread->Send(msg,4);
}
//---------------------------------------------------------------------------


void __fastcall TViewForm::TestPortBtnClick(TObject *Sender)
{
    char msg[5];

    msg[0] = 's';
    msg[1] = 'p';

    msg[2] = 'f';
    msg[3] = 0x0f;

    ComThread->Send(msg,4);
    if (UsbThread)
        UsbThread->Send(msg,4);
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::LpassCreateBtnClick(TObject *Sender)
{
    char msg[10];

    if (Application->MessageBox("'lpass.dat' f�jlt l�trehozzam?", "K�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'F';
        msg[1] = 'p';

        strcpy(&msg[2],ROOT_PASSWD);

        ComThread->Send(msg,2+strlen(&msg[2]));
        if (UsbThread)
            UsbThread->Send(msg,2+strlen(&msg[2]));
    }
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::LpassRemovaBtnClick(TObject *Sender)
{
    char msg[10];
   if (Application->MessageBox("'lpass.dat' f�jlt t�r�ljem?", "K�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 'F';
        msg[1] = 'P';

        ComThread->Send(msg,2);
        if (UsbThread)
            UsbThread->Send(msg,2);
    }
}

//---------------------------------------------------------------------------

void __fastcall TViewForm::TestTimeBtnClick(TObject *Sender)
{
   unsigned short hour, min, sec,  msec;
    char msg[10];

    TestTime->Time.DecodeTime(&hour,&min,&sec,&msec);

    if (Application->MessageBox("Lek�ldjem?", "Test id� k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 's';
        msg[1] = 'h';
        msg[2] =  (char)(hour);
        msg[3] =  (char)(min);


        ComThread->Send(msg,4);
        if (UsbThread)
            UsbThread->Send(msg,4);
    }
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::InstallStopBtnClick(TObject *Sender)
{
    unsigned short hour, min, sec,  msec;
    char msg[10];
    int data_l = 0;

     try
     {
        data_l = InstallStopEdit->Text.ToInt();
     }
     catch ( ... )
     {
        Error_Message("Rossz az install perc �rt�ke!");
        return;
     }

     if ((data_l < 10) || (data_l > 255))
     {
        Error_Message("Csak 10-255 perc lehet az install perc �rt�ke!");
        return;
     }

    if (Application->MessageBox("Lek�ldjem?", "Test id� k�rd�s.",MB_YESNO	) == IDYES  )
    {
        msg[0] = 's';
        msg[1] = 'n';
        msg[2] =  (char)(data_l);

        ComThread->Send(msg,3);
        if (UsbThread)
            UsbThread->Send(msg,3);
    }
}

//---------------------------------------------------------------------------
void __fastcall TViewForm::KonstansokBtnClick(TObject *Sender)
{
//
    if (Application->MessageBox("Konfigur�ci�t lek�rdezzem?", "Inform�ci� k�rd�s.",MB_YESNO	) == IDYES  )
    {
        char msg[10];
        msg[0] = 'g';
        msg[1] = 'i';

        ComThread->Send(msg,2);
        if (UsbThread)
            UsbThread->Send(msg,2);
    }
}
//---------------------------------------------------------------------------

