//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "USB.h"
//---------------------------------------------------------------------------
USEFORM("kliens_test.cpp", ViewForm);
USEFORM("SzReadMe.cpp", ReadMeForm);
USEFORM("Szprt.cpp", SzPr); /* TQuickRep: File Type */
USEFORM("SzHurok.cpp", HurokForm);
//---------------------------------------------------------------------------
extern TUSB*       UsbThread;
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{        
    try
    {
         Application->Initialize();
         Application->CreateForm(__classid(TViewForm), &ViewForm);
         Application->CreateForm(__classid(TReadMeForm), &ReadMeForm);
         Application->CreateForm(__classid(TSzPr), &SzPr);
         Application->CreateForm(__classid(THurokForm), &HurokForm);
         Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    catch (...)
    {
         try
         {
             throw Exception("");
         }
         catch (Exception &exception)
         {
             Application->ShowException(&exception);
         }
    }
    return 0;
}
//---------------------------------------------------------------------------
