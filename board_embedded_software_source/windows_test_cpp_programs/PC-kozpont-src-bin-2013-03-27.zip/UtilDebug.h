/***
 *  UtilDebug.h : Declaration of some debug utility classes
 *
 *  Revision : 1.0 (G. CSENDES)
 *  Date     : 10/07/00
 *  Copyright (c) 2000 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/

#ifndef __DEBUG_LOG_H
#define __DEBUG_LOG_H

//#define _INC_CRTDBG
#include <Windows.h>

#ifndef FILE
#   include <stdio.h>
#endif

// naplo file osztaly definicio
class LogFile 
{
private:
    char *szLogFile;
	bool m_Initialized;
	void PrintTime(FILE* fp);
public:
    LogFile();
    ~LogFile();

    bool Init(const char *fName);    
	bool InitCurrTime(const char* name);
    void Print(char *text);
    void Print(char *text1, char *text2);
    void Print(char *text, int num);
    void Print(char *text, double num);
	void Printf(const char* Fmt, ...);
};

extern LogFile LF;

// debug makrok
#ifdef _DEBUG

#define INIT_DEBUG(fName)       LF.Init(fName)
#define SE_DEBUG(txt)              LF.Print(txt)
#define DEBUGTXT(txt1, txt2)    LF.Print(txt1, (char*)txt2)
#define DEBUGNUM(txt, num)      LF.Print(txt, ((int)(num)))
#define DEBUGFLT(txt, num)      LF.Print(txt, ((double)(num)))
#define ERRORMSG(txt)           LF.Print("error: " , txt);
#define DEBUGERR(txt)           ERRORMSG(txt)
#define DEBUGBOX(txt) \
    { \
            ::MessageBox(NULL, txt, "DEBUG", MB_ICONSTOP); \
            DEBUGTXT("DEBUGBOX: ",txt); \
    }

// ASSERT
extern void SE_Assert (const char *file, int line, const char *msg);
#define SE_ASSERT(x)  if(!(x)) SE_Assert( __FILE__, __LINE__, #x)

#else

#define INIT_DEBUG(fName)			{}
#define SE_DEBUG(txt)				{}
#define DEBUGTXT(txt1, txt2)		{}
#define DEBUGNUM(txt, num)			{}
#define DEBUGFLT(txt, num)			{}
#define DEBUGBOX(txt)				{}
#define ERRORMSG(txt)               {}
#define DEBUGERR(txt)               ERRORMSG(txt)
#define SE_ASSERT(x)				{}

#endif //_DEBUG

#ifndef ASSERT
    #define ASSERT(x)               SE_ASSERT(x)
#endif

#endif //__DEBUG_LOG_H
