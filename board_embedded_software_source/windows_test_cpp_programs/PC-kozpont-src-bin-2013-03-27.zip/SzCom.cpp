//---------------------------------------------------------------------------
#include <vcl.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ctype.h>
#include <dirent.h>
#include <dir.h>
#include <mem.h>
#include  <dos.h>


#pragma hdrstop

#include "SzCom.h"
#include "Szprt.h"
#include "kliens_test.h"
#include "TUSB.h"
#include "SeUtils.h"
#include "SeDebugLog.h"
#pragma package(smart_init)

extern void XTPrintf(const char* sText);
extern SzCom *ComThread;


static char msg[1000];

CSeSmartPtr<CSeDebugLog> g_DebugLogFile = new CSeDebugLog("Debug.LOG", true);

unsigned short timercount = 0;

/**********************************************************
 * time out fg.
 **********************************************************/

bool t_time_out(bool start,short diff)
{	
	static bool  overflow = 0;
	static unsigned int starttimercount = 0;
	static unsigned short _time_out = 0;

	if (start)
	{
        timercount = 0;
		_time_out = diff;
	   //	overflow =(_time_out <= timercount)?1:0;
	  //	starttimercount = timercount;
      sprintf(msg,"start t:%d,te:%d",timercount,_time_out);
      XTPrintf(msg);
	}
	else
	{
        sprintf(msg,"t:%d,te:%d",timercount,_time_out);
        XTPrintf(msg);
	  /*	if (overflow)
		{
			if (timercount > _time_out)
				return false;
			else
				overflow = 0;
		}
		else  */
		if (timercount >= _time_out)
			return true;
	}
	return false;
}//uint8_t rx1_time_out(uint8_t start,uint8_t diff)


/**********************************************************************
 * DebugLog Message:
 **********************************************************************/
void DebugLog(char* msg)
{
    if (ViewForm->LogCkB->State == cbChecked)
  //  struct  time t;
   // char mess[1000];
   // gettime(&t);
   // sprintf(mess,"%2d:%02d:%02d.%02d: %s", t.ti_hour, t.ti_min, t.ti_sec, t.ti_hund,msg);
    g_DebugLogFile->WriteMessage(msg);
}//void DebLog()

//---------------------------------------------------------------------------

const char  SzCom::com_frame[] = "Pico!!!Brace\n";    // keret header.
//char Thread_Com::unit_address[] ="001";			// battery cime.
__fastcall SzCom::SzCom(bool CreateSuspended, COM_SET* cs)
	: TThread(CreateSuspended), com_set(cs)
{
    char buff[30];
    com=NULL;
    bOpen = true ;

    rxBytes = 4;
    
    sprintf(buff,"COM%d:",com_set->Port);

    com = new Tcom(buff,com_set->Baudrate ,com_set->ByteSize,
                        com_set->Parity   ,com_set->StopBits, bOpen/*, &NotOpenUSB*/);
    if (!com)
    {
        bOpen=false;
        XTPrintf("COM port open error!");
    }
    bBootLoad=false;

/*
    usb = new TUSB();
    if (!usb)
        return;
   
    if (!usb->Init(ViewForm,&com->recbuff[0],&com->sendbuff[0]))
        return;

  if (usb)
	usb->u_RecLength=0;  */
}

//---------------------------------------------------------------------------
void PrintErrorStatus(HANDLE hand, DWORD dwErrorFlags)
{
//    char msg[100];
  
    sprintf(msg,"COM%d: Com Error: ",ComThread->com_set->Port);

    switch(dwErrorFlags)
    {
        case CE_BREAK:
            strcat(msg,"BREAK");
            break;
        case CE_DNS:
            strcat(msg,"DNS");
            break;
        case CE_FRAME:
            strcat(msg,"FRAME");
            break;
        case CE_IOE:
            strcat(msg,"IOE");
            break;
        case CE_MODE:
            strcat(msg,"MODE");
            break;
        case CE_OOP:
            strcat(msg,"OOP");
            break;
        case CE_OVERRUN:
            strcat(msg,"OVERRUN");
            break;
        case CE_PTO:
            strcat(msg,"PTO");
            break;
        case CE_RXOVER:
            strcat(msg,"RXOVER");
            break;
        case CE_RXPARITY:
            strcat(msg,"RXPARITY");
            break;
        case CE_TXFULL:
            strcat(msg,"TXFULL");
            break;
    }
    XTPrintf(msg);
}//void PrintErrorStatus(DWORD dwErrorFlags)

//---------------------------------------------------------------------------
void __fastcall SzCom::Execute()
{
    COMSTAT     ComStat ;
    DWORD       dwLength;
    DWORD       dwErrorFlags;
    HANDLE      hPort=com->Get_hPort();
    DWORD       dwEvtMask;
	bool	    result=true;
    m_logprint  = 0;
    m_logindex  = 0;


 /*   t_time_out(1,4);
    timercount = 0xffe1;
    while(!Terminated)
    {

        Sleep(100);
        if (t_time_out(0,0))
        {
            XTPrintf("VEGE");
            t_time_out(1,4);
        }


    }
    return; */

        hPort=com->Get_hPort();
        if (hPort==NULL)
            return;
        if (!SetCommMask( hPort, EV_RXCHAR|EV_ERR|EV_TXEMPTY ))
        {
            error = GetLastError();
            strcpy(errorstr,"CreateEvent");
            DoTerminate();
        }

    if (hPort==NULL)
        return;

	while(result && !Terminated)
	{
      	dwEvtMask = 0 ;
        while(ViewForm->recStop);
		if (WaitCommEvent(hPort, &dwEvtMask, /*&com->osRead*/NULL))
        {
            ViewForm->TimerTimer->Interval = 2000;
    		switch (dwEvtMask)
        	{
         		case EV_ERR :
               		com->ClearCommErr(hPort, &dwErrorFlags, &ComStat, true );
            		break;
				case EV_RXCHAR:

                    if (!com->ReadCom( com->recbuff, 36))
                    {
    //                      XTPrintf("Rec Error");
                          com->ClearCommErr(hPort, &dwErrorFlags, &ComStat, true );
   //                     Send(true);
                        break;
                    }
                    Synchronize(CompleteRequest);
            		break;
                case EV_TXEMPTY:
                {
/*                   if (Closeflg)
                    {
                        if (com)
                            delete com;
                        Closeflg=false;
                        Sleep(100);
                    }
*/
                    break;
                }
				default:
         	   		break;
        	}
 		}
    	else
		{
        	error = GetLastError();
        	strcpy(errorstr,"WaitCommEvent");
            result = false;
            DoTerminate();
    	}
	}
	if (!error)
    	DoTerminate();

}//Execute()
//---------------------------------------------------------------------------

void __fastcall SzCom::StopThread(void)
{
    SetCommMask( com->Get_hPort(), 0);
}//StopThread(void)

//---------------------------------------------------------------------------
 void __fastcall SzCom::CompleteRequest(void)
 {

    if (com->dwLength<=0)
    {
        XTPrintf("COM Length Error!");
       
        return;
    }
    int ii=0;
//    com->recbuff[com->dwLength] = 0;
 //     sprintf(msg,"received: %s,",com->recbuff);
   //   XTPrintf(msg);


    if (ViewForm->DumpChB->State == cbChecked)
        dump(&com->recbuff[0], com->dwLength);
    else
    {                                                                     
        char* pch;
         pch = strtok(com->recbuff,"\r\n");
    //    com->recbuff[com->dwLength] = 0;
     //   sprintf(msg,"%s,",com->recbuff);

        if (!strcmp("!sP",pch))
        {
            m_logprint = 1;
            m_logindex = 0;
             ViewForm->ReadeLogBn->Enabled = false;
        //    SzPr->QRStringsBand->Items->Clear();
            return;
        }
        if (!strcmp("!eP",pch))
        {
            m_logprint = 2;
            ViewForm->ReadeLogBn->Enabled = true;
           // ViewForm->PrintBtn->Enabled = true;
          //  return;
        }

        if (m_logprint == 1)
        {

            while (com->dwLength)
            {
                m_lamplog[m_logindex] = com->recbuff[ii];
                ++ii;
                ++m_logindex;
                --com->dwLength;
            }
             m_logindex-=1;
            return;
        }
        else
        if (m_logprint == 2)
        {
            for (ii=0;ii<m_logindex;ii++)
            {
                 if (m_lamplog[ii] == 0)
                    m_lamplog[ii]  = 0x20;
            }
            m_logindex = 0;
            m_logprint = 0;
           //   XTPrintf(m_lamplog);
            pch = strtok(m_lamplog,"\r\n");
            while(pch)
            {
                if (pch)
                {
                    XTPrintf(pch);
               // DebugLog(pch);
                }
                pch = strtok(NULL,"\r\n");
            }
            return;
        }
        else
            XTPrintf(pch);
     /*   if (bprint == 1)
        {
            SzPr->QRStringsBand->Items->Add(pch);
            return;
        }     */
      //  DebugLog(pch);

        while(pch)
        {
             pch = strtok(NULL,"\n");
            if (pch)
            {
                XTPrintf(pch);
               // DebugLog(pch);
            }

        }


    }

      //Send(false);

} // void CompleteRequest(void)


//---------------------------------------------------------------------------
DWORD __fastcall SzCom::Send(char* msg, int len)
{
    m_logprint = 0;
    dump(msg,len);
//    XTPrintf(msg);
    return com->WriteCom(msg,len);

}//Send(..)

//---------------------------------------------------------------------------
DWORD __fastcall SzCom::SendNoDump(char* msg, int len)
{
    return com->WriteCom(msg,len);

}//SendNoDump(..)

/**************************************************************************
 *		Com class part start
 *************************************************************************/
//const char** Tcom::com_error_header=com_exception_msg;

__fastcall Tcom::Tcom(const char* com,WORD Baudrate, Byte ByteSize, Byte Parity, Byte StopBits, bool& error /*short num */)
//    : thread_num(num)
{
    COMMTIMEOUTS  CommTimeOuts ;
    strcpy(Port,com);
    char buff[100];

//    com_exception.msg_header=com_error_header;
//    com_exception.handle=Application->Handle;
//	sprintf( com_exception.msg,"%s port error: ", com);
//	error = false;
//    try
//    {
		hPort = CreateFile (TEXT(Port), // Port Name (Unicode compatible)
                    GENERIC_READ|GENERIC_WRITE,  // Open for Read-Write
                    0,             // COM port cannot be shared
                    NULL,          // Always NULL for Windows CE
                    OPEN_EXISTING, // For communication resource
                    FILE_FLAG_OVERLAPPED,// Non-overlapped operation only
//                    0,
//                    FILE_ATTRIBUTE_NORMAL,
                    NULL);         // Always NULL for Windows CE
  		if (hPort == INVALID_HANDLE_VALUE)
        {
  /*         if (hPort == INVALID_HANDLE_VALUE)
            {
        		com_exception.set_errorcode(GetLastError());
            	com_exception.set_errorindex(COM_OPEN_ERROR);
                com_exception.set_errorport(thread_num);
            	throw( 	com_exception );
			}
  */
            error=false;
            sprintf(buff, "%s not open !!", Port);
            XTPrintf(buff);
            return;
		}
        else
        {
            sprintf(buff, "%s open !!", Port);
            XTPrintf(buff);
        }

 		if (!GetCommState(hPort,&dDCB))
    	{
            CloseHandle(hPort);
            error=false;
            sprintf(buff, "%s open,but GetCommState() error was !!", Port);
            XTPrintf(buff);
            return;
    	}

 		dDCB.BaudRate = Baudrate;
 		dDCB.ByteSize = ByteSize;
 		dDCB.Parity   = Parity;
 		dDCB.StopBits =	StopBits;
  		dDCB.fBinary = TRUE ;
        dDCB.fParity = TRUE ;
        dDCB.fAbortOnError= TRUE;


// 	dDCB.Flags 	  = 5;;

 		if (!SetCommState( hPort,&dDCB ))
    	{
            CloseHandle(hPort);
            error=false;
            sprintf(buff, "%s open,but SetCommState() error was !!", Port);
            XTPrintf(buff);
            return;
    	}
        SetupComm( hPort, RXQUEUE, TXQUEUE ) ;
        PurgeComm( hPort, PURGE_TXCLEAR|PURGE_RXCLEAR|
        					   PURGE_TXABORT | PURGE_RXABORT );

 //      SetDCB(FBAUDRATE,FBYTESIZE,FPARITY,FSTOPBIT);

        memset( &osRead, 0, sizeof( OVERLAPPED ) ) ;
        memset( &osWrite, 0, sizeof( OVERLAPPED ) ) ;
      // set up for overlapped I/O
        osRead.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    FALSE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName
        if(osRead.hEvent == INVALID_HANDLE_VALUE)
	    {
            CloseHandle(hPort);
            error=false;
            sprintf(buff, "%s open,but Set event error was !!", Port);
            XTPrintf(buff);
            return;
        }

 	    osWrite.hEvent = CreateEvent(NULL,// LPSECURITY_ATTRIBUTES lpsa
			    TRUE, // BOOL fManualReset
			    TRUE, // BOOL fInitialState
			    NULL); // LPTSTR lpszEventName
        if(osWrite.hEvent == INVALID_HANDLE_VALUE)
	    {
            CloseHandle(hPort);
            error=false;
            sprintf(buff, "%s open,but Set event error was !!", Port);
            XTPrintf(buff);
            return;
        }
        //9600
       	CommTimeOuts.ReadIntervalTimeout = 40;
      	CommTimeOuts.ReadTotalTimeoutMultiplier = 1 ;
      	CommTimeOuts.ReadTotalTimeoutConstant = 0 ;
        //2400
       // CommTimeOuts.ReadIntervalTimeout = 100;
       //	CommTimeOuts.ReadTotalTimeoutMultiplier = 2 ;
       //	CommTimeOuts.ReadTotalTimeoutConstant = 0 ;

      // CBR_9600 is approximately 1byte/ms. For our purposes, allow
      // double the expected time per character for a fudge factor.
//      	CommTimeOuts.WriteTotalTimeoutMultiplier = 2*CBR_9600/Baudrate ;
   //     CommTimeOuts.WriteIntervalTimeout = MAX_REC_LENGTH*2;
  		CommTimeOuts.WriteTotalTimeoutMultiplier =  2*CBR_9600/Baudrate ;
      	CommTimeOuts.WriteTotalTimeoutConstant = 20 ;
      	if (!SetCommTimeouts(hPort , &CommTimeOuts ))
        {
            CloseHandle(hPort);
            error=false;
            sprintf(buff, "%s open,but GetCommState() error was !!", Port);
            XTPrintf(buff);
            return;
        }
	  	error=true;
}/* com(...) */

__fastcall Tcom::~Tcom(void)
{
	CloseHandle(hPort);
}/* ~com(void) */

//--------------------------------------------------------------------------
DWORD __fastcall  Tcom::ReadCom(LPSTR lpszBlock, int nMaxLength )
{
   DWORD iBytesReadThisTime=0;
   DWORD iBytesRead=0;
   BOOL       fReadStat ;
   COMSTAT    ComStat ;
   DWORD      dwErrorFlags;
   DWORD   dwError,dwTr;

   dwTr = nMaxLength;

   if (dwTr <= 0)
    return 0;

   while(dwTr)
   {
        fReadStat = ReadFile( hPort, &lpszBlock[iBytesRead], dwTr, &iBytesReadThisTime, &osRead ) ;

        if (!fReadStat && (GetLastError() == ERROR_IO_PENDING))
        {
                if(!GetOverlappedResult( hPort,&osRead, &dwTr, TRUE ))
                {
                    dwError = GetLastError();
                    if(dwError == ERROR_IO_INCOMPLETE)
                        continue;
                    else
                    {
                        ClearCommErr( hPort, &dwErrorFlags, &ComStat, true ) ;
                        dwLength=0;
                        return 0;
                    }
                }
                iBytesRead+=dwTr;
        }
        else
        {
                ClearCommErr( hPort, &dwErrorFlags, &ComStat, true ) ;
                iBytesRead+=iBytesReadThisTime;
                break;
        }
    }
   ClearCommErr( hPort, &dwErrorFlags, &ComStat, true ) ;
   dwLength=iBytesRead;

//  if (dwLength)
//       dump(  lpszBlock, dwLength);
   return dwLength ;
}/*  DWORD __fastcall  Tcom::ReadCommBlock(..)*/

//--------------------------------------------------------------------------
DWORD __fastcall Tcom::WriteCom(char* buf,int len)
{
    DWORD write;
//	DWORD dwBytesSent=0;
	DWORD dwErrorFlags;
   	COMSTAT     ComStat;
  

	if (len <= 0)
		return -1;

    if(!WriteFile(hPort,buf,len,&write,&osWrite))
 	{
		if(GetLastError() == ERROR_IO_PENDING)
		{
         	while(GetOverlappedResult( hPort, &osWrite, &write, TRUE ))
         	{
           		if (GetLastError() == ERROR_IO_INCOMPLETE)
            	{
               		continue;
            	}
            	else
            	{
               		ClearCommError( hPort, &dwErrorFlags, &ComStat ) ;
               		break;
            	}
			}
		}
		else
		{
            ClearCommError( hPort, &dwErrorFlags, &ComStat ) ;
		}
    }
    return write;
};


/***************************************************************************
 *  FUNCTION-NAME  :  ClearCommErr
 *  DESCRIPTION    :  com receive error
 ***************************************************************************/
bool __fastcall Tcom::ClearCommErr( HANDLE hFile, LPDWORD dwErrors, LPCOMSTAT ComStat, bool mode)
{
	 ClearCommError( hFile, dwErrors, ComStat ) ;
     char sText[50];
     if (!*dwErrors && mode)
     {
//        sprintf(sText,"Rec error: %s",com_error[*dwErrors]);
//        XTPrintf(sText);
//            Ser_Test->Xterm->Lines->Add(sText);
     }
     return true;
}/*   ClearCommError( hPort, &dwErrorFlags, &ComStat ) */

/***************************************************************************/
/*  FUNCTION-NAME  :  dump                                                 */
/*  DESCRIPTION    :  dumps a buffer                                       */
/*  PARAMETERS     :  - buffer to be dumped                                */
/*                    - lenght of buffer                                   */
/*  RETURN-VALUE   :  - TRUE if OK.                                        */
/*                    - FALSE otherwise                                    */
/*  EXTERNAL REFERENCES : none                                             */
/*  MODIFIED EXTERNALS  : none                                             */
/***************************************************************************/
BOOL dump(  void *buf, unsigned long len )
{
#define DUMP_LINE_LEN 16
#define min(a,b)  ((a) < (b) ? (a) : (b) )
        unsigned short line, incr = 0;
        unsigned char *p;
        unsigned short i,c;
        unsigned char  left[DUMP_LINE_LEN*3+2], right[DUMP_LINE_LEN+1];
        char	sRes[100];
        // invalid pointer ?
	if (!buf)
           return FALSE;
        for (p = (unsigned char*)buf, line = 0; len; p += incr, len -= incr, line++)
        {
            incr = min( len, DUMP_LINE_LEN);
	    memset(right, 0, sizeof(right));
	    for (i = 0; i < incr; i++ )
		{
                sprintf((char*)&left[i*3], "%02X ", c = (unsigned short)p[i]);
                right[i] = (unsigned char)(isprint(c) ? c:'.');
        }
            	sprintf(sRes,"%04X: %-48s [%-16s]\n", line*DUMP_LINE_LEN, left, right);
             XTPrintf(sRes);

        }
   //     XTPrintf(sRes);
	return TRUE;
} // dump


/****************************************************************************
 *  FUNCTION-NAME  : int Bcd_Hex(char );
 *  DESCRIPTION    : Bcd to Hex converter.
 ****************************************************************************/
 int BcdtoHex(short data)
 {
 	short temp,temp1;

    temp1=(data & 15);
     data&=240;
    temp=data*10+temp1;
    temp1=temp/16;
    temp%=16;
    return temp1+temp;

 }/*  int BcdtoHex(char data)*/

 /****************************************************************************
 *  FUNCTION-NAME  : char HextoBcd(short );
 *  DESCRIPTION    : Hex to Bcd converter.
 ****************************************************************************/
 char HextoBcd(short data)
 {
 	short temp,temp1;

    temp=((data/10)<<4);
    temp1=(data%10);
    return (char)(temp1+temp);

 }/*  char HextoBcd(short data)*/
