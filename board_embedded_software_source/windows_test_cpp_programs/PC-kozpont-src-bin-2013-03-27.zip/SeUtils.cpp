/***
 *  SeUtils.cpp : Implementation of some utility classes
 *
 *  Revision : 1.0 (A. Tagscherer)
 *  Date     : 10/07/00
 *  Copyright (c) 2000 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/
#include "stdafx.h"
#include <math.h>
#pragma hdrstop

#ifndef _ASSERTE
	#include "crtdbg.h"
//    #include "UtilDebug.h"
//    #define _ASSERTE SE_ASSERT
    #include <atlbase.h>
//  #undef _ASSERTE
#else
    #include <atlbase.h>
#endif


#include "SeUtils.h"
#include "SeErrorHandler.h"


//#define FALSESTRING     _T("FALSE")
//#define TRUESTRING      _T("TRUE")


//accepted format: YYYY.MM.DD[ HH24:MI[:SS[.MSE]]]
HRESULT DateTimeStrToSystemTime(CString &dtstr,SYSTEMTIME &systime)
{
    SYSTEMTIME t;
    t.wDayOfWeek = -1;
    t.wHour = 0;
    t.wMinute = 0;
    t.wSecond = 0;
    t.wMilliseconds = 0;
    TCHAR *end_ptr;
    CString str;
    str = dtstr.Mid(0,4);           //YYYY
    if (str.GetLength() < 4)
        CHECKHRESULT(E_FAIL)
    t.wYear = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(5,2);
    if (str.GetLength() < 2)
        CHECKHRESULT(E_FAIL)
    t.wMonth = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(8,2);
    if (str.GetLength() < 2)
        CHECKHRESULT(E_FAIL)
    t.wDay = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(11,2);
    if (str.GetLength() == 0)
    {
        systime = t;
        return S_OK;
    }
    if (str.GetLength() < 2)
        CHECKHRESULT(E_FAIL)
    t.wHour = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(14,2);
    if (str.GetLength() < 2)
        CHECKHRESULT(E_FAIL)
    t.wMinute = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(17,2);
    if (str.GetLength() == 0)
    {
        systime = t;
        return S_OK;
    }
    if (str.GetLength() < 2)
        CHECKHRESULT(E_FAIL)
    t.wSecond = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    str = dtstr.Mid(20,3);
    if (str.GetLength() == 0)
    {
        systime = t;
        return S_OK;
    }
    if (str.GetLength() < 3)
        CHECKHRESULT(E_FAIL)
    t.wMilliseconds = (WORD)_tcstod((LPCTSTR)str,&end_ptr);
    if (*end_ptr != 0)
        CHECKHRESULT(E_FAIL)

    systime = t;
    return S_OK;
}

/*
HRESULT __SeCreateConfigParamArray(long indexcount,VARIANT *array)
{
	SAFEARRAYBOUND sab[2] = {{2,0},{indexcount,0}};
	SAFEARRAY *sa;

	if (array == NULL)
		return S_OK;
	sa = SafeArrayCreate(VT_VARIANT,2,sab);
	if (sa == NULL)
		CHECKHRESULT(E_OUTOFMEMORY)
	VariantInit(array);
	array->vt = VT_ARRAY | VT_VARIANT;
	array->parray = sa;
	return S_OK;
}

HRESULT __SeGetParamInConfigParamArray(const VARIANT &array,long index,BSTR *paramname,VARIANT *paramval)
{
	HRESULT hr;
	CComVariant cv1,cv2;
	long idxs[2][2] = {{0,index},{1,index}};
	SAFEARRAY *sa;

	if (((array.vt & VT_ARRAY) != VT_ARRAY) || ((array.vt & VT_VARIANT) != VT_VARIANT) ||
        (!(array.parray)) || (SafeArrayGetDim(array.parray) != 2))
    {
        CHECKHRESULT(E_INVALIDARG)
    }
	sa = array.parray;
	hr = SafeArrayGetElement(sa,idxs[0],&cv1);
	CHECKHRESULT(hr)
	hr = SafeArrayGetElement(sa,idxs[1],&cv2);
	CHECKHRESULT(hr)

    if (paramval != NULL)
    {
        VariantInit(paramval);
        hr = cv2.Detach(paramval);
        CHECKHRESULT(hr)
    }
    if (paramname != NULL)
        *paramname = ::SysAllocString(cv1.bstrVal);
    return S_OK;
}

HRESULT __SeSetParamInConfigParamArray(const VARIANT &array,long index,const BSTR paramname,const VARIANT &paramval)
{
	HRESULT hr;
	CComVariant cv;
	long idxs[2][2] = {{0,index},{1,index}};
	SAFEARRAY *sa;

	if (((array.vt & VT_ARRAY) != VT_ARRAY) || ((array.vt & VT_VARIANT) != VT_VARIANT) ||
        (!(array.parray)) || (SafeArrayGetDim(array.parray) != 2))
    {
        CHECKHRESULT(E_INVALIDARG)
    }
	sa = array.parray;
	cv = paramname;
	hr = SafeArrayPutElement(sa,idxs[0],&cv);
	CHECKHRESULT(hr)
	hr = SafeArrayPutElement(sa,idxs[1],(void*)&paramval);
	CHECKHRESULT(hr)
	return S_OK;
}

HRESULT __SeFindParamInConfigParamArray(const VARIANT &array,const BSTR paramname,VARIANT *paramval,bool &found)
{
	HRESULT hr;
	long a,last;
	long indexes[2];
	CComVariant cv;
	SAFEARRAY *sa;

	if (((array.vt & VT_ARRAY) != VT_ARRAY) || ((array.vt & VT_VARIANT) != VT_VARIANT))
		CHECKHRESULT(E_FAIL)
	sa = array.parray;
	hr = SafeArrayGetUBound(sa,2,&last);
	CHECKHRESULT(hr)
	indexes[0] = 0;
	for (a = 0; a <= last; a++)
	{
		indexes[1] = a;
		hr = SafeArrayGetElement(sa,indexes,&cv);
		CHECKHRESULT(hr)
		if (cv.vt != VT_BSTR)
			CHECKHRESULT(E_FAIL)
		if (_wcsicoll(cv.bstrVal,paramname) == 0)
		{
			if (paramval != NULL)
			{
			    indexes[0] = 1;
			    cv.Clear();
			    hr = SafeArrayGetElement(sa,indexes,&cv);
			    CHECKHRESULT(hr)
			    VariantInit(paramval);
			    hr = cv.Detach(paramval);
			    CHECKHRESULT(hr)
			}
			found = true;
			return S_OK;
		}
	}
	found = false;
	return S_OK;
}
*/
HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,CComBSTR &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_BSTR);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
	OutValue = cv.bstrVal;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,CString &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_BSTR);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    OutValue = cv.bstrVal;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,BYTE &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_UI1);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    OutValue = cv.bVal;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,long &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_I4);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    OutValue = cv.lVal;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,double &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_R8);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    OutValue = cv.dblVal;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,bool &OutValue)
{
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_BOOL);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    OutValue = cv.boolVal ? true:false;
    return S_OK;
}

HRESULT SeVariantToTypeNoLocale(const VARIANT &InValue,IUnknown **OutValue)
{
    if (!OutValue)
        return S_OK;
    CComVariant cv(InValue);
    HRESULT hr = SeChangeVariantTypeNoLocale(cv,cv,VT_UNKNOWN);
    if (hr == DISP_E_OVERFLOW)
        hr = DISP_E_TYPEMISMATCH;
    CHECKHRESULT(hr)
    *OutValue = cv.punkVal;
    return S_OK;
}

HRESULT SeTypeToVariant(BSTR InValue,CComVariant &OutValue)
{
    CComVariant cv(InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(const CString &InValue,CComVariant &OutValue)
{
    CComVariant cv((BSTR)T2ComBSTR(InValue));
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(const TCHAR *InValue,CComVariant &OutValue)
{
    CComVariant cv((BSTR)T2ComBSTR(InValue));
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(BYTE InValue,CComVariant &OutValue)
{
    CComVariant cv(InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(long InValue,CComVariant &OutValue)
{
    CComVariant cv(InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(double InValue,CComVariant &OutValue)
{
    CComVariant cv(InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(bool InValue,CComVariant &OutValue)
{
    CComVariant cv(InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeTypeToVariant(const IUnknown *InValue,CComVariant &OutValue)
{
    CComVariant cv((IUnknown*)InValue);
    if ((cv.vt == VT_NULL) || (cv.vt == VT_EMPTY))
        CHECKHRESULT(E_INVALIDARG)
    HRESULT hr;
    hr = OutValue.Clear();
    CHECKHRESULT(hr)
    hr = cv.Detach(&OutValue);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeChangeVariantTypeNoLocale(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType)
{
    HRESULT hr = SeChangeVariantType(Input,Output,OutputVarType,MAKELCID(MAKELANGID(LANG_ENGLISH,SUBLANG_ENGLISH_UK),SORT_DEFAULT),false);
    CHECKHRESULT(hr)
    return S_OK;
/* default locale settings for UK_ENGLISH 
LOCALE_ICALENDARTYPE        "1"
LOCALE_ICURRDIGITS          "2"
LOCALE_ICURRENCY            "0"
LOCALE_IDIGITS              "2"
LOCALE_IFIRSTDAYOFWEEK      "0"
LOCALE_IFIRSTWEEKOFYEAR     "0"
LOCALE_ILZERO               "1"
LOCALE_IMEASURE             "0"
LOCALE_INEGCURR             "1"
LOCALE_INEGNUMBER           "1"
LOCALE_IPAPERSIZE           "9"
LOCALE_ITIME                "1"
LOCALE_S1159                "AM"
LOCALE_S2359                "PM"
LOCALE_SCURRENCY            "L"
LOCALE_SDATE                "/"
LOCALE_SDECIMAL             "."
LOCALE_SGROUPING            "3;0"
LOCALE_SLIST                ","
LOCALE_SLONGDATE            "dd MMMM yyyy"
LOCALE_SMONDECIMALSEP       "."
LOCALE_SMONGROUPING         "3;0"
LOCALE_SMONTHOUSANDSEP      ","
LOCALE_SNEGATIVESIGN        "-"
LOCALE_SPOSITIVESIGN        ""
LOCALE_SSHORTDATE           "dd/MM/yyyy"
LOCALE_STHOUSAND            ","
LOCALE_STIME                ":"
LOCALE_STIMEFORMAT          "HH:mm:ss"
LOCALE_SYEARMONTH           "MMMM yyyy"
*/
}

HRESULT SeChangeVariantTypeCurrentLocale(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType)
{
    HRESULT hr = SeChangeVariantType(Input,Output,OutputVarType,MAKELCID(MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT),SORT_DEFAULT),true);
    CHECKHRESULT(hr)
    return S_OK;
}

HRESULT SeChangeVariantType(const VARIANT &Input,CComVariant &Output,VARTYPE OutputVarType,LCID LocaleID,bool UseUserSettingsOnCP)
{
    CComVariant ocv;
    bool ibstr = false,obstr = false;
    HRESULT hr;
    DWORD flag = UseUserSettingsOnCP ? 0:LOCALE_NOUSEROVERRIDE;
    if ((Input.vt == OutputVarType) || (Input.vt == VT_EMPTY) || (Input.vt == VT_NULL)) //do not need to change the type!
    {
        if (&Input != &Output)  //if not the same variable
        {
            ocv = Input;
            hr = ocv.Detach(&Output);
            CHECKHRESULT(hr)
        }
        return S_OK;
    }
    if (Input.vt == VT_BSTR)
        ibstr = true;
    if (OutputVarType == VT_BSTR)
        obstr = true;
    bool needconversion = false;
    if ((ibstr && (!obstr)) || ((!ibstr) && obstr))
    {
        if (ibstr)
        {
            switch(OutputVarType)
            {
            case VT_I1:
                hr = VarI1FromStr(Input.bstrVal,LocaleID,flag,&(ocv.cVal));
                CHECKHRESULT(hr)
                break;
            case VT_I2:
                hr = VarI2FromStr(Input.bstrVal,LocaleID,flag,&(ocv.iVal));
                CHECKHRESULT(hr)
                break;
            case VT_I4:
                hr = VarI4FromStr(Input.bstrVal,LocaleID,flag,&(ocv.lVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI1:
                hr = VarUI1FromStr(Input.bstrVal,LocaleID,flag,&(ocv.bVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI2:
                hr = VarUI2FromStr(Input.bstrVal,LocaleID,flag,&(ocv.uiVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI4:
                hr = VarUI4FromStr(Input.bstrVal,LocaleID,flag,&(ocv.ulVal));
                CHECKHRESULT(hr)
                break;
            case VT_R4:
                hr = VarR4FromStr(Input.bstrVal,LocaleID,flag,&(ocv.fltVal));
                CHECKHRESULT(hr)
                break;
            case VT_R8:
                hr = VarR8FromStr(Input.bstrVal,LocaleID,flag,&(ocv.dblVal));
                CHECKHRESULT(hr)
                break;
            case VT_DATE:
                hr = VarDateFromStr(Input.bstrVal,LocaleID,flag,&(ocv.date));
                CHECKHRESULT(hr)
                break;
            case VT_BOOL:
                hr = VarBoolFromStr(Input.bstrVal,LocaleID,flag,&(ocv.boolVal));
                CHECKHRESULT(hr)
                break;
            case VT_DECIMAL:
                hr = VarDecFromStr(Input.bstrVal,LocaleID,flag,&(ocv.decVal));
                CHECKHRESULT(hr)
                break;
            case VT_CY:
                hr = VarCyFromStr(Input.bstrVal,LocaleID,flag,&(ocv.cyVal));
                CHECKHRESULT(hr)
                break;
            default:
                needconversion = true;
                break;
            }
            if (!needconversion)
                ocv.vt = OutputVarType;
        }
        else    //obstr
        {
            switch(Input.vt)
            {
            case VT_I1:
                hr = VarBstrFromI1(Input.cVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_I2:
                hr = VarBstrFromI2(Input.iVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_I4:
                hr = VarBstrFromI4(Input.lVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI1:
                hr = VarBstrFromUI1(Input.bVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI2:
                hr = VarBstrFromUI2(Input.uiVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_UI4:
                hr = VarBstrFromUI4(Input.ulVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_R4:
                hr = VarBstrFromR4(Input.fltVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_R8:
                hr = VarBstrFromR8(Input.dblVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_DATE:
                if ((Input.date < 1.0) && (Input.date >= 0.0))
                {
                    hr = VarBstrFromDate(Input.date,LocaleID,flag | VAR_TIMEVALUEONLY,&(ocv.bstrVal));
                    CHECKHRESULT(hr)
                }
                else if (floor(Input.date) == Input.date)
                {
                    hr = VarBstrFromDate(Input.date,LocaleID,flag | VAR_DATEVALUEONLY,&(ocv.bstrVal));
                    CHECKHRESULT(hr)
                }
                else
                {
                    hr = VarBstrFromDate(Input.date,LocaleID,flag,&(ocv.bstrVal));
                    CHECKHRESULT(hr)
                }
                break;
            case VT_BOOL:
                hr = VarBstrFromBool(Input.boolVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_DECIMAL:
                hr = VarBstrFromDec((DECIMAL*)(&(Input.decVal)),LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            case VT_CY:
                hr = VarBstrFromCy(Input.cyVal,LocaleID,flag,&(ocv.bstrVal));
                CHECKHRESULT(hr)
                break;
            default:
                needconversion = true;
                break;
            }
            if (!needconversion)
                ocv.vt = OutputVarType;
        }
    }
    if (needconversion)
    {
        hr = VariantChangeTypeEx(&ocv,(VARIANT*)(&Input),LocaleID,(unsigned short)flag,OutputVarType);
        CHECKHRESULT(hr)
    }
    hr = Output.Clear();
    CHECKHRESULT(hr)
    hr = ocv.Detach(&Output);
    CHECKHRESULT(hr)
    return S_OK;
}

bool SeVariantIsEmpty(const VARIANT &Vari)
{
    return ((Vari.vt == VT_EMPTY) || (Vari.vt == VT_NULL));
}

HRESULT SeDoubleToStringCurrentLocal(double Value,CString &StrValue)
{
	CComVariant cv1(Value),cv2;
	HRESULT hr = SeChangeVariantTypeCurrentLocale(cv1,cv2,VT_BSTR);
	CHECKHRESULT(hr)
	StrValue = cv2.bstrVal;
	return S_OK;
}

HRESULT SeStringToDoubleCurrentLocal(const CString &StrValue,double &Value)
{
    CComVariant cv1((BSTR)T2ComBSTR(StrValue)),cv2;
	HRESULT hr = SeChangeVariantTypeCurrentLocale(cv1,cv2,VT_R8);
	CHECKHRESULT(hr)
	Value = cv2.dblVal;
	return S_OK;
}

CString SeGetPrivateProfileString(LPCTSTR lpAppName,LPCTSTR lpKeyName,LPCTSTR Default,LPCTSTR lpFileName)
{
    CString str;
	long bs = MAX_PATH,cs;
	long len = Default ? _tcslen(Default):0;
	if (bs < len)
		bs = len + 1;
	bool ok = false;
	do
	{
		cs = GetPrivateProfileString(lpAppName,lpKeyName,Default,str.GetBuffer(bs),bs,lpFileName);
		str.ReleaseBuffer();
		if (cs == bs - 1)
			bs *= 2;
		else
			ok = true;
	} while (!ok);
	return str;
}

double SeGetPrivateProfileDouble(LPCTSTR lpAppName,LPCTSTR lpKeyName,double Default,LPCTSTR lpFileName)
{
    CString str;
    GetPrivateProfileString(lpAppName,lpKeyName,"",str.GetBuffer(MAX_PATH),MAX_PATH,lpFileName);
    str.ReleaseBuffer();
    TCHAR* endpt;
    double d = _tcstod((LPCTSTR)str,&endpt);
    if ((str.IsEmpty()) || (endpt[0] != _T('\0')))
        d = Default;
    return d;
}

bool SeGetPrivateProfileBool(LPCTSTR lpAppName,LPCTSTR lpKeyName,bool Default,bool *Exist,LPCTSTR lpFileName)
{
    CString str;
    GetPrivateProfileString(lpAppName,lpKeyName,"",str.GetBuffer(MAX_PATH),MAX_PATH,lpFileName);
    str.ReleaseBuffer();
    if (str.CompareNoCase(_T("TRUE")) == 0)
    {
        if (Exist)
            *Exist = true;
        return true;
    }
    else if (str.CompareNoCase(_T("FALSE")) == 0)
    {
        if (Exist)
            *Exist = true;
        return false;
    }
    else if (str.CompareNoCase(_T("0")) == 0)
    {
        if (Exist)
            *Exist = true;
        return false;
    }
    else if (str.CompareNoCase(_T("1")) == 0)
    {
        if (Exist)
            *Exist = true;
        return true;
    }
    else
    {
        if (Exist)
            *Exist = false;
        return Default;
    }
}

long SeSystemDeltaTimeToMS(SYSTEMTIME st)
{
    return (((long)st.wDay) * 24 * 3600 * 1000 + ((long)st.wHour) * 3600 * 1000 + ((long)st.wMinute) * 60 * 1000 + ((long)st.wSecond) * 1000 + ((long)st.wMilliseconds));
}

SYSTEMTIME SeMSToSystemDeltaTime(long ms)
{
	SYSTEMTIME st;
	ms = abs(ms);
	st.wDay = ms / (24 * 3600 * 1000);
	ms %= (24 * 3600 * 1000);
	st.wHour = ms / (3600 * 1000);
	ms %= (3600 * 1000);
	st.wMinute = ms / (60 * 1000);
	ms %= (60 * 1000);
	st.wSecond = ms / 1000;
	st.wMilliseconds = ms % 1000;
    return st;
}


//if dtSrc1 < dtSrc2 -> return -1 
//if dtSrc1 == dtSrc2 -> return 0
//else return 1
long CompareDates(DATE dtSrc1, DATE dtSrc2)
{
	if (dtSrc1 == dtSrc2)
		return 0;
	if ((dtSrc1 < 0.0) && (dtSrc2 >= 0.0))
		return -1;
	else if ((dtSrc1 < 0.0) && (dtSrc2 < 0.0))
	{
		double d1 = ceil(dtSrc1);
		double d2 = ceil(dtSrc2);
		if (d1 < d2)
			return -1;
		else if (d1 > d2)
			return 1;
		else
		{
			double h1 = fabs(dtSrc1 - d1);
			double h2 = fabs(dtSrc2 - d2);
			return (h1 < h2) ? -1 : 1;
		}
	}
	else
		return (dtSrc1 < dtSrc2) ? -1:1;
}

void SeDelay( int DelayInMillisec)
{
    LARGE_INTEGER start, stop, frequency;
    LONGLONG diff, milliseccount;

    QueryPerformanceFrequency(&frequency);
    milliseccount = (LONGLONG)DelayInMillisec * frequency.QuadPart / (LONGLONG)1000;

    QueryPerformanceCounter(&start);
    do
    {
    QueryPerformanceCounter(&stop);
    diff = stop.QuadPart - start.QuadPart;
    } while(diff < milliseccount);
}

HRESULT GetModuleDirAndFileName(HINSTANCE hInstance,CString *ModuleDir,CString *ModuleFileName)
{
    CString path;
    DWORD len = GetModuleFileName(hInstance,path.GetBuffer(MAX_PATH),MAX_PATH);
    path.ReleaseBuffer();
    if (len > 0)
    {
        int backslash = path.ReverseFind(_T('\\'));
        if (backslash >= 0)
        {
            if (ModuleFileName)
                *ModuleFileName = path.Mid(backslash + 1);
            if (ModuleDir)
                *ModuleDir = path.Left(backslash);
        }
        else
        {
            if (ModuleFileName)
                *ModuleFileName = path;
            if (ModuleDir)
                *ModuleDir = _T("");
        }
    }
    else
    {
        GETWIN32ERROR();
        if (ModuleFileName)
            *ModuleFileName = _T("");
        if (ModuleDir)
            *ModuleDir = _T("");
    }
    return S_OK;
}

HRESULT GetModuleDirAndFileName(CString *ModuleDir,CString *ModuleFileName)
{
	HRESULT hr = GetModuleDirAndFileName(NULL,ModuleDir,ModuleFileName);
	CHECKHRESULT(hr)
	return S_OK;
}

HRESULT SeGetTempPath(CString &TempPath)
{
    DWORD res,len = MAX_PATH;
    CString buff;
    do
    {
        res = GetTempPath(len,buff.GetBuffer(len));
        if (res > len)
            buff.ReleaseBuffer(0);
        else
            buff.ReleaseBuffer(res);
        if (res == 0)
        {
            GETWIN32ERROR();
            CHECKHRESULT(E_FAIL)
        }
        else if (res > len)
            len = res + 6;
        else
            break;
    }
    while (true);
    long backslash = buff.ReverseFind(_T('\\'));
    if (backslash >= 0)
        buff = buff.Left(backslash);
    TempPath = buff;
    return S_OK;
}

void SeShowInfoMessage(const CString &Message)
{
    SeShowInfoMessage((LPCTSTR)Message);
}

void SeShowInfoMessage(const TCHAR *Message)
{
    MessageBox(NULL,(LPCTSTR)Message,"Information",MB_OK|MB_ICONINFORMATION);
}

