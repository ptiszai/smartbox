//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SzReadMe.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TReadMeForm *ReadMeForm;
//---------------------------------------------------------------------------
__fastcall TReadMeForm::TReadMeForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TReadMeForm::ExitBtnClick(TObject *Sender)
{
    Close();
}
//---------------------------------------------------------------------------
void __fastcall TReadMeForm::FormShow(TObject *Sender)
{
    ReadMe->Lines->LoadFromFile("Readme.txt");
}
//---------------------------------------------------------------------------
