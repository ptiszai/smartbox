#ifndef SEDEBUGLOGH
#define SEDEBUGLOGH

#include <Windows.h>
#include <Stdio.h>


class CSeDebugLogInterface
{
  public:

	CSeDebugLogInterface() {}
	~CSeDebugLogInterface() {}
	virtual void StartProcedure(char* DbgStr) {}
	virtual void StopProcedure( void ) {}
    virtual void WriteMessage( char* DbgStr ) {}
    virtual void WriteMessage( int DbgInt ) {}
    virtual void WriteMessage(char* String, long DbgInt ) {}
};


class CSeDebugLog : public CSeDebugLogInterface
{
  public:

	CSeDebugLog( char* FileName, bool WriteImmediate = false );
	~CSeDebugLog( void );
	void StartProcedure( char* DbgStr );
	void StopProcedure( void );
    void WriteMessage( char* DbgStr );
    void WriteMessage( int DbgInt );
    void WriteMessage(char* String, long DbgInt );

  private:
	char *StringList[1024],
		 sTmp[1024],
		 DbgFName[1024];
    char *m_ImmediateString;
    bool m_WriteImmediate;

    LARGE_INTEGER Start,
				  Stop,
				  Frequency;

    __int64 Diff,
			MilliSecCount,
			MilliFreqy;

    int slptr;

    FILE *DebugFile;

    void CheckList();
    void WriteImmedString();

};




#endif //SEDEBUGLOGH
