//---------------------------------------------------------------------------

#ifndef kliens_testH
#define kliens_testH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <QuickRpt.hpp>
#include <QRPrntr.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------

#define ROOT_PASSWD	"apma0410\n"

//class TSzPr;

//#define USB 1
class TViewForm : public TForm
{
__published:	// IDE-managed Components
    TMemo *View;
    TButton *SendBtn;
    TCheckBox *DumpChB;
    TEdit *SendEdit;
    TButton *SetTimeBtn;
    TButton *SetDateBtn;
    TButton *Button1;
    TButton *ReadeLogBn;
    TBitBtn *ReadMeBtn;
    TCheckBox *LogCkB;
    TButton *RemoveLogBn;
    TButton *ResetBtn;
    TTimer *TimerTimer;
    TSpeedButton *PrintBtn;
    TGroupBox *GroupBox1;
    TCheckBox *LoopMsg;
    TComboBox *LoopAddr;
    TButton *LoopSendBn;
    TButton *LoopReset;
    TButton *LoopList;
    TGroupBox *GroupBox2;
    TSpeedButton *LcdKUpBtn;
    TSpeedButton *LcdKDownBtn;
    TButton *LcdKSaveBtn;
    TGroupBox *GroupBox3;
    TButton *FunkManualBtn;
    TRadioGroup *FunkInstallGrp;
    TRadioGroup *FunkInfrGrp;
    TButton *FunkClrAllABtn;
    TDateTimePicker *NextWeekly;
    TDateTimePicker *NextAnnual;
    TButton *FunkLcdClearBtn;
    TSpeedButton *FunkLightSwitchBtn;
    TButton *FunkGetAllABtn;
    TButton *Button2;
    TGroupBox *Grp;
    TButton *AtoBBtn;
    TButton *GetABBtn;
    TBitBtn *ExitBtn;
    TPanel *Panel1;
    TRadioGroup *OUTRGrp;
    TRadioGroup *ALARMLedRGrp;
    TSpeedButton *SendLedBtn;
    TButton *TestPortBtn;
    TGroupBox *GroupBox4;
    TButton *LpassCreateBtn;
    TButton *LpassRemovaBtn;
    TDateTimePicker *TestTime;
    TSpeedButton *TestTimeBtn;
    TGroupBox *GroupBox5;
    TEdit *InstallStopEdit;
    TSpeedButton *InstallStopBtn;
    TBitBtn *KonstansokBtn;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall SendBtnClick(TObject *Sender);
    void __fastcall ViewDblClick(TObject *Sender);
    void __fastcall SetTimeBtnClick(TObject *Sender);
    void __fastcall SetDateBtnClick(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall ReadeLogBnClick(TObject *Sender);
    void __fastcall ViewClick(TObject *Sender);
    void __fastcall ReadMeBtnClick(TObject *Sender);
    void __fastcall RemoveLogBnClick(TObject *Sender);
    void __fastcall ResetBtnClick(TObject *Sender);
    void __fastcall TimerTimerTimer(TObject *Sender);
    void __fastcall PrintBtnClick(TObject *Sender);
    void __fastcall LoopSendBnClick(TObject *Sender);
    void __fastcall LoopResetClick(TObject *Sender);
    void __fastcall LoopListClick(TObject *Sender);
    void __fastcall LcdKUpBtnClick(TObject *Sender);
    void __fastcall LcdKDownBtnClick(TObject *Sender);
    void __fastcall FunkManualBtnClick(TObject *Sender);
    void __fastcall FunkInstallGrpClick(TObject *Sender);
    void __fastcall FunkInfrGrpClick(TObject *Sender);
    void __fastcall FunkClrAllABtnClick(TObject *Sender);
    void __fastcall NextWeeklyCloseUp(TObject *Sender);
    void __fastcall NextAnnualCloseUp(TObject *Sender);
    void __fastcall FunkLcdClearBtnClick(TObject *Sender);
    void __fastcall FunkLightSwitchBtnClick(TObject *Sender);
    void __fastcall FunkGetAllABtnClick(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall AtoBBtnClick(TObject *Sender);
    void __fastcall GetABBtnClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    void __fastcall SendLedBtnClick(TObject *Sender);
    void __fastcall TestPortBtnClick(TObject *Sender);
    void __fastcall LpassCreateBtnClick(TObject *Sender);
    void __fastcall LpassRemovaBtnClick(TObject *Sender);
    void __fastcall TestTimeBtnClick(TObject *Sender);
    void __fastcall InstallStopBtnClick(TObject *Sender);
    void __fastcall KonstansokBtnClick(TObject *Sender);
private:	// User declarations
    COM_SET com_set;
    void __fastcall TCom_ThreadDone(TObject * /*Sender*/);
    void __fastcall TUsb_ThreadDone(TObject * /*Sender*/);
public:		// User declarations
    bool    oneError,recStop,bnewpage;
    __fastcall TViewForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TViewForm *ViewForm;
extern void XTPrintf(const char* sText);
extern SzCom*      ComThread;
extern TUSB*       UsbThread;
//---------------------------------------------------------------------------
#endif
