/***
 *  SeErrorHandler.cpp : Implementation of of ErrorHandler functions
 *
 *  Revision : 1.0 (A. Tagscherer)
 *  Date     : 25/08/01
 *  Copyright (c) 2001 Semmelweiss University, 2nd Department of Internal Medicine, Cell Analytic Labs
 *
 *************************************************************************/

#include "stdafx.h"
#include <windows.h>

#pragma hdrstop

#include "SeErrorHandler.h"
#include "SeCString.h"
#include "SeUtils.h"

#ifdef IJL_LIB_INCLUDED
	#include "ImageBufferHandler.h"
//    extern ImageBufferHandler::CSeJpegLib_global g_SeJpegLib;
#endif	//IJL_LIB_INCLUDED


#define UNKNOWNERROR    _T("Unknown system error occured!")

LPCTSTR __SeModuleNameFromSourceFileName(LPCTSTR SourceFileName,LPCTSTR ModuleExt,LPTSTR Buffer,long BufferSize)
{
	CString str = SourceFileName;
    if (!(str.IsEmpty()))
    {
        int backslash = str.ReverseFind(_T('\\'));
		if (backslash >= 0)
			str = str.Mid(backslash + 1);
        int point = str.ReverseFind(_T('.'));
        if (point >= 0)
            str = str.Left(point);
    }
	if (!(str.IsEmpty()))
	{
		str += _T(".");
		str += ModuleExt;
	}
	if (BufferSize >= str.GetLength() + 1)
	{
		_tcscpy(Buffer,(LPCTSTR)str);
	}
	else
		return NULL;
	return Buffer;
}

CSeErrorLogFile::CSeErrorLogFile(LPCTSTR ModuleCPPName,LPCTSTR ModuleExt,bool UseModuleNameAsFileName)
{
    m_Created = false;
	m_NeedToLog = false;
	m_SimpleLog = false;
	::InitializeCriticalSection(&m_CrSect);
	
	CString str = ModuleCPPName;
    if (!(str.IsEmpty()))
    {
        long backslash = str.ReverseFind(_T('\\'));
		if (backslash >= 0)
			str = str.Mid(backslash + 1);
        long point = str.ReverseFind(_T('.'));
        if (point >= 0)
            str = str.Left(point);
    }
	if (!(str.IsEmpty()))
	{
		str += _T(".");
		str += ModuleExt;
	}
	Init((LPCTSTR)str,UseModuleNameAsFileName);
}

CSeErrorLogFile::CSeErrorLogFile(LPCTSTR ModuleName,bool UseModuleNameAsFileName)
{
    m_Created = false;
	m_NeedToLog = false;
	m_SimpleLog = false;
	::InitializeCriticalSection(&m_CrSect);
	Init(ModuleName,UseModuleNameAsFileName);
}

CSeErrorLogFile::~CSeErrorLogFile()
{
	::DeleteCriticalSection(&m_CrSect);
}

void CSeErrorLogFile::Init(LPCTSTR ModuleName,bool UseModuleNameAsFileName)
{
	bool exists;
	CString hdir;

	m_Created = false;
    m_FileName = _T("");

	HMODULE hmod = GetModuleHandle(ModuleName);
	
	DWORD len = GetModuleFileName(NULL,m_ProcessFileName.GetBuffer(MAX_PATH),MAX_PATH);
	m_ProcessFileName.ReleaseBuffer(len);
    len = GetModuleFileName(hmod,m_ModuleFileName.GetBuffer(MAX_PATH),MAX_PATH);
    m_ModuleFileName.ReleaseBuffer(len);
	if (UseModuleNameAsFileName)
		m_FileName = m_ModuleFileName;
	else
	{
		CString ucprocname,str;
		ucprocname = m_ProcessFileName;
		ucprocname.MakeUpper();
		if ((ucprocname.Find(_T("DLLHOST.EXE")) >= 0) ||
			(ucprocname.Find(_T("REGSVR32.EXE")) >= 0))
		{
			int backslash = m_ModuleFileName.ReverseFind(_T('\\'));
			if (backslash >= 0)
			{
				str = m_ModuleFileName.Left(backslash + 1);
				backslash = m_ProcessFileName.ReverseFind(_T('\\'));
				if (backslash >= 0)
					m_FileName = str + m_ModuleFileName.Mid(backslash + 1);
			}
		}
		else
			m_FileName = m_ProcessFileName;
	}
    if (!(m_FileName.IsEmpty()))
    {
        int point = m_FileName.ReverseFind(_T('.'));
        int backslash = m_FileName.ReverseFind(_T('\\'));
        if ((point < 0) || (backslash > point))
            m_FileName = m_FileName + _T('.') + ERRORLOGFILEEXT;
        else
            m_FileName = m_FileName.Left(point + 1) + ERRORLOGFILEEXT;
        backslash = m_FileName.ReverseFind(_T('\\'));
		if (backslash >= 0)
			hdir = m_FileName.Left(backslash);
    }
    else
	{
		DWORD len = GetCurrentDirectory(MAX_PATH,hdir.GetBuffer(MAX_PATH));
		hdir.ReleaseBuffer(len);
        m_FileName = hdir + _T("\\") + ERRORLOGFILENAME;
	}

	if (hdir.IsEmpty())
	{
		DWORD len = GetCurrentDirectory(MAX_PATH,hdir.GetBuffer(MAX_PATH));
		hdir.ReleaseBuffer(len);
	}

//	m_NeedToLog = SeGetPrivateProfileBool(_T("DEBUG"),_T("ERRLOGFILE"),false,&exists,(LPCTSTR)(hdir + _T("\\ModuleSettings.ini")));
    m_NeedToLog=true;
	m_SimpleLog = SeGetPrivateProfileBool(_T("DEBUG"),_T("SIMPLELOGFILE"),false,&exists,(LPCTSTR)(hdir + _T("\\ModuleSettings.ini")));
    if (!(m_ModuleFileName.IsEmpty()))
    {
        int backslash = m_ModuleFileName.ReverseFind(_T('\\'));
		if (backslash >= 0)
			m_ModuleName = m_ModuleFileName.Mid(backslash + 1);
		else
			m_ModuleName = m_ModuleFileName;
        int point = m_ModuleName.ReverseFind(_T('.'));
        if (point >= 0)
            m_ModuleName = m_ModuleName.Left(point);
    }
	if (m_ModuleName.IsEmpty())
		m_ModuleName = _T("UNKNOWN");
}

void CSeErrorLogFile::AddStringLogToFile(const char *FileName,int Line,const char *Function,const TCHAR* String)
{
	if (!m_NeedToLog)
		return;
    CString str,str2;
	class l_SmartCS
	{
	private:
		CRITICAL_SECTION    *m_CS;
		long				m_LockCount;
		HANDLE				m_FH;
	public:
		l_SmartCS(CRITICAL_SECTION *CS)
		{
			m_CS = CS;
			m_LockCount = 0;
			m_FH = NULL;
		}
		~l_SmartCS()
		{
			if (m_LockCount > 0)
				::LeaveCriticalSection(m_CS);
			m_LockCount = 0;
			if (m_FH)
		        CloseHandle(m_FH);
			m_FH = NULL;

		}
		void Lock()
		{
			if (m_LockCount == 0)
				::EnterCriticalSection(m_CS);
			m_LockCount++;
		}
/*		void Unlock()
		{
			m_LockCount--;
			if (m_LockCount == 0)
				::LeaveCriticalSection(m_CS);
		}
*/
		void SetHandle(HANDLE FH)
		{
			m_FH = FH;
		}
	} scs(&m_CrSect);

    if (!m_Created)
    {
        FILETIME ft_create,ft_exit,ft_kernel,ft_user;
        SYSTEMTIME st_create;
        CString str2,processtime;
        if (GetProcessTimes(GetCurrentProcess(),&ft_create,&ft_exit,&ft_kernel,&ft_user) &&
			FileTimeToLocalFileTime(&ft_create,&ft_create) &&
            FileTimeToSystemTime(&ft_create,&st_create))
        {
            processtime.Format(_T("%4d.%02d.%02d  %02d:%02d:%02d.%03d"),st_create.wYear,
                               st_create.wMonth,st_create.wDay,st_create.wHour,
                               st_create.wMinute,st_create.wSecond,st_create.wMilliseconds);
        }
        str = _T("************************************************************************\r\n");
        if (processtime.GetLength() > 0)
            str2.Format(_T("NEW RUN, module (%s) of process (%s) created at:"),m_ModuleFileName,m_ProcessFileName);
        else
            str2.Format(_T("NEW RUN, module (%s) of process (%s) created at unknown time"),m_ModuleFileName,m_ProcessFileName);
		str += str2;
        str += processtime;
        str += _T("\r\n");

        str2.Format(_T("Module compiled at: %s  %s"),__DATE__,__TIME__);
		str += str2;

        str += _T("\r\n");
        str += _T("************************************************************************\r\n");
    }
    SYSTEMTIME st;
    GetLocalTime(&st);
    str2.Format(_T("%4d.%02d.%02d  %02d:%02d:%02d.%03d   :"),st.wYear,st.wMonth,
                st.wDay,st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
    str += str2;
    if (FileName)
    {
		str2.Format(_T("Module=%s   File="),(LPCTSTR)m_ModuleName);
        str += str2;
        str += A2CT(FileName);
    }
    str2.Format(_T("   Line=%d"),Line);
    str += str2;
    if (Function)
    {
        str += _T("   Function=");
        str += A2CT(Function);
    }
	if (String)
		str += String;
	scs.Lock();
    HANDLE fh = CreateFile((LPCTSTR)m_FileName,GENERIC_READ | GENERIC_WRITE,
                           FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_ARCHIVE,NULL);
    if (fh == INVALID_HANDLE_VALUE)
        return;
	scs.SetHandle(fh);
    if (SetFilePointer(fh,0,NULL,FILE_END) == (DWORD)-1)
        return;
    DWORD wl;
    if (!WriteFile(fh,str.GetBuffer(0),str.GetLength(),&wl,NULL))
        return;
    m_Created = true;
}

void CSeErrorLogFile::AddErrorLogToFile(const char *FileName,int Line,HRESULT Error,const char *Function)
{
    CString str;
    str.Format(_T("   Error=0x%X\r\n"),Error);
	AddStringLogToFile(FileName,Line,Function,(LPCTSTR)str);
}

void CSeErrorLogFile::AddStringFormatLogToFile(const char *FileName,int Line,LPCTSTR lpszFormat,...)
{
	va_list argList;
	va_start(argList, lpszFormat);
#ifdef __ATLMISC_H__
	class __CString : public CString
	{
	public:
		void __FormatV(LPCTSTR lpszFormat, va_list argList)
		{
			FormatV(lpszFormat,argList);
		}
	};
	__CString str;
	str.__FormatV(lpszFormat,argList);
#else
	CString str;
	str.FormatV(lpszFormat,argList);
#endif
	va_end(argList);
	AddStringLogToFile(FileName,Line,NULL,(LPCTSTR)str);
}

bool SeFormatErrorMessage(HRESULT MsgCode,bool AlwaysGetString,CString** MsgString)
{
    if (MsgString == NULL)
		return true;
	switch (HRESULT_FACILITY(MsgCode))
	{
#ifdef IPL_LIB_INCLUDED
	case IPL_FACILITY_CODE:
		{
			const char* error = iplErrorStr(HRESULT_CODE(MsgCode));
			CSeSmartPtr<CString> es;
			if (error == NULL)
				es = new CString(_T(""));
			else
				es = new CString(error);
			if (es->GetLength() == 0)
			{
				if (AlwaysGetString)
				{
					*MsgString = new CString(UNKNOWNERROR);
					return true;
				}
				else
					return false;
			}
			else
			{
				*MsgString = es.Detach();
				return true;
			}
		}
		break;
#endif	//IPL_LIB_INCLUDED
#ifdef IJL_LIB_INCLUDED
	case IJL_FACILITY_CODE:
		{
			const char* error = g_SeJpegLib->ijlErrorStr((_IJLERR)(HRESULT_CODE(MsgCode)));
			CSeSmartPtr<CString> es;
			if (error == NULL)
				es = new CString(_T(""));
			else
				es = new CString(error);
			if (es->GetLength() == 0)
			{
				if (AlwaysGetString)
				{
					*MsgString = new CString(UNKNOWNERROR);
					return true;
				}
				else
					return false;
			}
			else
			{
				*MsgString = es.Detach();
				return true;
			}
		}
		break;

#endif	//IJL_LIB_INCLUDED
    case FACILITY_WIN32:
	default:
		{
			LPTSTR lpMsgBuf;
			if (FormatMessage(
				FORMAT_MESSAGE_ALLOCATE_BUFFER |
				FORMAT_MESSAGE_FROM_SYSTEM |
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				MsgCode,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				(LPTSTR) &lpMsgBuf,
				0,
				NULL) > 0)
			{
				CSeSmartPtr<CString> es = new CString(lpMsgBuf);
				LocalFree(lpMsgBuf);
				*MsgString = es.Detach();
				return true;
			}
			else
			{
				if (AlwaysGetString)
				{
					*MsgString = new CString(UNKNOWNERROR);
					return true;
				}
				else
					return false;
			}
		}
		break;
	}
    return false;
}

bool SeShowErrorMessage(HRESULT MsgCode,bool AlwaysGetString)
{
	CSeSmartPtr<CString> MsgString;
	if (SeFormatErrorMessage(MsgCode,AlwaysGetString,&MsgString))
	{
		MessageBox(NULL,(LPCTSTR)(*MsgString),_T("Error"),MB_OK|MB_ICONINFORMATION);
		return true;
	}
	else
		return false;
}

