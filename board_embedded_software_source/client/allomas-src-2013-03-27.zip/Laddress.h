// allomas konstans cime:
// mindig teljes "Build All" a forditas!
#define LADDRESS 355
