#ifndef  LCOMM_H
#define LCOMM_H


#define COMM_MAX_ADDR	64
#define TX_MAX_SENDED_NUM	5
#define RX_MAX_RECEIVE_NUM	5

#define BAUD 1200      
#define FOSC 8000000L

#define NINE 0     /* Use 9bit communication? FALSE=8bit */
#define HIGH_SPEED 0
#define	BRGH 1		//2400
//#define	BRGH 0		//1200

#if NINE == 1
#define NINE_BITS 0x40
#else
#define NINE_BITS 0
#endif

#if HIGH_SPEED
#define BRG16 0x8
#define MUL   16UL
#else
#define BRG16 0
#define MUL   64UL
#endif

#define DIVIDER ((int)(FOSC/(MUL * BAUD) -1))

#define	R_STR_CHAR 		','		// start character
#define	R1_STR_CHAR 	'?'		// start character
#define	S_STR_CHAR 		';'		// start character
#define	S1_STR_CHAR 	'!'		// start character

#define SEARCH_ADDRESS1 0xaa	// uj cimkeres indul be.
#define SEARCH_ADDRESS2 0x55	// uj cimkeres indul be.
#define BROAD_ADDRESS	0xfe	// broad. cim.
#define BROAD_RES_ADDR	0x90	// reset cim mindegyik allomasnal.
#define DE_ON_COMMAND   0x11	// Test: DE on.
#define DE_OFF_COMMAND  0x12	// Test: DE off.
#define RE_ON_COMMAND   0x13	// Test: RE on.
#define RE_OFF_COMMAND  0x14	// Test: RE off.
#define TEST_ON_COMMAND    0x15	// Test: mode on.
#define TEST_OFF_COMMAND    0x16	// Test: mode off.

//PC
#define PC_COMMAND	0xbb	// PC-nek


//regi:2007.05.24.
/*#define	RX_TIME_TO_TX1	4		// 160 ms, jo vetel utan.
#define	RX_TIME_TO_TX2	14		// 480 ms, rossz vetel utan.
#define	RX_TIME_TO_TX3	2		// 80 ms,  adas utan.
#define	RS485_LEVEL		25		// 1000 ms,  rs485 szint
*/
//uj:2007.05.24.alap 10ms
#define	RX_TIME_TO_TX1	16		// 160 ms, jo vetel utan.
#define	RX_TIME_TO_TX2	48		// 480 ms, rossz vetel utan.
#define	RX_TIME_TO_TX3	8		// 80 ms,  adas utan.
#define	RS485_LEVEL		200		// 2000 ms,  rs485 szint

void rx_data(unsigned char* pData);
void rx_clr_addr(unsigned char* pData);
void rx_search_addr(unsigned char* pData);
void rx_broad(unsigned char* pData);
void rx_clear_addr(unsigned char* pData);
void tx_alt_data(void);
void tx_bejentkezes(void);
void addrclear(void);
void addrwrite(unsigned char addrh, unsigned char addrl);
int time_out(char start,unsigned int diff);
unsigned char addrread(void);
unsigned char loopread(void);
int get_send_start_time(unsigned int timercount);
char  IsGoodCheckSumma(unsigned char* pData);
void install_executor(void);
int install_receiver(unsigned char* pData);
void install_sender(void);
void install_error(void);
void rx_set_new_addr(unsigned char addrh,unsigned char addrl);
void rx_get_addr();
void tx_addr();
void tx_mesg();

extern void com_init(void);
extern void com_rx_tx(void);
extern unsigned char tx_int();
extern unsigned char rx_int(unsigned char ucData);
extern unsigned int prev_rx_time_num;
extern void tx_send_test();
extern char test_mode;
extern int RS485_level_error_count;

#endif
