#ifndef  LINFR_H
#define  LINFR_H

extern void infr_init(void);
extern void infr(void);
extern void set_infra_data(unsigned char dt1_a, unsigned char dt2_a);
extern void set_infra_data_1addr(unsigned short dt1_a);
extern unsigned char status_infra;
void infra_send(void);
void inf_write(void);

#endif
