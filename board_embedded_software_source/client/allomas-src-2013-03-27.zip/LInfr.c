/*
 *	Lamp allomas PIC18F1320.
 *  Tiszai I.
 *  2006
 */
#include <pic18.h>
#include "Ldefines.h"
#include "Lmain.h"
#include "LInfr.h"


#ifdef INFR_MODE
/*----------------------- valtozok ------------------------------*/

unsigned char tx_start;
unsigned char tx_stop;
unsigned char tx_kesz_n;
unsigned char tx_bit_szam;
static unsigned char tx_data;
unsigned char tx_maszk;
unsigned char infra_count;
unsigned char status_infra;
unsigned char infra_tx_en;
unsigned char data1;
unsigned char data2;

/***********************************************************
 * init resz.
 ***********************************************************/

void infr_init(void)
{
//	if (en == 1)		//adas enged
//	{
		TMR1L=0xf5;				
		TMR1H=0xe5;
//	T1CON=0b00000001;			// 8MHz/4/6666 = 300	(0xFFFF - 6666 = 0xe5f5)
//	TMR1L=0xea;				
//	TMR1H=0xcb;
//	WRITETIMER0(TMR_INFR1);

	T1CON=0b00000001;			// 8MHz/4/13333 = 150	(0xFFFF - 0x3415 = 0xCBEA)	
	TMR1IE=1; 					//T1 IT enged�lyezve
	TMR1IP=0;					//Interrupt priority lo

	// ---- PWM  ---------
	T2CON=0b00000100;	
	PR2=66;
	CCP1CON=0b00001100;			//PWM mode
	DC1B0=0;
	DC1B1=0;
	CCPR1L=33;

	infra_count = 0;
	infra_tx_en = 1;
//	}
//------
/*	if (en == 0)			//adas tilt
	{
	T1CON=0b00000000;		//Timer1 stop
	T2CON=0b00000000;		//TIMER2 OFF  modulacio off
	infra_tx_en=0;
	status_infra=0
	}
	TMR1L=0xea;				
	TMR1H=0xcb;
	T1CON=0b00000001;			// 8MHz/4/13333 = 150	(0xFFFF - 0x3415 = 0xCBEA)	
	PIE1bits.TMR1IE=1; 			//T1 IT enged�lyezve
	IPR1bits.TMR1IP=0;			//Interrupt priority lo

	// ---- PWM  ---------
	T2CON=0b00000100;	//
	PR2=66;
	CCP1CON=0b00001100;			//PWM mode
	CCP1CONbits.DC1B0=0;
	CCP1CONbits.DC1B1=0;
	CCPR1L=33;

	infra_count = 0
	infra_tx_en=1;
	}
//------
	if (en == 0)			//adas tilt
	{
	T1CON=0b00000000;		//Timer1 stop
	T2CON=0b00000000;		//TIMER2 OFF  modulacio off
	infra_tx_en=0;
	status_infra=0
	}*/
}//void com_init(void)

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/

void infr(void)
{
	if (CHK_SYS(INFR_ENABLE))
	{
		if (status_infra == 1) 
		{
			status_infra=0;
			infra_send();
		}
	}
}//void infr(void)

/***********************************************************
 * send.
 ***********************************************************/
void set_infra_data(unsigned char dt1_a, unsigned char dt2_a)
{
	data1 = dt1_a;
	data2 = dt2_a;
//	infra_send();
}//void set_infra_data(unsigned char dt1_a, unsigned char dt2_2)

//---------------------------------------------------------------
void set_infra_data_1addr(unsigned short dt1_a)
{
	data2 = (unsigned char)(dt1_a%64);
	data1 = (unsigned char)(dt1_a/64);;
//	infra_send();
}//void set_infra_data(unsigned char dt1_a, unsigned char dt2_2)

//---------------------------------------------------------------
void infra_send(void)
{
	if  (infra_tx_en == 1)
	{
		infra_count++;
		if (infra_count == 1)
		{
			tx_data = data1;
			tx_start = 1;
		}

		if ((infra_count >= 2) && (infra_count <= 13))
			inf_write();		

		if (infra_count == 15)
		{
			tx_data  = data2;
			tx_start = 1;
		}

		if ((infra_count >= 16) && (infra_count <= 27))
			inf_write();		
	
		if (infra_count == 28)
		{
			tx_data  = data2 + data1;
			tx_start = 1;
		}
		if ((infra_count >= 29) && (infra_count <= 41))
			inf_write();		

		if (infra_count == 100)
			infra_count = 0;
	}
}//void infra_send(void)

//---------------------------------------------------------------
void inf_write(void)
{
	unsigned char tx_tar;

	if	(tx_start==1)
	{
		T2CON=0b00000100;	//MOD ON START bit
		tx_start=0;
		tx_stop=2;
		tx_kesz_n=1;
		tx_bit_szam=8;
		tx_maszk=0x00000001;
	}
	else
	{
		if (tx_kesz_n != 0)
		{
			if (tx_bit_szam !=0)
			{
				tx_tar=tx_data & tx_maszk;
				if (tx_tar == 0)
					T2CON=0b00000100;	//MOD ON adatbit == 0					
				else					   	
					T2CON=0b00000000;	//MOD OFF adat bit  == 1
				tx_maszk = tx_maszk << 1;
				tx_bit_szam--;
			}
			else
			{
				if (tx_stop !=0)
				{
					T2CON=0b00000000;	//MOD OFF stop bitek
					tx_stop--;
				}
				else							
					tx_kesz_n = 0;						
			}
		}
	}
}
#endif
