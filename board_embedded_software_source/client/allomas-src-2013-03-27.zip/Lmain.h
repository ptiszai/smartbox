#ifndef  LMAIN_H
#define LMAIN_H

void init(void);


extern void ee_write(unsigned char data, unsigned char eeadr);
extern unsigned char ee_read(unsigned char eeadr);
extern unsigned char bin2bcd(unsigned char bin) ;
extern volatile unsigned char		status;
extern volatile unsigned int 		_timercount;
extern volatile unsigned int 		rxt_timercount;
extern volatile unsigned int 		inst_timercount;
extern volatile unsigned char 		sys_status;
extern volatile unsigned int 		receive_count;
#endif
