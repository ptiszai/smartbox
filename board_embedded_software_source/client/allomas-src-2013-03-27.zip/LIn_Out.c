#include <pic18.h>
#include "LIn_Out.h"
#include "Ldefines.h"
#include "Lmain.h"

/*
1., H�l�zatkies�s teszt alatt
2., T�lt�s hiba (IN1=1)
3., Akku hiba (IN2=1)
4., F�nycs�hiba(IN3=1)

A kliens �ramk�r az OUT1 kimenettel ind�tja a tesztet.
Am�g OUT1=0 addig tart a teszt �zemm�d( teh�t am�g a kimeneti tranya be van kapcsolva).

*/
char dinput;
char doutput;
char flag = 1;

/***********************************************************
 * init resz.
 ***********************************************************/
void in_out_init(void)
{
	dinput = PORTA;
	dinput &= 0x17;
}//void in_out_init(void)

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/
void in_out(void)
{
	dinput = PORTA;
	dinput &= 0x1f;

/*	if (dinput & 0x01)
		dinput &= 0x1e;
	else
		dinput |= 0x01;*/

	
	doutput =  (LATA & 0x40) ? 0x10: 0 ;
	if (!(dinput & 0x01))
	{
		dinput &= 0x1f;
		return;
	}
	//doutput <<= 2;
	
// TEST LACINAK START
/*	if (dinput & 2)
		RS485_LED_OFF
	else
		RS485_LED_ON*/
/*	if (_timercount > 3000)
	{
		_timercount = 0;
		if (flag)
			DO1_ON
		else
			DO1_OFF
		flag = (flag) ? 0 : 1;
	}*/
// TEST LACINAK END
}//void in_out(void)
