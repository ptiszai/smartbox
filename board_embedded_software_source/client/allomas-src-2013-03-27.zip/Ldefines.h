#ifndef  LDEF_H
#define  LDEF_H

//******************************
// FORDITASI KAPCSOLOK -- START
//***************************** 
#define INFR_MODE		// infra mod
//#define INR1_MODE		// infra modban cimzes
//#define OLD_ADDR			// regi allamos cim kepzese, magvaltozott 2009.10.18
//#define ADDR_FROM_EE    // EE-bol a cim:2010-09-07

//******************************
// FORDITASI KAPCSOLOK -- SEND
//***************************** 

#define OUTPUT_PIN      0x0	
#define INPUT_PIN       0x1	
#define OUTPUT_DATA     0x0	
#define INPUT_DATA      0xFF


// status bits
#define RX			0x1
#define RX_READY	0x2
#define RX_INT		0x4
#define TX_INT		0x8
#define TX_READY 	0x10
#define RX_ERROR	0x20
#define ADDRCLEAR	0x40
#define REST		0x80

#define CLR_STATUS(x)		{status &= (~x);};
#define SET_STATUS(x)		{status |= (x);};
#define CHK_STATUS(x)		(status & (x))

#define CLR_IMP(x)		{imp_flg &= (~x);}
#define SET_IMP(x)		{imp_flg |= (x);}
#define CHK_IMP(x)		(imp_flg & (x))

// sys_status
#define START_SEARCH	0x1
#define INFR_ENABLE		0x2
#define MYADDR_INST		0x4
#define TEST_ENABLE		0x4
/*#define MER				0x2
#define NO_MER			0x4
#define MER_KALIB_IMP	0x8
#define MER_KALIB		0x10
#define MER_KALIB_1		0x20
#define MER_KALIB_2		0x40
#define CLEAR			0x80*/
//#define REST			0x80
//#define DEMO			0x80

#define CLR_SYS(x)		(sys_status &= (~x)); 
#define SET_SYS(x)		(sys_status |= (x));
#define CHK_SYS(x)		(sys_status & (x))

// install	
#define START_INST		0x01
#define BEJ_INST		0x02

#define CLR_INSTALL(x)		{install &= (~x);};
#define CLRA_INSTALL		{install = 0;};
#define SET_INSTALL(x)		{install |= (x);};
#define CHK_INSTALL(x)		(install & (x))

// error
#define FRAME_ERROR			0x1
#define CMD_ERROR			0x2
#define BN_ERROR			0x4
#define CHS_ERROR			0x8

#define CLR_ERROR(x)		error &= (~x);
#define SET_ERROR(x)		error |= (x);
#define CHK_ERROR(x)   		(error & (x))

//#define TMR_1S				0xb1df  // 1sec
#define TMR_500MS			0xec77	// 500ms
#define TMR_40MS			0xcf2b	// 40ms ez nem ennyi, ez 160Hz?
#define TMR_4MS				0xd8ef	// 4ms 1:1
#define TMR_10MS			0xb1df  // 10ms

#ifdef INR1_MODE
#define TMR_INFR			0xcbea
#else
#define TMR_INFR			0xe5f5
#endif
//#define TMR0_1S				0xe000

#define EE_DATA				9
#define	ELM_LENGTH			1830

#define	P_DIG_OUT			PORTA
#define	P_DIG_IN			PORTA

#define	M_DIG_IN			0x0f
#define	M_DIG_OUT			0x50

#define P_RS485_DE			0x80	
#define RS485_DE_OFF  		LATA &= ~P_RS485_DE;
#define RS485_DE_ON			LATA |=  P_RS485_DE;

#define P_RS485_RE			0x20	
#define RS485_RE_ON  		LATB &= ~P_RS485_RE;
#define RS485_RE_OFF		LATB |=  P_RS485_RE;

#define P_RS485_RX			0x01
#define RS485_RX  			(PORTB & P_RS485_RX)

#define P_RS485_LED			0x04
//#define RS485_LED_ON  	;
#define RS485_LED_ON  		LATB &= ~P_RS485_LED;
#define RS485_LED_OFF		LATB |=  P_RS485_LED;
#define CHK_RS485_LED		(LATB & P_RS485_LED)

#define P_DO1				0x40	
#define DO1_OFF  			LATA &= ~P_DO1;
#define DO1_ON				LATA |=  P_DO1;

//#define P_DO2				0x40	
//#define DO2_OFF  			LATA &= ~P_DO2;
//#define DO2_ON				LATA |=  P_DO2;

#define P_INFR				0x08

#define EE_VERSION			1
#define EE_COMM_1ADDR1		1
#define EE_COMM_1ADDR2		2
#define EE_COMM_1ADDR_CHS	3
#define EE_COMM_2ADDR1		16
#define EE_COMM_2ADDR2		17
#define EE_COMM_2ADDR_CHS	18
//#define EE_COMM_LOOP1		3
//#define EE_COMM_LOOP2		4

#define RX_OFF1					PIE1 &= 0xdf;RCSTA &= 0xe0;
#define RX_ON1					RCSTA |= 0x10; \
								PIE1 |= 0x20;  \
								PIR1 |= 0x20;  \
								IPR1 |= 0x20;


#define RX_OFF					
#define RX_ON					
 
#endif
