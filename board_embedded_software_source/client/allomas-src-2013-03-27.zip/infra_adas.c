

unsigned char tx_start,tx_stop,tx_kesz_n,tx_bit_szam,tx_data,tx_maszk,infra_count,status_infra;







/*
	if (status_infra == 1) 
	 	{
		status_infra=0;
		infra_adas();
		}



  	if (PIR1bits.TMR1IF)					
    	{                             	 
      	PIR1bits.TMR1IF = 0;         	//clear interrupt flag
		TMR1H=0x0cb;
		TMR1L=0x0ea;				
		status_infra=1;
    	}
*/


//---------------------------------------------------------------------------------
void infra_adas_en(unsigned char en)
{
	if (en == 1)		//adas enged
	{
	TMR1L=0xea;				
	TMR1H=0xcb;
	T1CON=0b00000001;			// 8MHz/4/13333 = 150	(0xFFFF - 0x3415 = 0xCBEA)	
	PIE1bits.TMR1IE=1; 			//T1 IT enged�lyezve
	IPR1bits.TMR1IP=0;			//Interrupt priority lo

	// ---- PWM  ---------
	T2CON=0b00000100;	//
	PR2=66;
	CCP1CON=0b00001100;			//PWM mode
	CCP1CONbits.DC1B0=0;
	CCP1CONbits.DC1B1=0;
	CCPR1L=33;

	infra_count = 0
	infra_tx_en=1;
	}
//------
	if (en == 0)			//adas tilt
	{
	T1CON=0b00000000;		//Timer1 stop
	T2CON=0b00000000;		//TIMER2 OFF  modulacio off
	infra_tx_en=0;
	status_infra=0
	}
}



//--------------------------------------------------------------------------------
void infra_adas(void)
{
if  (infra_tx_en == 1)
	{
	infra_count++;
	if (infra_count == 1)
		{
		tx_data=cim1;
		tx_start=1;
		}

	if ((infra_count >= 2) && (infra_count <= 13))
		{
		infra_adas();		
		}

	if (infra_count == 15)
		{
		tx_data=cim2;
		tx_start=1;
		}

	if ((infra_count >= 16) && (infra_count <= 27))
		{
		infra_adas();		
		}	

	if (infra_count == 28)
		{
		tx_data=cim2+cim1;
		tx_start=1;
		}
	if ((infra_count >= 27) && (infra_count <= 39))
		{
		infra_adas();		
		}

	if (infra_count == 100)
		{
		infra_count = 0;
		}
	}
}
//---------------------------------------------------------------
void inf_adas(void)
{
unsigned char tx_tar;

	if	(tx_start==1)
		{
		T2CON=0b00000100;	//MOD ON START bit
		tx_start=0;
		tx_stop=2;
		tx_kesz_n=1;
		tx_bit_szam=8;
		tx_maszk=0x00000001;
		}
		else
			{
			if (tx_kesz_n != 0)
				{
				if (tx_bit_szam !=0)
					{
					tx_tar=tx_data & tx_maszk;
					if (tx_tar == 0)
				    	{
						T2CON=0b00000100;	//MOD ON adatbit == 0
						}
						else
					   		{
							T2CON=0b00000000;	//MOD OFF adat bit  == 1
							}
					tx_maszk = tx_maszk << 1;
					tx_bit_szam--;
					}
					else
						if (tx_stop !=0)
							{
							T2CON=0b00000000;	//MOD OFF stop bitek
							tx_stop--;
							}
							else
								{
								tx_kesz_n=0;
								}
				}
			}
}
//--------------------------------------------------------------------------
