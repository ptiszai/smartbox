/*
 *	Lamp allomas PIC18F1320.
 *  Tiszai I. - Pasztor I.
 *  2006
 *
 *	Leiras:
 *	Vetel:
 *	',',cimh,ciml,parancs,chs:
 *  ',',cimh,ciml,0x00,chs		// x: D0,D1 output, es input lekerdezes.
 *  ',',cimh,ciml,0x10,chs		// test mod.
 *  ',',cimh,ciml,0x2x,chs		// setting output:x: D0,D1 output....
 *  ',',cimh,ciml,0x80,chs		// reset.
 *	',',0xfe,0x80,chs		// reset mindegyik allomasnal.
 *	',',0xfe,0x81,chs		// cim infra adas inditas.
 *	',',0xfe,0x82,chs		// cim infra adas leallitas.
 *	',',0xfe,0x70,chs		// test start, mindegyik allomasnal.
 *	',',0xfe,0x71,chs		// test stop , mindegyik allomasnal.
 *  Install:
 *	'?',0xfe,0x90,chs		// reset cim mindegyik allomasnal. 
 *  '?',ciml,cimh,0x90,chs		// cim torlese.
 *  '?',0xaa,0x55,chs		// reset all. cim utana uj cim kepzest indit, ha nincs mar cime.
 *	'?',lcount xor hcount,uj cim,chs // uj cim kuldes. (lcount xor hcount: all. szamlalo xor erteke).
 *	'?',uj cim,0,chs 		// uj cim kuldes.
 *  Test resz:
 *  ':',cim,0x11,chs		// Test: DE on.
 *  ':',cim,0x12,chs		// Test: DE off.
 *  ':',cim,0x13,chs		// Test: RE on.
 *  ':',cim,0x14,chs		// Test: RE off.
 *  chs = cim+parancs
 *  cim 					// allomas cim.
 *
 *	Adas:
 *	';',cimh,ciml,parancs,chs:
 *	';',cimh,ciml,0x0x,chs		// x: D0,D1,D2,D3 input.
 *	';',cimh,ciml,0x8x,chs		// x: D0-D6 uj cim,D7=1: uj cim.
 *  Install:
 *  '!',0xaa,lcount xor hcount,chs	// all. bejelentkezik uj cimert,(lcount xor hcount: all.szamlalo xor erteke).
 *	'!',uj cim,0,chs 		// uj cim kuldes.
 *  chs = cim+parancs	
 *  cim 					// allomas cim.
 *  PC:
 * Vetel:
 *  '!',0xbb,cimh,ciml,chs	    // uj fix cim kuldese PC -bol.
 *  '?',0xbb,00,00,chs	        // cim kerdese PC -bol.
 * Adas:
 *  '!',0xbb,cimh,ciml,chs	    // uj fix cim vetele a PC -nek.
 */
 
#include <pic18.h>
//#include <p18cxxx.h>
//#include <stdlib.h>
#include "Lmain.h"
#include "LComm.h"
#include "Ldefines.h"
#include "Laddress.h"
#include "LIn_Out.h"
#include "LInfr.h"
#include "delay.h"

// transm.
unsigned char	txBuffer[TX_MAX_SENDED_NUM]; // transm. buffer
int   tx_head;
// receive.
unsigned char	rxBuffer[RX_MAX_RECEIVE_NUM]; // receive buffer
int   rec_head;
unsigned int 	prev_rx_time_num;
unsigned char   al_addressl,al_addressh;
unsigned char   al_loop;
unsigned char   my_new_addr;
unsigned char temp1 ;
unsigned char temp2 ;
unsigned char temp3 ;
unsigned char temp4 ;
unsigned char temp5 ;
unsigned char itemp ;
unsigned char error_count;
char test_mode;
int RS485_level_error_count;
//int search_addr_send_time;
int temp_search_adress;
volatile unsigned int 		install;
char testinput;
/***********************************************************
 * init resz.
 ***********************************************************/

void com_init(void)
{
	char temp;
	RS485_RE_OFF
	RS485_DE_OFF
//	DelayUs(10)
	//itemp = DIVIDER; 
//	SPBRG = DIVIDER;  
	SPBRG = 207;  //2400   
//	SPBRG = 103;  //1200  	
//	TXSTA = (SPEED|NINE_BITS|0x24);
	//RCSTA = (SPEED|NINE_BITS|0x90);
	TXSTA = 0x24;
	RCSTA = 0x90;
	BAUDCTL = 0;
//	TRISC6=OUTPUT;
//	TRISC7=INPUT;
	rec_head= 0;
	tx_head = 0;
	error_count = 0;
	test_mode = 0;
	install = 0;
	RS485_level_error_count = 0;
	RCIP	= 1;		// Serial I/O receive interrupt
	RCIF	= 0;
	RCIE	= 0;
	TXIP	= 1;		// Serial I/O transmit interrupt
	TXIF	= 0;
	TXIE	= 0;
	addrread();
	//al_loop    = loopread();
	my_new_addr = 0;
//	set_infra_data(al_address,0);
	SET_STATUS(RX)
	temp = RCREG;
	RX_ON1
	RS485_RE_ON
	testinput = 0x0d;
	//SET_SYS(INFR_ENABLE);
//tx_mesg();
}//void com_init(void)

/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
void com_rx_controlling(unsigned char* pData)
{
	asm("clrwdt");
//	if (install_receiver(pData))
//		return;
	if (*pData == R_STR_CHAR)
	{
		pData++;
		if (!IsGoodCheckSumma(pData))
			return;

		if ((*pData == al_addressh) && (*(pData+1) == al_addressl))
		{  // sajat cime jott.
			rx_data(pData);
		}
		else
		if (*pData == BROAD_ADDRESS)
		{ // korparancs kuldes,valasz ilyenkor nincsen.
	//	pData++;
			rx_broad(pData);
		}
	}
	else
	if (*pData == S1_STR_CHAR)
	{
		pData++;
		if (!IsGoodCheckSumma(pData))
			return;
		if (*pData == PC_COMMAND)
		{
#if ADDR_FROM_EE
			pData++;
			rx_set_new_addr(*pData,*(pData+1));
#endif
		}
	}
	if (*pData == R1_STR_CHAR)
	{
		pData++;
		if (!IsGoodCheckSumma(pData))
			return;
		if (*pData == PC_COMMAND)
		{
			rx_get_addr();
		}
	/*	if (*pData == SEARCH_ADDRESS1)
		{ // cim kereses, ha nincs mar cime,(cimtorles utan).	
			rx_search_addr(pData);
		}
		else
		if (*pData == al_address)
			rx_clear_addr(pData);
		else
		if (*pData == BROAD_ADDRESS)
			rx_clear_addr(pData);
*/

	}
}//comm_rx_controlling(..)

// check summa vizsgalata.
char  IsGoodCheckSumma(unsigned char* pData)
{
	temp1 = *pData;
 	temp2 = *(++pData);
	temp3 = *(++pData);
    temp4 = *(++pData);
	temp5 = (temp1+temp2+temp3);
	if ( temp5 == temp4)
		return 1;
	else
		return 0;
//	return ((*(pData) + *(++pData))	== *(++pData));
}//IsGoodCheckSumma(unsigned char* pData)

// altalanos lekerdezes
void rx_data(unsigned char* pData)
{
/*		pData++;
        pData++;
	//	txBuffer[2] = dinput;
		if (!(*pData & 0xf0))
		{	// x:D1=0 es input lekerdezes.
			DO1_OFF;
		}
		else
		if ((*pData & 0x10) == 0x10)
		{	// test mode:D1=1
			DO1_ON
		}
		else
		if ((*pData & 0x20) == 0x20)
		{	// x: D0,D1 output, es input lekerdezes.
			if (*pData & 0x01)
				DO1_ON
			else
				DO1_OFF

		}
		else
		if (*pData == 0x80)
		{ // reset
			SET_STATUS(REST)
			txBuffer[2] |= 0x80;
		}
		else
			return;
*/		
		tx_alt_data();
}//void rx_data(unsigned char* pData)

// uj cim jott a PC-bol.
void rx_set_new_addr(unsigned char addrh,unsigned char addrl)
{
	addrwrite(addrh,addrl);
	addrread();
	tx_addr();

}

void rx_get_addr()
{
	tx_addr();
}

// allomas cim kereses elinditasa.
void rx_search_addr(unsigned char* pData)
{
/*	pData++;
	if (*pData == SEARCH_ADDRESS2)
	{
		if ((al_address == 0xff) || (al_address > COMM_MAX_ADDR) || (!al_address))
		{
			SET_SYS(START_SEARCH);
			SET_INSTALL(START_INST)
			get_send_start_time(_timercount);
		}
	}*/		
}//void rx_clr_addr(unsigned char* pData)

void rx_clear_addr(unsigned char* pData)
{
/*	pData++;
	if (*pData == 0x90)
	{ // cim torles.
		addrclear();
	}*/
}//void rx_clear_addr(unsigned char* pData)

// kozos allomas parancs vetele.
void rx_broad(unsigned char* pData)
{
		pData++;
		pData++;
		if (*pData == 0x80)
		{ // reset
			SET_STATUS(REST)
			SET_STATUS(TX_READY)
		}
		else
		if (*pData == 0x81)
		{ // cim infra adas inditas.
			SET_SYS(INFR_ENABLE);
			txBuffer[2] |= 0x81;
		}
		else
		if (*pData == 0x82)
		{ // cim infra adas inditas.
			CLR_SYS(INFR_ENABLE);
			txBuffer[2] |= 0x82;
		}
		else
		if (*pData == 0x70)
		{ // test inditas.
			DO1_ON
			txBuffer[2] |= 0x70;
			SET_SYS(TEST_ENABLE)
			testinput = 0x0d;
		}
		else
		if (*pData == 0x71)
		{ // test stop.
			DO1_OFF
			txBuffer[2] |= 0x70;
			CLR_SYS(TEST_ENABLE)
		}
}//void rx_broad(unsigned char* pData)

/***********************************************************
 *  Adas  resz.
 ***********************************************************/
void tx_send(void)
{
	RS485_LED_ON
	RX_OFF
	RS485_RE_OFF	
	DelayMs(20);
	RS485_DE_ON
	DelayMs(20);
	time_out(1,RX_TIME_TO_TX3);
	tx_head = 0;
	TXREG=txBuffer[0];
	TXIE = 1;
	TXIF = 0;
}//void tx_send(void)

void tx_alt_data(void)
{
	//	in_out();
	txBuffer[0] = S_STR_CHAR;
	txBuffer[1] = al_addressh;
    txBuffer[2] = al_addressl;
	if (CHK_SYS(TEST_ENABLE))
	{
		//if (testinput != 0x0e)
		//	testinput = (dinput & 0x0e);
		txBuffer[3] = ( doutput | (dinput | 0x01));
		//txBuffer[2] = (testinput | 0x01);
	}
	else
		txBuffer[3] = (doutput | (dinput | 0x0e));
//	txBuffer[3] =PORTA;
	txBuffer[4] = txBuffer[1] + txBuffer[2] + txBuffer[3];
	tx_send();
}//void tx_send(void)

void tx_addr()
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = PC_COMMAND;
	txBuffer[2] = al_addressh;
    txBuffer[3] = al_addressl;
	txBuffer[4] = txBuffer[1] + txBuffer[2] + txBuffer[3];
	tx_send();

}

void tx_mesg()
{
	txBuffer[0] = 'R';
	txBuffer[1] = 'S';
	txBuffer[2] = al_addressl;
    txBuffer[3] = al_addressh;;
	txBuffer[4] = txBuffer[1] + txBuffer[2] + txBuffer[3];
	tx_send();

}
/***********************************************************
 * main()-be a forutin.
 ***********************************************************/

void com_rx_tx(void)
{
	char temp;

	if (CHK_STATUS(RX))
	{		
		if (CHK_STATUS(RX_READY))
		{		
			RS485_RE_OFF			
			RX_OFF
			CLR_STATUS(RX_READY)
			CLR_STATUS(RX)
			error_count = 0;
			com_rx_controlling(&rxBuffer[0]);	
			time_out(1,RX_TIME_TO_TX1);												
		}
		else
		if (CHK_STATUS(RX_ERROR))
		{			
			//install_error();
			CLR_STATUS(RX_ERROR)		
			CLR_STATUS(RX_READY)
			CLR_STATUS(RX)
			time_out(1,RX_TIME_TO_TX2);
			RS485_LED_OFF
//			RS485_LED_ON
//			if (error_count > 100)
//				asm ("reset");
//			++error_count;
		}
	/*	else
		if ((RCSTA & 4) || (RCSTA & 2))
		{
			//install_error();
			CLR_STATUS(RX_INT)
			SET_STATUS(RX_ERROR)
			temp = RCREG;
			RX_OFF	
			RS485_RE_OFF	
			time_out(1,RX_TIME_TO_TX2);
			RCSTA |= 0x10;		
		}*/	
	}
	else
	if (time_out(0,0))
	{
		RS485_DE_OFF
		RS485_RE_ON	
		RX_ON
		SET_STATUS(RX)	
	}

	if (CHK_STATUS(TX_READY))
	{ // tx end.
		tx_head=0;
		DelayMs(20);
		RS485_DE_OFF
		RS485_RE_ON	
		RX_ON
		CLR_STATUS(TX_READY)
		RS485_LED_OFF
		error_count = 0;
		if (CHK_STATUS(REST))
		{
			CLR_STATUS(REST)
			asm ("reset");
		}
	/*	if (CHK_STATUS(ADDRCLEAR))
		{
			CLR_STATUS(ADDRCLEAR)
			addrclear();
			asm ("reset");
		}*/
		SET_STATUS(RX)
					
	}

}//void com_rx_tx(void)

/***********************************************************
 * inturrept resz.
 ***********************************************************/
 /**********************************************************
 * COM adas int.
 **********************************************************/
unsigned char tx_int()
{
	++tx_head;
	if (tx_head>=TX_MAX_SENDED_NUM)
	{
		SET_STATUS(TX_READY)
		CLR_STATUS(TX_INT)
		TXIE=0;
		return 1;
	}
	return txBuffer[tx_head];

}//unsigned char tx_int()

/**********************************************************
 * COM vetel int.
 **********************************************************/
 
char rx_int( unsigned char ucData)
{	 
	rxBuffer[rec_head] = ucData;
	++rec_head;
	if (rec_head >= RX_MAX_RECEIVE_NUM)
	{
		rec_head=0;
		if (!test_mode)
		{
			RX_OFF
			RS485_RE_OFF
		}
		CLR_STATUS(RX_INT)
		SET_STATUS(RX_READY)
		return 1;
	}
	return 0;
}//void rx_int(..)

// allomas cimet torli es FF-re allitja.
void addrclear(void)
{
/*	ee_write(0xff, EE_COMM_ADDR1);
	ee_write(0   , EE_COMM_ADDR2);
	al_address = 0xff;
	temp1 = ee_read(EE_COMM_ADDR1);
	if (temp1 == 0xff)
		RS485_LED_ON
        */
}//void addrclear(void)

// allomas cim olvasasa.
#ifdef OLD_ADDR
unsigned char addrread(void)
{
	short addr_l;
	al_addressh = ee_read(EE_COMM_1ADDR1);
	al_addressl = ee_read(EE_COMM_1ADDR2);
	//temp2 = ~temp2;
	//if ( temp1 = temp2)
	//{
	//	temp2 = bin2bcd(temp1);
#ifdef INFR_MODE
	set_infra_data( al_addressh, /*temp2 & 0x0f*/al_addressl);
	addr_l = ((short)al_addressh)*256 + (short)al_addressl; 
#endif

	//set_infra_data_1addr(addr_l);
      //  set_infra_data( 1, 22);
	//	return temp1;
	//}
	return 0xff;
}//void addrread(void)

// allomas cim irasa.
void addrwrite(unsigned char addrh, unsigned char addrl )
{
	ee_write(addrh,  EE_COMM_1ADDR1);
	ee_write(addrl,  EE_COMM_1ADDR2);
}//void addrwrite(void)
#else
// uj cim resz:2009.10.18.
unsigned char addrread(void)
{
	short addr_l;
#if ADDR_FROM_EE

	al_addressh = ee_read(EE_COMM_1ADDR1);
	al_addressl = ee_read(EE_COMM_1ADDR2);
	temp2 = ee_read(EE_COMM_1ADDR_CHS);
	temp1 = al_addressh + al_addressl;
	if (temp1 != temp2)
	{
		al_addressh = ee_read(EE_COMM_2ADDR1);
		al_addressl = ee_read(EE_COMM_2ADDR2);
		temp2 = ee_read(EE_COMM_2ADDR_CHS);
		temp1 = al_addressh + al_addressl;
		if (temp1 == temp2)
		{
			addrwrite(al_addressh, al_addressl );	
		}
		else
		{
			al_addressh = 0;
			al_addressl	= 0;
		}
	}
#else
	al_addressl = (unsigned char)(LADDRESS & 0x00FF);
	al_addressh = (unsigned char)(LADDRESS >> 8);
#endif
	

#ifdef INFR_MODE
	//set_infra_data( al_addressh, /*temp2 & 0x0f*/al_addressl); // kiveve 2010.12.23
	set_infra_data_1addr((unsigned short)LADDRESS); // berakva 2010.12.23
	addr_l = ((short)al_addressh)*256 + (short)al_addressl;
#endif

 
	return 0xff;
}//void addrread(void)
#endif

// allomas cim irasa.
void addrwrite(unsigned char addrh, unsigned char addrl )
{
	ee_write(addrh,  EE_COMM_1ADDR1);
	ee_write(addrl,  EE_COMM_1ADDR2);
	temp1 = addrh + addrl;
	ee_write(temp1,  EE_COMM_1ADDR_CHS);
	ee_write(addrh,  EE_COMM_2ADDR1);
	ee_write(addrl,  EE_COMM_2ADDR2);
	ee_write(temp1,  EE_COMM_2ADDR_CHS);
}//void addrwrite(void)




// allomas hurok olvasasa.
unsigned char loopread(void)
{
/*	temp1 = ee_read(EE_COMM_LOOP1);
	temp2 = ee_read(EE_COMM_LOOP2);
	temp2 = ~temp2;
	if ( temp1 = temp2)
	{
	//	temp2 = bin2bcd(temp1);
//		set_infra_data( 1, temp1);
	//	return temp1;
//	}*/
	return 0xff;
}//void loopread(void)

// allomas hurok irasa.
void loopwrite(unsigned char loop)
{
//	ee_write(loop,  EE_COMM_LOOP1);
//	ee_write(~loop, EE_COMM_LOOP2);
}//void loopwrite(void)

// allomas hurok torli es FF-re allitja.
void loopclear(void)
{
//	ee_write(0xff, EE_COMM_LOOP1);
//	ee_write(0   , EE_COMM_LOOP2);
//	al_loop = 0;
	
}//void addrclear(void)
/**********************************************************
 * time out fg.
 **********************************************************/
int time_out(char start,unsigned int diff)
{	
//	static unsigned int overflow = 0;
	static unsigned int _time_out = 0;

//	if (test_mode)
//		return 1;

	if (start)
	{	
		rxt_timercount = 0;
		_time_out = diff;	
//		_time_out = timercount + diff;
//		overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
		/*if (overflow)
		{
			if (timercount > _time_out)
				return 0;
			else
				overflow = 0;
		}
		else*/
		if (rxt_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t time_out(uint8_t start,uint8_t diff)
/*
int install_time_out(char start,unsigned int diff)
{	
//	static unsigned int overflow = 0;
	static unsigned int _time_out = 0;

	if (start)
	{		
		inst_timercount = 0;
		_time_out = diff;
	//	_time_out = timercount + diff;
	//	overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
		if (inst_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t install_time_out(uint8_t start,uint8_t diff)
*/
void tx_send_test()
{
	txBuffer[2] = dinput;
//	tx_send();
}

/**********************************************************
 * Install resz.
 **********************************************************/
/*
int get_send_start_time(unsigned int timercount)
{
	unsigned int temp = 10;
	srand(timercount);
	temp = rand()/50;
	temp = (temp < RX_TIME_TO_TX2) ? RX_TIME_TO_TX2+temp : temp;
	install_time_out(1,temp);
 	temp_search_adress =(temp & 0x00ff) ^ ((temp & 0xff00) >> 8);
	return 1;
}//unsigned int get_send_start_time(unsigned int timercount)

void tx_bejentkezes(void)
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = SEARCH_ADDRESS1;	
	txBuffer[2] = (temp_search_adress & 0x00ff) ^ ((temp_search_adress & 0xff00) >> 8);
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	tx_send();
}//void tx_bejentkezes(void)

void tx_ujcim(void)
{
	txBuffer[0] = S1_STR_CHAR;
//	txBuffer[1] = al_address;	
	txBuffer[2] = 0;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	tx_send();
}//void tx_bejentkezes(void)

void install_executor(void)
{
	if (CHK_SYS(START_SEARCH))
	{
		if (CHK_INSTALL(START_INST))
		{
			if (install_time_out(0,0))
			{
				tx_bejentkezes();
				CLRA_INSTALL;
				SET_INSTALL(MYADDR_INST)
			}
		}
	}
}//void install_executor(void)

int install_receiver(unsigned char* pData)
{
	if (CHK_SYS(START_SEARCH))
	{
		if (*pData == R1_STR_CHAR)
		{
			pData++;
			if (CHK_INSTALL(BEJ_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					if (*pData == temp_search_adress)
					{  // sajat kereso random cime jott, es uj cime.
						my_new_addr = *(++pData);
						CLRA_INSTALL;
						SET_INSTALL(MYADDR_INST)
						return 1;
					}
				}
			}
			else
			if (CHK_INSTALL(MYADDR_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					if (*pData == temp_search_adress)
					{  // sajat uj cimevel jott a lekerdezes.
						my_new_addr = *(++pData);
						CLRA_INSTALL;
//						addrwrite(my_new_addr);
						my_new_addr = *(++pData);
						loopwrite(my_new_addr);
//						al_address = addrread();
						tx_ujcim();
						install_error();
						return 1;
					}
				}
			}
		}
		install_error();
		return 1;
	}
	return 0;
}//void install_receiver(void)

void install_error(void)
{
	
	if (CHK_SYS(START_SEARCH))
	{
		CLR_SYS(START_SEARCH)
		CLRA_INSTALL
		return;
	}
}//void install_error(void)
*/
