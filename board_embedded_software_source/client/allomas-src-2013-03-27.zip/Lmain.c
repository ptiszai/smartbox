/*
 *	Lamp allomas PIC18F1320.
 *  Tiszai I.
 *  2006
 */
//&
// PA4 DO1 ROSSZ!!!!!!!!!!!!
#include <pic18.h>
#include "Ldefines.h"
#include "Lmain.h"
#include "LInfr.h"
#include "LComm.h"
#include "LIn_Out.h"
//I'm using HT PICC18 with an ICD 2.
/*---------------------- konstansok ----------------------------*/
/* fill the EEPROM with initial values */
//1. verzio, 2. high cim, 3. low cim



//static volatile near unsigned char	RES1		@ 0xF82;
//static volatile near unsigned char	RES2		@ 0xF83;
//static volatile near unsigned char	sys_status	@ 0xF84;

//My configuration bits:

__CONFIG(1, RCIO & IESODIS & FCMDIS); // internal oscillator with RA6 digital i/o
__CONFIG(2, BORDIS & PWRTDIS &  WDTPS32K); // Brown out reset disabled,power-up timer disbale, enable wdt
__CONFIG(3, MCLRDIS); // enable mclr
__CONFIG(4, LVPDIS & DEBUGDIS  & STVRDIS);// disable lvp mode
__CONFIG(5, UNPROTECT); // code protection
__CONFIG(6, WRTEN);
__CONFIG(7, TRU);

//__IDLOC(0xFFFFFFFF);


__EEPROM_DATA(0xff,0x00,0x01,0xff,0xff,0xff,0xff,0xff);
//MYCONFIG = 0x78;
/*----------------------- valtozok ------------------------------*/
volatile unsigned char		status;
volatile unsigned char 		sys_status;
volatile unsigned int 		_timercount;
volatile unsigned int 		rxt_timercount;
volatile unsigned int 		inst_timercount;
//volatile unsigned int 		receive_count;
//volatile unsigned char 		res1,res2;


/*----------------------- fuggvenyek ----------------------------*/

/***********************************************************
 * main part.
 ***********************************************************/
 
void main(void)
{
	init();
//	tx_send_test();
#ifdef INFR_MODE
	SET_SYS(INFR_ENABLE)		// INFRA BEKAPCS. PASZTOR PITYUNAK:2007.11.29.
#endif
	while(1)
	{
		com_rx_tx();		// com.

		in_out();			// bemenetek,kimenetek vezerlese.
#ifdef INFR_MODE
		infr();				// infra ado.
#endif
		asm("clrwdt");
//		timer();
	//	asm("clrwdt");
	}
}//void main(void)

/***********************************************************
 * init part.
 ***********************************************************/

void altalanos_init(void)
{
	OSCCON = 0x76;
	ADCON1 = 0xff;
	ADCON0 = 0;
	RBPU=0;
	TRISA = INPUT_DATA;
	TRISA &= ~M_DIG_OUT;
	TRISA &= ~P_RS485_DE;
	TRISB = INPUT_DATA;
	TRISB &= ~P_RS485_RE;
	TRISB &= ~P_RS485_LED;
	TRISB &= ~P_INFR;
	LATA = 0;
	LATB = 0;
	
	if (!(RCON & TO))
	{//nem tap reset volt.
		if(CHK_SYS(TEST_ENABLE))
			DO1_ON
		else
			DO1_OFF
	}
	else
	{
		DO1_OFF
		sys_status = 0;
	}
	RS485_DE_OFF
	RS485_RE_OFF
	RS485_LED_ON
	IPEN	= 1;	// int. prioritas on.
	
	// timer 0
	TMR0IP	= 0;
	TMR0IE	= 1;
	TMR0IF	= 0;
	T0CON   = 0x0f;
	WRITETIMER0(TMR_40MS); //regi:2007.05.24.
//	WRITETIMER0(TMR_10MS); //uj:2007.05.24.
	TMR0ON  = 1;
	
//	DO2_OFF
	// valtozok init.
	status = 0;
//	receive_count = 0;
//	_timercount = 0;		// TEST LACINAK
} //void altalanos_init()
//----------------------------------------------------------

void init(void)
{
//	di();
	GIE=0;
	altalanos_init();
	com_init();
//	in_out_init();
#ifdef INFR_MODE
	infr_init();
#endif
//  WDTCON = 1; 
	GIEH	= 1;
	GIEL 	= 1;
    INTCON = 0xe0;
    GIE=1;
//	ei();
}//void init(void)

/*************************************************************
 * ISR part,Hight,Low Isr
 *************************************************************/
// hight
void interrupt HI_ISR(void)
{
	unsigned char temp;
//	static int flag = 1;
	if((RCIE)&&(RCIF))		
	{	// serial rx
		RCIF = 0;
		if ((RCSTA & 4) || (RCSTA & 2))
		{
			RS485_RE_OFF
			CLR_STATUS(RX_INT)
			SET_STATUS(RX_ERROR)
			temp = RCREG;
	//		if (!test_mode)
	//		{
				RX_OFF
			
	//		}
			RCSTA |= 0x10;				
		}	
		else
		{			
			SET_STATUS(RX_INT)	
			rx_int(RCREG);
/*
// test
			if (flag)	
				RS485_LED_ON
			else
				RS485_LED_OFF
			flag = (flag)?0:1;
			RS485_RE_ON
			temp = RCREG;
// test
*/
		}	
	}	
	if((TXIE)&&(TXIF))			
	{ // serial tx
		TXIF = 0;
		SET_STATUS(TX_INT)
		temp=tx_int();
		if (CHK_STATUS(TX_READY))
			return;
		TXREG=temp;
	}	
}//Hight ISR


//-------------------------------------------------------------------------------------------------
// Low
void interrupt low_priority LOW_ISR(void)
{
//	static int flag = 1;
	if (TMR0IE && TMR0IF)		// did the timer cause the interrupt?
	{
		TMR0IF = 0;
		WRITETIMER0(TMR_40MS);//regi:2007.05.24.
		rxt_timercount++;
		inst_timercount++;
		_timercount++;
	//	receive_count++;
		RS485_level_error_count++;
	//	WRITETIMER0(TMR_40MS);//regi:2007.05.24.
	//	WRITETIMER0(TMR_10MS);//uj:2007.05.24.
/*
// test
		if (RS485_level_error_count>30)
		{
			if (flag)	
				RS485_LED_ON
			else
				RS485_LED_OFF
			flag = (flag)?0:1;
			RS485_level_error_count = 0;
		}
// test
*/
	}
	if (TMR1IE && TMR1IF)					
    {                             	 
      	TMR1IF = 0;         	//clear interrupt flag
//		WRITETIMER1(TMR_INFR);
		TMR1L=0x0f5;
		TMR1H=0x0e5;				
		status_infra = 1;
    }
}//Low Isr

/*************************************************************
 * EEPROM write. 
 *************************************************************/
void ee_write(unsigned char data, unsigned char eeadr)	/* write a byte of data to EEPROM */
{
	EEPROM_WRITE(eeadr, data);

}//void ee_write(unsigned char)

/*************************************************************
 * EEPROM read. 
 *************************************************************/
unsigned char ee_read(unsigned char eeadr)	/* read a byte of data from EEPROM */
{
/*	wait_on_wr(); */

	EEPROM_READ(eeadr);
	return EEDATA;

}//unsigned char read(void)

unsigned char bin2bcd(unsigned char bin)                    
{

  unsigned char Temp = 0; 
  while(bin>9) 
  { 
    Temp += 0x10; 
    bin-=10; 
  } 
  return Temp+bin; 

}
