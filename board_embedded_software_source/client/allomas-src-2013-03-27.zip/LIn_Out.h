#ifndef  LINOUT_H
#define  LINOUT_H

extern void in_out_init(void);
extern void in_out(void);
extern char dinput;
extern char doutput;

#endif
