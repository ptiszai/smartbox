#ifndef _HKLOOP_H
#define _HKLOOP_H

#define P_KOZP_DE1			0x04	
#define KOZP_DE1_OFF  		PORTA &= ~P_KOZP_DE1;
#define KOZP_DE1_ON			PORTA |=  P_KOZP_DE1;
//#define KOZP_DE1_OFF  		KOZP_DE1_ON;	//teszt

#define P_KOZP_RE1			0x08	
#define KOZP_RE1_ON  		PORTA &= ~P_KOZP_RE1;
#define KOZP_RE1_OFF		PORTA |=  P_KOZP_RE1;
//#define KOZP_RE1_OFF		KOZP_RE1_ON;	//teszt


#define KTX_MAX_SENDED_NUM	COMM_MAX_ADDR*2+20
#define	KTX_DEF_SENDED_NUM	8
#define KRX_MAX_RECEIVE_NUM	6
#define	KS_STR_CHAR 	';'		// start character
#define	KS1_STR_CHAR 	'M'		// start character
#define	KS2_STR_CHAR 	'N'		// start character
#define	KR_STR_CHAR 	','		// start character
#define	PCR_STR_CHAR 	'P'		// start character
#define	PCS_STR_CHAR 	'p'		// start character

#define RX1_OFF 			UCSR1B &= 0x6f;
#define RX1_ON 				UCSR1B |= 0x90;

#define TX1_OFF 			UCSR1B &= 0xdf;
#define TX1_ON 				UCSR1B |= 0x20;

#define CLR_KERROR(x)		kerror &= (~x);
#define SET_KERROR(x)		kerror |= (x);
#define CHK_KERROR(x)   	(kerror & (x))

#define	BROAD_ADDRESS		0xfe
//parancsok:
//vetel:
#define R_GENERAL_CMD		0 		// altalanos lekerdezes.
#define R_1RESET_CMD		0x80	// reset 1 allomasnal.
//#define S_1TEST_CMD			0x10	// test 1 allomasnal.
#define R_1ADRRES_CMD		0x90	// reset allomas cim.
#define R_ASKADDR_CMD		0x92	// allomas cimek lekerdezese.
#define R_ADRRES_CMD		0x90	// reset cim mindegyik allomasnal. 
#define R_STARTINST_CMD		0x83	// install bekapcsolasa. 
#define R_STOPINST_CMD		0x84	// install kikapcsolasa. 
#define R_STARTMESG_CMD		0xa1	// rendszernek: uzenet kuldes mod bekapcsolva.	
#define R_STOPMESG_CMD		0xa2	// rendszernek: uzenet kuldes mod kikapcsolva.
#define R_STARTINFRA_CMD	0x81	// korparancs:cim infra adas inditas.(3x)
#define R_STOPINFRA_CMD		0x82	// korparancs:cim infra adas leallitas.(3x)
#define R_RESET_CMD			0x80	// korparancs:reset mindegyik allomasnal.(3x)
#define R_STARTTEST_CMD		0x70	// korparancs:test start, mindegyik allomasnal.(3x)
#define R_STOPTEST_CMD		0x71	// korparancs:test stop, mindegyik allomasnal.(3x)
//#define R_STARTINSTALL_CMD	0x85	// korparancs:install inditas.(3x)
#define R_HRESET_CMD		0xa3	// hurok reset.
//#define R_AA_CMD			0xaa	

//adas
#define S_GENERAL_CMD		0 		// nincs valtozas,hiba.
#define S_ERROR_CMD			0xf0	// parancs nincs elvegezve,hiba.
#define S_INSTALL_CMD		0xf1	// install modban fut.
#define S_MESSG_CMD			0xf2	// szimpla uzenet, max. 20 byte.
#define S_ADDRLSTNUM_CMD	0x91	// lekerdezett cimek szma max. 124.
#define S_ADDRLST_CMD		0x92	// lekerdezett cimek, max. 124*2 byte.

/*
//uj:2007.05.24.alap 10ms inkabb 6.6 ms
//#define	RX_KTIME_TO_TX1	5		// 50 ms, jo vetel utan.
#define	RX_KTIME_TO_TX2	20		// 200 ms, rossz vetel utan.
#define	RX_KTIME_TO_TX3	20		// 200 (regi 160 ms),  adas utan.
#define	RX_KTIME_TO_TX4	50		// (500 ms) 3000 ms
#define	RX_KTIME_TO_TX5	2		// 20 ms */


#define	RX_KTIME_TO_TX2	8		// 200 ms, rossz vetel utan.
#define	RX_KTIME_TO_TX3	8		// 200 (regi 160 ms),  adas utan.
#define	RX_KTIME_TO_TX4	25		// (500 ms) 3000 ms
#define	RX_KTIME_TO_TX5	2		// 20 ms 	

//#define	RS485_LEVEL		200		// 1000 ms,  rs485 szint

#define CLR_KSTATUS(x)		{ kstatus &= (~x); };
#define SET_KSTATUS(x)		{kstatus |= (x);};
#define CHK_KSTATUS(x)		(kstatus & (x))

uint8_t k_rx_broad();
uint8_t k_rx_data();
void k_tx_send_common(void);
unsigned char  k_IsGoodCheckSumma(/*volatile unsigned char* pData*/);
void k_tx_oke(volatile unsigned char cmd);
void k_tx_back();
void k_tx_notoke(void);
uint8_t k_get_nextchan_data(void);
void k_tx_addr_list(void);
void k_tx_messg(void);
void k_get_chek_req(CHANNELtype* all);
void k_tx_addr_sum_num();
uint8_t k_time_out(uint8_t start,uint16_t diff);

extern void k_com_init(void);
extern void k_set_error_flag(CHERRFLAG flag_a);
//extern void k_tx_send(LOOPtype* ptrData);
extern void k_tx_send(CHANNELtype* ptrData);
extern void k_com_rx_tx(void);
extern uint8_t k_rx_int( unsigned char ucData);
extern unsigned char k_tx_int();
extern uint8_t   hur_address;
extern uint16_t k_timercount;
extern int8_t kerror;
extern int8_t kstatus;
extern void PutString( const char *str);
extern void test_send();
//extern void k_rx_controlling(volatile unsigned char* pData);
//extern LOOPtype NextLoop(void);
//extern uint8_t	loop_ask_index;
//extern LOOPtype	loop_array[COMM_MAX_LOOP+1];

#endif
