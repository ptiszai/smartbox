#ifndef __MACROS_H
#define __MACROS_H	1

#include <avr\eeprom.h>
#define _AVR

#if !defined(_AVR)
#error "This file should only be used with ICCV7 for AVR"
#endif

/* FOR ATMEL AVR and TINY AVR ONLY! */

#ifndef BIT
#define BIT(x)	(1 << (x))
#endif

#define OUTPUT_PIN      0x0	
#define INPUT_PIN       0x1	
#define OUTPUT_DATA     0x0	
#define INPUT_DATA      0xFF

#if defined(_AVR) && !defined(flash)
#define flash	const		/* IAR compatibility */
#endif

#ifndef C_task
#define C_task
#endif

#define _asm	asm			/* old style */
#define NOP asm volatile("nop\n\t"::);


#ifdef _AVR
/* Serial Port Macros
 * for 4 Mhz crystal!
 * 
 * USE THE AppBuilder for UART initialization!!!
 */
#define BAUD9600_4		25
#define BAUD19K_4		12

#define BAUD2400_16  		416
#define BAUD9600_16		103
#define BAUD19K_16		51

/* NOT ALL (new) AVRs define these. Use the AppBuilder!!
 */
#define UART_TRANSMIT_ON()	UCR |= 0x8
#define UART_TRANSMIT_OFF()	UCR &= ~0x8
#define UART_RECEIVE_ON()	UCR |= 0x10
#define UART_RECEIVE_OFF()	UCR &= ~0x10

#define COMPRESS_DISABLE		NOCC_START()
#define COMPRESS_REENABLE		NOCC_END()

#define NOCC_START()	asm(".nocc_start")
#define NOCC_END()	asm(".nocc_end")

void _StackCheck(void);
void _StackOverflowed(char);

#define	EEPROM_READ(addr, var) (var) = eeprom_read_byte ((uint8_t *)(addr))	
#define EEPROM_WRITE(addr, var)	eeprom_write_byte ((uint8_t *)(addr), (uint8_t)(var)) 
#endif

#ifndef sbi
#define sbi(_register,_bit_value) (_register) |= _BV(_bit_value)
#endif

#ifndef cbi
#define cbi(_register,_bit_value) (_register) &= ~(_BV(_bit_value))
#endif 

#define bit_is_set_in_var(var, bit)		var = var | (1 << bit);
#define bit_is_clear_in_var(var, bit) 	var = var & (1 << bit);

#define TRUE            1
#define FALSE           0


#define DDR(x) _SFR_IO8(_SFR_IO_ADDR(x)-1)
#define PIN(x) _SFR_IO8(_SFR_IO_ADDR(x)-2)

#endif
