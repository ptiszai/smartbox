#ifndef _HALOOP_H
#define _HALOOP_H

#define P_RS485_DE0			0x01	
#define RS485_DE0_OFF  		PORTA &= ~P_RS485_DE0;
#define RS485_DE0_ON		PORTA |=  P_RS485_DE0;

#define P_RS485_RE0			0x02	
#define RS485_RE0_ON  		PORTA &= ~P_RS485_RE0;
#define RS485_RE0_OFF		PORTA |=  P_RS485_RE0;

#define P_RS485_LED			0x10
#define RS485_LED_ON  		PORTA &= ~P_RS485_LED;
#define RS485_LED_OFF		PORTA |=  P_RS485_LED;
#define RS485_LED_TOGGLE    /*PORTA ^=  P_RS485_LED;*/


//#define RX_OFF 				UCSRB &= 0x6f;
//#define RX_ON 				UCSRB |= 0x90;
#define TX0_OFF 			UCSR0B &= 0xdf;
#define TX0_ON 				UCSR0B |= 0x20;

#define RX0_OFF 			UCSR0B &= 0x6f;
#define RX0_ON 				UCSR0B |= 0x90;

//#define COMM_MAX_ADDR		COMM1_MAX_ADDR*COMM_MAX_LOOP

#define SEARCH_ADDRESS1 0xaa	// uj cimkeres indul be.
#define SEARCH_ADDRESS2 0x55	// uj cimkeres indul be.
#define BROAD_ADDRESS	0xfe	// broad. cim.
/*
#define	RX_TIME_TO_TX1	100		// 500 ms, jo vetel utan a kovetkezo adas.(660 ms) 1:6.6ms
#define	RX_TIME_TO_TX2	100		// 1000 ms, rossz vetel utan a kovetkezo adas.
#define	RX_TIME_TO_TX3	100//200		// 2000 ms, vetel time-out utan a kovetkezo adas.
#define	RX_TIME_TO_TX4	600		// 6000 ms, korkerdes utan a kovetkezo adas.
*/


#define	RX_TIME_TO_TX1	30		// 600 ms, jo vetel utan a kovetkezo adas.
#define	RX_TIME_TO_TX2	50		// 1000 ms, rossz vetel utan a kovetkezo adas.
#define	RX_TIME_TO_TX3	50//200		// 2000 ms, vetel time-out utan a kovetkezo adas.
#define	RX_TIME_TO_TX4	300		// 6000 ms, korkerdes utan a kovetkezo adas.

// install	
#define START_INST		0x01
#define BEJ_INST		0x02
#define PUT_ADDR_INST	0x04
#define ASK_ADDR_INST	0x08

#define CLR_INSTALL(x)		{install &= (~x);};
#define CLRA_INSTALL		{install = 0;};
#define SET_INSTALL(x)		{install |= (x);};
#define CHK_INSTALL(x)		(install & (x))


// lstatus bits
#define RX				0x1
#define RX_READY		0x2
#define RX_INT			0x4
#define TX				0x8
#define TX_INT			0x10
#define TX_READY 		0x20
#define KOZP_MSG		0x40
#define LINSTALL        0x80

#define CLR_LSTATUS(x)		{ lstatus &= (~x); };
#define SET_LSTATUS(x)		{lstatus |= (x);};
#define CHK_LSTATUS(x)		(lstatus & (x))

// error
#define FRAME_LERROR	0x1
#define CMD_LERROR		0x2
#define BN_LERROR		0x4
#define CHS_LERROR		0x8
#define RX_LERROR		0x10

#define CLR_LERROR(x)		lerror &= (~x);
#define SET_LERROR(x)		lerror |= (x);
#define CHK_LERROR(x)   	(lerror & (x))

#define COMM_MAX_LOOP		25
#define COMM_MAX_ADDR		65
//#define COMM_MAX_ADDR		127
//#define MAX_ADDR			192
#define MAX_ADDR			1600

#define	S_STR_CHAR 		','		// start character
#define S1_STR_CHAR		'?'
#define	R_STR_CHAR 		';'		// start character
#define	R1_STR_CHAR 	'!'		// start character

#define LTX_MAX_SENDED_NUM	5
#define LRX_MAX_RECEIVE_NUM	5

typedef enum 
{
	ERR_RXflag = 0,
	ERR_TOflag,
	ERR_CONTflag,
	ERR_RESPflag,
	ERR_NONEflag
} CHERRFLAG;

typedef struct
{
	uint8_t 			id;
	uint8_t 			addrh;		// high
	uint8_t 			addrl;		// low
    uint8_t 			cmd;
	uint8_t 			data; 		// in:0-3 bit, out:4-8 bit;
	uint8_t 			prev_data; 	// error:0-3 bit,in:4-8 bit;
    uint8_t             error;
	uint8_t             prev_error;
} CHANNELtype;

typedef struct
{
//	uint8_t 			loop;
	uint8_t 			error;
	CHANNELtype			chn;
//	CHANNELtype			rchn;				 
}LOOPtype;

typedef struct
{
	CHANNELtype			chn;
//	uint8_t 			loop;
	uint8_t				num;
	
}CHN_ASK;


extern uint8_t a_rx_data(volatile unsigned char* pData);
//uint8_t time_out(uint8_t start,uint16_t diff);
uint8_t a_rx_new_addr_req(volatile unsigned char* pData);
uint8_t install_receiver(volatile unsigned char* pData);
void install_error(void);
void install_sender(void);
void a_tx_send(CHANNELtype* ptrData);

extern void a_com_init();
//extern unsigned char ch1l_tx_int();
//extern char ch1l_rx_int( unsigned char ucData);
extern void a_com_rx_tx(void);
extern CHANNELtype IndexAll(uint8_t index);
extern CHANNELtype FirstAll(void);
extern CHANNELtype* SearchAll(uint8_t all_addressh, uint8_t all_addressl);
extern CHANNELtype* pCurrAll(void);
extern void chl1_tx_send(CHANNELtype* ptrData);
extern uint8_t alladdrnumenable;
extern uint8_t allloopnumenable;
extern uint8_t all_ask_index;
extern uint16_t prev_test_timer_sec;

 //char l_IsRecFinished();

extern void a_com_init(void);
uint8_t a_time_out(uint8_t start,uint16_t diff);
extern int8_t 	lstatus;
extern int8_t 	lerror;
extern uint16_t a_timercount;
//extern uint8_t l_recTotalTimeoutMultiplier;
//extern volatile unsigned char	a_txBuffer[LTX_MAX_SENDED_NUM+1]; // transm. buffer
extern uint8_t	rx_ready_s;
extern  void a_tx_send_common(void);
extern unsigned char a_tx_int();
extern void a_rx_int( unsigned char ucData);
extern uint16_t tx_max_sended_num;
extern uint8_t rx_max_receive_num;
extern void a_set_error_flag(CHERRFLAG flag_a, CHANNELtype* chan);
//extern uint8_t rx_error;

extern CHN_ASK chn_ask;
extern CHANNELtype all_array[COMM_MAX_ADDR+10];
extern void set_allomas_error(uint8_t loop,uint8_t addr,uint8_t err_bit);

extern CHANNELtype NextAll(void);
extern void a_rx_controlling(volatile unsigned char* pData);
extern void set_cmd_all_All(uint8_t cmd);
//extern void chl1_set_error_flag(CHERRFLAG flag_a);
extern uint16_t install_all_addr;
#endif
