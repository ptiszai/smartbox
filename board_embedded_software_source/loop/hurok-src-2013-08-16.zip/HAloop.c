/*
 *	Lamp allomas com. Atmega128.
 *  Tiszai I.
 *  2007
 *
 *	Leiras:
 *	Adas:
 *	',',cimh,ciml,parancs,chs:
 *  ',',cimh,ciml,0x0x,chs		// x: D0,D1 output, es input lekerdezes.
 *  ',',cimh,ciml,0x10,chs		// test mod.
 *  ',',cimh,ciml,0x80,chs		// reset
 *	',',0xfe,00,0x80,chs		// reset mindegyik allomasnal.
 *	',',0xfe,00,0x81,chs		// cim infra adas inditas.
 *	',',0xfe,00,0x82,chs		// cim infra adas leallitas.
 *	',',0xfe,00,0x70,chs		// test start, mindegyik allomasnal.
 *	',',0xfe,00,0x71,chs		// test stop , mindegyik allomasnal.
 *  chs = cim+parancs
 *  cim 					// allomas cim.
 *
 *	Vetel:
 *	';',cimh,ciml,parancs,chs:
 *	';',cimh,ciml,0x0x,chs		// x: D0,D1,D2,D3 input.
 *  chs = cim+parancs	
 *  cim 	
 *
 *  '!',0xbb,cimh,ciml,chs	// uj fix cim kuldese, PC -bol.		
 */

#include <avr\io.h>
#include <compat\ina90.h>
#include <stdio.h>
#include <string.h>

#include "macros.h"
#include "utils.h"
#include "Hurok.h"
#include "HAloop.h"
#include "HKloop.h"
#include "HConfig.h"


/*---------------------- konstansok -----------------------------*/

/*----------------------- valtozok ------------------------------*/
// transm.
volatile unsigned char	a_txBuffer[LTX_MAX_SENDED_NUM+2]; // transm. buffer
static uint8_t   tx_head;
// receive.
volatile unsigned char	a_rxBuffer[LRX_MAX_RECEIVE_NUM+2]; // receive buffer
static uint8_t   rec_head;

int8_t lstatus;
int8_t lerror;
uint16_t tx_max_sended_num;
uint8_t rx_max_receive_num;
uint8_t	rx_ready_s = 0;
uint16_t a_timercount;
//uint8_t l_recTotalTimeoutMultiplier;

uint8_t all_ask_index;
//uint8_t got_rand_all_addr,put_new_all_addr;
CHANNELtype all_array[COMM_MAX_ADDR+10];
uint8_t install;
CHN_ASK chn_ask;
uint16_t prev_test_timer_sec = 0;
uint16_t install_all_addr,prev_install_all_addr;

//uint8_t rx_error;

/***********************************************************
 * init resz.
 ***********************************************************/

void a_com_init(void)
{
	DDRA |= ((1<<DDA0)|(1<<DDA1)|(1<<DDA4));
	RS485_DE0_OFF
	RS485_RE0_OFF

	unsigned int baud=BAUD2400_16;
 	UCSR0A = 0x00;
 	UBRR0H = (unsigned char)(baud>>8);
 	UBRR0L = (unsigned char)baud;
 	UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0);

	UCSR0C = (3<<UCSZ00);	
	RS485_LED_OFF
	tx_head=0;
	rec_head=0;
    lstatus = 0;
    lerror = 0;
	SET_LSTATUS(RX)

	chn_ask.num = 0;
	a_channels_load(all_array);
	config_a_load_addr();

	tx_max_sended_num  = LTX_MAX_SENDED_NUM;
	rx_max_receive_num = LRX_MAX_RECEIVE_NUM;

	RS485_LED_ON
	DelayMs(100);
	RS485_LED_OFF
//	DelayMs(100);

	chn_ask.num = 2;				// infra off;
	chn_ask.chn.addrh = 0xfe;
	chn_ask.chn.addrl = 0x00;
	chn_ask.chn.cmd   = 0x82;
	a_tx_send(&chn_ask.chn);		// elso kerdezes, ami cim kereses.
	
	install_all_addr = 0;
	prev_install_all_addr = 0;
	//allloopenable = 1;
	//alladdrnumenable = 4;
}//all_com_init(void)

/***********************************************************
 * allomas tomb feldolgozo fg.-ek resz.
 ***********************************************************/
CHANNELtype NextAll(void)
{	
	++all_ask_index;

	all_ask_index = (all_ask_index > alladdrnumenable) ? 0 : all_ask_index;
/*	while ((all_ask_index<alladdrnumenable))
	{	
		if (!all_ask_index)
			break;
		if (all_array[all_ask_index].addr)
			break;
		++all_ask_index;
		if ((all_ask_index>=alladdrnumenable))
			all_ask_index=0;
	}*/	
	return all_array[all_ask_index];
}//CHANNELtype* NextAll(void)

CHANNELtype CurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return all_array[all_ask_index];
	return all_array[0];
}//CHANNELtype* CurrAll(void)


CHANNELtype* pCurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return &all_array[all_ask_index];
	return &all_array[0];
}//CHANNELtype* CurrAll(void)

CHANNELtype FirstAll(void)
{
	all_ask_index = 0;
	return all_array[0];
}//CHANNELtype* FirstAll(void)

void set_cmd_all_All(uint8_t cmd)
{
	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		all_array[index].cmd = cmd;
	}
}//void set_cmd_all_All(uint8_t cmd)

/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
void a_rx_controlling(volatile unsigned char* pData)
{
//#ifdef DEBUG	
//	sprintf(msg,"rx_c:%x,%x,%x,%x,%x",a_rxBuffer[0],a_rxBuffer[1],a_rxBuffer[2],a_rxBuffer[3],a_rxBuffer[4]);
//	sprintf(msg,"rx_c:%x",a_rxBuffer[4]);
//	SET_SYSSTATUS(SYS_MESSG)
//	PutString(msg);

//#endif

   // if (install_receiver(pData))
	//	return;

	CHANNELtype* chan = pCurrAll();

	//	char msg[40];
		

	if (*pData != R_STR_CHAR)
	{
		return;
	}
	pData++;

	if (config.install)				
	{  
		if (((int)(*pData))*256 + (int)(*(pData+1)) == install_all_addr)
		{
			if (search_alladdr(*pData, *(pData+1)))
				return;
			config_add_new_addr(*pData, *(pData+1));
		}		
		return;
	}	
	
	if ((*pData == chan->addrh) && (*(pData+1) == chan->addrl))
	{  // kerdezett allomas cime jott.	

		if (a_rx_data(pData))
		{
			//	chan.error = 0;
			a_set_error_flag(ERR_NONEflag,chan);
			return;		
		}
		else
		{
			if (CHK_SYSSTATUS(SYS_TEST) == 0)
			{
				a_set_error_flag(ERR_CONTflag,chan);
			}
		}

	}			

//	l_set_error_flag(ERR_NONEflag);
//	PutString("???????");


}//comm_rx_controlling(...)

//----------------------------------------------------
// check summa vizsgalata.
unsigned char  IsGoodCheckSumma(volatile unsigned char* pData)
{
    int temp =  (int)(*pData);
    temp += ((int)*(++pData));
    temp += (int)(*(++pData));

   // sprintf(msg,"rx_chs:%d,%x,%x",temp,(unsigned char)temp,*(pData+1));
//	PutString(msg);
//	sprintf(msg,"rx_c:%x",a_rxBuffer[4]);
    return (unsigned char)temp == *(++pData);

//	return (/* (unsigned char)*/(*pData + *(++pData) + *(++pData))	== *(++pData) );
}//IsGoodCheckSumma(unsigned char* pData)


//----------------------------------------------------
// altalanos lekerdezes
uint8_t a_rx_data(volatile unsigned char* pData)
{
	if (IsGoodCheckSumma(pData))
	{
	//	sprintf(msg,"rx:%x,%x,%x,%x,%x",a_rxBuffer[0],a_rxBuffer[1],a_rxBuffer[2],a_rxBuffer[3],a_rxBuffer[4]);
	//	PutString(msg);	
	

		CHANNELtype* chan = SearchAll(*pData, *(pData+1));
		if (chan->addrh == 0xaa)
			return 0;
		++pData;		
		chan->data = (*(++pData)) & 0x3f;
		a_channels_data_write(chan->id-1, chan->data);

	//	char msg[40];
		

		return 1;
	}
	else
	{
	//	PutString("Hchs err");	
		return 0;
	}

}//void rx_data(unsigned char* pData)

/***********************************************************
 *  Adas  resz.
 ***********************************************************/
 
void a_tx_send(CHANNELtype* ptrData)
{
	if (ptrData)
	{		        	
//		if  (ptrData->cmd == 0x90)
//			a_txBuffer[0] = S1_STR_CHAR;
//		else
			a_txBuffer[0] = S_STR_CHAR;
       // if  (ptrData->addrh == 0xaa)
       // {// uj install kerdes.
			if (config.install)				
			{       
				if (install_all_addr < config.max_addr)
				{		
					if (install_all_addr == prev_install_all_addr)						
						install_all_addr++;
					else
						prev_install_all_addr = install_all_addr;     
					a_txBuffer[1] = (int)(install_all_addr/256);
					a_txBuffer[2] = (int)(install_all_addr%256);    
				}
				else
				{
					config.install = 0;
					install_all_addr = 0;
					prev_install_all_addr = 0;
					a_channels_load(all_array);
					config_a_load_addr();
				}
			}
			else
			{
				if ((!ptrData->addrh) && (!ptrData->addrl))
					return;
				a_txBuffer[1] = ptrData->addrh;
				a_txBuffer[2] = ptrData->addrl;
			}
       // }
       // else
     //   {						
			if  ( (a_txBuffer[1] == 0xfe) && (a_txBuffer[2] == 0) )
			{
				a_txBuffer[3] = ptrData->cmd;			
			}
			else
				a_txBuffer[3] = /*(ptrData->out & 0x0f)*/ ((ptrData->data & 0xf0) >> 4)| (ptrData->cmd & 0xf0);			
		//	lcd_set_chan_addr(ptrData->addr);
	//	}		

		a_txBuffer[4] = a_txBuffer[1] + a_txBuffer[2] + a_txBuffer[3];
		
		
		a_tx_send_common();	
//		lcd_set_loop_addr(1,ptrData->addr);
	}

}//void tx_send(void)


 void a_tx_send_common(void)
 {
//#ifdef DEBUG
//char msg[40];
	//	sprintf(msg,"tx:%x,%x,%x,%x,%x",a_txBuffer[0],a_txBuffer[1],a_txBuffer[2],a_txBuffer[3],a_txBuffer[4]);
	//	PutString(msg);	
 
//#endif			
		RS485_LED_ON
		CLR_LSTATUS(RX)	
		RS485_RE0_OFF			
		DelayMs(10);	
		RS485_DE0_ON
		delayms(10); 					
		tx_head=0;
		TX0_ON		
		SET_LSTATUS(TX)		

 }//void 1_tx_send_common(void)
/*
//-------------------------------------------------------------
void set_allomas_error(uint8_t addrh,uint8_t addrl,uint8_t err_bit)
{
	CHANNELtype* all = SearchAll(addrh,addrl);
	//all->data = 0;
	all->data = err_bit;

}//void set_allomas_error(1,2,2)*/

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/

void a_com_rx_tx(void)
{
	if (CHK_LSTATUS(RX))
	{		
		if (CHK_LSTATUS(RX_READY))
		{			
		//	PutString("RXREADY");		
			CLR_LSTATUS(RX_READY)
		//	CLR_STATUS(RX)
			rx_ready_s = 1;
			
			a_rx_controlling(a_rxBuffer);
		
			RS485_RE0_OFF			
			RX0_OFF
			a_time_out(1,RX_TIME_TO_TX1);		
		}
		else				
		if (CHK_LERROR(RX_LERROR))
		{			
			CLR_LERROR(RX_LERROR)	
			CLR_LSTATUS(RX_READY)
			RS485_LED_OFF
			a_time_out(1,RX_TIME_TO_TX2);
		if (CHK_SYSSTATUS(SYS_TEST) == 0)			
				a_set_error_flag(ERR_RXflag, pCurrAll());
			install_error();
//#ifdef DEBUG
	//		PutString("HRec error");
//#endif
			RS485_RE0_OFF			
	//		RX0_OFF
			
		}
		else
		if (a_time_out(0,0))
		{// adast indit.
			//	PutString("HTindit");
			if (!rx_ready_s)
			{
				if (CHK_SYSSTATUS(SYS_TEST) == 0)
					a_set_error_flag(ERR_TOflag, pCurrAll());
				install_error();
			}
			else
				rx_ready_s = 0;
			
			if (chn_ask.num)
			{// kozpont kerdez 1.-et.			
				
				chn_ask.num--;	
				
					a_tx_send(&chn_ask.chn);

//				if (!chn_ask.num && ((chn_ask.chn.cmd  == 0x71) || (chn_ask.chn.cmd  == 0x82)))				
//				;
//					lcd_set_chan_cmd("                 ");			
				rx_ready_s = 1;
				
			}
			else
			{						
						CHANNELtype data = NextAll();
						if (!config.install && !all_ask_index)									
							data = NextAll();
					
						if (CHK_SYSSTATUS(SYS_TEST))
						{
							if (data.addrh == 0xaa)
								data = NextAll();
						}
						a_tx_send(&data);						
			}			
		}
	}
	else
	if (CHK_LSTATUS(TX_READY))
	{ // tx end.		
		rec_head=0;
		delayms(15);
		RS485_DE0_OFF
		delayms(5);	
		RS485_RE0_ON		
		TX0_OFF	
		RX0_ON 
		CLR_LSTATUS(TX_READY)
		CLR_LSTATUS(TX)
		SET_LSTATUS(RX)
		if (CHK_LSTATUS(LINSTALL))
			a_time_out(1,RX_TIME_TO_TX4);		
		else		
			a_time_out(1,RX_TIME_TO_TX3);			
		RS485_LED_OFF
	}
}//void all_com_rx_tx(void)

/**********************************************************
 * Install resz.
 **********************************************************/

CHANNELtype* SearchAll_install(uint8_t all_addressh,uint8_t all_addressl)
{
/*	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		if ((all_array[index].addrh == all_addressh) && (all_array[index].addrl == all_addressl))
			return  &all_array[index];
	}*/
	return &all_array[0];
	
}//CHANNELtype* SearchAll_install(void)

void install_tx_ujcim(void)
{
/*	a_txBuffer[0] = S1_STR_CHAR;
	a_txBuffer[1] = got_rand_all_addr;	
	a_txBuffer[2] = put_new_all_addr;
	a_txBuffer[3] = a_txBuffer[1] + a_txBuffer[2];
	a_tx_send_common();*/
}//void tx_bejentkezes(void)

void install_tx_ask_ujcim(void)
{
/*	a_txBuffer[0] = S1_STR_CHAR;
	a_txBuffer[1] = put_new_all_addr;	
	a_txBuffer[2] = config.loop;				// 1. loop.
	a_txBuffer[3] = a_txBuffer[1] + a_txBuffer[2];
	a_tx_send_common();*/
}//void install_tx_ask_ujcim(void)

void install_tx_cim(void)
{
/*	a_txBuffer[0] = S_STR_CHAR;
	a_txBuffer[1] = put_new_all_addr;	
	a_txBuffer[2] = 0;
	a_txBuffer[3] = a_txBuffer[1] + a_txBuffer[2];
	a_tx_send_common();*/
}//void install_tx_cim(void)


uint8_t install_search_new_addr(void)
{
/*	uint8_t ii;
	CHANNELtype* pAll;

	for (ii=1; ii<COMM_MAX_ADDR; ii++)
	{
		pAll = SearchAll_install(ii);
		if ((pAll->addr > COMM_MAX_ADDR) || !pAll->addr)
			break;
	}
	return ii;*/
	return 0;
}//void install_search_new_addr(void)

uint8_t install_receiver(volatile unsigned char* pData)
{
/*	if (CHK_LSTATUS(LINSTALL))
	{
		if (*pData == R1_STR_CHAR)
		{
			pData++;
			if (CHK_INSTALL(BEJ_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					got_rand_all_addr = *(++pData);
					put_new_all_addr = install_search_new_addr();
					if ((put_new_all_addr > 0) && (put_new_all_addr <= COMM_MAX_ADDR))
					{										
						CLRA_INSTALL;
						SET_INSTALL(PUT_ADDR_INST)		
//#ifdef DEBUG										
						sprintf(msg,"INST:got_addr:0x%x,0x%x",got_rand_all_addr,put_new_all_addr);
//#endif
						//(msg);
						DelayMs(100);
						install_tx_ujcim();
						rx_ready_s = 0;
						return 1;					
					}
				}
			}
			else
	//		if (CHK_INSTALL(ASK_ADDR_INST))
			if (CHK_INSTALL(PUT_ADDR_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					if (*pData == put_new_all_addr)
					{  // sajat uj cimevel jott a valasz.															
						config_add_new_addr(put_new_all_addr);
						a_channels_add(all_array,put_new_all_addr);
			
						CLR_LSTATUS(LINSTALL)
						CLRA_INSTALL
//#ifdef DEBUG
						sprintf(msg,"INST:put_addr:0x%x",put_new_all_addr);
//#endif
						PutString(msg);
						rx_ready_s = 0;
						DelayMs(100);
						install_tx_cim();
						return 1;
					}
				}
			}
		}
		install_error();
		return 1;
	}*/
	return 0;
}//uint8_t install_receiver(void)


void install_sender(void)
{
/*	if (CHK_INSTALL(PUT_ADDR_INST))
	{
		CLRA_INSTALL;
		SET_INSTALL(ASK_ADDR_INST)
		install_tx_ask_ujcim();
	}*/
}//void install_sender(void)

void install_error(void)
{
/*	if (CHK_LSTATUS(LINSTALL))
	{
//		if (CHK_INSTALL(ASK_ADDR_INST))
		if (CHK_INSTALL(PUT_ADDR_INST))
		{
			chn_ask.num = 2;
			chn_ask.chn.cmd = 0x90;
			chn_ask.chn.addr = put_new_all_addr;
//#ifdef DEBUG
		//	PutString("install_error:res addr");
//#endif

		}
//		else
//			PutString("install_error--baj van");
		CLR_LSTATUS(LINSTALL)
		CLRA_INSTALL
		
	}*/
}//void install_error(void)

/***********************************************************
 * inturrept resz.
 ***********************************************************/
 /**********************************************************
 * COM adas int.
 **********************************************************/
unsigned char a_tx_int()
{	
//	++tx_head;
	if (tx_head>=tx_max_sended_num)
	{
		SET_LSTATUS(TX_READY)
	//	CLR_LSTATUS(TX_INT)
		TX0_OFF
		return 1;
	}
	return  a_txBuffer[tx_head++];
}//unsigned char l_tx_int()

/**********************************************************
 * COM vetel int.
 **********************************************************/
 /*char l_IsRecFinished()
 {
	if ((rec_head >= rx_max_receive_num) || (l_recTotalTimeoutMultiplier >= 2))
	{
		rec_head=0;
//		RCIE = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LSTATUS(RX_READY)
		return 1;
	}
	return 0;
 }*/

void a_rx_int( unsigned char ucData)
{	 

	a_rxBuffer[rec_head] = ucData;
	++rec_head;

	if (rec_head >= rx_max_receive_num) /*|| (RecTotalTimeoutMultiplier >= 2))*/
	{
		rec_head=0;
//		RCIE = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LSTATUS(RX_READY)
		return;
	}
//	l_IsRecFinished();
//	l_recTotalTimeoutMultiplier = 0;	
	return;
}//void l_rx_int(..)

//----------------------------------------------------
void a_set_error_flag(CHERRFLAG flag_a,CHANNELtype* chan)
{
//	CHANNELtype* chan = pCurrAll();

	if (chan == NULL)
		return;

	
	if (flag_a == ERR_NONEflag)
	{
	//	chan->prev_data = 0;
		chan->error = 0;
	//	int temp = chan->error;
	/*	if (chan->addrl == 0x63)
		{
			sprintf(msg,"st_err:%x, %d",chan->error, all_ask_index);
				PutString(msg);
		}*/	
		
	}
	else		
	{
	//	if (chan->error & 0x80)
//				return;
	/*	if (chan->addrl == 0x63)
			{
				sprintf(msg,"_err:%x, %d",chan->error, all_ask_index);
				PutString(msg);
			}*/

		if ( !(chan->error & 0x08) && ((chan->error & 0x07) < 6))
		{
			chan->error++;
		/*	if (chan->addrl == 0x63)
			{
				sprintf(msg,"err:0x%x",chan->error);
		//		PutString(msg);
			}*/

		}
		else
		{
		//	if (chan->error & 0x08)
		//		return;

			chan->error = 0;
			chan->error |= 0x08;
			switch (flag_a)
			{
				case ERR_RXflag:			
					chan->error |= 0x01;
			//		PutString("rx err");
					break;
				case ERR_TOflag:
					chan->prev_data = 0x07;
					chan->data = 0x07;
					chan->error |= 0x02;
				/*	if (chan->addrl == 0x63)
					{
						PutString("to err");
					}*/
			//	PutString("ETO");
					break;
				case ERR_CONTflag:
					chan->error |= 0x04;;
				//	PutString("cnt err");
					break;
				case ERR_NONEflag:
					chan->error = 0;
				//	PutString("none err");
					break;
				case ERR_RESPflag:
				//	PutString("resp err");
					break;
			}
			
		}
	}
//	lcd_set_chan_data(&chan);
}//void l_set error_flag(uint8_t flag_a)


/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t a_time_out(uint8_t start,uint16_t diff)
{	
//	static uint8_t overflow = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		a_timercount = 0;
		_time_out = diff;
	//	overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
	/*	if (overflow)
		{
			if (timercount > _time_out)
				return 0;
			else
				overflow = 0;
		}
		else*/
		if (a_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t time_out(uint8_t start,uint8_t diff)


//-------------------------------------------------------------
// Test resz.
//-------------------------------------------------------------
void start_test(uint8_t mode_a)
{
	SET_SYSSTATUS(mode_a)
//	prev_test_timer_sec = timersec;
	chn_ask.num = 5;
	chn_ask.chn.cmd  = 0x70;
	chn_ask.chn.addrh = 0xfe;
	chn_ask.chn.addrl = 0;	
	set_cmd_all_All(0x10);	
}//void start_test(void)

//-------------------------------------------------------------
void end_test(void)
{
	CLR_SYSSTATUS(SYS_TEST)

	chn_ask.num = 5;
	chn_ask.chn.cmd  = 0x71;
	chn_ask.chn.addrh = 0xfe;
	chn_ask.chn.addrl = 0;			
	set_cmd_all_All(0);	
}//void start_test(void)
/*
//-------------------------------------------------------------
void test_executor(void)
{
	if (CHK_SYSSTATUS(SYS_TEST2))
	{
		if ((timersec - prev_test_timer_sec) > 140)
		{      
			prev_test_timer_sec = timersec; 
			//if (!(timersec % 200)) // 2 perc 20 sec
			//{
				end_test();
			//}
		}
	}
	else
	if (CHK_SYSSTATUS(SYS_TEST40))
	{
		if ((timersec - prev_test_timer_sec) > 2430)
		{       
			prev_test_timer_sec = timersec; 
	//		if (!(timersec % 2430)) // 40.5 perc
	//		{
				end_test();
	//		}
		}
	}
}//void start_test(void)
*/
