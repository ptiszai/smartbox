#ifndef _HALLOMAS_H
#define _HALLOMAS_H

/*
typedef struct
{
	uint8_t a_data;
	uint8_t a_error;
	uint8_t k_data;
	uint8_t k_error;
} STATIONS;*/

extern void allomas_exe();
extern uint8_t set_datas_st(uint8_t addrh_a,uint8_t addrl_a, uint8_t data_a, uint8_t error_a, uint8_t type_a);
extern uint8_t get_datas_st(uint8_t addrh_a,uint8_t addrl_a, uint8_t* data_a, uint8_t* error_a, uint8_t type_a );
extern int k_get_allomas_sender_index();

#endif
