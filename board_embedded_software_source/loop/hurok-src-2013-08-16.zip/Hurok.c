/*
 *	Lamp kozpont Atmega128.
 *  Tiszai I.
 *  2007
 */

 /*
 	HIBAK!!!

	
 */
#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <inttypes.h>
#include <compat\ina90.h>

#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>

#include "HAloop.h"
#include "HKloop.h"
#include "Hurok.h"
#include "HConfig.h"
#include "utils.h"

/*---------------------- konstansok -----------------------------*/

/*----------------------- valtozok ------------------------------*/
volatile unsigned char		status;
volatile unsigned char 		sys_status;
volatile unsigned char		error;
volatile uint16_t 			timercount;
volatile uint16_t 			timersec;
volatile int 				k_sec;
volatile uint16_t 			k_send_sec;
char msg[50];


/*
 * Read out and reset MCUCSR early during startup.
 */
 /*
 * Mirror of the MCUCSR register, taken early during startup.
 */
 /*
uint8_t mcucsr __attribute__((section(".noinit")));

void handle_mcucsr(void)
  __attribute__((section(".init3")))
  __attribute__((naked));
void handle_mcucsr(void)
{
  mcucsr = MCUCSR;
  MCUCSR = 0;
}*/
/*
const uint8_t eecontent[] =
{ 0x01,0x01,0x01,0x02,0x01,0x02,0 };*/

/*----------------------- fuggvenyek ----------------------------*/
#ifdef FORCERESET
void forceHardReset()
{
  cli(); // disable interrupts
  wdt_enable(WDTO_30MS); // enable watchdog
  while(1){}; // wait for watchdog to reset processor
} 
#endif


/***********************************************************
 * main part.
 ***********************************************************/
//res_start:
int main(void)
{ 
 	init();
	
	while(1)
	{
		wdt_reset(); 			// watch dog		
		a_com_rx_tx();			// allomas hurok.
		k_com_rx_tx();			// kozpont hurok.	
//		test_send();
#ifdef FORCERESET
		if (k_send_sec > KOZPONT_SEND_TO_MAX)
		{ // 120 sec
			forceHardReset();		
		}
#endif
	}
	return 1;
}


/***********************************************************
 * init part.
 ***********************************************************/
void altalanos_init(void)
{

 // init timers
 // TIMER0 initialize - prescale:1024
 // desired value: 10 mSec
/*
	DDRA = 0;
	TCCR0 = 0x00; //stop
 	TCNT0 = 157; //set count -- ((1/16)uS/1024)*157 = 10048 uS
	//TCNT0 = 2;
 	TCCR0 = _BV(CS02)|_BV(CS01)|_BV(CS00); //start timer :clk/1024
 	TIMSK = _BV(TOIE0); //timer interrupt sources:over	
*/
// 20 ms
TCCR1B = 0; // disable ticking
TIMSK = (TIMSK & ~(0x3c)) | 0x04; // enable overflow interrupt
TCNT1H = 0; // reset counter
TCNT1L = 0;
ICR1H = 40000U >> 8; // set overflow value
ICR1L = 40000U & 0xff;
TCCR1A = 0xfe; // 11 11 11 10, set channel config
TCCR1B = 0x1a; // 00011010 start ticking 


	timercount = 0;
    timersec = 0;
	k_sec = 0;
	k_send_sec = 0;

	config.infra = 0;
	config.install = 0;

	wdt_enable(WDTO_2S);
	sys_status = 0;
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//	eecontentwrite();
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!			
//	PutString("altalanos_init oke");


		
}//void altalanos_init(void)

//--------------------------------------------------------------
void init(void)
{
	_CLI();

	delayms(50);		
	altalanos_init();
    config_load();
	k_com_init();			
	a_com_init();

	RS485_LED_OFF
	RS485_LED_ON
	delayms(1000);
	RS485_LED_OFF

	_SEI();
#ifdef DEBUG
//	PutString("init ready");
#endif
//	test();
}//void init(void)

/*************************************************************
 * ISR part.
 *************************************************************/

//ISR (TIMER0_OVF_vect)
ISR (TIMER1_OVF_vect)
{
//	unsigned char sreg;
	timercount++;
	
	a_timercount++;
	k_timercount++;


	if(!(timercount%100))
	{
		timersec++;
		k_sec++;
		k_send_sec++;
	//	RS485_LED_TOGGLE
	}
	
//	_CLI();
//	sreg = SREG;
	// desired value: 10mSec
//	TCNT0 = 157; //reload counter value
//	TCNT0 = 0x02; //reload counter value

//	TCNT0 = 0xff; //reload counter value

//	SREG = sreg;		
//	_SEI();

}//ISR (TIMER0_OVF_vect)

//--------------------------------------------------------------
// vetel ISR.


// vetel ISR allomasok fele.
ISR(USART0_RX_vect)
{
 //	uint8_t rxbuff;

	UCSR0B &= ~_BV(RXCIE0);
//	rx_error = UCSR1A;
	if (bit_is_set(UCSR0A, FE0) || bit_is_set(UCSR0A, DOR0) || bit_is_set(UCSR0A, PE0))
	{

		CLR_LSTATUS(RX_INT)
		SET_LERROR(RX_LERROR)
		uint8_t rxbuff = UCSR0A;
		rxbuff = UDR0;				

//		PutString("E1");	
	}	
	else
	{
  		//rxbuff = UDR0;  
		SET_LSTATUS(RX_INT)
     	a_rx_int(UDR0);	
    }
	UCSR0B |= _BV(RXCIE0);
	
}

// adas ISR allomasok fele.
ISR(USART0_UDRE_vect)
{
	unsigned char temp;
//	SET_LSTATUS(TX_INT)
	temp=a_tx_int();
	if (CHK_LSTATUS(TX_READY))
		return;
	UDR0=temp;
//	PutChar(temp);
}

// vetel ISR kozpont fele
ISR(USART1_RX_vect)
{	
	UCSR1B &= ~_BV(RXCIE1);

	if (bit_is_set(UCSR1A, FE1) || bit_is_set(UCSR1A, DOR1) || bit_is_set(UCSR1A, PE1))
	{
		CLR_KSTATUS(RX_INT)
		SET_KERROR(RX_LERROR)
		uint8_t rxbuff = UCSR1A;
		rxbuff = UDR1;
		return;					
	}	
	else
	{ 
		SET_KSTATUS(RX_INT)
     	if (k_rx_int(UDR1))
			return;
    }
	UCSR1B |= _BV(RXCIE1);	
}

// adas ISR kozpont fele.
ISR(USART1_UDRE_vect)
{
	unsigned char temp;
//	SET_KSTATUS(TX_INT)
	temp=k_tx_int();
	if (CHK_KSTATUS(TX_READY))
		return;
	UDR1=temp;
}

ISR(__vector_default)
{

}


/*
void none(void)
{
	asm volatile
	( 
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
	);
}*/

