#ifndef _HCONFIG_H_
#define _HCONFIG_H_

//#include "K1loop.h"
#include "HAloop.h"
#include "Hurok.h"

#define VERSION 0x02;

// config eeprom address
#define	EE_VERSION		1
#define	EE_LOOP_NUM EE_VERSION + 1
// channels part of l loop.
#define EE_A_CHN_NUM			8
#define EE_A_CHN_BEGIN 			EE_A_CHN_NUM + 1
#define EE_A_CHN_DATA_BEGIN 	EE_A_CHN_BEGIN + 2*COMM_MAX_ADDR + 2

#define LOOP_MAX_ADDR		25


struct _config 
{
    uint8_t 	ver;			//	verzio
	uint8_t 	loop;			//	loop num;
	uint16_t	max_addr;		//	maximalis cim lehetoseg.
  /*  uint8_t		weekly_test[3]; //  weekly test, day, month, year
	uint8_t		annual_test[3]; //  annual test, day, month, year
	uint8_t		pheriph;		//  pheripherie:0  serial, 1 usb, 2 eth.
	uint8_t		loop_type;		//  loop:0  1loop, 1 more loop.*/
	uint8_t		infra;			//  infra on/off;
	uint8_t		install;		//  install on/off;
	uint8_t		first;
};
/*
struct _channel_config 
{
    
};*/

void config_save(void);
void config_load(void);

extern void eecontentwrite(void);
extern struct _config config;
/*extern void config_weekly_save(uint8_t year, uint8_t month,  uint8_t day);
extern void config_annual_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a);
extern void config_pheriph_save(uint8_t mode_a);
extern void config_loop_type_save(uint8_t mode_a);*/
extern void config_add_new_addr(uint8_t new_addrh, uint8_t new_addrl);
extern void config_remove_alladdr(void);
extern uint8_t config_remove_1_addr(uint8_t addrh, uint8_t addrl);
extern void a_channels_load(CHANNELtype* chn);
extern void a_channels_add(CHANNELtype* chn, uint8_t new_addrh, uint8_t new_addrl);
extern uint8_t all_addr[COMM_MAX_ADDR*2+10];
extern void config_a_load_addr();
extern uint8_t alladdrnumenable;
extern uint8_t search_alladdr(uint8_t addrh, uint8_t addrl);
extern void config_loop_write_addr(uint8_t laddr_a);
extern void a_channels_data_write(uint8_t index, uint8_t data);
#ifdef ALLOMAS_ADDRESS_ROM
#define ALL_ADDRESS_MAX_NUM		64		// max. allomas cim �rt�ke: most 64 (1600 �rt�k a fels� hat�r).
#endif
#endif
