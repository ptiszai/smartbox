/*
 *	Lamp kozponti hurok  Atmega64..
 *  Tiszai I.
 *  2007
 *
 *	Leiras:
 *	Adas: A
 *	Vetel:V
 *
	
 *
 *	V:',',lcim,0x00,0x00,0x0x,chs		// altalanos lekerdezes,parancsok.
 *	A:';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.
 *	A:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,acimh,aciml,data,chs		// elozoleg megkapott hiba visszajelzese.
 *	A:';',lcim,0x00,0x00,00,00,00,chs	
 *
 *	V:',',lcim,0x00,0x00,0x00,chs		// altalanos lekerdezes.
 *	A:'M',num,"uzenet.."			// szimpla uzenet, max. 20 byte.
 *
 *	V:',',lcim,acimh,aciml,0x80,chs		// reset 1 allomasnal.
 *	A:',',lcim,0x00,00,0x80,00,00,chs		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,acimh,aciml,0x90,chs		// reset allomas cim
 *	A:',',lcim,0x00,00,0x90,00,00,chs	// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0xfe,0x00,0x90,chs		// reset a hurkon levo ossz allomas cim
 *	A:',',lcim,0x00,00,0x90,00,00,chs	// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *	V:',',lcim,0x00,0x00,0x82,chs		// allomas cimek lekerdezese.
 *
 *	V:',',lcim,0x00,0x00,0x91,chs		// allomas cimek szamanak a lekerdezese.
 *	A:';',lcim,0x00,0x00,0x91,num,chs  // allomas cimek szama a num-ban
 *	A:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,0x00,0x92,chs		// allomas cimek lekerdezese.
 *	A:'N',lcim,0x92,num,a0..an,chs  // allomas cimek.
 *	A:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,0x00,0x90,chs		// reset cim mindegyik allomasnal. 
 *	A:',',lcim,0x00,00,0x90,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,00,0x83,chs		// install bekapcsolasa. 
 *	A:',',lcim,0x00,00,0x83,00,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,00,0x84,chs		// install kikapcsolasa. 
 *	A:',',lcim,0x00,00,0x84,00,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,00,0x90,chs		// osszes cim torlese . 
 *	A:';',lcim,0x00,00,0x90,00,00,chs 		// parancs elvegezve.
 *	A:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',0xfe,0x00,00,0x81,chs		// korparancs:cim infra adas inditas.(3x)
 *	V:',',0xfe,0x00,00,0x82,chs		// korparancs:cim infra adas leallitas.(3x)
 *	V:',',0xfe,0x00,00,0x80,chs		// korparancs:reset mindegyik allomasnal.(3x)
 *	V:',',0xfe,0x00,00,0x70,chs		// korparancs:test start, mindegyik allomasnal.(3x)
 *	V:',',0xfe,0x00,00,0x71,chs		// korparancs:test stop, mindegyik allomasnal.(3x)
 *	V:',',0xfe,0x00,00,0x83,chs		// korparancs:install bekapcsolasa.(3x) 
 *	V:',',0xfe,0x00,00,0x84,chs		// korparancs:install kikapcsolasa.(3x) 
 *	V:',',0xfe,0x00,00,0x90,chs		// korparancs:reset a hurkon levo ossz allomas cim
 *
 *	V:',',lcim,0x00,00,0xa1,chs		// rendszernek: uzenet kuldes mod bekapcsolva. 
 *	A:',',lcim,0x00,00,0xa1,0x00,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,0x00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,00,0xa2,chs		// rendszernek: uzenet kuldes mod kikapcsolva. 
 *	A:',',lcim,0x00,00,0xa2,00,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	V:',',lcim,0x00,00,0xa3,chs		// rendszernek: reset. 
 *	A:',',lcim,0x00,00,0xa3,00,00,chs 		// parancs elvegezve.
 *	A:',',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *  PC parancsok:
 *	V:'P',lcim,0x01,max_addrl,max_addrh,chs		// max. addres jott a PC-bol. 
 *
 *  V:'P',lcim,0x02,00,00,chs					// max. addres kerdese a PC-bol.
 *  A:'p',lcim,0x02,max_addrl,max_addrh,chs		// max. addres kuldese a PC-nek.
 *
 *  V:'P',0xbb,lcim,00,00,chs					// uj hurokcim a PC-bol.
 *  A:'p',lcim,0xbb,0,0,chs						// uj cim elfogadasa a PC-nek.
 *
 */
#include <avr\io.h>
#include <compat\ina90.h>
#include <stdio.h>
#include <string.h>
#include <avr/sleep.h> 
#include <avr/interrupt.h>

#include "macros.h"
#include "utils.h"
#include "Hurok.h"
#include "HAloop.h"
#include "HKloop.h"
#include "HConfig.h"

/*----------------------- valtozok ------------------------------*/
// transm.
volatile unsigned char	k_txBuffer[KTX_MAX_SENDED_NUM+10]; // transm. buffer
static uint16_t   ktx_head;
// receive.
volatile unsigned char	k_rxBuffer[KRX_MAX_RECEIVE_NUM+10]; // receive buffer
static uint16_t   krec_head;
static uint8_t 	 kozp_ask_index;
int8_t kstatus;
int8_t kerror;
uint16_t k_tx_max_sended_num;
uint16_t k_rx_max_receive_num;
uint16_t k_timercount;
char messg[50];


/***********************************************************
 * init resz.
 ***********************************************************/
void k_com_init(void)
{
	DDRA |= ((1<<DDA2)|(1<<DDA3));
	KOZP_DE1_OFF
	KOZP_RE1_OFF

	unsigned int baud = BAUD2400_16;
 	UCSR1A = 0x00;
 	UBRR1H = (unsigned char)(baud>>8);
 	UBRR1L = (unsigned char)baud;
 	UCSR1B = (1<<RXEN1)|(1<<TXEN1);//|(1<<RXCIE1);
//	UCSRB = (1<<TXEN) ;
	UCSR1C = (3<<UCSZ10);	
//	RS485_LED_OFF
	ktx_head=0;
	krec_head=0;
  
	k_tx_max_sended_num 	= KTX_DEF_SENDED_NUM/*KTX_MAX_SENDED_NUM*/;
	k_rx_max_receive_num 	= KRX_MAX_RECEIVE_NUM;
	kozp_ask_index = 0;
	kstatus = 0;
    kerror = 0;
	SET_KSTATUS(RX)
	KOZP_RE1_ON
	RX1_ON
	k_time_out(1,RX_KTIME_TO_TX4);
	config.first = 1;
//	SET_SYSSTATUS(SYS_MESSG)

	//SET_SYSSTATUS(SYS_MESSG)
}//void k_com_init(void)


/***********************************************************
 * allomas tomb feldolgozo fg.-ek resz.
 ***********************************************************/
CHANNELtype* k_NextAll(void)
{	
	if (alladdrnumenable<1)
		return NULL;

	++kozp_ask_index;

	kozp_ask_index = (kozp_ask_index > alladdrnumenable) ? 1 : kozp_ask_index;	

	return &all_array[kozp_ask_index];
}//CHANNELtype* NextAll(void)

CHANNELtype k_CurrAll(void)
{
	if (kozp_ask_index <= alladdrnumenable)
		return all_array[kozp_ask_index];
	return all_array[0];
}//CHANNELtype* CurrAll(void)

CHANNELtype IndexAll(uint8_t index)
{
	if (index <= alladdrnumenable)
		return all_array[index];
	else
		return all_array[0];
}//CHANNELtype* IndexAll(void)

CHANNELtype* SearchAll(uint8_t all_addressh, uint8_t all_addressl)
{
	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		if ((all_array[index].addrh == all_addressh) && (all_array[index].addrl == all_addressl))
			return  &all_array[index];
	}
	return NULL;
	
}//CHANNELtype* IndexAll(void)


/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
void  k_rx_controlling()
{
//	sprintf(msg,"H-%x,%x,%x,%x,%x",k_rxBuffer[0],k_rxBuffer[1],k_rxBuffer[2],k_rxBuffer[3],k_rxBuffer[4]);
	k_time_out(1,RX_KTIME_TO_TX4);
	if (k_rxBuffer[0] == PCR_STR_CHAR)
	{ // PC part of commands			
		if (!k_IsGoodCheckSumma())
			return;
		if (k_rxBuffer[1] == 0xbb)
		{ //set new address		
			config_loop_write_addr((uint8_t)k_rxBuffer[2]);
			return;
		}
	}
	
	//PutString(msg);
	if (k_rxBuffer[0] == KR_STR_CHAR)
	{			
		if (!k_IsGoodCheckSumma())
			return;

//	sprintf(msg,"H-%x,%x,%x,%x,%x",k_rxBuffer[0],k_rxBuffer[1],k_rxBuffer[2],k_rxBuffer[3],k_rxBuffer[4]);
//	sprintf(msg,"H-%d,%x",k_rxBuffer[1],config.loop);
//	PutString(msg);
	//	k_rxBuffer[1] =  config.loop;
		if (k_rxBuffer[1] == config.loop)
		{  // sajat cime jott.
		
			k_rx_data();
		//	PutString("Altalanos");
	//	sprintf(msg,"!!-%x,%x",k_rxBuffer[1],config.loop);
	//PutString(msg);
		}
	//	PutString(msg);
//	return;
		else
		if (k_rxBuffer[1] == BROAD_ADDRESS)
		{ // korparancs kuldes,valasz ilyenkor nincsen.
		//	pData++;
		//	PutString("Broad");
			k_rx_broad();
			
		}
		config.first = 0;
	//	else
	//		k_tx_oke( k_rxBuffer[1]);
	}
	if (CHK_SYSSTATUS(SYS_TEST))
	{
		if (k_sec > 5)
		{
			chn_ask.num = 2;
//			chn_ask.loop = config.loop;
			chn_ask.chn.addrh = BROAD_ADDRESS;
			chn_ask.chn.addrl = 0;
			chn_ask.chn.cmd = R_STARTTEST_CMD;
			k_sec = 0;
		}
	}
	else
	if (CHK_SYSSTATUS(SYS_INFRA))
	{
		if (k_sec > 5)
		{
			chn_ask.num = 2;
//			chn_ask.loop = config.loop;
			chn_ask.chn.addrh = BROAD_ADDRESS;
			chn_ask.chn.addrl = 0;
			chn_ask.chn.cmd = R_STARTINFRA_CMD;
			k_sec = 0;
		}
	}

}//void k_rx_controlling(volatile unsigned char* pData)

//----------------------------------------------------
// check summa vizsgalata.
unsigned char  k_IsGoodCheckSumma()
{
//volatile unsigned char chs = *(++pData) ;//+ *(++pData);//	+ *(++pData));
//k_tx_oke( chs);
	return ((unsigned char)(k_rxBuffer[1] + k_rxBuffer[2] + k_rxBuffer[3] + k_rxBuffer[4]) == k_rxBuffer[5]);
}//IsGoodCheckSumma(unsigned char* pData)

//----------------------------------------------------
// altalanos lekerdezes
uint8_t k_rx_data()
{
	if (!k_rxBuffer[2] && !k_rxBuffer[3])
	{ //rendszer
	
		if (k_rxBuffer[4] & 0xf0)
		{ //belso parancsok.
			if (k_rxBuffer[4] == R_STARTINST_CMD)
			{ // start install
				//SET_LSTATUS(LINSTALL)				
				config.install = 1;
				install_all_addr = 0;
				k_tx_oke(k_rxBuffer[4]);
			}
			else
			if (k_rxBuffer[4] == R_STOPINST_CMD)
			{ // stop install
				//CLR_LSTATUS(LINSTALL) 
				config.install = 0;
				a_channels_load(all_array);
				config_a_load_addr();
				k_tx_oke(k_rxBuffer[4]);
			}
			else
			if (k_rxBuffer[4] == R_ADRRES_CMD)
			{ // stop install
				//CLR_LSTATUS(LINSTALL) 
				config_remove_alladdr();
				a_channels_load(all_array);
				config_a_load_addr();
				k_tx_oke(k_rxBuffer[4]);
			}
			else
			if (k_rxBuffer[4] == R_STARTMESG_CMD)
			{ // start uzenet kuldes			
				SET_SYSSTATUS(SYS_MESSG)
				k_tx_oke(k_rxBuffer[4]);
			}
			else
			if (k_rxBuffer[4] == R_ASKADDR_CMD)
			{// allomas cimek lekerdezese.
				k_tx_addr_list();
			}							
			else
			if (k_rxBuffer[4] == R_STOPMESG_CMD)
			{ // stop uzenet kuldes
				CLR_SYSSTATUS(SYS_MESSG) 
				CLR_SYSSTATUS(IS_MSG);
				k_tx_oke(k_rxBuffer[4]);
			}
			else
			if (k_rxBuffer[4] == R_HRESET_CMD)
			{	// reset
				cli();
				sleep_enable();
				sleep_cpu();
				sleep_disable();
				//PutString("reset");
				return 1;
			}
			else
			if (k_rxBuffer[4] == S_ADDRLSTNUM_CMD)
			{ // allomas cimek szamanak a lekerdezese.			
				k_tx_addr_sum_num();
			}					
		}
		else			
		{			
			// altalanos lekerdezes.
			if (config.first)
			{
				if (k_rxBuffer[4] & 4)	//install
					config.install = 1;
				if (k_rxBuffer[4] & 2)	//infra
				{
					chn_ask.num = 2;
	//				chn_ask.loop = config.loop;
					chn_ask.chn.addrh = BROAD_ADDRESS;
					chn_ask.chn.addrl = 0;
					chn_ask.chn.cmd = R_STARTINFRA_CMD;
					config.first =  0; 
				}

			}
															
		/*	if (CHK_SYSSTATUS(IS_MSG))
			{ // uzenet.
					CLR_SYSSTATUS(IS_MSG)
					k_tx_messg();
			}
			else*/								
			if (!k_get_nextchan_data())
				// allomas adatok kuldese sorban.
				k_tx_oke(k_rxBuffer[4]); 															
		}
	}
	else
	{
		if (k_rxBuffer[2] == BROAD_ADDRESS)
		{
				if (k_rxBuffer[4] == R_ADRRES_CMD)
				{ // hurkon levo osszes allomas cimenek a torlese.
				/*	chn_ask.num = 2;
					chn_ask.loop = config.loop;
					chn_ask.chn.addr = BROAD_ADDRESS;
					chn_ask.chn.cmd = R_ADRRES_CMD;
					k_tx_oke(k_rxBuffer[3]); 
					config_remove_alladdr();
					config_a_load_addr();
					a_channels_load(all_array);*/
					return 1;
				}			
		}
		else
		{
			CHANNELtype* all = SearchAll(k_rxBuffer[2],k_rxBuffer[3]);
			if (all)
			{ // megvan a cim.
			// allomas cim jott.			
				if ((k_rxBuffer[4] == R_1RESET_CMD) || (k_rxBuffer[4] == R_ADRRES_CMD))
				{				
					chn_ask.num = 3;
//					chn_ask.loop = config.loop;
					chn_ask.chn.addrh = all->addrh;
					chn_ask.chn.addrl = all->addrl;
					chn_ask.chn.cmd = k_rxBuffer[4];
					k_tx_oke(k_rxBuffer[4]);
				//	config_remove_1_addr( all->addrh, all->addrl);
				//	config_a_load_addr();					
				//	a_channels_load(all_array);
					return 1;	
				}
				else
				{
					k_get_chek_req(all);			
					return 1;
				}
			}
		}
		k_tx_notoke(); 
	}
	return 0;
}//uint8_t k_rx_data(volatile unsigned char* pData)


//----------------------------------------------------
// korparancs
uint8_t k_rx_broad()
{
	
	if (!k_rxBuffer[2] && !k_rxBuffer[2])
	{
		if (k_rxBuffer[4] == R_STARTTEST_CMD)	
		{		
			if (CHK_SYSSTATUS(SYS_TEST) == 0)
			{
				SET_SYSSTATUS(SYS_TEST)
				a_channels_load(all_array);
#ifdef TOLTES_COM_CLEAR_AFTER_TEST
				int ii;
				for (ii=1; ii<(alladdrnumenable+1); ii++)
				{ //toltest, hibat torli
					all_array[ii].data |= 1;	
					all_array[ii].prev_data |= 1;
					all_array[ii].error = 0;
					all_array[ii].prev_error = 0;
				}
#endif
			}
		}
		else
		if (k_rxBuffer[4] == R_STOPTEST_CMD)
		{
			CLR_SYSSTATUS(SYS_TEST)
			a_channels_load(all_array);
		}
		else	
		if (k_rxBuffer[4] == R_STARTINFRA_CMD)			
			SET_SYSSTATUS(SYS_INFRA)
		else
		if (k_rxBuffer[4] == R_STOPINFRA_CMD)
			CLR_SYSSTATUS(SYS_INFRA)	
		else		
		if (k_rxBuffer[4] == R_ADRRES_CMD)
		{ // stop install
				
			config_remove_alladdr();
			a_channels_load(all_array);
			config_a_load_addr();
			return 1;
			
		}
		if (k_rxBuffer[4] == R_STARTINST_CMD)
		{
			config.install = 1;
			install_all_addr = 0;
			return 1;
		}
		else
		if (k_rxBuffer[4] == R_STOPINST_CMD)
		{
			config.install = 0;
			config.install = 0;
			a_channels_load(all_array);
			config_a_load_addr();
			return 1;
		}
			
		
		if (   (k_rxBuffer[4] == R_1RESET_CMD) 
			|| (k_rxBuffer[4] == R_1ADRRES_CMD) 
			|| (k_rxBuffer[4] == R_ADRRES_CMD) 
		    || (k_rxBuffer[4] == R_STARTINFRA_CMD)
			|| (k_rxBuffer[4] == R_STOPINFRA_CMD)			
			|| (k_rxBuffer[4] == R_STARTTEST_CMD)
			|| (k_rxBuffer[4] == R_STOPTEST_CMD)
			)
		{	// korparancs.
			chn_ask.num = 5;
//			chn_ask.loop = config.loop;
			chn_ask.chn.addrh = k_rxBuffer[1];
			chn_ask.chn.addrl = 0;
			chn_ask.chn.cmd = k_rxBuffer[4];
			//PutString("Broad");
		/*	if (CHK_SYSSTATUS(IS_MSG))
			{ // uzenet.
				CLR_SYSSTATUS(IS_MSG)
				k_tx_messg();
			}
			else*/
				k_tx_oke(k_rxBuffer[4]);
			return 1;
		}		
	}
	
	k_tx_notoke();
	return 0;
}//uint8_t k_rx_data(volatile unsigned char* pData)
	
//----------------------------------------------------
void k_get_chek_req(CHANNELtype* all)
{
	if (all->error & 0x08)
		all->prev_error = 0x08;
#ifndef TOLTES_COM_CLEAR_AFTER_TEST
	else
	{
		if (all->prev_error == 0x08)
			all->prev_error = 0;
	}
#endif

#ifdef TOLTES_COM_CLEAR_AFTER_TEST
	if (CHK_SYSSTATUS(SYS_TEST) == 0)
	{
		if ((all->prev_data & 0x01)  == 0)
		{ // toltes hiba volt mar....
			if (all->data & 0x02)
				all->prev_data |= 2;
			else
				all->prev_data &= 0x05;
			if (all->data & 0x04)
				all->prev_data |= 4;
			else
				all->prev_data &= 0x03;
		}
		else
			all->prev_data = (k_rxBuffer[4] & 0x07);
	}
#else	
	all->prev_data = (k_rxBuffer[4] & 0x07);
#endif

	k_tx_oke(0);

}//void k_get_chek_req()

/***********************************************************
 *  Adas  resz.
 ***********************************************************/
void k_tx_back()
{
	k_txBuffer[0] = k_rxBuffer[0];
    k_txBuffer[1] = k_rxBuffer[1];
	k_txBuffer[2] = k_rxBuffer[2];
	k_txBuffer[3] = k_rxBuffer[3];				       
	k_txBuffer[4] = k_rxBuffer[4];
	k_txBuffer[5] = k_rxBuffer[5];
	k_txBuffer[6] = k_rxBuffer[6];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
	k_tx_max_sended_num 	= KTX_DEF_SENDED_NUM;
	k_tx_send_common();

}//void k_tx_oke(unsigned char cmd)

void k_tx_oke(volatile unsigned char cmd)
{

	k_txBuffer[0] = KS_STR_CHAR;
    k_txBuffer[1] = config.loop;
	k_txBuffer[2] = 0;
	k_txBuffer[3] = 0;
	k_txBuffer[4] = cmd;	
	k_txBuffer[5] = 0;	
	k_txBuffer[6] = 0;	

	uint8_t ii;

	if (config.install)
	{
		k_txBuffer[6] = 0x02; 	//state:install.
	}
	else
	{
		for (ii=1; ii<=alladdrnumenable; ii++)
		{
			if (CHK_SYSSTATUS(SYS_TEST))
			{
				if (all_array[ii].data & 0x06) 
				{
			
					k_txBuffer[6] = 0x01;
					break;
				}
			}
#ifdef TOLTES
			else
			{			
				if (!(all_array[ii].data & 0x01) )
				{
			
					k_txBuffer[6] = 0x01;	//state:toltes hiba.
					break;
				}

			}
#endif
		}
	}

		       
	k_txBuffer[7] = k_txBuffer[1] + k_txBuffer[2] + k_txBuffer[3] + k_txBuffer[4] + k_txBuffer[5] + k_txBuffer[6];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
//	PutString("OKE");
	k_tx_max_sended_num 	= KTX_DEF_SENDED_NUM;
	k_tx_send_common();

}//void k_tx_oke(unsigned char cmd)

void k_tx_notoke(void)
{
	k_txBuffer[0] = KS_STR_CHAR;
    k_txBuffer[1] = config.loop;
	k_txBuffer[2] = 0;
	k_txBuffer[3] = 0;
	k_txBuffer[4] = S_ERROR_CMD;	
	k_txBuffer[5] = 0;	
	k_txBuffer[6] = 0;				       
	k_txBuffer[7] = k_txBuffer[1] + k_txBuffer[2] + k_txBuffer[3] + k_txBuffer[4] + k_txBuffer[5] + k_txBuffer[6];
			
	//	PutString("NOKE");
	k_tx_max_sended_num 	= KTX_DEF_SENDED_NUM;
	k_tx_send_common();
}//void k_tx_notoke(unsigned char cmd)

//-------------------------
uint8_t k_get_nextchan_data(void)
{
	CHANNELtype* chn = NULL;
	uint8_t ii;

	if ((alladdrnumenable<1) ||	(alladdrnumenable > COMM_MAX_ADDR))
		return 0;

	for (ii=1; ii<=alladdrnumenable; ii++)
	{
		if (CHK_SYSSTATUS(SYS_TEST))
		{
			if (((all_array[ii].data & 0x06) != (all_array[ii].prev_data & 0x06)) 
			|| ((all_array[ii].error & 0x08) && (!all_array[ii].prev_error))
			|| ((!all_array[ii].error) && (all_array[ii].prev_error & 0x08)))
			{
				chn = &all_array[ii];
				break;
			}
		}
		else
		{
#ifdef TOLTES

			if (((all_array[ii].data & 0x01) != (all_array[ii].prev_data & 0x01)) 
			|| ((all_array[ii].error & 0x08) && (!all_array[ii].prev_error))
			|| ((!all_array[ii].error) && (all_array[ii].prev_error & 0x08)))
#else
			if (((all_array[ii].error & 0x08) && (!all_array[ii].prev_error))
			|| ((!all_array[ii].error) && (all_array[ii].prev_error & 0x08)))
#endif
			{
				chn = &all_array[ii];
				break;
			}
		}
	}
	
	if (chn == NULL)
		return 0;

	uint8_t stat = 0;
	k_txBuffer[0] = KS_STR_CHAR;
    k_txBuffer[1] = config.loop;
	k_txBuffer[2] = chn->addrh;
	k_txBuffer[3] = chn->addrl;
	k_txBuffer[4] = chn->data;

	if ((chn->error & 0x08) && (!chn->prev_error))
	{ // com error
		k_txBuffer[5] = chn->error;
		k_txBuffer[4] = 0x07;
#ifndef TOLTES_COM_CLEAR_AFTER_TEST
		chn->prev_data = 0x07;
		chn->data = 0x07;
#endif
	}
#ifndef TOLTES_COM_CLEAR_AFTER_TEST
	else	
	if ((chn->prev_error & 0x08) && (!chn->error))
	{ // com error megszunt
		k_txBuffer[5] = 0x40;
		
	}
	else
		k_txBuffer[5] = 0;
#endif
	if (config.install)
	// install modban fut.
		stat |= 1;
	else
		stat &=0xfe;
	k_txBuffer[6] = stat;
	k_txBuffer[7] = k_txBuffer[1] + k_txBuffer[2] + k_txBuffer[3] + k_txBuffer[4] + k_txBuffer[5] + k_txBuffer[6];
	//	PutString("DATA");
	k_tx_max_sended_num = KTX_DEF_SENDED_NUM;	
	k_tx_send_common();	
	return 1;		
}//uint8_t k_get_nextchan_data(void)

void k_tx_addr_sum_num()
{
	k_txBuffer[0] = KS_STR_CHAR;
    k_txBuffer[1] = config.loop;
	k_txBuffer[2] = 0;
	k_txBuffer[3] = 0;
	k_txBuffer[4] = S_ADDRLSTNUM_CMD;	
	k_txBuffer[5] = alladdrnumenable;	
	k_txBuffer[6] = 0;			       
	k_txBuffer[7] = k_txBuffer[1] + k_txBuffer[2] + k_txBuffer[3] + k_txBuffer[4] + k_txBuffer[5] + k_txBuffer[6];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
//	PutString("OKE");
	k_tx_max_sended_num 	= KTX_DEF_SENDED_NUM;
	k_tx_send_common();
}//void k_tx_addr_sum_num()


void k_tx_addr_list(void)
{
	int ii;
	unsigned char chks;

	config_a_load_addr();

	k_txBuffer[0] = KS2_STR_CHAR;
    k_txBuffer[1] = config.loop;
	k_txBuffer[2] = R_ASKADDR_CMD;
	chks = k_txBuffer[1] + k_txBuffer[2];
	if (!all_addr[1])
	{		
		k_txBuffer[3] = 0;
		k_txBuffer[4] = chks;		
	}
	else
	{
		k_txBuffer[3] = all_addr[1]; 
		chks += k_txBuffer[3];
		for (ii=0; ii<((int)all_addr[1])*2; ii+=2)
		{
			k_txBuffer[4+ii] = 	all_addr[2+ii];
			k_txBuffer[5+ii] = 	all_addr[3+ii];
			chks += (k_txBuffer[4+ii] + k_txBuffer[5+ii]);		
		}
		k_txBuffer[4+ii] = chks;
	
	}
	k_tx_max_sended_num = ((int)k_txBuffer[3])*2 + 5;
//	k_txBuffer[4] = k_tx_max_sended_num;
	k_tx_send_common();
	k_time_out(1,50);
}//void k_tx_addr_list(void)

void k_tx_messg(void)
{
	int ii = 0;
	k_txBuffer[0] = KS1_STR_CHAR;
    k_txBuffer[1] = config.loop;
//	k_txBuffer[2] = 0;
//	k_txBuffer[3] = S_MESSG_CMD;
	for (ii = 0; (ii<20 && messg[ii]) ; ii++)				       
		k_txBuffer[ii+2] = messg[ii];
	k_txBuffer[ii+2] = 0;
//	k_txBuffer[1] = ii+2;
	//k_tx_max_sended_num = ii+2;	
	k_tx_max_sended_num = 20;
		
	k_tx_send_common();

}//void k_tx_messg(unsigned char cmd)

void k_tx_send(CHANNELtype* ptrData)
{
	if (ptrData)
	{
	}
}//void k_tx_send(CHANNELtype* ptrData)


void k_tx_send_common(void)
{
//	RS485_LED_ON
//	RX1_OFF
	//RS485_RE_OFF
//	DelayMs(5);
	KOZP_RE1_OFF	
	DelayMs(30);
	KOZP_DE1_ON
	DelayMs(10);
	k_time_out(1,RX_KTIME_TO_TX3);
	ktx_head = 0;
	krec_head = 0;
	CLR_KSTATUS(TX_READY)
	SET_KSTATUS(TX)
	CLR_KSTATUS(RX)
	k_send_sec = 0;

//	TXREG=txBuffer[0];
//	UDR1 = k_txBuffer[0];
	TX1_ON	
}//void k_tx_send(void)


/***********************************************************
 * main()-be a forutin.
 ***********************************************************/
void k_com_rx_tx(void)
{
//return;
	if (CHK_KSTATUS(RX))
	{		
		if (CHK_KSTATUS(RX_READY))
		{	
		
		//	RX1_OFF		
			KOZP_RE1_OFF			
					
			CLR_KSTATUS(RX_READY)
			RS485_LED_TOGGLE
		//	k_tx_oke(k_txBuffer[0]);
			//return;	
		//	k_tx_back();		
			k_rx_controlling();
				
				//SET_KSTATUS(RX)
			CLR_KSTATUS(RX)	
	//		k_time_out(1,RX_KTIME_TO_TX4);		
		}
		else				
		if (CHK_KERROR(RX_LERROR))
		{			
			CLR_KERROR(RX_LERROR)	
			CLR_KSTATUS(RX_READY)
			k_time_out(1,RX_KTIME_TO_TX3);
			
			//a_set_error_flag(ERR_RXflag, pCurrAll());
		
		//	KOZP_RE1_OFF


			CLR_KSTATUS(RX)
	//		PutString("KHurok Err");
	//		RS485_LED_OFF
	//		RX1_OFF			
		}			
	}
	else
	if (k_time_out(0,0))
	{		
		KOZP_DE1_OFF
		KOZP_RE1_ON	
		TX1_OFF
		delayms(5);	
		RX1_ON
		SET_KSTATUS(RX)
		CLR_KSTATUS(TX_READY)
		CLR_KSTATUS(TX)
		k_time_out(1,RX_KTIME_TO_TX4);
		krec_head=0;
	//	RS485_LED_ON
	}

	if (CHK_KSTATUS(TX_READY))
	{ // tx end.
	//	TX1_OFF			
		krec_head=0;
		ktx_head=0;
	//	delayms(10);	//2007.11.20
	//	KOZP_DE1_OFF	//2007.11.20
//		TX1_OFF		
//		delayms(15);		
//		KOZP_RE1_ON	
//		delayms(10);	
//		RX1_ON 
		CLR_KSTATUS(TX_READY)
		CLR_KSTATUS(TX)
//		SET_KSTATUS(RX)	
		k_tx_max_sended_num = KTX_DEF_SENDED_NUM;
		RS485_LED_TOGGLE			
		k_time_out(1,RX_KTIME_TO_TX5);			
	//	RS485_LED_OFF		
	}
}//void k_com_rx_tx(void)


/***********************************************************
 * inturrept resz.
 ***********************************************************/
 /**********************************************************
 * COM adas int.
 **********************************************************/
unsigned char k_tx_int()
{	
	
	if (ktx_head>=k_tx_max_sended_num)
	{
		SET_KSTATUS(TX_READY)	
	//	KOZP_DE1_OFF
		TX1_OFF			
		return 1;
	}
	return  k_txBuffer[ktx_head++];
	//return 1;	
}//unsigned char k_tx_int()

/**********************************************************
 * COM vetel int.
 **********************************************************/
uint8_t k_rx_int( unsigned char ucData)
{
	k_rxBuffer[krec_head] = ucData;
	++krec_head;

//	RS485_LED_TOGGLE
	if (krec_head >= k_rx_max_receive_num) /*|| (RecTotalTimeoutMultiplier >= 2))*/
	{
		RX1_OFF
		krec_head=0;
		KOZP_RE1_OFF	
	//	CLR_KSTATUS(RX_INT)
		SET_KSTATUS(RX_READY)
	//	PutString("End");
	//	RS485_LED_TOGGLE	
		return 1;
	}
	return 0;
}// void k_rx_int( unsigned char ucData)

/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t k_time_out(uint8_t start,uint16_t diff)
{	
//	static uint8_t overflow = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		k_timercount = 0;
		_time_out = diff;
						
	}
	else
	{
		if (k_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t time_out(uint8_t start,uint8_t diff)

/**********************************************************
 * Message.
 **********************************************************/

 /*--- void PutString( unsigned char *str )----------------------------*/
void PutString( const char *str)
{
	if (CHK_SYSSTATUS(SYS_MESSG))
	{
		unsigned char i = 0;
		while ( str[i] ) 
		{	
			messg[i] = str[i];		
			i++;	
		}
		i++;
		messg[i] = 0x0d ;
//	PutChar( 0x0a );
		i++;
		messg[i]  = 0x00 ;
		messg[20] = 0x00 ;			
	//	SET_SYSSTATUS(IS_MSG);
		k_tx_messg();
		CLR_SYSSTATUS(SYS_MESSG)
	}

}//void PutString( const char *str)

/*********************************/
// Teszt resz

void test_send()
{
	SET_SYSSTATUS(SYS_MESSG)
	PutString( "123456789" );
}
