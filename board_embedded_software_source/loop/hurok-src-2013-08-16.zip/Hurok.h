#ifndef _HUROK_H
#define _HUROK_H

#define HUROK_VERSION		5

#define TOLTES 			1
//#define FORCERESET		1
//#define TOLTES_COM_CLEAR_AFTER_TEST		1
#define ALLOMAS_ADDRESS_EE	1
//#define ALLOMAS_ADDRESS_ROM	1


#define KOZPONT_SEND_TO_MAX		120 // 2 min

//#define	SYS_1LOOP			0x01
//#define	SYS_MLOOP			0x02
//#define	SYS_LIGHT			0x04
#define	SYS_TEST			0x01
#define	SYS_INFRA			0x02
#define	SYS_WAIT_ADDRLIST	0x04
#define	SYS_MESSG			0x08
#define	IS_MSG				0x10


#define CLR_SYSSTATUS(x)		{sys_status &= (~x);}
#define SET_SYSSTATUS(x)		{sys_status |= (x);}
#define CHK_SYSSTATUS(x)		(sys_status & (x))

void init(void);

extern volatile uint16_t 		timercount;
extern volatile uint16_t 		timersec;
extern volatile int 			k_sec;
extern volatile uint16_t        k_send_sec;
extern volatile unsigned char 	sys_status;
extern char msg[50];
#endif
