#ifndef _AADDRESS_H_
#define _AADDRESS_H_


#define HUROK_LOOP_ADDRESS  1 // 1-25 lehet

#endif
