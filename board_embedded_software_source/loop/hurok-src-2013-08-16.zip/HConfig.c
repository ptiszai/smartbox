#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include  "HAloop.h"
#include  "HKLoop.h"
#include  "HConfig.h"
#include  "utils.h"
#include  "allomas-address.h"


// csak forditaskor kell!!!
/*uint8_t EEMEM eeprombyte18=0xff;	//allomas cim vege.
uint8_t EEMEM eeprombyte17=0x18;	//allomas cim.
uint8_t EEMEM eeprombyte16=0x01;	//allomas cim.
uint8_t EEMEM eeprombyte15=0x9b;	//allomas cim.
uint8_t EEMEM eeprombyte14=0x00;	//allomas cim.

*/

uint8_t EEMEM eeprombyte1=0x04;		//verzio
uint8_t EEMEM eeprombyte2=0x1;		//loop cime.1
//uint8_t EEMEM eeprombyte2=0x19;		//loop cime.1
//uint8_t EEMEM eeprombyte3=0x02;		//max addr low:2
//uint8_t EEMEM eeprombyte4=0x00;		//max addr higth
uint8_t EEMEM eeprombyte3=0x3F;		//max addr low,  1599
uint8_t EEMEM eeprombyte4=0x06;		//max addr higth

uint8_t EEMEM eeprombyte5=0x00;		//none
uint8_t EEMEM eeprombyte6=0x00;		//none
uint8_t EEMEM eeprombyte7=0x00;		//none
uint8_t EEMEM eeprombyte8=0x00;		//none

//uint8_t EEMEM eeprombyte9=0x00;		//allomas szam, =< 64
/*
uint8_t EEMEM eeprombyte10=0x00;	//allomas  higth cim:5
uint8_t EEMEM eeprombyte11=0x02;	//allomas low cim.

uint8_t EEMEM eeprombyte12=0x00;	//allomas cim:6
uint8_t EEMEM eeprombyte13=0x06;	//allomas cim.
*/

//2.

//uint8_t EEMEM eeprombyte9=0x28;		//allomas szam:40
uint8_t EEMEM eeprombyte9=64;		//allomas szam:64


uint8_t EEMEM eeprombyte10=0x00;	//allomas h. cim:1
uint8_t EEMEM eeprombyte11=0x01;	//allomas l. cim.

uint8_t EEMEM eeprombyte12=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte13=0x02;	//allomas l. cim.2


uint8_t EEMEM eeprombyte14=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte15=0x03;	//allomas l. cim.3

uint8_t EEMEM eeprombyte16=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte17=0x04;	//allomas l. cim.4

uint8_t EEMEM eeprombyte19=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte20=0x05;	//allomas l. cim.5

uint8_t EEMEM eeprombyte21=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte22=0x06;	//allomas l. cim.6

uint8_t EEMEM eeprombyte23=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte24=0x07;	//allomas l. cim.7

uint8_t EEMEM eeprombyte25=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte26=0x08;	//allomas l. cim.8

uint8_t EEMEM eeprombyte27=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte28=0x09;	//allomas l. cim.9

uint8_t EEMEM eeprombyte29=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte30=0x0a;	//allomas l. cim.10

uint8_t EEMEM eeprombyte31=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte32=0x0b;	//allomas l. cim.11

uint8_t EEMEM eeprombyte33=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte34=0x0c;	//allomas l. cim.12

uint8_t EEMEM eeprombyte35=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte36=0x0d;	//allomas l. cim.13

uint8_t EEMEM eeprombyte37=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte38=0x0e;	//allomas l. cim.14

uint8_t EEMEM eeprombyte39=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte40=0x0f;	//allomas l. cim.15

uint8_t EEMEM eeprombyte41=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte42=0x10;	//allomas l. cim.16

uint8_t EEMEM eeprombyte43=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte44=0x11;	//allomas l. cim.17

uint8_t EEMEM eeprombyte45=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte46=0x12;	//allomas l. cim.18

uint8_t EEMEM eeprombyte47=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte48=0x13;	//allomas l. cim.19

uint8_t EEMEM eeprombyte49=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte50=0x14;	//allomas l. cim.20

uint8_t EEMEM eeprombyte51=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte52=0x15;	//allomas l. cim.21

uint8_t EEMEM eeprombyte53=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte54=0x16;	//allomas l. cim.22

uint8_t EEMEM eeprombyte55=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte56=0x17;	//allomas l. cim.23

uint8_t EEMEM eeprombyte57=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte58=0x18;	//allomas l. cim.24

uint8_t EEMEM eeprombyte59=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte60=0x19;	//allomas l. cim.25

uint8_t EEMEM eeprombyte61=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte62=0x1a;	//allomas l. cim.26

uint8_t EEMEM eeprombyte63=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte64=0x1b;	//allomas l. cim.27

uint8_t EEMEM eeprombyte65=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte66=0x1c;	//allomas l. cim.28

uint8_t EEMEM eeprombyte67=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte68=0x1d;	//allomas l. cim.29

uint8_t EEMEM eeprombyte69=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte70=0x1e;	//allomas l. cim.30

uint8_t EEMEM eeprombyte71=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte72=0x1f;	//allomas l. cim.31

uint8_t EEMEM eeprombyte73=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte74=0x20;	//allomas l. cim.32

uint8_t EEMEM eeprombyte75=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte76=0x21;	//allomas l. cim.33

uint8_t EEMEM eeprombyte77=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte78=0x22;	//allomas l. cim.34

uint8_t EEMEM eeprombyte79=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte80=0x23;	//allomas l. cim.35

uint8_t EEMEM eeprombyte81=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte82=0x24;	//allomas l. cim.36

uint8_t EEMEM eeprombyte83=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte84=0x25;	//allomas l. cim.37

uint8_t EEMEM eeprombyte85=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte86=0x26;	//allomas l. cim.38

uint8_t EEMEM eeprombyte87=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte88=0x27;	//allomas l. cim.39

uint8_t EEMEM eeprombyte89=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte90=0x28;	//allomas l. cim.40

uint8_t EEMEM eeprombyte91=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte92=0x29;	//allomas l. cim.41
//42
uint8_t EEMEM eeprombyte93=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte94=0x2a;	//allomas l. cim.42
//43
uint8_t EEMEM eeprombyte95=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte96=0x2b;	//allomas l. cim.43
//44
uint8_t EEMEM eeprombyte97=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte98=0x2c;	//allomas l. cim.44
//45
uint8_t EEMEM eeprombyte99=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte100=0x2d;	//allomas l. cim.45
//46
uint8_t EEMEM eeprombyte101=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte102=0x2e;	//allomas l. cim.46
//47
uint8_t EEMEM eeprombyte103=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte104=0x2f;	//allomas l. cim.47
//48
uint8_t EEMEM eeprombyte105=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte106=0x30;	//allomas l. cim.48
//49
uint8_t EEMEM eeprombyte107=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte108=0x31;	//allomas l. cim.49
//50
uint8_t EEMEM eeprombyte109=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte110=0x32;	//allomas l. cim.50
//51
uint8_t EEMEM eeprombyte111=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte112=0x33;	//allomas l. cim.51
//52
uint8_t EEMEM eeprombyte113=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte114=0x34;	//allomas l. cim.52
//53
uint8_t EEMEM eeprombyte115=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte116=0x35;	//allomas l. cim.53
//54
uint8_t EEMEM eeprombyte117=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte118=0x36;	//allomas l. cim.54
//55
uint8_t EEMEM eeprombyte119=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte120=0x37;	//allomas l. cim.55
//56
uint8_t EEMEM eeprombyte121=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte122=0x38;	//allomas l. cim.56

uint8_t EEMEM eeprombyte123=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte124=0x39;	//allomas l. cim.57
//58
uint8_t EEMEM eeprombyte125=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte126=0x3a;	//allomas l. cim.58
//59
uint8_t EEMEM eeprombyte127=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte128=0x3b;	//allomas l. cim.59
//60
uint8_t EEMEM eeprombyte129=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte130=0x3c;	//allomas l. cim.60
//61
uint8_t EEMEM eeprombyte131=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte132=0x3d;	//allomas l. cim.61
//62
uint8_t EEMEM eeprombyte133=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte134=0x3e;	//allomas l. cim.62

uint8_t EEMEM eeprombyte135=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte136=0x3f;	//allomas l. cim.63
//64
uint8_t EEMEM eeprombyte137=0x00;	//allomas h. cim:
uint8_t EEMEM eeprombyte138=0x40;	//allomas l. cim.64

uint8_t EEMEM eeprombyte139=0xff;	//allomas cim vege.
uint8_t EEMEM eeprombyte140=0xff;	//allomas cim vege.


/*
//1-so
uint8_t EEMEM eeprombyte9=0x24;		//allomas szam:36

uint8_t EEMEM eeprombyte34=0x01;	//allomas cim:404
uint8_t EEMEM eeprombyte35=0x94;	//allomas cim.

uint8_t EEMEM eeprombyte38=0x01;	//allomas cim:408
uint8_t EEMEM eeprombyte39=0x98;	//allomas cim.

uint8_t EEMEM eeprombyte16=0x01;	//allomas cim:409
uint8_t EEMEM eeprombyte17=0x99;	//allomas cim.

uint8_t EEMEM eeprombyte32=0x01;	//allomas cim:410
uint8_t EEMEM eeprombyte33=0x9a;	//allomas cim.

uint8_t EEMEM eeprombyte28=0x01;	//allomas cim:411
uint8_t EEMEM eeprombyte29=0x9b;	//allomas cim.

uint8_t EEMEM eeprombyte46=0x01;	//allomas cim:412
uint8_t EEMEM eeprombyte47=0x9c;	//allomas cim.

uint8_t EEMEM eeprombyte58=0x01;	//allomas cim:413
uint8_t EEMEM eeprombyte59=0x9d;	//allomas cim.

uint8_t EEMEM eeprombyte22=0x01;	//allomas cim:414
uint8_t EEMEM eeprombyte23=0x9e;	//allomas cim.

uint8_t EEMEM eeprombyte24=0x01;	//allomas cim:415
uint8_t EEMEM eeprombyte25=0x9f;	//allomas cim.

uint8_t EEMEM eeprombyte42=0x01;	//allomas cim:416
uint8_t EEMEM eeprombyte43=0xa0;	//allomas cim.

uint8_t EEMEM eeprombyte62=0x01;	//allomas cim:417
uint8_t EEMEM eeprombyte63=0xa1;	//allomas cim.

uint8_t EEMEM eeprombyte48=0x01;	//allomas cim:418
uint8_t EEMEM eeprombyte49=0xa2;	//allomas cim.

uint8_t EEMEM eeprombyte52=0x01;	//allomas cim:419
uint8_t EEMEM eeprombyte53=0xa3;	//allomas cim.

uint8_t EEMEM eeprombyte56=0x01;	//allomas cim:420
uint8_t EEMEM eeprombyte57=0xa4;	//allomas cim.

uint8_t EEMEM eeprombyte72=0x01;	//allomas cim:421
uint8_t EEMEM eeprombyte73=0xa5;	//allomas cim.

uint8_t EEMEM eeprombyte76=0x01;	//allomas cim:422
uint8_t EEMEM eeprombyte77=0xa6;	//allomas cim.

uint8_t EEMEM eeprombyte70=0x01;	//allomas cim:423
uint8_t EEMEM eeprombyte71=0xa7;	//allomas cim.

uint8_t EEMEM eeprombyte80=0x01;	//allomas cim:424
uint8_t EEMEM eeprombyte81=0xa8;	//allomas cim.

uint8_t EEMEM eeprombyte10=0x01;	//allomas cim:425.
uint8_t EEMEM eeprombyte11=0xa9;	//allomas cim.

uint8_t EEMEM eeprombyte66=0x01;	//allomas cim:426
uint8_t EEMEM eeprombyte67=0xaa;	//allomas cim.

uint8_t EEMEM eeprombyte14=0x01;	//allomas cim:427
uint8_t EEMEM eeprombyte15=0xab;	//allomas cim.

uint8_t EEMEM eeprombyte50=0x01;	//allomas cim:474
uint8_t EEMEM eeprombyte51=0xda;	//allomas cim.

uint8_t EEMEM eeprombyte78=0x01;	//allomas cim:475
uint8_t EEMEM eeprombyte79=0xdb;	//allomas cim.

uint8_t EEMEM eeprombyte40=0x01;	//allomas cim:477
uint8_t EEMEM eeprombyte41=0xdd;	//allomas cim.

uint8_t EEMEM eeprombyte44=0x01;	//allomas cim:478
uint8_t EEMEM eeprombyte45=0xde;	//allomas cim.

uint8_t EEMEM eeprombyte30=0x01;	//allomas cim:479
uint8_t EEMEM eeprombyte31=0xdf;	//allomas cim.

uint8_t EEMEM eeprombyte36=0x01;	//allomas cim:480
uint8_t EEMEM eeprombyte37=0xe0;	//allomas cim.

uint8_t EEMEM eeprombyte18=0x01;	//allomas cim:481
uint8_t EEMEM eeprombyte19=0xe1;	//allomas cim.

uint8_t EEMEM eeprombyte74=0x01;	//allomas cim:482
uint8_t EEMEM eeprombyte75=0xe2;	//allomas cim.

uint8_t EEMEM eeprombyte64=0x01;	//allomas cim:483
uint8_t EEMEM eeprombyte65=0xe3;	//allomas cim.

uint8_t EEMEM eeprombyte68=0x01;	//allomas cim:487
uint8_t EEMEM eeprombyte69=0xe7;	//allomas cim.

uint8_t EEMEM eeprombyte60=0x01;	//allomas cim:488
uint8_t EEMEM eeprombyte61=0xe8;	//allomas cim.

uint8_t EEMEM eeprombyte20=0x01;	//allomas cim:489
uint8_t EEMEM eeprombyte21=0xe9;	//allomas cim.

uint8_t EEMEM eeprombyte26=0x01;	//allomas cim:491
uint8_t EEMEM eeprombyte27=0xeb;	//allomas cim.

uint8_t EEMEM eeprombyte54=0x01;	//allomas cim:492
uint8_t EEMEM eeprombyte55=0xec;	//allomas cim.

uint8_t EEMEM eeprombyte12=0x01;	//allomas cim:493
uint8_t EEMEM eeprombyte13=0xed;	//allomas cim.

uint8_t EEMEM eeprombyte82=0xff;	//allomas cim vege.
*/

extern  unsigned int all_addresses[];
extern  unsigned int hurok_address;

struct _config config;

uint8_t all_addr[COMM_MAX_ADDR*2+10]; // 0.:loop;1.:addr.num.2.- :datas.
uint8_t alladdrnumenable;

const uint8_t eecontent[] =
{ 0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x00, 
  0x02,0x00,0x01,0x00,0x63,0x00,0x9b,0x01,0x18,
  0xff
};

//---------------------------------------------
void config_save(void)
{

}//void config_save(void)

//---------------------------------------------
void config_load(void)
{
#ifdef ALLOMAS_ADDRESS_EE
	uint8_t* 	ee_addr = (uint8_t*)EE_VERSION;
	uint8_t		temp_data1,temp_data2;
	
	// eeprom read part.
	config.ver =  eeprom_read_byte(ee_addr);
	ee_addr++;

//	config.loop =  eeprom_read_byte(ee_addr); //KIVEVE:2013.08.16.
	config.loop = HUROK_LOOP_ADDRESS;
	ee_addr++;
	temp_data1  =  eeprom_read_byte(ee_addr);
	ee_addr++;
	temp_data2  =  eeprom_read_byte(ee_addr);
	config.max_addr = ((uint16_t)temp_data2) * 256 + (uint16_t)temp_data1;
	config.max_addr = ((config.max_addr < 1) || (config.max_addr > MAX_ADDR)) ? MAX_ADDR : config.max_addr; 
#endif	
#ifdef ALLOMAS_ADDRESS_ROM
	config.ver  = HUROK_VERSION;
	config.loop = hurok_address;
	config.max_addr = ALL_ADDRESS_MAX_NUM;
	config.max_addr = ((config.max_addr < 1) || (config.max_addr > MAX_ADDR)) ? MAX_ADDR : config.max_addr; 
#endif
    
}//void config_load(void)

/*******************************************
 * Save default constans.
 *******************************************/

void config_write(uint8_t data_a, uint16_t  addr_a)
{
    uint8_t* 	addr = (uint8_t*)addr_a;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(data_a)); 
    delayms(10); 
}//void config_write(uint8_t data_a, uint8_t  addr)

//-----------------------------------------------------------------
void config_loop_write_addr(uint8_t laddr_a)
{
#ifdef ALLOMAS_ADDRESS_EE
	laddr_a = HUROK_LOOP_ADDRESS; // berakva 2013.08.16.
	if ( laddr_a <= LOOP_MAX_ADDR)
	{
		uint8_t* 	eadr = (uint8_t*)EE_LOOP_NUM;						
		eeprom_write_byte(eadr,laddr_a);
		config.loop = laddr_a;	
	}
#endif
}//void config_write_addr()
/*
//-----------------------------------------------------------------
void config_weekly_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a)
{    
    uint16_t 	addr = (uint16_t)EE_WEEKLY;
     
    config_write(bin2bcd(year_a), addr); 
    eeprom_write_byte((uint8_t*)addr,bin2bcd(day_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(month_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(year_a));
      
    config_load();          
}//void config_weekly_save(void)

//-----------------------------------------------------------------
void config_annual_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a)
{
    uint16_t 	addr = (uint16_t)EE_ANNUAL;

    config_write(bin2bcd(year_a), addr); 
    eeprom_write_byte((uint8_t*)addr,bin2bcd(day_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(month_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(year_a));   
    config_load();            
}//void config_weekly_save(void)

//-----------------------------------------------------------------
void config_pheriph_save(uint8_t mode_a)
{
    config_write(mode_a, EE_PHERIPH);
    config_load();
}//void config_pheriph_save(uint8_t mode_a)

//-----------------------------------------------------------------
void config_loop_type_save(uint8_t mode_a)
{    
    config_write(mode_a, EE_LOOP_TYPE); 
    config_load();
}//void config_pheriph_save(uint8_t mode_a)
*/


//-----------------------------------------------------------------
#ifdef ALLOMAS_ADDRESS_ROM
uint16_t get_all_addresses_len()
{
	uint16_t ii = 0;
	while (all_addresses[ii])
	{
		ii++;
	}
	return ii;
}
#endif

//-----------------------------------------------------------------
void config_a_load_addr()
{
#ifdef ALLOMAS_ADDRESS_EE
	uint8_t* 	eadr = (uint8_t*)EE_A_CHN_NUM;
	uint8_t  	len = eeprom_read_byte(eadr); // len.
	
	all_addr[0] = config.loop;
	if (len && (len <= COMM_MAX_ADDR))
	{
		uint16_t ii;		
		all_addr[1] = len;
		for (ii=2,++eadr; ii<(len*2+2); ii+=2, eadr+=2)
		{
			all_addr[ii]   =  eeprom_read_byte(eadr);
			all_addr[ii+1] =  eeprom_read_byte(eadr+1);
		}
	}
	else
	{
		all_addr[1] = 0;
	}
#endif
#ifdef ALLOMAS_ADDRESS_ROM
	uint16_t ii;
	uint16_t len =  get_all_addresses_len();
	if (len && (len <= COMM_MAX_ADDR))
	{
		all_addr[0] = hurok_address;
		all_addr[1] = len;

		for (ii=0; ii<len; ii++)	
		{			
			all_addr[ii+2] = all_addresses[ii];	
		}
	}
	else
	{
		all_addr[1] = 0;
	}
#endif
}//void config_load_addr()


//-----------------------------------------------------------------
void config_a_write_addr()
{
#ifdef ALLOMAS_ADDRESS_EE
	if ( all_addr[1] <= COMM_MAX_ADDR)
	{
		uint8_t* 	eadr = (uint8_t*)EE_A_CHN_NUM;
		uint8_t ii;	
					
		eeprom_write_byte(eadr,all_addr[1]);
		if (!all_addr[1])
			return;
		for (ii=2,++eadr; ii<(all_addr[1]*2+2); ii+=2, eadr+=2)
		{
			eeprom_write_byte(eadr,all_addr[ii]);
			delayms(5);
			eeprom_write_byte(eadr+1,all_addr[ii+1]);
		}
	}
#endif
}//void config_write_addr()

//-----------------------------------------------------------------
void config_add_new_addr(uint8_t new_addrh, uint8_t new_addrl)
{
#ifdef ALLOMAS_ADDRESS_EE
	uint8_t* 	addr = (uint8_t*)EE_A_CHN_NUM;
	uint8_t  	temp = eeprom_read_byte(addr);
	uint16_t	_addr;

	if (temp && (temp <= COMM_MAX_ADDR))
	{
		_addr = EE_A_CHN_BEGIN + temp*2;
		++temp;							
	}
	else
	{
		temp = 1;
		_addr = EE_A_CHN_BEGIN;

	}
	eeprom_write_byte((uint8_t*)_addr,new_addrh);				
	delayms(5);
	_addr++;
	eeprom_write_byte((uint8_t*)_addr,new_addrl);
	delayms(5);
	eeprom_write_byte((uint8_t*)addr,temp);
	delayms(10);
	a_channels_data_write(temp-1, 0x07);
	delayms(10);
#endif

}//void config_add_new_addr(uint8_t new_addr)


//-----------------------------------------------------------------
void config_remove_alladdr(void)
{
#ifdef ALLOMAS_ADDRESS_EE
		uint8_t* 	addr = (uint8_t*)EE_A_CHN_NUM;
		uint8_t  	temp = eeprom_read_byte(addr);
		uint8_t     ii =0;

		if (temp && (temp <= COMM_MAX_ADDR))
		{
			for (addr=(uint8_t*)EE_A_CHN_BEGIN; ii<(temp*2+1); ii++, addr++)
			{
				eeprom_write_byte(addr,0);				
				delayms(5);
			}
		}
		
		delayms(5);
		eeprom_write_byte((uint8_t*)EE_A_CHN_NUM,0);				
	all_addr[0] = config.loop;
	all_addr[1] = 0;
#endif
	//	PutString("Remove");
//	alladdrnumenable = 0;
}//void config_add_new_addr(void)

//-----------------------------------------------------------------
uint8_t config_remove_1_addr(/*uint8_t loop,*/ uint8_t addrh, uint8_t addrl)
{
#ifdef ALLOMAS_ADDRESS_EE
	uint8_t 	ii;
//	char	msg[20];
	
	if (/*(loop <= 0 ) || (loop > COMM_MAX_LOOP) || */(!addrl && !addrh) || ((((int)addrh)*256+(int)addrl) > config.max_addr))		
			return 0;

	
//	if ((all_addr[0] <= 0) || (all_addr[0] > COMM_MAX_LOOP) || (all_addr[0] != loop) )
//		return 0;


	if ((all_addr[1] <= 0) || (all_addr[1] > COMM_MAX_ADDR))
		return 0;


	//	if (loop != 1)
	//		return 0;

	for (ii=2; ii<(all_addr[1]*2+2); ii+=2)
	{			

		if ((all_addr[ii] == addrh) && (all_addr[ii+1] == addrl))
			break;
	}

	if (ii == (all_addr[1]*2+2))
		return 0;

	// megvan!
	all_addr[ii] = 0xff;

	for (; ii<(all_addr[1]*2+2); ii+=2)
	{
		 all_addr[ii]   = all_addr[ii+2];
		 all_addr[ii+1] = all_addr[ii+3];
	}

	all_addr[1]--;

	config_a_write_addr();
#endif
	return 1;

}//void config_remove_1_addr(uint8_t loop, uint8_t addr)

//-----------------------------------------------------------------
uint8_t search_alladdr(uint8_t addrh, uint8_t addrl)
{
	if ((!addrl && !addrh) || ((((int)addrh)*256+(int)addrl) > config.max_addr))		
			return 0;
#ifdef ALLOMAS_ADDRESS_EE
	uint8_t* 	eadr = (uint8_t*)EE_A_CHN_NUM;
	uint8_t  	len = eeprom_read_byte(eadr); // len.
	uint8_t		e_addrh,e_addrl;
	

	if (len && (len <= COMM_MAX_ADDR))
	{
		uint8_t ii;		
		all_addr[1] = len;
		for (ii=2,++eadr; ii<(len*2+2); ii+=2, eadr+=2)
		{
			e_addrh   =  eeprom_read_byte(eadr);
			e_addrl   =  eeprom_read_byte(eadr+1);
			if ((e_addrh == addrh) && (e_addrl == addrl))
				return 1;
		}
	}
#endif
#ifdef ALLOMAS_ADDRESS_ROM
	int ii;
	unsigned int addr = ((unsigned int)addrh)*256+(unsigned int)addrl;

	config_load();
	uint16_t len =  get_all_addresses_len();
	if (len && (len <= COMM_MAX_ADDR))
	{
		all_addr[0] = hurok_address;
		all_addr[1] = len;

		for (ii=0; ii<len; ii++)	
		{			
			if (all_addresses[ii] == addr)
				return 1;	
		}
	}
#endif
	return 0;
}

/*******************************************
 * Factory default constans.
 *******************************************/
void eecontentwrite(void)
{
	uint8_t* 	ver = (uint8_t*)EE_VERSION;
	uint8_t	 	index = 0;
	uint8_t  	temp = eeprom_read_byte(ver);

	if (temp == 0)
		return;
	while(eecontent[index] != 0xff)
	{
			eeprom_write_byte((uint8_t*)ver,eecontent[index]);	
			++index;		
			++ver;
			delayms(10);
	}
}//void eecontentwrite(void)


/*******************************************
 * Cannels part.
 *******************************************/
 uint8_t a_channels_data_load(uint8_t index)
 { 	
	uint8_t* addr = (uint8_t*)EE_A_CHN_DATA_BEGIN;	
	return eeprom_read_byte(addr+2*index);
 }

//-----------------------------------------
 void a_channels_data_write(uint8_t index, uint8_t data)
 { 
	uint8_t* addr = (uint8_t*)EE_A_CHN_DATA_BEGIN;	
	eeprom_write_byte(addr+2*index, data);
	delayms(10);
 }

//-----------------------------------------
void a_channels_load(CHANNELtype* chn)
{
	
	uint8_t		ii=1;
	uint8_t     data;

#ifdef ALLOMAS_ADDRESS_EE
	uint8_t* 	addr ;
	uint8_t  	templ, temph;

	addr = (uint8_t*)EE_A_CHN_NUM;	
	templ = eeprom_read_byte(addr);
//	templ = eeprom_read_byte(addr+1);

	if (templ  && (templ < COMM_MAX_ADDR) )
		alladdrnumenable = templ;
	else
		alladdrnumenable = 0;
#endif		
#ifdef ALLOMAS_ADDRESS_ROM
	uint16_t len =  get_all_addresses_len();
	if (len && (len <= COMM_MAX_ADDR))		
		alladdrnumenable = len;
	else
		alladdrnumenable = 0;
#endif


	chn[0].addrh = 0;
	chn[0].addrl = 0;
	chn[0].cmd = 0;
	chn[0].data = 0;
	chn[0].error = 0;
	chn[0].prev_error = 0;
//	chn[0].prev_data = 0;
//	chn[0].errornum = 0;
	all_ask_index = 0;

	if (!alladdrnumenable)
		return;
#ifdef ALLOMAS_ADDRESS_EE	
	++addr;
//	char msg[60];
	for (addr=(uint8_t*)EE_A_CHN_BEGIN; ii<(alladdrnumenable+1); ii++, addr+=2)
	{
		temph = eeprom_read_byte(addr);
		templ = eeprom_read_byte(addr+1);		
		if ( ((((int)temph)*256+(int)templ) > 0) && ((((int)temph)*256+(int)templ) < config.max_addr) )
		{
			chn[ii].addrh = temph;	
			chn[ii].addrl = templ;
		}
		else
		{
			chn[ii].addrl = 0;
			chn[ii].addrh = 0;
		}

		chn[ii].id = ii;
		chn[ii].cmd = 0;	
		chn[ii].error = 0;
		chn[ii].prev_error = 0;

		data = a_channels_data_load(ii-1);
		chn[ii].data = data & 0x07;	
		chn[ii].prev_data = data & 0x07;
	//	chn[ii].data = 0x07;	
	//	chn[ii].prev_data = 0x07;
//		chn[ii].errornum = 0x20;
	//	sprintf(msg,"load:%x,ii:%x,addr:%x,%x",alladdrnumenable,ii,chn[ii].addrl,chn[ii].addrh);
	//	PutString(msg);	
	}
#endif
#ifdef ALLOMAS_ADDRESS_ROM
	config_load();
	for (ii=0; ii<alladdrnumenable; ii++)	
	{			
		if (all_addresses[ii] < config.max_addr)
		{
			chn[ii+1].addrh = all_addresses[ii] / 256;	
			chn[ii+1].addrl = all_addresses[ii] % 256;
		}
		else
		{
			chn[ii+1].addrl = 0;
			chn[ii+1].addrh = 0;
		}
		chn[ii+1].id = ii+1;
		chn[ii+1].cmd = 0;	
		chn[ii+1].error = 0;
		chn[ii+1].prev_error = 0;

		data = a_channels_data_load(ii);
		chn[ii+1].data = data & 0x07;	
		chn[ii+1].prev_data = data & 0x07;
	}
#endif
	all_ask_index = 0;	
	//alladdrnumenable++;
}//void l1channels_load(CHANNELtype* chn)

/*******************************************/
/*void lmchannels_load(LOOPtype* ll)
{
	uint8_t* 	addr = (uint8_t*)EE_LOOP_NUM;
	uint8_t		ii=1;
	uint8_t  	temp = eeprom_read_byte(addr);

	if (temp && (temp <= COMM_MAX_LOOP))
		allloopnumenable = temp;
	else
		allloopnumenable = 0;
			
	for (ii=0; ii<allloopnumenable; ii++)
	{
		ll[ii].loop = ii + 1;
		ll[ii].chn.addr = 0;
		ll[ii].chn.cmd = 0;
		ll[ii].chn.data = 0;
		ll[ii].chn.prev_data = 0;
	}

	loop_ask_index = 0;

}//void lmchannels_load(CHANNELtype* chn)
*/
//---------------------------------------------------
void a_channels_add(CHANNELtype* chn, uint8_t new_addrh, uint8_t new_addrl)
{	
	if (alladdrnumenable < COMM_MAX_ADDR)
	 	++alladdrnumenable;
	else
		alladdrnumenable = COMM_MAX_ADDR;

	chn[alladdrnumenable].addrh = new_addrh;
	chn[alladdrnumenable].addrl = new_addrl;
	chn[alladdrnumenable].cmd = 0;
	chn[alladdrnumenable].data = 0x07;	
	chn[alladdrnumenable].prev_data = 0x07;
	chn[alladdrnumenable].error = 0;
	chn[alladdrnumenable].prev_error = 0;

}//void l1channels_add(CHANNELtype* chn)



