#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include  "HConfig.h"
#include  "HAloop.h"
#include  "HKLoop.h"
#include  "utils.h"
#include  "HAllomas.h"

#if VERSION == 3

/****************************
 * Functions, subrtutins part
 ***************************/



/********************
 * Init
 ********************/
void allomas_ini()
{
	int ii;
	for (ii=1;ii<COMM_MAX_ADDR;ii++)
	{
		all_array[ii].a_data = 0xff;	
		all_array[ii].a_error = 0xff;
		all_array[ii].k_data = 0xff;
		all_array[ii].k_error = 0xff;
	}
}

//----------------------
static uint8_t search_addr_to_index(uint8_t addrh_a,uint8_t addrl_a)
{
	if (all_addr[1])
	{
		uint8_t ii;	
		for (ii=0;ii<all_addr[1];ii++)
		{ 
		//	uint8_t_CopyTo_uint16_t(&all_addr[2+ii*2], &addr_l);
			if ((all_addr[2+ii*2] == addrh_a) && (all_addr[3+ii*2] == addrl_a))
				return ii;		
		}
	}
	return 255;	
}

//----------------------
uint8_t set_datas_st(uint8_t addrh_a,uint8_t addrl_a, uint8_t data_a, uint8_t error_a, uint8_t type_a)
{
	uint8_t aindex_l = search_addr_to_index(addrh_a, addrl_a);
	if (aindex_l == 255)
		return 1; //error
	
	if (type_a == 1)
	{ // allomas
		if (data_a != 0x80)
			all_array[aindex_l].a_data 	= data_a;
		if (error_a != 0x80)
			all_array[aindex_l].a_error 	= error_a;
	}
	else
	{ //kozpont
		if (data_a != 0x80)
			all_array[aindex_l].k_data 	= data_a;
		if (error_a != 0x80)
			all_array[aindex_l].k_error 	= error_a;
	}

	return 0;
}

//----------------------
uint8_t get_datas_st(uint8_t addrh_a,uint8_t addrl_a, uint8_t* data_a, uint8_t* error_a, uint8_t type_a )
{
	if (data_a && error_a)
	{
		uint8_t aindex_l = search_addr_to_index(addrh_a, addrl_a);
		if (aindex_l == 255)
			return 1; //error
		if (type_a == 1)
		{ // allomas
			*data_a = all_array[aindex_l].a_data;
			*error_a = all_array[aindex_l].a_error;
		}
		else
		{ //kozpont
			*data_a = all_array[aindex_l].k_data;
			*error_a = all_array[aindex_l].k_error;
		}
	}
	return 0;
}

/********************
 * indexet ad visza a kozponti kuldesnek, ha kulonbotik az allamos es a kozpont altal visszakuldott adat
 ********************/
int k_get_allomas_sender_index()
{
	int ii;
	for (ii=1; ii<=alladdrnumenable; ii++)
	{ 
		if ((all_array[ii].addrl == 0) && (all_array[ii].addrh == 0))
			continue;
		if ((all_array[ii].a_data == 0xff) &&  (all_array[ii].a_error == 0xff))
			continue;
		if ((all_array[ii].a_data =! all_array[ii].k_data) ||  (all_array[ii].a_error =! all_array[ii].k_error))		
			return ii;		
	}
	return -1;
}
#endif
