#ifndef  LDEF_H
#define  LDEF_H

#define OUTPUT_PIN      0x0	
#define INPUT_PIN       0x1	
#define OUTPUT_DATA     0x0	
#define INPUT_DATA      0xFF

/*
// status bits
#define RX				0x1
#define RX_READY		0x2
#define RX_INT			0x4
#define TX				0x8
#define TX_INT			0x10
#define TX_READY 		0x20
#define TX_KOZP_ASK		0x40
#define RX_SEARCH_ADDRESS_BAD 0x80*/

//#define RX_TMOUT		0x80


#define CLR_STATUS(x)		{_CLI(); status &= (~x); _SEI();};
#define SET_STATUS(x)		{status |= (x);};
#define CHK_STATUS(x)		(status & (x))

/*
#define CLR_IMP(x)		{imp_flg &= (~x);}
#define SET_IMP(x)		{imp_flg |= (x);}
#define CHK_IMP(x)		(imp_flg & (x))
*/
// sys_status

#define NO_MER			0x4
#define CLEAR			0x80
//#define REST			0x80
#define PC_TEST			0x40

#define CLR_SYS(x)		(sys_status &= (~x)); 
#define SET_SYS(x)		(sys_status |= (x));
#define CHK_SYS(x)		(sys_status & (x))
	
// error
#define FRAME_ERROR			0x0001
#define CMD_ERROR			0x0002
#define ADDR_ERROR			0x0004
#define CHS_ERROR			0x0008
#define RX_ERROR			0x0010
#define TX_ERROR			0x0020


#define CLR_ERROR(x)		global_error &= (~x);
#define SET_ERROR(x)		global_error |= (x);
#define CHK_ERROR(x)   		(global_error & (x))


#define TMR_1S				0xb1df  //1sec
#define TMR_250MS			0xec77	// 250ms
#define TMR_20MS			0xcf2b	// 20ms
#define TMR_2MS				0xd8ef	// 2ms 1:1
//#define TMR0_1S				0xe000

#define EE_DATA				9
#define	ELM_LENGTH			1830

/*
#define EE_VERSION			0
#define EE_LOOP_ADDRESS		1
#define EE_ALL_TYPE			2		// ha 1, akkor 32 allomas (64 cim),2 akkor 64 allomas (128 cim).
#define EE_ALL_CURR_NUM		3		// jelenlegi allomas szam.
#define EE_ALL_CURR_BEGIN	EE_ALL_CURR_NUM+1
#define EE_ALL_CURR_END		EE_ALL_CURR_BEGIN+256
*/



#define bit_is_set_in_var(var, bit)		var = var | (1 << bit);
#define bit_is_clear_in_var(var, bit) 	var = var & (1 << bit);

#endif
