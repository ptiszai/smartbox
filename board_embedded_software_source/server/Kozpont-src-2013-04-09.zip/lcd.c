#include <math.h>
#include <stdio.h>

#include "macros.h"
#include "sed1335.h"
#include "lcd.h"
#include "KCom.h"
#include "Fonts.h"



/* globals */
volatile uint16_t app_position=0;       /**< current append position */
/* globals */
//volatile uint8_t *grbuffer=((uint8_t *)(GR_OFFSET));
//volatile uint16_t stack[STACKSIZE*2];           /* stack for floodfill */
//olatile uint16_t stackpointer=0;

uint16_t draw_area_x1=0, draw_area_x2=GR_WIDTH;
uint16_t draw_area_y1=0, draw_area_y2=GR_HEIGHT;


/**
* \brief write out a complete screen-page
*
* All other chars on the screen will be cleared
* returns FALSE on error
*
* \param buffer text to write out
* \param len length of text
*/
/*
uint8_t text_screen(char *buffer, uint16_t len)
{
	int i;
 
	if (len>TEXTSIZE)
		return FALSE;

	sed1335_set_address(sed1335_get_txcur(0));      // start of text-layer 
	sed1335_set_cur_dir(CSRDIR_R);
	app_position=sed1335_text_write(buffer, len, sed1335_get_txcur(0));

	// clear rest of screen 
	for (i=len; i<TEXTSIZE; i++)
		sed1335_data(0x00);

	return TRUE;
}*/

/**
* \brief write out text, overwriting text at the current position
*
* \param buffer text to write out
* \param len length of text
*/
/*
uint8_t text_overwrite(char *buffer, uint16_t len)
{
	if (len>TEXTSIZE)
		return FALSE;
 	
	sed1335_set_address(sed1335_get_txcur(0));
	sed1335_set_cur_dir(CSRDIR_R);
	app_position=sed1335_text_write(buffer, len, sed1335_get_txcur(0));
 	
	return TRUE;
}*/
 	
/**
* \brief append text at the current position
*
* append text at position app_position (can beset with text_set_pos)
* text_append() also increments app_position (caused by special-chars)
*
* \param buffer text to write out
* \param len legth of text
*/
uint8_t text_append(char *buffer, uint16_t len)
{
	uint16_t bytes_written=0;
 	       
	/* (maybe FIXME: start at beginning if we reached end of text-area ?) */
	if ((app_position+len)>TEXTSIZE)
		return FALSE;
 	       
	sed1335_set_address(sed1335_get_txcur(app_position));
	/* sed1335_set_cur_dir(CSRDIR_R); */
	bytes_written=sed1335_text_write(buffer, len, sed1335_get_txcur(app_position));
	       
	/* inrement append_position (includes whitespace characters inserted for special-chars) */
	app_position+=bytes_written;
 	
	return TRUE;
}
	
/**
* \brief set position to append text at
*
* (this works only for append mode)
*
* \param x column
* \param y line
*/
uint8_t text_set_pos(uint16_t x, uint16_t y)
{
	if (y>(LINES))
		return FALSE;
	
	if (x>((APH<<8) | APL))
		return FALSE;
 	
	app_position=((y*((APH<<8) | APL)) + x);
 	
	return TRUE;
}

//----------------------------------------------------------------
//kurzor az lcd_x, lcd_y pozicioba a karakteres layeren.
void txt_set_cursor(uint16_t Pix_x_a,uint16_t Pix_y_a)
{
    uint16_t Pix_addr;
 
   Pix_y_a *= 54;
   Pix_addr = Pix_y_a + Pix_x_a;
   sed1335_set_address(Pix_addr) ;
}//void Karakter_xy(void) 

	
/**
* \brief put coordinates on stack
*
* put coordinates on stack, return false if stack is full
* this stack implementation is used for the floodfill implementation
*
* \param x x coordinate
* \param y y coordinate
*/
/*
uint8_t ff_push(uint16_t x, uint16_t y)
{
	if ((stackpointer+2) > (STACKSIZE*2))
		return FALSE;

	// first push x, then y on the stack 
	 stack[stackpointer++]=x;
	 stack[stackpointer++]=y;
 
	 return TRUE;
}*/

/**
* \brief pop coordinates from stack
*
* pop coordinates from stack, return FALSE if stack is empty
* this stack implementation ios used for the floodfill implementation
* \param x pointer to write the x coordinate to
* \param y pointer to write the y coordinate to
*/
/*
uint8_t ff_pop(uint16_t *x, uint16_t *y)
{
 	if (stackpointer<2)
		return FALSE;
	
	*y=stack[--stackpointer];
	*x=stack[--stackpointer];
	
	return TRUE;
}*/
 	
/**
* \brief clear the floodfill stack
*/
/*
void ff_clear_stack()
{
	stackpointer=0;
}*/
	 	
/**
* \brief round to ceiling and return an unsigned uint16
*
* \param d double value to round
*/

uint16_t gr_round(double d)
{
	return ((uint16_t) ceil(d));
}
	
/**
* \brief clear graphic screen buffer
*/
void gr_clear()
{
	uint16_t i;
	uint8_t *p=((uint8_t *)(GR_OFFSET));
 	       
	for (i=0; i<GR_SIZE; i++)
		*p++=0x00;
}
 	
/**
* \brief write graphic buffer to display
 */
/*
void gr_write_all()
{
	sed1335_set_address(sed1335_get_grcur(0));      // start of graphic-layer 
	sed1335_set_cur_dir(CSRDIR_R);
	       
	sed1335_mem_write((uint8_t *)grbuffer, GR_SIZE , sed1335_get_grcur(0));
}
*/
/**
* \brief write graphic buffer to display
 */
void gr_write(uint16_t position, uint8_t byte)
{
	sed1335_set_address(position + sed1335_get_grcur(0));      /* start of graphic-layer */
	sed1335_set_cur_dir(CSRDIR_R);
	sed1335_single_byte(byte);       	
}
	
/**
* \brief specify allowed drawing area
*
* This function can be used to specify a drawing area (rectangle) which limits any graphic operation
* to reside inside the specified area.
* returns TRUE if the area is within the display
*
* \param x1 x coordinate of the upper left corner
* \param y1 y coordinate of the upper left corner
* \param x2 x coordinate of the lower right corner
* \param y2 y coordinate of the lower right corner
*/
/*
uint8_t gr_set_draw_area(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
	if (!in_x_range(x1) || !in_y_range(y1)) return FALSE;
	if (!in_x_range(x2) || !in_y_range(y2)) return FALSE;
	

 	
	draw_area_x1=min(x1,x2);
	draw_area_x2=max(x1,x2);
	draw_area_y1=min(y1,y2);
	draw_area_y2=max(y1,y2);
 	
	return TRUE;
}*/
 	
/**
* \brief determine if a position is inside the drawing area
*
* returns TRUE if the position is inside the area
* \param x x coordinate
* \param y y coordiif a position is inside the drawing area
*
* returns TRUE if the position is inside the area
* \param x x coordinate
* \param y y coordinate
*/
uint8_t gr_in_draw_area(uint16_t x, uint16_t y)
{
	if ((x>=draw_area_x1) && (x<=draw_area_x2))
	if ((y>=draw_area_y1) && (y<=draw_area_y2))
		return TRUE;
	
	return FALSE;
}
	
/**
* \brief set a pixel, return FALSE on error
*
* \param x x coordinate
* \param y y coordiante
*/
uint8_t gr_setpixel(uint16_t x, uint16_t y)
{
	uint16_t position = 0;
	static uint16_t prev_position = 0;
	static uint8_t pixel = 0;
 	

	if (!in_x_range(x) || !in_y_range(y)) 
	{
	
		return FALSE;
	}
 	

	if (!gr_in_draw_area(x,y))
		return TRUE;    
 	
	
	position = y * /*((uint16_t)(GR_WIDTH >> 3))*/53 + ((uint16_t)(x / 6));

	if (position != prev_position)
		pixel = 0;

	prev_position = position;

	sed1335_set_address(position + sed1335_get_grcur(0));

//	pixel = sed1335_read_byte();
//	char msg[50];
//	sprintf(msg,"gr_setpixel1: 0x%x",pixel);
//	PutString(msg);
	 	
//	if (gr_bit_is_clear(pixel, (0x80 >>(x%6)) ) )
//	{
		/* set the bit */
		pixel |= (0x80 >> (x%6));
//	}
//	sprintf(msg,"gr_setpixel2: 0x%x",pixel);
//	PutString(msg);
	gr_write(position,pixel);
	return TRUE;
}
	
/**
* \brief clear a pixel, return FALSE on error
*
* \param x x coordinate
* \param y y coordiante
*/
/*
uint8_t gr_clearpixel(uint16_t x, uint16_t y)
{
	uint16_t position = 0;
	uint8_t pixel;
	
	// if (!in_x_range(x) || !in_y_range(y)) return FALSE; 
	if (!gr_in_draw_area(x,y))
		return FALSE;
	
	// determine memory position 
	position = y * ((uint16_t)(GR_WIDTH >> 3)) + ((uint16_t)(x >> 3));

	sed1335_set_address(position + sed1335_get_grcur(0));

	pixel = sed1335_read_byte();
 	
	if (!gr_bit_is_clear(pixel, (0x80 >>(x%6)) ) )
	{
		// unset the bit 
		pixel &= ~((uint8_t) (0x80 >> (x%6)));
	}
	gr_write(position,pixel); 	
	return TRUE;
}*/
 	
/**
* \brief draw line, return FALSE on error
*
* \param x1 x coordinate to start from
* \param y1 y coordinate to start from
* \param x2 x coordiante to draw to
* \param y2 y coordinate to draw to
*/
uint8_t gr_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
//return 1;
	int dx,dy;
	double m,b=0;
	uint16_t i;
 	
	dx = x1 - x2;
	dy = y1 - y2;
	
	if (dy == 0)
	{
		for (i=min(x1,x2); i<=(max(x1,x2)); i++)
			if (!gr_setpixel(i,y1))
				return FALSE;
	}
 	else 
	if (dx == 0)
	{
		for(i=min(y1,y2); i<=(max(y1,y2)); i++)
			if (!gr_setpixel(x1,i))
				return FALSE;
	}
 	else
	{
		m = ((double)dy/(double)dx);
		b = y1 - m*x1;
		if (fabs(dy)<=fabs(dx))
		{
			for (i=(min(x1,x2)); i<=(max(x1,x2)); i++)
				if (!gr_setpixel(i,gr_round(m*i+b)))
					return FALSE;
		}
		else
		{
			for (i=(min(y1,y2)); i<=(max(y1,y2)); i++)
				if (!gr_setpixel(gr_round((i-b)/m),i))
					return FALSE;
		}
	}	
	return TRUE;
}
 	
 	
/**
* \brief draw a circle, return FALSE on error
*
* \param xc x coordinate of the circle center
* \param yc y coordinate of the circle center
* \param r rarius
*
* This function is a wrapper function for gr_ellipse()
*/
/*
uint8_t gr_circle(uint16_t xc, uint16_t yc, uint16_t r)
{
	return gr_ellipse(xc, yc, r, r);
 */	
	/* uncomment for an alternative circle drawing algorithm */

/*
	uint16_t x=0;
	uint8_t err=0;
	double root;
 	
	while (x<=sqrt(r*r-x*x))  
	{
		root=sqrt(r*r-x*x);
		err+= gr_setpixel(gr_round(xc+root),yc+x);
		err+= gr_setpixel(gr_round(xc+root),yc-x);
		err+= gr_setpixel(gr_round(xc-root),yc+x);
		err+= gr_setpixel(gr_round(xc-root),yc-x);
	        
		err+= gr_setpixel(xc+x, gr_round(yc+root));
		err+= gr_setpixel(xc-x, gr_round(yc+root));
		err+= gr_setpixel(xc+x, gr_round(yc-root));
		err+= gr_setpixel(xc-x, gr_round(yc-root));
	        
		x++;
	}
	        
	if (err!=8)
		return FALSE;
 	        
		return TRUE;
*/
//}
	
	
/* uncomment for an alternative ellipse drawing algorithm */
	
/*
* \brief draw an ellipse, return FALSE on error
*
* \param xc x coordinate of the ellipse center
* \param yc y coordinate of teh ellipse center
* \param xr x radius
* \param yr y radius
*/
/* uint8_t gr_ellipse(uint16_t xc, uint16_t yc, uint16_t xr, uint16_t yr)
{
	#define ELL_ITERATIONS 300
 	
	double theta;
	uint16_t i;
	uint16_t x,y;
 	
	x=xc+xr;
	y=yc;
	
	for (i=0; i< ELL_ITERATIONS; i++)
	{
		theta = 2*M_PI*i/ELL_ITERATIONS;
		if (!gr_line(x,y,gr_round(xc+xr*cos(theta)), gr_round(yc+yr*sin(theta))))
			return FALSE;
	                
		gr_line(x,y,gr_round(xc+xr*cos(theta)), gr_round(yc+yr*sin(theta)));
 	
		x = gr_round(xc+xr*cos(theta));
		y = gr_round(yc+yr*sin(theta));
	}
 	
	return TRUE;
}
*/
/**
* \brief draw an ellipse, return FALSE on error
*
* \param xc x coordinate of the ellipse center
* \param yc y coordinate of teh ellipse center
* \param xr x radius
* \param yr y radius
*
* fast ellipse algorithm
*/
/*
uint8_t gr_ellipse(uint16_t xc, uint16_t yc, uint16_t xr, uint16_t yr)
{
	int16_t x, cx1, cx2, cy1, cy2;
	int32_t aq, bq, dx, dy, r, rx, ry;
	
	gr_setpixel(xc + xr, yc);
	gr_setpixel(xc - xr, yc);
	
	cx1 = xc - xr;
	cy1 = yc;
	
	cx2 = xc + xr;
	cy2 = yc;
 	
	// calc sqr 
	aq = xr * xr;
	bq = yr * yr;
 	
	// dx = 2 * a^2
	dx = (aq << 1);
	
	// dy = 2* b^2 
	dy = (bq << 1);
	
	// r = a * b^2 
	r = xr * bq;
	
	// rx = 2 * a * b^2 
	rx = (r << 1);
 	
	ry = 0;
	x = xr;

	while (x > 0)
	{
		if (r > 0)
		{
			cy1++;
			cy2--;
			ry += dx;
			r -= ry;
		}
	if (r <= 0)
	{
		x--;
		cx1++;
		cx2--;
		rx-=dy;
		r+=rx;
	}
 	
	gr_setpixel((uint16_t) cx1, (uint16_t) cy1);
	gr_setpixel((uint16_t) cx1, (uint16_t) cy2);
	gr_setpixel((uint16_t) cx2, (uint16_t) cy1);
	gr_setpixel((uint16_t) cx2, (uint16_t) cy2);
	} 	
	return TRUE;
}
*/	
	
/**
* \brief draw a rectangle, return FALSE on error
*
* \param x1 x coordinate to start at
* \param y1 y coordinate to start at
* \param x2 x coordinate to end at
* \param y2 y coordinate to end at
*/
uint8_t gr_rectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
	if (!gr_line(x1,y1,x2,y1))
		return FALSE;
 	
	if (!gr_line(x2,y1,x2,y2))
		return FALSE;
 	
	if (!gr_line(x2,y2,x1,y2))
		return FALSE;
 	
	if (!gr_line(x1,y2,x1,y1))
		return FALSE;
 	
	return TRUE;
}
 	
	
/**
* \brief determine if a pixel in the graphic buffer is set, return TRUE if pixel is set
*
* \param x x coordinate
* \param y y coordinate
*/

/*
uint8_t gr_getpixel(uint16_t x, uint16_t y)
{
	uint16_t position=0;
 	
	if (!in_x_range(x) || !in_y_range(y))
		return FALSE;
 	
	// determine memory position 
	position = y * ((uint16_t)(GR_WIDTH >> 3)) + ((uint16_t)(x >> 3));
	if (gr_bit_is_clear(*(grbuffer+position), (0x80 >>(x%8)) ) )
	{
		return FALSE;
	}
	
	return TRUE;
}*/
 	
 	
/**
* \brief floodfill a graphic object, scanline algorithm with own stack, return FALSE on error
*
* \param x x coordinate
* \param y y coordinate
*/
/*
uint8_t gr_fill(uint16_t x, uint16_t y)
{
	int16_t y1 = 0;
	uint16_t tx = x,ty=y;
	uint8_t left,right;
 	       
	// if (!in_x_range(x) || !in_y_range(y)) 
	if (!gr_in_draw_area(x,y))
		return FALSE;
 	       
	ff_clear_stack();
 	       
	if(!ff_push(tx, ty))
		return FALSE;
 	       
	while (ff_pop(&tx,&ty))
	{
		y1 = ty;
	               
	// move up until we find the border 
		while ((gr_getpixel(tx,y1) == FALSE) && y1>=0)
			y1--;
 	
		y1++;
		left = right=FALSE;
	
	// move down 
		while ((gr_getpixel(tx,y1) == FALSE) && (y1<GR_HEIGHT))
		{
			gr_setpixel(tx,y1);
 	
		// move left 
			if (left==FALSE && tx>0 && gr_getpixel(tx-1, y1) == FALSE)
			{
				if (!ff_push(tx-1, y1))
					return FALSE;
				left = TRUE;
			}
		// stop if there's a border 
			else 
			if (left==TRUE && tx>0 && gr_getpixel(tx-1,y1) == TRUE)
			{
				left = FALSE;
			}
 	
		// move right 
			if (right==FALSE && tx<(GR_WIDTH-1) && gr_getpixel(tx+1,y1) == FALSE)
			{
				if (!ff_push(tx+1,y1))
					return FALSE;
				right = TRUE;
			}
		// stop if there's a border 
			else 
			if (right==TRUE && tx<(GR_WIDTH-1) && gr_getpixel(tx+1,y1) == TRUE)
			{
				right = FALSE;
			} 	
			y1++;
		}
	}
	return TRUE;
}*/
/**
* \brief clear a rectangular area
*
* return FALSE on error
* \param x1 x coordinate of the upper left corner
* \param y1 y coordinate of the upper left corner
* \param x2 x coordinate of the lower right corner
* \param y2 y coordinate of the lower right corner
*/
/*
uint8_t gr_clear_area(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{       
	uint16_t i,j;
	uint16_t _x1, _x2;
	uint16_t _y1, _y2;
	uint16_t position=0;
	uint16_t x_pos_written;
 	
	if (!in_x_range(x1) || !in_y_range(y1)) return FALSE;
	if (!in_x_range(x2) || !in_y_range(y2)) return FALSE;
 	
		_x1 = min(x1,x2);
		_x2 = max(x1,x2);
		_y1 = min(y1,y2);
		_y2 = max(y1,y2);
 	
		for (i=_y1; i<=_y2; i++)
		{
			x_pos_written = _x1;
 	
			// first bytes 
			if ((_x1 < 8) && (_x2>8))
			{
				for (j=_x1; j<8; j++)
					gr_clearpixel(j,i);
				x_pos_written=8;
			}
 	
			for (j=x_pos_written; (j+8)<=_x2; j+=8)
			{
				// determine memory position
				position = i * ((uint16_t)(GR_WIDTH >> 3)) + ((uint16_t)(j >> 3));
	
				// unset a byte block
				(*(grbuffer+position)) = 0x00;
 	
				x_pos_written += 8;
			}
 	
			// if some pixels are left, clear them 
			if (x_pos_written < _x2)
			{
				for (j=x_pos_written; j<=_x2; j++)
					gr_clearpixel(j,i);
			}
		} 	
	return TRUE;
}*/

//----------------------------------------------------------------
// kurzor az lcd_x, lcd_y karakter pozicioba a grafikus layeren.
void gr_set_cursor(uint16_t Pix_x_a,uint16_t Pix_y_a)                                        
{
   uint16_t Pix_addr, start;
 //   uint8_t Lcd_addr_lo,Lcd_addr_hi;
 //  Pix_x = Lcd_x;
 //  Pix_y = Lcd_y * 54;
   Pix_y_a = Pix_y_a  * 53;
   Pix_addr = Pix_y_a + Pix_x_a;
   start =  (SAD2H << 0x08) | SAD2L;
   Pix_addr = Pix_addr + start;
   sed1335_set_address(Pix_addr) ;
  
}//void gr_set_cursor(void) 

//----------------------------------------------------------------               
//12x16-os karakterkiveses
void bigstring(const char* pTxt, uint8_t len, uint8_t Inverzbit)                                            
{
#ifdef LARGE_FONT
	int i,Bn1,Bn2,Bn3,Bn4;
	char Tmp_char;

    if (pTxt == NULL)
        return;

 //	lcd_send_cmd(CSRDIR_U);                                    //Kurzor fel
 //	lcd_send_cmd(0x42);                                      //Display memoria irasa
//	sed1335_set_cur_dir(CSRDIR_U);
//	sed1335_cmd(0x42);
	for ( i=0; i<len; i++)
	{
//		lcd_send_cmd(Cur_up);                                 //Kurzor fel
// 		lcd_send_cmd(0x42);                                   //Display memoria irasa.
		sed1335_set_cur_dir(CSRDIR_U);
		Tmp_char = pTxt[i];   
		Bn4 = Tmp_char * 32;
		for (Bn3 = 0; Bn3 < 15; Bn3++)
		{
            Bn1 = Bn4 + Bn3;            
			Bn2 = pgm_read_byte(&Font12x16[Bn1]);			
//			Bn2 = pgm_read_byte(Font6x8[Bn1]);
            if (Inverzbit)
			 	Bn2 = 255 - Bn2;
//            lcd_send_data(Bn2);
			sed1335_single_byte(Bn2);
			
        }
//		lcd_send_cmd(Cur_right);                               //Kurzor jobbra
//		lcd_send_cmd(0x42);                                    //Display memoria irasa
		sed1335_set_cur_dir(CSRDIR_R);
		++Bn1;
		Bn2 = pgm_read_byte(&Font12x16[Bn1]);							
//		Bn2 = Font6x8[Bn1];
		if (Inverzbit) 
			Bn2 = 255 - Bn2;
//		lcd_send_data(Bn2);
		sed1335_single_byte(Bn2);

		sed1335_set_cur_dir(CSRDIR_D);
//		lcd_send_cmd(CSRDIR_D);                                //Kurzor le
//		lcd_send_cmd(0x42);                                    //Display memoria irasa
		++Bn1;
		Bn2 = pgm_read_byte(&Font12x16[Bn1]);							
//		Bn2 = Font6x8[Bn1];							
 		if (Inverzbit) 
			Bn2 = 255 - Bn2;
//		lcd_send_data(Bn2);
		sed1335_single_byte(Bn2);

        for (Bn3 = 17; Bn3 < 31; Bn3++)
		{
            Bn1 = Bn4 + Bn3;
            Bn2 = pgm_read_byte(&Font12x16[Bn1]);			
//			Bn2 = pgm_read_byte(Font6x8[Bn1]);
            if (Inverzbit == 1)
				Bn2 = 255 - Bn2;
//            lcd_send_data(Bn2);    
			sed1335_single_byte(Bn2);     
		 }

//         lcd_send_cmd(Cur_right);                       		//Kurzor jobbra
//		 lcd_send_cmd(0x42);                                    //Display memoria irasa
		 sed1335_set_cur_dir(CSRDIR_R);
		 ++Bn1;
		 Bn2 = pgm_read_byte(&Font12x16[Bn1]);				
//		Bn2 = pgm_read_byte(Font6x8[Bn1]);
 		 if (Inverzbit)
		 	Bn2 = 255 - Bn2;
//		lcd_send_data(Bn2);
		sed1335_single_byte(Bn2);  
	}
#endif
}//void bigchar(void)  	

