/*#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <compat\ina90.h>
#include <util/delay.h>*/
#include "macros.h"
#include "utils.h"
#include "sed1335.h"

/**
 * \brief wait for "cycles" instruction cycles
 *
 * at 16MHz one cycle is 62.5ns
 * \param cycles number fo cycles to busy wait
 */

void wait(uint16_t cycles)
{
 	unsigned int i;
 	
	for (i=0; i<cycles; i++)
	{
 		__asm__
		( 		
			"nop\n"		
		);
	}
}
	
/**
* \brief return absolute memory address for a relative text-mode address
*
* This address can than be used for sed1335_mem_write()
* \param addr relative text-memory address
*/
uint16_t sed1335_get_txcur(uint16_t addr)
{
	if (addr < (SAD2H << 8) + SAD2L) 
	{
		return addr;
	} 
	else 
		return -1;    /* error (address out of range) */
}
	
/**
* \brief return absolute memory address for a relative graphic-mode address
*
* This address can than be used for sed1335_mem_write()
* \param addr relative graphic-memory address
*/
uint16_t sed1335_get_grcur(uint16_t addr)
{
	uint16_t start=0;
	
	/* get start address of layer 2 */
	start=(SAD2H << 0x08) | SAD2L;
	start=start+addr;
	
	if ( (start >= TEXTSIZE) && (start < MEM_END))
	{
    	return start;
	} 
	else 
		return -1;	
}
	
/**
* \brief set the internal memory pointer to the absolute address addr
*
* return -1 if address is out of range
* \param addr address to jump to
*/
int sed1335_set_address(uint16_t addr)
{
	if (addr>MEM_END)
		return -1;
	
	sed1335_cmd(CSRW);
	sed1335_data(lo(addr));
	sed1335_data(hi(addr));

 	return 0;
}
 	
/**
* \brief write a data byte to the controller
* \param byte data byte to write
*/
void sed1335_data(uint8_t byte)
{
//	LCD_DATA_PORT = byte;
	unset_command();
//	LCD_DATA_PORT = byte;
	unset_read();
	enable_sed();
	set_write();	

	/* wait(5); */
 	__asm__
	( 		
		"nop\n"
		"nop\n"		
	);
	
	LCD_DATA_PORT = byte;

	__asm__
	( 		
		"nop\n"
		"nop\n"	
		"nop\n"	
	);
 	
	/* wait(5); */
	unset_write();          /* the controller reads the wrote data now */
 
	__asm__
	( 		
		"nop\n"
		"nop\n"	
//		"nop\n"		
	);
	disable_sed();
}
	
/**
* \brief read a byte, MREAD command has to be specified before
*/
uint8_t sed1335_read_byte()
{       // nem jo!!! hw hiba???
	uint8_t byte=0;
 	       
	/* input */
	LCD_DATA_PORT=0xff;
	LCD_DATA_DDR=0x00;
 	
	set_command();
//	unset_command();
	unset_read();
	unset_write();
	enable_sed();
	set_read();

	__asm__
	( 		
		"nop\n"
		"nop\n"
		"nop\n"
	); 

	byte = LCD_DATA_IN;
	
//	 wait(5); 
	unset_read();
//	disable_sed();
 	
	LCD_DATA_PORT = 0x00;
	LCD_DATA_DDR = LCD_DATA_MASK;
	       
	return byte;
}
 	
/**
* \brief issue a SED1335 command
*
* \param byte command byte
*/
void sed1335_cmd(uint8_t byte)
{
	set_command();
	unset_read();
	enable_sed();
	set_write();
	

	/* wait(5); */
	__asm__
	( 		
		"nop\n"
		"nop\n"		
	);

	LCD_DATA_PORT=byte;

	__asm__
	( 		
		"nop\n"
		"nop\n"
		"nop\n"
	);

	/* wait(5); */
	unset_write();          /* the controller reads the wrote data now */
	unset_command();
	disable_sed();
}

/**
* \brief enable the display
*/
void sed1335_enable_display(void)
{
	sed1335_cmd(DISP_ON);
//	sed1335_data(FLASH);
}

/**
* \brief disable the display
*/
void sed1335_disable_display(void)
{
	sed1335_cmd(DISP_OFF);
}

/**
* \brief initialize the display
*/

void _sed1335_lcd_init(void)
{
	sed1335_cmd(SYSTEM_SET);        /// SYSTEM instruction 
	sed1335_data(SYS_P1);
	sed1335_data(SYS_P2);
	sed1335_data(FY);
	sed1335_data(CR);
	sed1335_data(TCR);
	sed1335_data(LF);
	sed1335_data(APL);
	sed1335_data(APH);
/*	
	sed1335_cmd(SCROLL);            // SCROLL instruction 
	sed1335_data(SAD1L);
	sed1335_data(SAD1H);
	sed1335_data(SL1);
	sed1335_data(SAD2L);
	sed1335_data(SAD2H);
	sed1335_data(SL2);
	sed1335_data(SAD3L);
	sed1335_data(SAD3H);
	sed1335_data(SAD4L);
	sed1335_data(SAD4H);

	sed1335_cmd(CSRDIR_R);          /// CSRDIR right instruction 

	sed1335_cmd(HDOT_SCR);          /// HDOT SCR instrcution 
	sed1335_data(SCRD);

	sed1335_cmd(OVLAY);             /// OVLAY instruction 
	sed1335_data(OVLAY_P1);
	
	sed1335_cmd(CSRFORM);           /// CSRFORM instruction 
	sed1335_data(CRX);
	sed1335_data(CSRF_P2);

	sed1335_cmd(CGRAM_ADR);         /// CGRAM ADR instruction 
	sed1335_data(SAGL);
	sed1335_data(SAGH);
*/		
}
//------------------------------------------------------------
void  sed1335_lcd_init()
{
	
  /*  sed1335_cmd(0x40);                                  //SYSTEM SET parancs

   sed1335_data(0x31);                                 //DR,T/L,IV,1,W/S, M2, M1, M0

//   Call Lcd_send_data(&H87)                                 'WF, 0, 0, 0, 0, FX
   sed1335_data(0x85);                                 //WF, 0, 0, 0, 0, FX


   sed1335_data(0x07);                                 //0, 0, 0, 0, FY
                                //C/R karakter/sor 40 (27h volt)
   sed1335_data(0x36);                                 //C/R karakter/sor 53

   sed1335_data(0x55);                                 //Total karakter/sor 85

   sed1335_data(0xef);                                 //L/F sor/frame 240

   //'Call Lcd_send_data(&H28)                                 'APL 40
   sed1335_data(0x36);                                 //APL 53

   sed1335_data(0x00);                                 //APH
//'Display memory width 40
*/
_sed1335_lcd_init();
   sed1335_cmd(0x44);                                  //Display start addres+regions
   sed1335_data(0x00);                                 //SAD1L                                '
   sed1335_data(0x00);                                 //SAD1H 0000h
   sed1335_data(0xef);                                 //SL1 =F0h 1. kepernyo sorszam:240

   sed1335_data(0x00);                                 //SAD2L
   sed1335_data(0x08);                                 //SAD2H 0800h Grafikus mem start


   sed1335_data(0xef);                                 //SL2=F0h

   sed1335_cmd(0x4c);                                  //Kurzormozgas 4C=jobbra, 4D=balra, 4E=fel, 4F=le

   sed1335_cmd(0x5a);                                 //HDOT SCROLL 0-7 piselscroll
   sed1335_data(0x00);

   sed1335_cmd(0x5b) ;                                 //OVERLAY: 0,0,0,OV,DM2,DM1,MX1,MX0
   sed1335_data(0x01);


   sed1335_cmd(0x59);                                  //Display on/off

   sed1335_data(0x14) ;                                //Screen2 ON, no flash  10h

   sed1335_cmd(0x5d);                                  //SET CURSOR type
   sed1335_data(0x07);                                 //kursor sz�less�g 0-f
   sed1335_data(0x87) ;                                //kurzor magass�g, d7=0=alahuzott, 1=blokk
   sed1335_data(0x4c)  ;                               
   sed1335_cmd(0x46);                                  //SET kurzor address
   sed1335_data(0x00);                                 //0000
   sed1335_data(0x00);
   sed1335_cmd(0x42)  ;                                

}//void lcd_init()


/**
* \brief enable sleep mode for display and SED1335 controller
*/
void sed1335_sleep_enable(void)
{
	sed1335_cmd(SLEEP_IN);
}
	
/**
* \brief wakeup sed1335 controller and display
*/
void sed1335_sleep_disable(void)
{
	sed1335_cmd(SYSTEM_SET);
	sed1335_data(SYS_P1);
}

/**
* \brief set layer and/or cursor flash rates
*
* see datasheet for details
* \param flashing flashing setup byte
*/
void sed1335_set_flashing(uint8_t flashing)
{
	sed1335_cmd(DISP_ON);
	sed1335_data(flashing);
}

/**
* \brief set memory cursor direction
*
* \param byte direction
*/
uint8_t sed1335_set_cur_dir(uint8_t byte)
{
/* check input */
	if ((byte >= 0x4c) && (byte <=0x4f))
	{
		sed1335_cmd(byte);
		return 0x00;
	}
	else
		return 0x01;
}

/**
* \brief write a buffer to the current lcd memory position
*
* if an address other than the current internal address is to be used,
* the address can be specified with sed1335_set_address()
* the addr parameter has to specified so that length checking can be done
*
* \param buf buffer to read from
* \param len length of buffer
* \param addr absolute address to write to
*/
/*
uint16_t sed1335_mem_write(uint8_t *buf, uint16_t len, uint16_t addr)
{
	int i;

	// check for out of range 
	if((addr+len) > MEM_END)
		return 0;
	// write command 
	sed1335_cmd(MWRITE);
    
	// write out buffer 
	for (i=0; i<len; i++)
		sed1335_data(buf[i]);

	if (i==0) 
		return(0);
	else 
		return(i);
}*/

/**
* \brief read from the display memory
*
* read len bytes from the memory at address addr and save it to *buf,
* returns the number of bytes read
*
* \param buf buffer to write to
* \param len buffer length
* \param addr absolute address to read from
*/
/*
uint16_t sed1335_read_mem(uint8_t *buf, uint16_t len, uint16_t addr)
{
	int i;
   
	// check out of bounds 
	if ((addr+len) > MEM_END)
		return 0;
 	
	for (i=0; i<len; i++)
	{
		sed1335_set_address(addr+i);
		sed1335_cmd(MREAD);
		buf[i]=sed1335_read_byte();
	}
 	return i;
}*/
 	       
/**
* \brief write out text to the display memory (special character aware)
*
* this is the same as sed1335_mem_write() except that this function interpretes special chars,
* return number fo bytes written
*
* \param buf buffer to write out
* \param len length of buffer
* \param addr absolute address to write to
*/
uint16_t sed1335_text_write(char *buf, uint16_t len, uint16_t addr)
{
	int i;
	int j;
	uint8_t whitespace_bytes=0;
	uint16_t current_position=0;
	
	/* check for out of range */
	if((addr+len) > MEM_END)
		return -1;

	/* write command */
	sed1335_cmd(MWRITE);

	/* write out buffer */
	for (i=0; i<len; i++)
	{
		switch(buf[i])
        {
			case '\n': /* fill the rest of the line with blanks */
				if (addr<sed1335_get_txcur(0))
				{
					/* invalid address */
					return 0;
				}
				current_position = (addr+i+whitespace_bytes) - sed1335_get_txcur(0);
				current_position = current_position % /*40*/53;    /* position in zeile */
	                                   
				for (j=0; j<(/*40*/53 - current_position); j++)            /* whitespaces for rest of line */
				{
					sed1335_data(0x20);
					whitespace_bytes++;
				}
				whitespace_bytes--;  /* don't count last one */
	            break;
       
			case '\t': /* fill next TABSIZE chars with blanks */
				for (j=0; j<TABSIZE; j++)
				{
					sed1335_data(0x20);
					whitespace_bytes++;
				}
				whitespace_bytes--;  /* don't count last one */
				break;

			default: sed1335_data(buf[i]);
				 break;
		}
	}
	
	return(i+whitespace_bytes);
}

/**
* \brief write a single byte to the current address
*
* \param byte byte to write out
*/
void sed1335_single_byte(uint8_t byte)
{
	sed1335_cmd(MWRITE);
	sed1335_data(byte);
}
	
/**
* \brief clear display
*/
void sed1335_clear_display(void)
{
	uint16_t i;
	sed1335_disable_display();
	sed1335_set_address(0);
	sed1335_cmd(MWRITE);
	for (i=0; i<32000; i++)
		sed1335_data(0x00);
	delayms(10);
	sed1335_enable_display();
	
}

void sed1335_clr_display(uint16_t y)
{ // y karakter sorszam.
    uint16_t i,start;
	sed1335_clear_display();
	return;
//		_CLI();
    y *= 54; 
	i = y;  
	start =  (SAD2H << 0x08) | SAD2L;
	sed1335_set_address(y);
    sed1335_cmd(MWRITE);
   // for (; i<start; i++)
	//	sed1335_data(0x00);
   // return;
   // i = y*8 + start;
   // sed1335_set_address(i);
   // sed1335_cmd(MWRITE);
    for (; i<MEM_END; i++)
		sed1335_data(0x00);
//		_SEI();
}
