#ifndef _MLOOP_H
#define _MLOOP_H


//parancsok:
//adas:
#define S_GENERAL_CMD		0 		// altalanos lekerdezes.
#define S_1RESET_CMD		0x80	// reset 1 allomasnal.
//#define S_1TEST_CMD			0x10	// test 1 allomasnal.
#define S_1ADRRES_CMD		0x90	// reset allomas cim.
#define S_ASKADDRNUM_CMD	0x91	// allomas cimek szamanak a lekerdezese.
#define S_ASKADDR_CMD		0x92	// allomas cimek lekerdezese.
#define S_ADRRES_CMD		0x90	// reset cim mindegyik allomasnal. 
#define S_STARTINST_CMD		0x83	// install bekapcsolasa. 
#define S_STOPINST_CMD		0x84	// install kikapcsolasa. 
#define S_STARTINFRA_CMD	0x81	// korparancs:cim infra adas inditas.(3x)
#define S_STOPINFRA_CMD		0x82	// korparancs:cim infra adas leallitas.(3x)
#define S_RESET_CMD			0x80	// korparancs:reset mindegyik allomasnal.(3x)
#define S_STARTTEST_CMD		0x70	// korparancs:test start, mindegyik allomasnal.(3x)
#define S_STOPTEST_CMD		0x71	// korparancs:test stop, mindegyik allomasnal.(3x)


//vetel
#define R_GENERAL_CMD		0 		// nincs valtozas,hiba.
#define R_ERROR_CMD			0xf0	// parancs nincs elvegezve,hiba.
#define R_MESSG_CMD			0xf2	// szimpla uzenet, max. 20 byte.
#define R_ASKADDRNUM_CMD	0x91	// allomas cimek szamanak a lekerdezese.
#define R_ADDRLST_CMD		0x92	// lekerdezett cimek, max. 124 byte.

extern void chlm_com_init(void);
extern void chlm_set_error_flag(CHERRFLAG flag_a);
extern void chlm_tx_send(LOOPtype* ptrData);
extern void klm_tx_send(CHN_ASK* ptrData);
extern void set_cmd_all_All(uint8_t cmd);
extern void chlm_rx_controlling(volatile unsigned char* pData, CHN_ASK* chk);
extern LOOPtype* NextLoop(void);
extern LOOPtype* CurrLoop(void);
extern uint8_t	loop_ask_index;
extern LOOPtype	loop_array[COMM_MAX_LOOP+1];
extern void loops_load();
#endif
