#include <avr/io.h>
#include <stdio.h>
#include <inttypes.h>
#include "macros.h"
#include "KConfig.h"
#include "adc.h"
#include "KCom.h"
#include "Kozpont.h"
#include "utils.h"

uint16_t r_X_prev;
uint16_t r_Y_prev;
uint16_t r_X, r_X0,r_X1;
uint16_t r_Y, r_Y0,r_Y1;

float lcd_width, lcd_heigth;

uint16_t pushed_left, pushed_right;
uint8_t  pushed_top,  pushed_bottom;

uint16_t ad_timercount;

//---------------------------------------------
void set_pushed_area(uint16_t left_a, uint8_t top_a, uint16_t right_a, uint8_t bottom_a)
{
    pushed_left = left_a;
    pushed_top  = top_a;
    pushed_right= right_a;
    pushed_bottom= bottom_a;
}//set_pushed_area(...)

//---------------------------------------------
uint16_t readADC(uint8_t channel) 
{
//	uint8_t i;
	uint16_t result = 0;
	
	// Den ADC aktivieren und Teilungsfaktor auf 64 stellen
	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1);

	// Kanal des Multiplexers waehlen
	ADMUX = channel;
	// Interne Referenzspannung verwenden (also 2,56 V)
	ADMUX |= /*(1<<REFS1) | */(1<<REFS0);
	
	// Den ADC initialisieren und einen sog. Dummyreadout machen
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	
	// Jetzt 3x die analoge Spannung and Kanal channel auslesen
	// und dann Durchschnittswert ausrechnen.
//	for(i=0; i<1; i++) {
		// Eine Wandlung
	ADCSRA |= (1<<ADSC);
		// Auf Ergebnis warten...
	while(ADCSRA & (1<<ADSC));
	result = ADCW;
		//result += ADCW;
//	}
	
	// ADC wieder deaktivieren
	ADCSRA &= ~(1<<ADEN);
	
//	result /= 3;
	
	return result;
}

/***********************************************************
 * Touch part.
 ***********************************************************/
uint16_t t_Y_meres(void)
{   
	uint16_t t_y;
		
	T_TOP_BOT_OUT
   	T_TOP_ON
	T_BOT_OFF
	T_LFT_RGT_IN
	T_LFT_ON
	T_RGT_ON
    
	t_y = readADC(2); 
    	    
    return t_y;

}//int t_X_meres(void)


int t_X_meres(void)
{
	uint16_t t_x;
		
	T_TOP_BOT_IN
   	T_TOP_ON
	T_BOT_ON
	T_LFT_RGT_OUT
	T_LFT_ON
	T_RGT_OFF
    
	t_x = readADC(1); 
    	    
    return t_x;  

}//int t_Y_meres(void)


//--------------------------------------------------------
int8_t t_a_d(int* pos_x_a, int* pos_y_a)
{   
	if (t_time_out(0,0))
	{
		t_time_out(1,3);
//		char msg[50];
    	r_X0 = t_X_meres();
		delayms(5);
		r_Y0 = t_Y_meres();
		delayms(5);
		r_X1 = t_X_meres();
		delayms(5);
		r_Y1 = t_Y_meres();
	
		r_X = (r_X0 + r_X1)/2;
		r_Y = (r_Y0 + r_Y1)/2;
	
	//	sprintf(msg,"t_x: x:%d,%d, y:%d,%d",r_X0,r_X1,r_Y0,r_Y1);
	//	PutString(msg);

    	if ((r_X == r_X_prev) && (r_Y == r_Y_prev))
		{
	//		PutString("adc2");
        	return 0;
		}

    	if ((r_X < LCD_R_X_MIN) || (r_X > LCD_R_X_MAX) || (r_Y < LCD_R_Y_MIN) || (r_Y > LCD_R_Y_MAX))
		{
		//	set_pushed_area(0,0,0,0);
	//		PutString("adc1");
        	return 0;
		}

    	r_X_prev = r_X;
    	r_Y_prev = r_Y;

		float temp;
		temp = ((float)r_X - LCD_R_X_MIN) * LCD_R_WIDTH_MUL;
		*pos_x_a = (int)(temp);
		temp = ((float)r_Y - LCD_R_Y_MIN) * LCD_R_HEIGTH_MUL;	
		*pos_y_a = (int)(temp);

	//	sprintf(msg,"T_x: x:%d, y:%d",*pos_x_a,*pos_y_a);
	//	PutString(msg);
        if ((*pos_x_a > pushed_left) && (*pos_x_a < pushed_right) && (*pos_y_a > pushed_top) && (*pos_y_a < pushed_bottom))
            return 0;
        else
		{			
		    return 1;
		}
	}
    return 0;
}//int8_t t_a_d()

/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t t_time_out(uint8_t start,uint8_t diff)
{	
	//static uint8_t  overflow = 0;
	//static uint16_t starttimercount = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		ad_timercount = 0;
		_time_out = diff;
	//	overflow =(_time_out <= timercount)?1:0;
	//	starttimercount = timercount;					
	}
	else
	{
/*		if (overflow)
		{
			if (timercount > _time_out)			
				return 0;
			else
				overflow = 0;
		}
		else*/
		if (ad_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t rx1_time_out(uint8_t start,uint8_t diff)
