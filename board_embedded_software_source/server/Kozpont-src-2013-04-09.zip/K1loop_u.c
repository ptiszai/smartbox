/*
 *	Lamp allomas com. Atmega32..
 *  Tiszai I.
 *  2006
 *
 *	Leiras:
 *	Adas:
 *	',',cim,parancs,chs:
 *  ',',cim,0x0x,chs		// x: D0,D1 output, es input lekerdezes.
 *  ',',cim,0x10,chs		// test mod.
 *  ',',cim,0x80,chs		// reset
 *  ',',0xaa,0x55,chs		// reset all. cim utana uj cim kepzest indit, ha nincs mar cime.
 *	',',0xfe,0x80,chs		// reset mindegyik allomasnal.
 *	',',0xfe,0x81,chs		// cim infra adas inditas.
 *	',',0xfe,0x82,chs		// cim infra adas leallitas.
 *	',',0xfe,0x70,chs		// test start, mindegyik allomasnal.
 *	',',0xfe,0x71,chs		// test stop , mindegyik allomasnal.
 *	'!',lcount xor hcount,uj cim,chs	// uj cim kuldes. (lcount xor hcount: all. kapott szamlalo xor erteke).
 *  Install:
 *	'?',0xfe,0x90,chs		// reset cim mindegyik allomasnal. 
 *  '?',cim,0x90,chs		// cim torlese.
 *  '?',0xaa,0x55,chs		// reset all. cim utana uj cim kepzest indit, ha nincs mar cime.
 *	'?',lcount xor hcount,uj cim,chs // uj cim kuldes. (lcount xor hcount: all. szamlalo xor erteke).
 *	'?',uj cim,0,chs 		// uj cim kuldes.
 *  chs = cim+parancs
 *  cim 					// allomas cim.
 *
 *	Vetel:
 *	';',cim,parancs,chs:
 *	';',cim,0x0x,chs		// x: D0,D1,D2,D3 input.
 *	';',cim,0x8x,chs		// x: D0-D6 uj cim,D7=1: uj cim.
 *  Install:
 *  '!',0xaa,lcount xor hcount,chs	// all. bejelentkezik uj cimert,(lcount xor hcount: all.szamlalo xor erteke).
 *	'!',uj cim,0,chs 		// uj cim vetele.
 *  chs = cim+parancs	
 *  cim 					// allomas cim.
 */

 
#include <avr\io.h>
#include <compat\ina90.h>
#include <stdio.h>
#include <string.h>

#include "macros.h"
#include "utils.h"
#include "Kozpont.h"
#include "K1loop.h"
#include "KTouch.h"
#include "KConfig.h"
#include "KCom.h"

/*---------------------- konstansok -----------------------------*/

/*----------------------- valtozok ------------------------------*/
// transm.
volatile unsigned char	txBuffer[TX_MAX_SENDED_NUM+1]; // transm. buffer
int8_t   tx_head;
// receive.
volatile unsigned char	rxBuffer[RX_MAX_RECEIVE_NUM+2]; // receive buffer
int8_t   rec_head;

int8_t l1status;
int8_t l1error;
uint8_t all_ask_index;
uint8_t got_rand_all_addr,put_new_all_addr;
CHANNELtype all_array[COMM_MAX_ADDR+1];
uint8_t alladdrnumenable;
uint8_t install;
CHN_ASK chn_ask;

static uint16_t prev_test_timer_sec = 0;

/***********************************************************
 * init resz.
 ***********************************************************/

void ch1l_com_init(void)
{
	DDRF |=(1<<DDF6)|(1<<DDF7);
	RS485_DE0_OFF
	RS485_RE0_OFF
	unsigned int baud=BAUD2400_16;
 	UCSR0A = 0x00;
 	UBRR0H = (unsigned char)(baud>>8);
 	UBRR0L = (unsigned char)baud;
 	UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0);
//	UCSRB = (1<<TXEN) ;
	UCSR0C = (3<<UCSZ00);	
//	RS485_LED_OFF
	tx_head=0;
	rec_head=0;
    l1status = 0;
    l1error = 0;
	SET_L1STATUS(RX)
	chn_ask.num = 0;
	l1channels_load(all_array);
//	CHANNELtype data = FirstAll();
	chn_ask.num = 2;				// infra off;
	chn_ask.chn.addr = 0xfe;
	chn_ask.chn.cmd  = 0x82;
	chl1_tx_send(&chn_ask.chn);		// elso kerdezes, ami cim kereses.

}//all_com_init(void)

/***********************************************************
 * allmos tomb feldolgozo fg.-ek resz.
 ***********************************************************/
CHANNELtype NextAll(void)
{	
	++all_ask_index;

	all_ask_index = (all_ask_index > alladdrnumenable) ? 0 : all_ask_index;
/*	while ((all_ask_index<alladdrnumenable))
	{	
		if (!all_ask_index)
			break;
		if (all_array[all_ask_index].addr)
			break;
		++all_ask_index;
		if ((all_ask_index>=alladdrnumenable))
			all_ask_index=0;
	}*/	
	return all_array[all_ask_index];
}//CHANNELtype* NextAll(void)

CHANNELtype CurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return all_array[all_ask_index];
	return all_array[0];
}//CHANNELtype* CurrAll(void)


CHANNELtype* pCurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return &all_array[all_ask_index];
	return &all_array[0];
}//CHANNELtype* CurrAll(void)

CHANNELtype FirstAll(void)
{
	all_ask_index = 0;
	return all_array[0];
}//CHANNELtype* FirstAll(void)

CHANNELtype IndexAll(uint8_t index)
{
	if (index <= alladdrnumenable)
		return all_array[index];
	else
		return all_array[0];
}//CHANNELtype* IndexAll(void)

CHANNELtype* SearchAll(uint8_t all_address)
{
	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		if (all_array[index].addr == all_address)
			return  &all_array[index];
	}
	return &all_array[0];
	
}//CHANNELtype* IndexAll(void)

void set_cmd_all_All(uint8_t cmd)
{
	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		all_array[index].cmd = cmd;
	}
}//void set_cmd_all_All(uint8_t cmd)

/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
void chl1_rx_controlling(volatile unsigned char* pData)
{

   // install_receiver(pData);
	CHANNELtype chan = CurrAll();

	//	char msg[40];
		sprintf(msg,"rx:0x%x,0x%x,0x%x,0x%x",pData[0],pData[1],pData[2],pData[3]);
		PutString(msg);

	if (*pData != R_STR_CHAR)
	{
		return;
	}
	pData++;
	
	if (*pData == chan.addr)
	{  // kerdezett allomas cime jott.		
		if (chl1_rx_data(pData))
		{
			chl1_set_error_flag(ERR_NONEflag);
			return;		
		}
	}			
	chl1_set_error_flag(ERR_CONTflag);
//	chl1_set_error_flag(ERR_NONEflag);
//	PutString("???????");

}//comm_rx_controlling(...)

//----------------------------------------------------
// check summa vizsgalata.
char  IsGoodCheckSumma(volatile unsigned char* pData)
{
	return (*pData + *(++pData)	== *(++pData));
}//IsGoodCheckSumma(unsigned char* pData)


//----------------------------------------------------
// altalanos lekerdezes
uint8_t chl1_rx_data(volatile unsigned char* pData)
{
	if (IsGoodCheckSumma(pData))
	{
		CHANNELtype* chan = SearchAll(*pData);
		if (chan->addr == 0xaa)
			return 0;		
		chan->data = (*(++pData)) & 0x3f;

	//	char temp[50];
	//	sprintf(temp,"kapott: addr: 0x%x, data: 0x%x",chan->addr,chan->data);
	//	PutString(temp);
		return 1;
	}
	else
		return 0;
}//void rx_data(unsigned char* pData)

//----------------------------------------------------
// uj cimet ker az allomas.
uint8_t chl1_rx_new_addr_req(volatile unsigned char* pData)
{
	if (IsGoodCheckSumma(pData))
	{
		chn_ask.num = 1;
		chn_ask.chn.addr = *(++pData);
		chn_ask.chn.cmd  = 0xff;
		chn_ask.chn.data  = 2; // uj cim.
		char temp[50];
		sprintf(temp,"kapott: addr: 0x%x, data_cim: 0x%x",chn_ask.chn.addr,chn_ask.chn.data);
		PutString(temp);
		return 1;
	}
	else
		return 0;
}//void  chl1_rx_new_addr_req(unsigned char* pData)

//----------------------------------------------------
void chl1_set_error_flag(CHERRFLAG flag_a)
{
	CHANNELtype* chan = pCurrAll();

	if (flag_a == ERR_NONEflag)
		chan->prev_data &= 0xf0;
	else		
	{
		if ( !(chan->prev_data & 0x08) && ((chan->prev_data & 0x0f) < 4))
			chan->prev_data++;
		else
		{
			chan->prev_data &= 0xf0;
			chan->prev_data |= 0x08;
			switch (flag_a)
			{
				case ERR_RXflag:			
					chan->prev_data |= 0x01;
					break;
				case ERR_TOflag:
					chan->prev_data |= 0x02;
			//	PutString("ETO");
					break;
				case ERR_CONTflag:
					chan->prev_data |= 0x04;;
					break;
				case ERR_NONEflag:
					chan->prev_data &= 0xf0;
					break;
			}
		}
	}
//	lcd_set_chan_data(&chan);
}//void chl1_set error_flag(uint8_t flag_a)
/***********************************************************
 *  Adas  resz.
 ***********************************************************/
 void chl1_tx_send_common(void)
 {
		CLR_L1STATUS(RX)	
		RS485_RE0_OFF			
		DelayMs(10);	
		RS485_DE0_ON
		delayms(10); 					
		tx_head=0;
		TX0_ON		
		SET_L1STATUS(TX)
		sprintf(msg,"tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
		PutString(msg);			
//		UDR = txBuffer[0];
 }//void chl1_tx_send_common(void)
 
 //----------------------------------------------------------
void chl1_tx_send(CHANNELtype* ptrData)
{
	if (ptrData)
	{		
        txBuffer[1] = ptrData->addr;
		if  (ptrData->cmd == 0x90)
			txBuffer[0] = S1_STR_CHAR;
		else
			txBuffer[0] = S_STR_CHAR;
        if  (ptrData->addr == 0xaa)
        {// uj install kerdes.
         //   SET_L1STATUS(L1INSTALL)
		//	SET_INSTALL(BEJ_INST)
			got_rand_all_addr = 0;
			put_new_all_addr = 0;
            txBuffer[0] = S1_STR_CHAR;
            txBuffer[2] = ptrData->cmd;
        }
        else
        {						
			if   (txBuffer[1] == 0xfe)
			{
				txBuffer[2] = ptrData->cmd;			
			}
			else
				txBuffer[2] = /*(ptrData->out & 0x0f)*/ ((ptrData->data & 0xf0) >> 4)| (ptrData->cmd & 0xf0);			
			lcd_set_chan_addr(ptrData->addr);
		}		

		txBuffer[3] = txBuffer[1] + txBuffer[2];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
		chl1_tx_send_common();	
		
	}
}//void tx_send(void)

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/

void chl1_com_rx_tx(void)
{
	static uint8_t	rx_ready_s = 0;

	if (CHK_L1STATUS(RX))
	{		
		if (CHK_L1STATUS(RX_READY))
		{			
			PutString("RXREADY");		
			CLR_L1STATUS(RX_READY)
		//	CLR_STATUS(RX)
			chl1_rx_controlling(rxBuffer);
			rx_ready_s = 1;
		//	if (!CHK_SYS(PC_TEST))				
		//	{
				RS485_RE0_OFF			
				RX0_OFF
				time_out(1,RX_TIME_TO_TX1);	
		//	}
	/*		else
			{
				CLR_SYS(PC_TEST)
				SET_L1STATUS(RX)
		//		RS485_LED_TOGGLE 
				RX0_ON
				rec_head=0;
			}*/
		}
		else
		if (CHK_L1ERROR(RX_L1ERROR))
		{			
			CLR_L1ERROR(RX_L1ERROR)	
			CLR_L1STATUS(RX_READY)
	//		RS485_LED_OFF
			time_out(1,RX_TIME_TO_TX2);
			chl1_set_error_flag(ERR_RXflag);
			install_error();
			PutString("ERROR1");
			
		}
		else
		if (bit_is_set(UCSR0A, FE0) || bit_is_set(UCSR0A, DOR0) || bit_is_set(UCSR0A, PE0))
		{
			RS485_RE0_OFF
			CLR_L1STATUS(RX_INT)
			SET_L1STATUS(RX_L1ERROR)
			install_error();
			char temp = UDR0;
			
			PutString("ERROR2");
			//chl1_set error_flag(ERR_RXflag);
		}
		else
		if (time_out(0,0))
		{// adast indit.
		
			if (!rx_ready_s)
			{
				chl1_set_error_flag(ERR_TOflag);
				install_error();
			}
			else
				rx_ready_s = 0;

			
//			if (CHK_L1STATUS(TX_KOZP_ASK))
			if (chn_ask.num)
			{// kozpont kerdez 1.-et.			
				
				chn_ask.num--;	
				chl1_tx_send(&chn_ask.chn);
//				CLR_L1STATUS(TX_KOZP_ASK)
				if (!chn_ask.num && ((chn_ask.chn.cmd  == 0x71) || (chn_ask.chn.cmd  == 0x82)))				
					lcd_set_chan_cmd("                 ");
			
				rx_ready_s = 1;
				
			}
			else
			{
				if (CHK_L1STATUS(L1INSTALL))
				{
			//		install_sender();
			//		return;
				}
				else
				{
					CHANNELtype data = NextAll();
					if (CHK_SYSSTATUS(SYS_TEST2) || CHK_SYSSTATUS(SYS_TEST40))
					{
						if (data.addr == 0xaa)
							data = NextAll();
					}
					chl1_tx_send(&data);
				}
			}
			
		}
	}
	else
	if (CHK_L1STATUS(TX_READY))
	{ // tx end.		
		rec_head=0;
		delayms(15);
		RS485_DE0_OFF
		delayms(5);		
		RS485_RE0_ON
		TX0_OFF	
		RX0_ON 
		CLR_L1STATUS(TX_READY)
		CLR_L1STATUS(TX)
		SET_L1STATUS(RX)
		if (CHK_L1STATUS(L1INSTALL))
		{
			time_out(1,RX_TIME_TO_TX4);		
		}
		else		
			time_out(1,RX_TIME_TO_TX3);			
	//	RS485_LED_OFF
	}
}//void all_com_rx_tx(void)

/***********************************************************
 * inturrept resz.
 ***********************************************************/
 /**********************************************************
 * COM adas int.
 **********************************************************/
unsigned char ch1l_tx_int()
{	
//	++tx_head;
	if (tx_head>=TX_MAX_SENDED_NUM)
	{
		SET_L1STATUS(TX_READY)
		CLR_L1STATUS(TX_INT)
		TX0_OFF
		return 1;
	}
	return  txBuffer[tx_head++];
}//unsigned char tx_int()

/**********************************************************
 * COM vetel int.
 **********************************************************/
 
char ch1l_rx_int( unsigned char ucData)
{	 
	
	rxBuffer[rec_head] = ucData;
	++rec_head;
//	PutString("1");
	if (rec_head >= RX_MAX_RECEIVE_NUM)
	{
		rec_head=0;
//		RCIE = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_L1STATUS(RX_INT)
		SET_L1STATUS(RX_READY)
	//	PutString("RX_end");
		return 1;
	}	
	return 0;
}//void rx_int(..)

/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t time_out(uint8_t start,uint8_t diff)
{	
	static uint8_t overflow = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		_time_out = timercount + diff;
		overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
		if (overflow)
		{
			if (timercount > _time_out)
				return 0;
			else
				overflow = 0;
		}
		else
		if (timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t time_out(uint8_t start,uint8_t diff)

//-------------------------------------------------------------
void set_allomas_error(uint8_t loop,uint8_t addr,uint8_t err_bit)
{
	CHANNELtype* all = SearchAll(addr);
	//all->data = 0;
	all->data = err_bit;

}//void set_allomas_error(1,2,2)


//-------------------------------------------------------------
void start_test(uint8_t mode_a)
{
	SET_SYSSTATUS(mode_a)
	prev_test_timer_sec = timersec;
	chn_ask.num = 2;
	chn_ask.chn.addr = 0xfe;
	chn_ask.chn.cmd  = 0x70;
	set_cmd_all_All(0x10);
	write_Allerror_to_sd("Test start;      \n", 0, 0);
	string_write(" TEST ", 1,24,0,0, LCD_BIGFONT );	
	
}//void start_test(void)

//-------------------------------------------------------------
void end_test(void)
{
	CLR_SYSSTATUS(SYS_TEST2)
	CLR_SYSSTATUS(SYS_TEST40)
	chn_ask.num = 2;
	chn_ask.chn.addr = 0xfe;
	chn_ask.chn.cmd  = 0x71;
	set_cmd_all_All(0);
	string_write("Charge", 1,24,0,0, LCD_BIGFONT );	
	write_Allerror_to_sd("Test end  ;      \n", 0, 0);
	lcd_editor_log_picture(EXITpic);
}//void start_test(void)

//-------------------------------------------------------------
void test_executor(void)
{
	if (CHK_SYSSTATUS(SYS_TEST2))
	{
		if (timersec != prev_test_timer_sec)
		{      
			prev_test_timer_sec = timersec; 
			if (!(timersec % 140)) // 2 perc 20 sec
			{
				end_test();
			}
		}
	}
	else
	if (CHK_SYSSTATUS(SYS_TEST40))
	{
		if (timersec != prev_test_timer_sec)
		{       
			prev_test_timer_sec = timersec; 
			if (!(timersec % 2430)) // 40.5 perc
			{
				end_test();
			}
		}
	}
}//void start_test(void)

/**********************************************************
 * Install resz.
 **********************************************************/
/*
void install_tx_ujcim(void)
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = got_rand_all_addr;	
	txBuffer[2] = put_new_all_addr;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	chl1_tx_send_common();
}//void tx_bejentkezes(void)

void install_tx_ask_ujcim(void)
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = put_new_all_addr;	
	txBuffer[2] = 0;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	chl1_tx_send_common();
}//void install_tx_ask_ujcim(void)

void install_tx_cim(void)
{
	txBuffer[0] = S_STR_CHAR;
	txBuffer[1] = put_new_all_addr;	
	txBuffer[2] = 0;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	chl1_tx_send_common();
}//void install_tx_cim(void)

*/

uint8_t install_search_new_addr(void)
{
	return 2;
}//void install_search_new_addr(void)

void install_receiver(volatile unsigned char* pData)
{
/*	if (CHK_L1STATUS(L1INSTALL))
	{
		if (*pData == R1_STR_CHAR)
		{
			pData++;
			if (CHK_INSTALL(BEJ_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					got_rand_all_addr = *(++pData);
					put_new_all_addr = install_search_new_addr();
					if ((put_new_all_addr > 0) && (put_new_all_addr <= COMM1_MAX_ADDR))
					{										
						CLRA_INSTALL;
						SET_INSTALL(PUT_ADDR_INST)						
						sprintf(msg,"BEJ_INST:got_addr:0x%x",got_rand_all_addr);
						PutString(msg);
						install_tx_ujcim();
						return;					
					}
				}
			}
			else
			if (CHK_INSTALL(ASK_ADDR_INST))
			{	
				pData++;		
				if (IsGoodCheckSumma(pData))
				{
					if (*pData == put_new_all_addr)
					{  // sajat uj cimevel jott a valasz.															
						config_add_new_addr(put_new_all_addr);
						l1channels_add(all_array,put_new_all_addr);
						install_tx_cim();
						CLR_L1STATUS(L1INSTALL)
						CLRA_INSTALL
						sprintf(msg,"ASK_ADDR_INST:put_addr:0x%x",put_new_all_addr);
						PutString(msg);
						return;
					}
				}
			}
		}
		install_error();
	}*/
}//void install_receiver(void)

/*
void install_sender(void)
{
	if (CHK_INSTALL(PUT_ADDR_INST))
	{
		CLRA_INSTALL;
		SET_INSTALL(ASK_ADDR_INST)
		install_tx_ask_ujcim();
	}
}//void install_sender(void)
*/
void install_error(void)
{
/*	if (CHK_L1STATUS(L1INSTALL))
	{
		if (CHK_INSTALL(PUT_ADDR_INST))
		{
			chn_ask.num = 1;
			chn_ask.chn.cmd = 0x90;
			chn_ask.chn.addr = put_new_all_addr;
			PutString("install_error:res addr");

		}
		else
			PutString("install_error--baj van");
		CLR_L1STATUS(L1INSTALL)
		CLRA_INSTALL
	}*/
}//void install_error(void)


