#ifndef _ADC_H
#define _ADC_H

#include "macros.h"
#include "KConfig.h"

#define P_T_TOP			0x02				//PF1
#define T_TOP_OFF  		PORTF &= ~P_T_TOP;	
#define T_TOP_ON		PORTF |=  P_T_TOP;

#define P_T_BOT			0x08				//PF3
#define T_BOT_OFF  		PORTF &= ~P_T_BOT;	
#define T_BOT_ON		PORTF |=  P_T_BOT;

#define P_T_LFT			0x01				//PF0
#define T_LFT_OFF  		PORTF &= ~P_T_LFT;	
#define T_LFT_ON		PORTF |=  P_T_LFT;

#define P_T_RGT			0x04				//PF2
#define T_RGT_OFF  		PORTF &= ~P_T_RGT;	
#define T_RGT_ON		PORTF |=  P_T_RGT;

#define T_TOP	PF1
#define T_BOT	PF3
#define T_LFT	PF0
#define T_RGT	PF2

// LCD constants
//#define  LCD_WIDTH               lcd_width
//#define  LCD_HEIGTH              lcd_heigth
#define  LCD_WIDTH               (float)310
#define  LCD_HEIGTH              (float)230

/*#define  LCD_R_X_MIN             (float)(220)
#define  LCD_R_Y_MIN             (float)(300)

#define  LCD_R_X_MAX             (float)(855)
#define  LCD_R_Y_MAX             (float)(785)
*/

#define  LCD_R_X_MIN             (float)(config.touch_r_x_min)
#define  LCD_R_Y_MIN             (float)(config.touch_r_y_min)

#define  LCD_R_X_MAX             (float)(config.touch_r_x_max)
#define  LCD_R_Y_MAX             (float)(config.touch_r_y_max)

#define  LCD_R_WIDTH_MUL		 (LCD_WIDTH / (LCD_R_X_MAX - LCD_R_X_MIN))
#define  LCD_R_HEIGTH_MUL		 (LCD_HEIGTH / (LCD_R_Y_MAX - LCD_R_Y_MIN))

#define  T_TOP_BOT_OUT 	sbi(DDRF,DDF3);sbi(DDRF,DDF1);
#define  T_TOP_BOT_IN 	cbi(DDRF,DDF3);cbi(DDRF,DDF1);

#define  T_LFT_RGT_OUT 	sbi(DDRF,DDF0);sbi(DDRF,DDF2);
#define  T_LFT_RGT_IN 	cbi(DDRF,DDF0);cbi(DDRF,DDF2);

uint8_t t_time_out(uint8_t start,uint8_t diff);
int8_t t_a_d(int*,int*);
extern void set_pushed_area(uint16_t left_a, uint8_t top_a, uint16_t right_a, uint8_t bottom_a);
extern uint16_t ad_timercount;
//extern float lcd_width, lcd_heigth;
#endif
