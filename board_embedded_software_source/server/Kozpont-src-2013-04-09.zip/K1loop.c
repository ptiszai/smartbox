/*
 *	Lamp allomas com. Atmega128.
 *  Tiszai I.
 *  2007
 *
 *	Leiras:
 *	Adas:
 *	',',cim,parancs,chs:
 *  ',',cim,0x0x,chs		// x: D0,D1 output, es input lekerdezes.
 *  ',',cim,0x10,chs		// test mod.
 *  ',',cim,0x80,chs		// reset
 *  ',',0xaa,0x55,chs		// reset all. cim utana uj cim kepzest indit, ha nincs mar cime.
 *	',',0xfe,0x80,chs		// reset mindegyik allomasnal.
 *	',',0xfe,0x81,chs		// cim infra adas inditas.
 *	',',0xfe,0x82,chs		// cim infra adas leallitas.
 *	',',0xfe,0x70,chs		// test start, mindegyik allomasnal.
 *	',',0xfe,0x71,chs		// test stop , mindegyik allomasnal.
 *	'!',lcount xor hcount,uj cim,chs	// uj cim kuldes. (lcount xor hcount: all. kapott szamlalo xor erteke).
 *  Install:
 *	'?',0xfe,0x90,chs		// reset cim mindegyik allomasnal. 
 *  '?',cim,0x90,chs		// cim torlese.
 *  '?',0xaa,0x55,chs		// reset all. cim utana uj cim kepzest indit, ha nincs mar cime.
 *	'?',lcount xor hcount,uj cim,chs // uj cim kuldes. (lcount xor hcount: all. szamlalo xor erteke).
 *	'?',uj cim,0,chs 		// uj cim kuldes.
 *  chs = cim+parancs
 *  cim 					// allomas cim.
 *
 *	Vetel:
 *	';',cim,parancs,chs:
 *	';',cim,0x0x,chs		// x: D0,D1,D2,D3 input.
 *	';',cim,0x8x,chs		// x: D0-D6 uj cim,D7=1: uj cim.
 *  Install:
 *  '!',0xaa,lcount xor hcount,chs	// all. bejelentkezik uj cimert,(lcount xor hcount: all.szamlalo xor erteke).
 *	'!',uj cim,0,chs 		// uj cim vetele.
 *  chs = cim+parancs	
 *  cim 			
 */


 
#include <avr\io.h>
#include <compat\ina90.h>
#include <stdio.h>
#include <string.h>

#include "macros.h"
#include "utils.h"
#include "Kozpont.h"
#include "Kloop.h"
#include "K1loop.h"
#include "KTouch.h"
#include "KConfig.h"
#include "KCom.h"


/*---------------------- konstansok -----------------------------*/

/*----------------------- valtozok ------------------------------*/
// transm.

uint8_t all_ask_index;
uint8_t got_rand_all_addr,put_new_all_addr;
CHANNELtype all_array[COMM_MAX_ADDR+1];
uint8_t install;
CHN_ASK chn_ask;


//uint8_t rx_error;

/***********************************************************
 * init resz.
 ***********************************************************/

void chl1_com_init(void)
{
	l_com_init(BAUD2400_16);
	chn_ask.num = 0;
	l1channels_load(all_array);
	config_l1load_addr();
//	CHANNELtype data = FirstAll();
	tx_max_sended_num  = LTX_MAX_SENDED_NUM;
	rx_max_receive_num = LRX_MAX_RECEIVE_NUM;
	chn_ask.num = 2;				// infra off;
	chn_ask.chn.addr = 0xfe;
	chn_ask.chn.cmd  = 0x82;
	chl1_tx_send(&chn_ask.chn);		// elso kerdezes, ami cim kereses.
	

	//allloopenable = 1;
}//all_com_init(void)

/***********************************************************
 * allomas tomb feldolgozo fg.-ek resz.
 ***********************************************************/
CHANNELtype NextAll(void)
{	
	++all_ask_index;

	all_ask_index = (all_ask_index > alladdrnumenable) ? 0 : all_ask_index;
/*	while ((all_ask_index<alladdrnumenable))
	{	
		if (!all_ask_index)
			break;
		if (all_array[all_ask_index].addr)
			break;
		++all_ask_index;
		if ((all_ask_index>=alladdrnumenable))
			all_ask_index=0;
	}*/	
	return all_array[all_ask_index];
}//CHANNELtype* NextAll(void)

CHANNELtype CurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return all_array[all_ask_index];
	return all_array[0];
}//CHANNELtype* CurrAll(void)


CHANNELtype* pCurrAll(void)
{
	if (all_ask_index <= alladdrnumenable)
		return &all_array[all_ask_index];
	return &all_array[0];
}//CHANNELtype* CurrAll(void)

CHANNELtype FirstAll(void)
{
	all_ask_index = 0;
	return all_array[0];
}//CHANNELtype* FirstAll(void)

void set_cmd_all_All(uint8_t cmd)
{
	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		all_array[index].cmd = cmd;
	}
}//void set_cmd_all_All(uint8_t cmd)

/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
void chl1_rx_controlling(volatile unsigned char* pData)
{
#ifdef DEBUG	
	sprintf(msg,"rx -- addr:0x%x,data 0x%x",pData[1],pData[2]);
	PutString(msg);
#endif

    if (install_receiver(pData))
		return;

	CHANNELtype chan = CurrAll();

	//	char msg[40];
		

	if (*pData != R_STR_CHAR)
	{
		return;
	}
	pData++;
	
	if (*pData == chan.addr)
	{  // kerdezett allomas cime jott.		
		if (chl1_rx_data(pData))
		{
			l_set_error_flag(ERR_NONEflag,&chan);
			return;		
		}
	}			
	l_set_error_flag(ERR_CONTflag,&chan);
//	l_set_error_flag(ERR_NONEflag);
//	PutString("???????");


}//comm_rx_controlling(...)

//----------------------------------------------------
// check summa vizsgalata.
unsigned char  IsGoodCheckSumma(volatile unsigned char* pData)
{
	return (*pData + *(++pData)== *(++pData) );
}//IsGoodCheckSumma(unsigned char* pData)


//----------------------------------------------------
// altalanos lekerdezes
uint8_t chl1_rx_data(volatile unsigned char* pData)
{
	if (IsGoodCheckSumma(pData))
	{
		CHANNELtype* chan = SearchAll(*pData);
		if (chan->addr == 0xaa)
			return 0;		
		chan->data = (*(++pData)) & 0x3f;

	//	char temp[50];
	//	sprintf(temp,"kapott: addr: 0x%x, data: 0x%x",chan->addr,chan->data);
	//	PutString(temp);
		return 1;
	}
	else
		return 0;

}//void rx_data(unsigned char* pData)

/***********************************************************
 *  Adas  resz.
 ***********************************************************/
 
void chl1_tx_send(CHANNELtype* ptrData)
{
	if (ptrData)
	{		
        txBuffer[1] = ptrData->addr;
		if  (ptrData->cmd == 0x90)
			txBuffer[0] = S1_STR_CHAR;
		else
			txBuffer[0] = S_STR_CHAR;
        if  (ptrData->addr == 0xaa)
        {// uj install kerdes.
			if (!config.install)				
				return;
            SET_LSTATUS(L1INSTALL)
			SET_INSTALL(BEJ_INST)
			got_rand_all_addr = 0;
			put_new_all_addr = 0;
            txBuffer[0] = S1_STR_CHAR;
            txBuffer[2] = ptrData->cmd;
        }
        else
        {						
			if   (txBuffer[1] == 0xfe)
			{
				txBuffer[2] = ptrData->cmd;			
			}
			else
				txBuffer[2] = /*(ptrData->out & 0x0f)*/ ((ptrData->data & 0xf0) >> 4)| (ptrData->cmd & 0xf0);			
		//	lcd_set_chan_addr(ptrData->addr);
		}		

		txBuffer[3] = txBuffer[1] + txBuffer[2];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
		rx_max_receive_num = LRX_MAX_RECEIVE_NUM;
		l_tx_send_common();	
		lcd_set_loop_addr(1,ptrData->addr);
	}

}//void tx_send(void)

//-------------------------------------------------------------
void set_allomas_error(uint8_t loop,uint8_t addr,uint8_t err_bit)
{
	CHANNELtype* all = SearchAll(addr);
	//all->data = 0;
	all->data = err_bit;

}//void set_allomas_error(1,2,2)

/**********************************************************
 * Install resz.
 **********************************************************/

void install_tx_ujcim(void)
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = got_rand_all_addr;	
	txBuffer[2] = put_new_all_addr;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	l_tx_send_common();
}//void tx_bejentkezes(void)

void install_tx_ask_ujcim(void)
{
	txBuffer[0] = S1_STR_CHAR;
	txBuffer[1] = put_new_all_addr;	
	txBuffer[2] = 1;				// 1. loop.
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	l_tx_send_common();
}//void install_tx_ask_ujcim(void)

void install_tx_cim(void)
{
	txBuffer[0] = S_STR_CHAR;
	txBuffer[1] = put_new_all_addr;	
	txBuffer[2] = 0;
	txBuffer[3] = txBuffer[1] + txBuffer[2];
	l_tx_send_common();
}//void install_tx_cim(void)


uint8_t install_search_new_addr(void)
{
	uint8_t ii;
	CHANNELtype* pAll;

	for (ii=1; ii<COMM_MAX_ADDR; ii++)
	{
		pAll = SearchAll(ii);
		if ((pAll->addr > COMM_MAX_ADDR) || !pAll->addr)
			break;
	}
	return ii;
}//void install_search_new_addr(void)

uint8_t install_receiver(volatile unsigned char* pData)
{
	if (CHK_LSTATUS(L1INSTALL))
	{
		if (*pData == R1_STR_CHAR)
		{
			pData++;
			if (CHK_INSTALL(BEJ_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					got_rand_all_addr = *(++pData);
					put_new_all_addr = install_search_new_addr();
					if ((put_new_all_addr > 0) && (put_new_all_addr <= COMM_MAX_ADDR))
					{										
						CLRA_INSTALL;
						SET_INSTALL(PUT_ADDR_INST)		
#ifdef DEBUG										
						sprintf(msg,"INST:got_addr:0x%x",got_rand_all_addr);
#endif
						PutString(msg);
						DelayMs(100);
						install_tx_ujcim();
						rx_ready_s = 0;
						return 1;					
					}
				}
			}
			else
	//		if (CHK_INSTALL(ASK_ADDR_INST))
			if (CHK_INSTALL(PUT_ADDR_INST))
			{			
				if (IsGoodCheckSumma(pData))
				{
					if (*pData == put_new_all_addr)
					{  // sajat uj cimevel jott a valasz.															
						config_add_new_addr(put_new_all_addr);
						l1channels_add(all_array,put_new_all_addr);
			
						CLR_LSTATUS(L1INSTALL)
						CLRA_INSTALL
#ifdef DEBUG
						sprintf(msg,"INST:put_addr:0x%x",put_new_all_addr);
#endif
						PutString(msg);
						rx_ready_s = 0;
						DelayMs(100);
						install_tx_cim();
						return 1;
					}
				}
			}
		}
		install_error();
		return 1;
	}
	return 0;
}//uint8_t install_receiver(void)


void install_sender(void)
{
/*	if (CHK_INSTALL(PUT_ADDR_INST))
	{
		CLRA_INSTALL;
		SET_INSTALL(ASK_ADDR_INST)
		install_tx_ask_ujcim();
	}*/
}//void install_sender(void)

void install_error(void)
{
	if (CHK_LSTATUS(L1INSTALL))
	{
//		if (CHK_INSTALL(ASK_ADDR_INST))
		if (CHK_INSTALL(PUT_ADDR_INST))
		{
			chn_ask.num = 3;
			chn_ask.chn.cmd = 0x90;
			chn_ask.chn.addr = put_new_all_addr;
#ifdef DEBUG
			PutString("install_error:res addr");
#endif

		}
//		else
//			PutString("install_error--baj van");
		CLR_LSTATUS(L1INSTALL)
		CLRA_INSTALL
	}
}//void install_error(void)

