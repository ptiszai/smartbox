/*

 */
#include	<pic18.h>
#include	"ptk.h"

void ho_nap_szam(void);
void nyari_teli_ido(void);

const unsigned char nyari[] = 26,25,31,30,28,27,26,25,30,29,28,27,25,31,30,29,27,26,25,31,29,28,27,26,31,30,29,28,26,25,31,30,28;
const unsigned char teli[]  = 29,28,27,26,31,30,29,28,26,25,31,30,28,27,26,25,30,29,28,27,25,31,30,29,27,26,25,31,29,28,27,26,31;


//-------------------------------------------------
void ora_leptet(void)
{
unsigned char kar[4],io,pxo;


  if (sec<59)	{sec=sec+1;}
    else	
	{ 
	  px=EEPROM_READ(ev_e2);
	  px=px & 0b00011111;
	  perc=EEPROM_READ(perc_e2+px);

	  if (sec>=59) 
		{
		sec=0;
        status_1perc=1;
		}
	 	if (perc<59)  
			{			
			  perc++;
		   	  EEPROM_WRITE(perc_e2+px,perc);
			  perc15_mentes();
			}
			else
			{ if (perc>=59)
				{
		     	  EEPROM_WRITE(perc_e2+px,0);		//perc_nulla;
				  status_ora=1;
				}
				ora=EEPROM_READ(ora_e2);
				if (ora<23)
				  {
				  ora++;
				  EEPROM_WRITE(ora_e2,ora);
				  nyari_teli_ido();				//		ny�ri -	t�li ora�ll�r�s
				  }
				else
				 
					{ ho_nap_szam();

					 if (ora>=23) {EEPROM_WRITE(ora_e2,0);ora=0;}						//ora=0;
						if (nap<nap_szam) { nap++; EEPROM_WRITE(nap_e2,nap); }
						else
							{if (nap>=nap_szam){EEPROM_WRITE(nap_e2,1);}		//nap=1;		

								if (ho<=12){ ho++; EEPROM_WRITE(ho_e2,ho);}
									if  (ho>=13)
									  {

										pxo=EEPROM_READ(ev_e2);
										pxo=pxo & 0b00011111;
										pxo=(pxo << 2);
										for(io=0;io<4;io++)
 											{
											kar[io]=EEPROM_READ(v_orai_e2+(pxo+io));  //EEPROM_READ(addr)			
											}
										for(io=0;io<4;io++)
											{
   											EEPROM_WRITE(v_orai_e2+(pxo+io),0); 	 //EEPROM_WRITE(addr, value)			
											}


										EEPROM_WRITE(ho_e2,1);			//	ho=1;
										ev=ev+1;
										EEPROM_WRITE(ev_e2,ev); 

	  									px=EEPROM_READ(ev_e2);
	  									px=px & 0b00011111;
	  									perc=EEPROM_READ(perc_e2+px);
					      		     	EEPROM_WRITE(perc_e2+px,0);		//perc_nulla;									
  									
										pxo=EEPROM_READ(ev_e2);
										pxo=pxo & 0b00011111;
										pxo=(pxo << 2);
										for(io=0;io<4;io++)
											{
   											EEPROM_WRITE(v_orai_e2+(pxo+io),kar[io]); 	 //EEPROM_WRITE(addr, value)			
											}


  	} 		}		}		} 		  }		


 return;
}
//--------------------------------------------------------------------------------------------------------

void nyari_teli_ido(void)
{
unsigned char aa; 

nap=EEPROM_READ(nap_e2);
ho=EEPROM_READ(ho_e2);
ev=EEPROM_READ(ev_e2);
px=ev & 0b00011111;

ora_allitas=0;
EEPROM_WRITE(elozo_orai_status,0);

//---------- ny�ri ---------
if (ho == 3)
	{
	aa=nyari[px];
	if (nap == aa)	
		{
		if (ora == 2)
			{
			ora++;
			EEPROM_WRITE(ora_e2,ora);	
	   		EEPROM_WRITE(v_e_napi+50,1);
	   		EEPROM_WRITE(elozo_orai_status,1);

			ora_allitas=1;


			}
		}
	}
//---------- t�li -----------
if (ho == 10)
	{
	aa=EEPROM_READ(teli_atallas);
	if (aa == 0)
		{
		aa=teli[px];
		if (nap == aa)	
			{
			if (ora == 3)
				{
				ora--;
				EEPROM_WRITE(ora_e2,ora);	
				ora_allitas=2;
				EEPROM_WRITE(teli_atallas,2);
		   		EEPROM_WRITE(v_e_napi+50,2);
				}
			}
		}
	}

} //void



//////////////////////////////////////////////////////////////

void ho_nap_szam(void)
{
	nap=EEPROM_READ(nap_e2);
	ho=EEPROM_READ(ho_e2);
	ev=EEPROM_READ(ev_e2);
	switch (ho)
	{	
		case 0 : {EEPROM_WRITE(ho_e2,1); nap_szam=31; break; }
		case 2 :
			{ if ((ev && 0x0003)==0)
			  	nap_szam=29;
				else
				nap_szam=28;
			  break;
			}
		case 4 : case 6 :  case 9 :  case 11 :
			{
			  nap_szam=30;
			  break;
			}
	default : nap_szam=31;
	}
	return;
}

////////////////////////////////////////////////////////////

void ora_ascii(void)
{
px=EEPROM_READ(ev_e2);
px=px & 0b00011111;
perc=EEPROM_READ(perc_e2+px);
ora=EEPROM_READ(ora_e2);
nap=EEPROM_READ(nap_e2);
ho=EEPROM_READ(ho_e2);
ev=EEPROM_READ(ev_e2);

disp_sor[0]=0x32;
disp_sor[1]=0x30;
disp_sor[2]=(ev/10)+0x30;
disp_sor[3]=(ev-((ev/10)*10))+0x30;	
disp_sor[4]=0x2d;
disp_sor[5]=(ho/10)+0x30;
disp_sor[6]=(ho-((ho/10)*10))+0x30;	
disp_sor[7]=0x2d;
disp_sor[8]=(nap/10)+0x30;
disp_sor[9]=(nap-((nap/10)*10))+0x30;
disp_sor[10]=0x20;
disp_sor[11]=0x20;
disp_sor[12]=(ora/10)+0x30;
disp_sor[13]=(ora-((ora/10)*10))+0x30;
disp_sor[14]=0x3a;
disp_sor[15]=(perc/10)+0x30;
disp_sor[16]=(perc-((perc/10)*10))+0x30;
disp_sor[17]=0x3a;
disp_sor[18]=(sec/10)+0x30;
disp_sor[19]=(sec-((sec/10)*10))+0x30;
	
return;
} 
////////////////////////////////////////////////////////////////

