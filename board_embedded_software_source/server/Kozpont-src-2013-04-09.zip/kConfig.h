#ifndef _CONFIG_H_
#define _CONFIG_H_

//#include "K1loop.h"
#include  "KLoop.h"
#include  "K1loop.h"
#include  "KMloop.h"


#define VERSION 0x03;

// config eeprom address
#define	EE_VERSION		0
#define EE_LOOP_NUM		EE_VERSION + 1
#define	EE_PHERIPH		EE_LOOP_NUM + 1
#define	EE_LOOP_TYPE 	EE_PHERIPH + 1
#define	EE_WEEKLY		EE_LOOP_TYPE + 1
#define	EE_ANNUAL		EE_WEEKLY + 3
#define	EE_TEST_HM		EE_ANNUAL + 3
#define	EE_INSTALL_STOP	EE_TEST_HM + 3
#define	EE_TOUCH_R		EE_INSTALL_STOP + 2
#define	EE_TRIAL_MODE   EE_TOUCH_R + 8
#define	EE_END			EE_TRIAL_MODE + 1


// channels part of l loop.
#define EE_L1CH_NUM			32
#define EE_1CH_BEGIN 		EE_L1CH_NUM + 1
#define EE_LOOP_GROUP_SIZE 	130

struct _config 
{
    uint8_t 	ver;			//	verzio
	uint8_t 	trial;			// trial:40 perc utan leall mod: 0xaa;  40 perc utan leall, villog: 0x55; kikapcsolva minden mas ertek: 0xff
    uint8_t		weekly_test[3]; //  weekly test, day, month, year
	uint8_t		annual_test[3]; //  annual test, day, month, year
	uint8_t		annual_HM_test[2]; //  annual test, hours,mins 
	uint8_t		pheriph;		//  pheripherie:0  serial, 1 usb, 2 eth.
	uint8_t		loop_type;		//  loop:0  1loop, 1 more loop.
	uint8_t		infra;			//  infra on/off;
	uint8_t		install;		//  install on/off;
	uint16_t	install_min;		//  install stop in min.
	uint16_t	touch_r_x_min;  // adc touch 
	uint16_t	touch_r_y_min;  // adc touch 
	uint16_t	touch_r_x_max;  // adc touch 
	uint16_t	touch_r_y_max;  // adc touch 
};
/*
struct _channel_config 
{
    
};*/

void config_save(void);
void config_load(void);

extern void eecontentwrite(void);
extern struct _config config;
extern void config_loop_save(uint8_t laddr_a);
extern void config_weekly_save(uint8_t year, uint8_t month,  uint8_t day);
extern void config_annual_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a);
extern void config_pheriph_save(uint8_t mode_a);
extern void config_loop_type_save(uint8_t mode_a);
extern void config_add_new_addr(uint8_t new_addr);
extern void config_remove_alladdr(void);
extern uint8_t config_remove_1_addr(uint8_t loop, uint8_t addr);
extern void l1channels_load(CHANNELtype* chn);
extern void l1channels_add(CHANNELtype* chn, uint8_t new_addr);
extern uint16_t all_addr[COMM_MAX_ADDR+3];
extern void config_l1load_addr();
extern uint8_t alladdrnumenable;
extern uint8_t allloopnumenable;
extern void lmchannels_load(LOOPtype* ll);
extern void config_annual_HM_save(uint8_t hours_a, uint8_t mins_a);
extern void config_install_save(uint8_t time);
extern void Reset();
extern void config_trial_save(uint8_t trial_a);
extern void config_trial_read();
#endif
