#ifndef FONTS_H
#define FONTS_H


#define LARGE_FONT	1


#ifdef LARGE_FONT 

extern const uint8_t Font12x16[] PROGMEM;
//#else
//extern const uint8_t Font6x8[] PROGMEM;
//#endif
#endif

#endif
