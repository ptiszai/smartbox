#include <avr\io.h>
#include <compat\ina90.h>
#include <stdio.h>
#include <string.h>

#include "macros.h"
#include "utils.h"
#include "KLoop.h"
#include "K1loop.h"
#include "KMloop.h"
#include "Kozpont.h"
#include "KTouch.h"
#include "KConfig.h"
#include "KCom.h"

volatile unsigned char	txBuffer[MTX_MAX_SENDED_NUM+1]; // transm. buffer
uint8_t   tx_head;
// receive.
volatile unsigned char	rxBuffer[MRX_MAX_RECEIVE_NUM+2]; // receive buffer
uint8_t   rec_head;

int8_t lstatus;
int8_t lerror;
uint8_t tx_max_sended_num;
uint8_t rx_max_receive_num;
uint8_t	rx_ready_s = 0;
uint16_t l_timercount;
uint8_t l_recTotalTimeoutMultiplier;
unsigned char test_kliens[8];

//
/***********************************************************
 * init resz.
 ***********************************************************/ 

void l_com_init(unsigned int baud)
{
//	DDRF |=(1<<DDF6)|(1<<DDF7);
	sbi(DDRF,DDF6);
	sbi(DDRF,DDF7);
	RS485_DE0_OFF
	RS485_RE0_OFF
//	unsigned int baud=BAUD2400_16;
 	UCSR0A = 0x00;
 	UBRR0H = (unsigned char)(baud>>8);
 	UBRR0L = (unsigned char)baud;
#ifdef ELSZALLT
	UCSR0B = (1<<TXEN0);
//	UCSRB = (1<<TXEN) ;
#else
 	UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0);
#endif
	UCSR0C = (3<<UCSZ00);
	
#ifdef ELSZALLT
	// elszallt a rx0 rs485-nel!!!
	UCSR1A = 0x00;
 	UBRR1H = (unsigned char)(baud>>8);
 	UBRR1L = (unsigned char)baud;
 	UCSR1B = (1<<RXEN1)|(1<<TXEN1)|(1<<RXCIE1);
//	UCSR1B = (1<<TXEN1) ;
	UCSR1C = (3<<UCSZ10);
	// elszallt a rx0 rs485-nel!!!
#endif
	
		
//	RS485_LED_OFF
	tx_head=0;
	rec_head=0;
    lstatus = 0;
    lerror = 0;
	SET_LSTATUS(RX)	
}//all_com_init(void)
/*
// Calculate UBRR correctly using large temp variables
      uint32_t temp;
      temp = xtal/16/baud-1;
      UBRRH = (temp >> 8);
      UBRRL = (temp & 0xFF);

   // Initialize UCSRB
      UCSRB= (1 <<RXEN | 1 << TXEN );
   
   // Initialize UCSRC cprrect;y
      UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0);
    */

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/

void l_com_rx_tx(void)
{
	//static uint8_t	rx_ready_s = 0;

	if (CHK_LSTATUS(RX))
	{		
		if (CHK_LSTATUS(RX_READY))
		{			
		//	PutString("RXREADY");		
			CLR_LSTATUS(RX_READY)
		//	CLR_STATUS(RX)
			rx_ready_s = 1;

			//if (config.loop_type)
				chlm_rx_controlling(rxBuffer,&chn_ask);
	/*		else
				chl1_rx_controlling(rxBuffer);*/				
				RS485_RE0_OFF			
				RX0_OFF
				time_out(1,RX_TIME_TO_TX1);		
		}
		else				
		if (CHK_LERROR(RX_LERROR))
		{			
			CLR_LERROR(RX_LERROR)	
			CLR_LSTATUS(RX_READY)
	//		RS485_LED_OFF
			time_out(1,RX_TIME_TO_TX2);
			if (config.loop_type)
				chlm_set_error_flag(ERR_RXflag);
	/*		else
			{
				l_set_error_flag(ERR_RXflag, pCurrAll());
				install_error();
			}*/
#ifdef DEBUG
			PutString("Rec error1");lllll
#endif
			RS485_RE0_OFF			
	//		RX0_OFF
			
		}
		else
		if (time_out(0,0))
		{// adast indit.
		
			if (!rx_ready_s)
			{
				if (config.loop_type)
					chlm_set_error_flag(ERR_TOflag);
	/*			else
				{
					l_set_error_flag(ERR_TOflag, pCurrAll());
					install_error();
				}*/
			}
			else
				rx_ready_s = 0;

			
			if (chn_ask.num)
			{// kozpont kerdez 1.-et.			
				
				chn_ask.num--;	
			//	if (config.loop_type)
					klm_tx_send(&chn_ask);
	/*			else
				{
					chl1_tx_send(&chn_ask.chn);
					if (!chn_ask.num && ((chn_ask.chn.cmd  == 0x71) || (chn_ask.chn.cmd  == 0x82)))				
						lcd_set_chan_cmd("                 ");
				}*/
				rx_ready_s = 1;				
			}
			else
			{
		
			//	if (config.loop_type)
			//	{	// more
						LOOPtype* data = NextLoop();
						if (data)
							chlm_tx_send(data);
			//	}
	/*			else
				{ 	// 1.
						CHANNELtype data = NextAll();
						if (!config.install && !all_ask_index)									
							data = NextAll();
					
						if (CHK_SYSSTATUS(SYS_TEST2) || CHK_SYSSTATUS(SYS_TEST40))
						{
							if (data.addrh == 0xaa)
								data = NextAll();
						}
						chl1_tx_send(&data);
				}*/			
			}			
		}
	}
	else
	if (CHK_LSTATUS(TX_READY))
	{ // tx end.
		TX0_OFF			
		rec_head=0;
		delayms(10);
		RS485_DE0_OFF
		delayms(10);		
		RS485_RE0_ON
		delayms(5);
	//	TX0_OFF	
		RX0_ON 
		CLR_LSTATUS(TX_READY)
		CLR_LSTATUS(TX)
		SET_LSTATUS(RX)
		if (CHK_LSTATUS(L1INSTALL))
			time_out(1,RX_TIME_TO_TX4);		
		else
		{
			if (chn_ask.num && chn_ask.timeout)	
				time_out(1,chn_ask.timeout);	
			time_out(1,RX_TIME_TO_TX3);	
		}
	//		PutString("Txt end");		
	//	RS485_LED_OFF
	}
}//void all_com_rx_tx(void)


/***********************************************************
 *  Adas  resz.
 ***********************************************************/

 void l_tx_send_common(void)
 {
#ifdef DEBUG
 	//	sprintf(msg,"tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	sprintf(msg,"tx -:%c,0x%x,0x%x,0x%x,0x%x,0x%x,chs:0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3],txBuffer[4],txBuffer[5],txBuffer[6]);
	//	PutString(msg);
#endif			
		CLR_LSTATUS(RX)	
		RS485_RE0_OFF			
		DelayMs(10);	
		RS485_DE0_ON
		delayms(10); 					
		tx_head=0;
		TX0_ON		
		SET_LSTATUS(TX)		

 }//void 1_tx_send_common(void)


/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t time_out(uint8_t start,uint16_t diff)
{	
//	static uint8_t overflow = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		l_timercount = 0;
		_time_out = diff;
	//	overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
	/*	if (overflow)
		{
			if (timercount > _time_out)
				return 0;
			else
				overflow = 0;
		}
		else*/
		if (l_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t time_out(uint8_t start,uint8_t diff)

/***********************************************************
 * inturrept resz.
 ***********************************************************/
 /**********************************************************
 * COM adas int.
 **********************************************************/
unsigned char l_tx_int()
{	
//	++tx_head;
	if (tx_head>=tx_max_sended_num)
	{
		SET_LSTATUS(TX_READY)
		CLR_LSTATUS(TX_INT)
		TX0_OFF
		return 1;
	}
	return  txBuffer[tx_head++];
}//unsigned char l_tx_int()

/**********************************************************
 * COM vetel int.
 **********************************************************/
 /*char l_IsRecFinished()
 {
	if ((rec_head >= rx_max_receive_num) || (l_recTotalTimeoutMultiplier >= 2))
	{
		rec_head=0;
//		RCIE = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LSTATUS(RX_READY)
		return 1;
	}
	return 0;
 }*/

void l_rx_int( unsigned char ucData)
{	 
	static unsigned char Frame = 0;

	if (!rec_head)
		Frame = ucData;

	if (rec_head == 1)
	{
		if (Frame == R2_STR_CHAR)
		{// uzenet		
			rx_max_receive_num = ucData;
		}
	}
	if (rec_head == 3)
	{
		if (Frame == R3_STR_CHAR)
		{// addres list		
			rx_max_receive_num = ucData*2 + 5;
		}
	}
//		l_recTotalTimeoutMultiplier = 0;

	rxBuffer[rec_head] = ucData;
	++rec_head;
	//	PutString("1");

	if (rec_head >= rx_max_receive_num /*|| (RecTotalTimeoutMultiplier >= 2)*/)
	{
		rec_head=0;
//		RCIE = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LSTATUS(RX_READY)
		//PutString("E");
		return;
	}
//	l_IsRecFinished();
//	l_recTotalTimeoutMultiplier = 0;	
	return;
}//void l_rx_int(..)

//----------------------------------------------------
void l_set_error_flag(CHERRFLAG flag_a,CHANNELtype* chan)
{

}//void l_set error_flag(uint8_t flag_a)



void test_set_kliens_rec()
{
	if (!test_kliens[0])
		return;

	LOOPtype* lp = CurrLoop();	
	if (test_kliens[0] == lp->loop)
	{//';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.	
		rxBuffer[0]=';';
		for(int ii=0;ii<7;ii++)
			rxBuffer[ii+1]=test_kliens[ii];
		test_kliens[0] = 0;
		RS485_RE0_OFF
		RX0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LSTATUS(RX_READY)
		SET_LSTATUS(RX)			
	}
}
