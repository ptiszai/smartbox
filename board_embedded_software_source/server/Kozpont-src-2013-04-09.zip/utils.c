#include <avr/io.h>
#include <util/delay.h>
#include <avr/wdt.h> 
#include "utils.h"

uint8_t bcd2bin(uint8_t bcd)                    
{
#ifdef OPTIMIZE_SPEED
  return (10*(bcd>>4)|(bcd&0x0f));
#else
  uint8_t Temp = bcd & 0x0F; 
  while (bcd>=0x10) 
  { 
    Temp += 10; 
    bcd -= 0x10; 
  } 
  return Temp; 
#endif
}

uint8_t bin2bcd(uint8_t bin)                    
{
#ifdef OPTIMIZE_SPEED
  return (((bin/10)<<4)|(bin%10));
#else
  uint8_t Temp = 0; 
  while(bin>9) 
  { 
    Temp += 0x10; 
    bin-=10; 
  } 
  return Temp+bin; 
#endif
}

void byte2dec(uint8_t val, char *s)  
{
  s[0]='0'+(val/10);
  s[1]='0'+(val%10);
  s[2]=0;
}

char nibble2hex(uint8_t val)  
{
  char s;
  s='0'+(val&0xf);
  if (s>'9') s+='A'-'9'-1;
  return s;
}


void byte2hex(uint8_t val, char *s)  
{
  s[0]=nibble2hex(val>>4);
  s[1]=nibble2hex(val);
  s[2]=0;
}

void word2hex(uint16_t val, char *s)  
{
  s[0]=nibble2hex(val>>12);
  s[1]=nibble2hex(val>>8);
  s[2]=nibble2hex(val>>4);
  s[3]=nibble2hex(val);
  s[4]=0;
}

// us-es kesleltetes.

void delayus(uint16_t us)
{
  uint16_t delay_loops;
  register uint16_t i;
  delay_loops = us/5*CYCLES_PER_US;
//  _delay_loop_2 (delay_loops);
  for (i=0; i < delay_loops; i++)
  {
    wdt_reset();
  };
}

void delay10us(void)
{
  delayus(5);
}

void delayms(uint16_t count)
{
  while (count-- != 0)
    delayus(1000);
}

// ms-es kesleltetes.
void DelayMs(uint16_t ms)
{
	uint16_t i;
	for (i=0;i<ms;i++)
		_delay_ms (1);
}//void DelayMs(uint8_t ms)
