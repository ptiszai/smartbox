#ifndef _KCOM_H
#define _KCOM_H

/*
DPU-D2-00A-E:115200,8,NONE,1
PC COM ebben az esteban nincs
*/
#define SERIAL_PRINTER				1

//
// com. part
#define P_COM_ETH			0x40	
#define COM_ETH_OFF  		PORTB &= ~P_COM_ETH;
#define COM_ETH_ON			PORTB |=  P_COM_ETH;

#define P_COM_RS			0x20	
#define COM_RS_OFF  		PORTB &= ~P_COM_RS;
#define COM_RS_ON			PORTB |=  P_COM_RS;

#define P_COM_USB			0x08	
#define COM_USB_OFF  		PORTC &= ~P_COM_USB;
#define COM_USB_ON			PORTC |=  P_COM_USB;

#define P_COM_TTL			0x80	
#define COM_TTL_OFF  		PORTB &= ~P_COM_TTL;
#define COM_TTL_ON			PORTB |=  P_COM_TTL;

#define COM_ALL_OFF  		{ COM_ETH_OFF; COM_RS_OFF; COM_USB_OFF; COM_TTL_OFF } ;

//#define RX0_OFF 			UCSR0B &= 0x6f;
//#define RX0_ON 				UCSR0B |= 0x90;

#define RX1_OFF 			UCSR1B &= 0x6f;
#define RX1_ON 				UCSR1B |= 0x90;

#define CLR_COM0(x)			{com0_state &= (~x);};
#define SET_COM0(x)			{com0_state |= (x);};
#define CHK_COM0(x)			(com0_state & (x))

#define CLR_COM1(x)			{com1_state &= (~x);};
#define SET_COM1(x)			{com1_state |= (x);};
#define CHK_COM1(x)			(com1_state & (x))

// status bits
#define RX_DATA				0x1
#define RX_ERROR			0x2


//#define	REC0_MAX_LENGTH		50
#define	REC1_MAX_LENGTH		35

typedef enum 
{
    COMPORTeth  = 0,
    COMPORTrs232,
    COMPORTusb,
    COMPORTttl
}COMPORTtype;


extern void PutChar( char byte );
extern void PutDatas( char *data, uint8_t length );
extern void PutString( const char *str);
extern void PutInt16( uint16_t data );
extern void PutInt32( uint32_t data );
extern char	com0_state;	
extern char	com1_state;	
extern void addrlist_print_com();

#ifdef SERIAL_PRINTER
extern void PutPrinter( const char *str);
#endif

extern uint16_t rx1_timercount;

void com0_init(void);
void com1_init(void);
void rx1_add_data(uint8_t data);
uint8_t rx1_time_out(uint8_t start,uint8_t diff);
void rx1_executor(void)	;
void set_com_port(COMPORTtype mode);

#endif
