#ifndef _PCF8583_H
#define _PCF8583_H


// i2c part

#define I2C_PORT	PORTD	
#define I2C_SDA		1	
#define I2C_SCL 	0

#define I2C_PORT_O	I2C_PORT
#define	I2C_PORT_D	DDR(I2C_PORT)
#define I2C_PORT_I	PIN(I2C_PORT)

#define I2C_SDA_WR	sbi(I2C_PORT_D,I2C_SDA)
#define I2C_SDA_RD	cbi(I2C_PORT_D,I2C_SDA)
#define I2C_SCL_WR	sbi(I2C_PORT_D,I2C_SCL)
#define I2C_SCL_RD	cbi(I2C_PORT_D,I2C_SCL)

#define I2C_SDA_H	sbi(I2C_PORT_O,I2C_SDA)
#define I2C_SDA_L	cbi(I2C_PORT_O,I2C_SDA)
#define I2C_SCL_H	sbi(I2C_PORT_O,I2C_SCL)
#define I2C_SCL_L	cbi(I2C_PORT_O,I2C_SCL)
	
#define PCF8583_A0	1

uint8_t I2C_write(uint8_t b);
uint8_t I2C_read(uint8_t ack);
void I2C_start(void);
void I2C_stop(void);


// PCF8583

uint8_t PCF8583_read(uint8_t address);

void PCF8583_write(uint8_t address, uint8_t data);
uint8_t PCF8583_read_bcd(uint8_t address);
void PCF8583_write_bcd(uint8_t address,uint8_t data);
uint8_t PCF8583_get_status(void);
void PCF8583_init(void);
void PCF8583_stop(void);
void PCF8583_start(void);
void PCF8583_hold_off(void);
void PCF8583_hold_on(void);
void PCF8583_alarm_off(void);
void PCF8583_alarm_on(void);
void PCF8583_write_word(uint8_t address,uint16_t data);
void PCF8583_write_date(uint8_t address,uint8_t day,uint16_t year);
void PCF8583_get_time(uint8_t *hour,uint8_t *min,uint8_t *sec,uint8_t *hsec);
void PCF8583_set_time(uint8_t hour,uint8_t min,uint8_t sec,uint8_t hsec);
void PCF8583_get_date(uint8_t *day,uint8_t *month,uint8_t *year);
void PCF8583_set_date(uint8_t day,uint8_t month,uint8_t year);
void PCF8583_get_alarm_time(uint8_t *hour,uint8_t *min,uint8_t *sec,uint8_t *hsec);
void PCF8583_set_alarm_time(uint8_t hour,uint8_t min,uint8_t sec,uint8_t hsec);
void PCF8583_get_alarm_date(uint8_t *day,uint8_t *month);
void PCF8583_set_alarm_date(uint8_t day,uint8_t month);

void PCF8563_set_alarm_weekday(uint8_t day);
void PCF8563_set_alarm_day(uint8_t day);
void PCF8563_set_alarm_min(uint8_t min);
void PCF8563_set_alarm_hour(uint8_t hour);

uint8_t PCF8563_get_alarm(void);

//extern volatile uint8_t PCF8583_status;
//extern volatile u08 PCF8583_alarm;



#endif
