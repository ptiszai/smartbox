#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include  "KLoop.h"
#include  "K1loop.h"
#include  "KMloop.h"
#include  "KConfig.h"
#include  "KCom.h"
#include  "utils.h"
#include  "Kozpont.h"

struct _config config;

uint16_t all_addr[COMM_MAX_ADDR+3]; // 0.:loop;1.:addr.num.2.- :datas. (1 loop korben a maximalsi allomas szam es adata)
uint8_t alladdrnumenable;
uint8_t allloopnumenable;


uint8_t EEMEM eeprombyte1=0x08;		//verzio
//uint8_t EEMEM eeprombyte2=0x19;		//loop szama.
uint8_t EEMEM eeprombyte2=0x02;	//loop szama.
uint8_t EEMEM eeprombyte3=0x00;		//pheripheria cime.
uint8_t EEMEM eeprombyte4=0x01;		//more loop.

uint8_t EEMEM eeprombyte5=0x00;		//WEEKLY
uint8_t EEMEM eeprombyte6=0x00;		//WEEKLY
uint8_t EEMEM eeprombyte7=0x00;		//WEEKLY

uint8_t EEMEM eeprombyte8=0x00;		//ANNUAL
uint8_t EEMEM eeprombyte9=0x00;		//ANNUAL
uint8_t EEMEM eeprombyte10=0x00;	//ANNUAL

uint8_t EEMEM eeprombyte11=0x00;	//TEST_HM
uint8_t EEMEM eeprombyte12=0x00;	//TEST_HM
uint8_t EEMEM eeprombyte13=0x00;	//TEST_HM

uint8_t EEMEM eeprombyte14=0x2D;	//INSTALL_STOP
uint8_t EEMEM eeprombyte15=0x00;	//INSTALL_STOP

uint8_t EEMEM eeprombyte16=0xDC;	//TOUCH_R:R_X_MIN
uint8_t EEMEM eeprombyte17=0x00;	//TOUCH_R:R_X_MIN
uint8_t EEMEM eeprombyte18=0x2C;	//TOUCH_R:R_Y_MIN//45
uint8_t EEMEM eeprombyte19=0x01;	//TOUCH_R:R_Y_MIN

uint8_t EEMEM eeprombyte20=0x57;	//TOUCH_R:R_X_MAX
uint8_t EEMEM eeprombyte21=0x03;	//TOUCH_R:R_X_MAX
uint8_t EEMEM eeprombyte22=0x11;	//TOUCH:R_Y_MAX //ee
uint8_t EEMEM eeprombyte23=0x03;	//TOUCH:R_Y_MAX

uint8_t EEMEM eeprombyte24=0xFF;	//40 perc utan leall mod: 0xaa;  40 perc utan leall, villog: 0x55; kikapcsolva a trial mod: 0xff

uint8_t EEMEM eeprombyte25=0xcd;    // eeprom vege jel


/*
#define  LCD_R_X_MIN             (float)215
#define  LCD_R_Y_MIN             (float)325

#define  LCD_R_X_MAX             (float)870
#define  LCD_R_Y_MAX             (float)750*/

/*
const uint8_t eecontent[] =
{ 0x01,0x03,0x17,0x04,0x07,0x18,0x05,0x07,0x00,0x00, 
  0x04,0x01,0x02,0x03,0x04,
  0xff
};*/



uint8_t* 	addr_st = NULL;

void config_save(void)
{
	
}//void config_save(void)

void config_load(void)
{
	
	uint8_t		temp_data1,temp_data2;
	uint8_t* 	ee_addr = (uint8_t*)EE_VERSION;
	
	
	config.ver =  eeprom_read_byte(ee_addr);
	ee_addr = (uint8_t*)EE_WEEKLY;
	config.weekly_test[0] =  eeprom_read_byte(ee_addr);
	config.weekly_test[0] = (config.weekly_test[0] > 0x31) ? 1 : config.weekly_test[0];
	ee_addr++;
	config.weekly_test[1] =  eeprom_read_byte(ee_addr);
	config.weekly_test[1] = (config.weekly_test[1] > 0x12) ? 1 : config.weekly_test[1];
	ee_addr++;
	config.weekly_test[2] =  eeprom_read_byte(ee_addr);
	config.weekly_test[2] = (config.weekly_test[2] > 99) ? 10 : config.weekly_test[2];

	ee_addr = (uint8_t*)EE_ANNUAL;
	config.annual_test[0] =  eeprom_read_byte(ee_addr);
	config.annual_test[0] = (config.annual_test[0] > 0x31) ? 1 : config.annual_test[0];
	ee_addr++;
	config.annual_test[1] =  eeprom_read_byte(ee_addr);
	config.annual_test[1] = (config.annual_test[1] > 0x12) ? 1 : config.annual_test[1];
	ee_addr++;
	config.annual_test[2] =  eeprom_read_byte(ee_addr);
	config.annual_test[2] = (config.annual_test[2] > 99) ? 10 : config.annual_test[2];

	ee_addr = (uint8_t*)EE_TEST_HM;
	config.annual_HM_test[0] = eeprom_read_byte(ee_addr); //ora
	config.annual_HM_test[0] = ((config.annual_HM_test[0] > 23) || (config.annual_HM_test[0] < 0)) ? 6 : config.annual_HM_test[0];
	ee_addr++;
	config.annual_HM_test[1] = eeprom_read_byte(ee_addr); //perc
	config.annual_HM_test[1] = ((config.annual_HM_test[1] > 59) || (config.annual_HM_test[1] < 0)) ? 0 : config.annual_HM_test[1];

	ee_addr = (uint8_t*)EE_PHERIPH;
	config.pheriph =  eeprom_read_byte(ee_addr);
    config.pheriph = (config.pheriph > 2) ? 0 : config.pheriph; 
	ee_addr = (uint8_t*)EE_LOOP_TYPE;
	config.loop_type =  eeprom_read_byte(ee_addr);
    config.loop_type = (config.loop_type > 1) ? 0 : config.loop_type;

	ee_addr = (uint8_t*)EE_INSTALL_STOP;
	config.install_min =  ((uint16_t)eeprom_read_byte(ee_addr))*60;

	ee_addr = (uint8_t*)EE_TOUCH_R;
	temp_data1  = eeprom_read_byte(ee_addr);
	ee_addr++;
	temp_data2  = eeprom_read_byte(ee_addr);   
	config.touch_r_x_min =  ((uint16_t)temp_data2) * 256 + (uint16_t)temp_data1;

	ee_addr = (uint8_t*)(EE_TOUCH_R+2);
	temp_data1  = eeprom_read_byte(ee_addr);
	ee_addr++;
	temp_data2  = eeprom_read_byte(ee_addr);   
	config.touch_r_y_min =  ((uint16_t)temp_data2) * 256 + (uint16_t)temp_data1;

	ee_addr = (uint8_t*)(EE_TOUCH_R+4);
	temp_data1  = eeprom_read_byte(ee_addr);
	ee_addr++;
	temp_data2  = eeprom_read_byte(ee_addr);  
	config.touch_r_x_max =  ((uint16_t)temp_data2) * 256 + (uint16_t)temp_data1;

	ee_addr = (uint8_t*)(EE_TOUCH_R+6);
	temp_data1  = eeprom_read_byte(ee_addr);
	ee_addr++;
	temp_data2  = eeprom_read_byte(ee_addr);  
	config.touch_r_y_max = ((uint16_t)temp_data2) * 256 + (uint16_t)temp_data1;

	ee_addr = (uint8_t*)EE_TRIAL_MODE;		
	config.trial =  eeprom_read_byte(ee_addr);

//	sprintf(msg,"T_R_x_min:%d,T_R_y_min:%d,T_R_x_max:%d,T_R_y_max:%d",config.touch_r_x_min,config.touch_r_y_min,config.touch_r_x_max,config.touch_r_y_max);
//	PutString(msg);
    
}//void config_load(void)

/*******************************************
 * Save default constans.
 *******************************************/
void config_loop_save(uint8_t laddr_a)
{
 	addr_st = (uint8_t*)EE_LOOP_NUM;
	eeprom_write_byte((uint8_t*)addr_st,laddr_a);
	loops_load();
}//void config_loop_save(uint8_t laddr_a)

//-----------------------------------------------------------------
void config_install_save(uint8_t time)
{
 	addr_st = (uint8_t*)EE_INSTALL_STOP;
	eeprom_write_byte((uint8_t*)addr_st,time);
	config_load();
}//void config_install_save(uint8_t time)

//-----------------------------------------------------------------
void config_write(uint8_t data_a, uint16_t  addr_a, uint8_t bcd)
{
    addr_st = (uint8_t*)addr_a;
	if (bcd)
    	eeprom_write_byte((uint8_t*)addr_st,bin2bcd(data_a)); 
	else
		eeprom_write_byte((uint8_t*)addr_st,data_a); 
    delayms(10); 
}//void config_write(uint8_t data_a, uint8_t  addr)

//-----------------------------------------------------------------
void config_weekly_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a)
{    
    uint16_t 	addr = (uint16_t)EE_WEEKLY;
     
	config_write(day_a, addr, 0); 
	addr++;
	config_write(month_a, addr, 0); 
	addr++;
    config_write(year_a, addr,0); 
 /*   eeprom_write_byte((uint8_t*)addr,bin2bcd(day_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(month_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(year_a));
*/      
    config_load();          
}//void config_weekly_save(void)

//-----------------------------------------------------------------
void config_annual_save(uint8_t year_a, uint8_t month_a,  uint8_t day_a)
{
    uint16_t 	addr = (uint16_t)EE_ANNUAL;

	config_write(day_a, addr,0); 
	addr++;
	config_write(month_a, addr,0); 
	addr++;
    config_write(year_a, addr,0);
 /*  
    eeprom_write_byte((uint8_t*)addr,bin2bcd(day_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(month_a)); 
    addr++;
    eeprom_write_byte((uint8_t*)addr,bin2bcd(year_a));  
*/	 
    config_load();            
}//void config_weekly_save(void)

//-----------------------------------------------------------------
void config_annual_HM_save(uint8_t hours_a, uint8_t mins_a)
{
	addr_st = (uint8_t*)EE_TEST_HM;

	eeprom_write_byte((uint8_t*)addr_st,hours_a);
	addr_st++;
	eeprom_write_byte((uint8_t*)addr_st,mins_a);
	config_load(); 
}

//-----------------------------------------------------------------
void config_pheriph_save(uint8_t mode_a)
{
    config_write(mode_a, EE_PHERIPH,1);
    config_load();
}//void config_pheriph_save(uint8_t mode_a)

//-----------------------------------------------------------------
void config_loop_type_save(uint8_t mode_a)
{    
    config_write(mode_a, EE_LOOP_TYPE,1); 
    config_load();
}//void config_pheriph_save(uint8_t mode_a)

//-----------------------------------------------------------------
void config_trial_save(uint8_t trial_a)
{    
   	addr_st = (uint8_t*)EE_TRIAL_MODE;
	eeprom_write_byte((uint8_t*)addr_st, trial_a);
	config.trial = trial_a;
}//void config_trial_save(uint8_t trial_a)

//-----------------------------------------------------------------
void config_trial_read()
{   
	addr_st = (uint8_t*)EE_TRIAL_MODE;		
	config.trial =  eeprom_read_byte(addr_st);
}//void config_trial_read()

/*
//-----------------------------------------------------------------
uint8_t config_remove_1_addr(uint8_t loop, uint8_t addr)
{

	uint8_t 	ii;

	
	if ((loop <= 0 ) || (loop > COMM_MAX_LOOP) || (addr <= 0) || (addr > COMM_MAX_ADDR))		
			return 0;
//	loop
	
	if ((all_addr[0] <= 0) || (all_addr[0] > COMM_MAX_LOOP) || (all_addr[0] != loop) )
		return 0;



// address

	if ((all_addr[1] <= 0) || (all_addr[1] > COMM_MAX_ADDR))
		return 0;

	if (!config.loop_type)				
	{// 1
		if (loop != 1)
			return 0;
	}


	for (ii=2; ii<(all_addr[1]+2); ii++)
	{			

		if (all_addr[ii] == addr)
			break;
	}

	if (ii == (all_addr[1]+2))
		return 0;

	// megvan!
	all_addr[ii] = 0xff;

	for (; ii<(all_addr[1]+2); ii++)
		 all_addr[ii] = all_addr[ii+1];


	all_addr[1]--;

	return 1;
}//void config_remove_1_addr(uint8_t loop, uint8_t addr)
*/

/*******************************************
 * Factory default constans.
 *******************************************/
 /*
void eecontentwrite(void)
{
	uint8_t* 	ver = (uint8_t*)EE_VERSION;
	uint8_t	 	index = 0;
	uint8_t  	temp = eeprom_read_byte(ver);

	if ((temp > 0) && (temp < 128))
		return;
	while(eecontent[index] != 0xff)
	{
			eeprom_write_byte((uint8_t*)ver,eecontent[index]);	
			++index;		
			++ver;
			delayms(10);
	}
}//void eecontentwrite(void)
*/

/*******************************************
 * Cannels part.
 *******************************************/

void l1channels_load(CHANNELtype* chn)
{
/*	uint8_t* 	addr = (uint8_t*)EE_LOOP_NUM;
	uint8_t		ii=1;
	uint8_t  	temp = eeprom_read_byte(addr);

	if (temp && (temp <= COMM_MAX_LOOP))
		allloopnumenable = temp;
	else
		allloopnumenable = 0;

//	allloopnumenable = 3;		//!!!!!!!!!!!!!!!!!!!

	addr = (uint8_t*)EE_L1CH_NUM;	
	temp = eeprom_read_byte(addr);

	if (temp && (temp <= COMM_MAX_ADDR))
		alladdrnumenable = temp;
	else
		alladdrnumenable = 0;
		

	chn[0].addr = 0xaa;
	chn[0].cmd = 0x55;
	chn[0].data = 0x0f;
	chn[0].prev_data = 0;
//	chn[0].errornum = 0;
	all_ask_index = 0;

//	if (alladdrnumenable == 1)
//		return;

	if (!alladdrnumenable)
		return;
	
	++addr;
//	char mss[60];
	for (addr=(uint8_t*)EE_1CH_BEGIN; ii<(alladdrnumenable+1); ii++, addr++)
	{
		temp = eeprom_read_byte(addr);		
		if ((temp > 0) && (temp <= COMM_MAX_ADDR))
			chn[ii].addr = temp;	
		else
			chn[ii].addr = 0;
		
		chn[ii].cmd = 0;
		chn[ii].data = 0x06;	
		chn[ii].prev_data = 0x60;
//		chn[ii].errornum = 0x20;
//		sprintf(mss,"l1channels_load:alladdr:%x,ii:%x,addr:%x",alladdrnumenable,ii,chn[ii].addr);
//		PutString(mss);	
	}
	all_ask_index = 0;	
	//alladdrnumenable++;*/
}//void l1channels_load(CHANNELtype* chn)

/*******************************************/
void lmchannels_load(LOOPtype* ll)
{
	uint8_t* 	addr = (uint8_t*)EE_LOOP_NUM;
	uint8_t		ii=1;
	uint8_t  	temp = eeprom_read_byte(addr);

	if (temp && (temp <= COMM_MAX_LOOP))
		allloopnumenable = temp;
	else
		allloopnumenable = 0;

//	allloopnumenable = 3;		//!!!!!!!!!!!!!!!!!!!
			
	for (ii=0; ii<allloopnumenable; ii++)
	{
		ll[ii].loop = ii + 1;
		ll[ii].addr_num = 0;
		ll[ii].error = 0;
		ll[ii].summa_error = 0;
		ll[ii].chn.addrh = 0;
		ll[ii].chn.addrl = 0;
		ll[ii].chn.cmd = 0;
		ll[ii].chn.data = 0x07;
		ll[ii].chn.prev_data = 0x07;
		ll[ii].chn.error = 0;
		ll[ii].chn.stat = 0;
	}

	loop_ask_index = 0;

}//void lmchannels_load(CHANNELtype* chn)

//---------------------------------------------------
void l1channels_add(CHANNELtype* chn, uint8_t new_addr)
{	
/*	if (alladdrnumenable < COMM_MAX_ADDR)
	 	++alladdrnumenable;
	else
		alladdrnumenable = COMM_MAX_ADDR;

	chn[alladdrnumenable].addr = new_addr;
	chn[alladdrnumenable].cmd = 0;
	chn[alladdrnumenable].data = 0x06;	
	chn[alladdrnumenable].prev_data = 0x60;
*/
}//void l1channels_add(CHANNELtype* chn)


CHANNELtype IndexAll(uint8_t index)
{
	CHANNELtype res;
	return res;
/*	if (index <= alladdrnumenable)
		return all_array[index];
	else
		return all_array[0];*/
}//CHANNELtype* IndexAll(void)

CHANNELtype* SearchAll(uint8_t all_addressh, uint8_t all_addressl)
{
/*	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		//if (all_array[index].addr == all_address)
		if ((int)(all_array[index].addrh)*256 + (int)all_array[index].addrl == (int)(all_addressh)*256 + (int)all_addressl)
			return  &all_array[index];
	}
	return &all_array[0];*/
	return NULL;
	
}//CHANNELtype* IndexAll(void)
