#ifndef SED1335_H
#define SED1335_H

#include <avr/io.h>
/* #include <avr/signal.h>  -  obsolete */
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <string.h>
 	
//#include "lcd.h"
	
#define TABSIZE         4       /**< number of blanks to insert for a TAB */

#define LCD_DATA_PORT   PORTA
#define LCD_DATA_DDR    DDRA
#define LCD_DATA_MASK   0xff
#define LCD_DATA_IN     PINA
#define LCD_CTRL_PORT   PORTG
#define LCD_A0_PORT   	PORTC
//#define LCD_CTRL_DDR    DDRB
//#define LCD_CTRL_MASK   0xf0
#define LCD_WR_PIN      PG0     /**< low active, enable writing to the sed1335 controller */
#define LCD_RD_PIN      PG1     /**< low active, enable reading from the sed1335 controller */
#define LCD_A0_PIN      PC5     /**< command mode pin, if 1 the data is to be interpreted as command */
#define LCD_CS_PIN      PG2     /**< low active chip-select pin */


#define SYSTEM_SET      0x40            /**< init device and display */
#define SLEEP_IN        0x53            /**< enter standby mode */
#define DISP_OFF        0x58            /**< disable display and flashing */
#define DISP_ON         0x59            /**< enable display and flashing */
#define SCROLL          0x44            /**< set display start address and region */
#define CSRFORM         0x5d            /**< set cursor type */
#define CGRAM_ADR       0x5c            /**< set start address of char generator RAM */
#define CSRDIR_U        0x4e            /**< set direction of cursor movement - up */
#define CSRDIR_D        0x4f            /**< down */
#define CSRDIR_L        0x4d            /**< left */
#define CSRDIR_R        0x4c            /**< right */
#define HDOT_SCR        0x5a            /**< set horizontal scroll position */
#define OVLAY           0x5b            /**< set display overlay format */
#define CSRW            0x46            /**< set cursor address */
#define CSRR            0x47            /**< read cursor address */
#define MWRITE          0x42            /**< write to display memory */
#define MREAD           0x43            /**< read from display memory */
	
#define SCR_WIDTH        319             /**< graphical screen width (in pixels) - 1 */

/* system set parameters */
#define M0              0               /**< 0 internal character generation ROM, 1 external */
#define M1              0               /**< 0 no D6 correction, 1 D6 correction - see datasheet */
#define M2              0               /**< 0 8 pixel character height, 1 16 pixel height */
#define WS              0               /**< 0 single-panel drive, 1 dual panel drive */
#define IV              1               /**< 0 no origin compensation for inverse display */
//#define FX              7               /**< range: 0x00-0x07, character width - 1 in pixels */
#define FX              5               /**< range: 0x00-0x07, character width - 1 in pixels */
#define FY              7               /**< range: 0x00-0x0f, character height -1 in pixels */
#define WF              1               /**< 0 16 line AC drive, 1 two-frame AC drive */
//#define CR              39              /**< range: 0-239, address range covered by one line - 1 */
#define CR              52              /**< range: 0-239, address range covered by one line - 1 */
                                       /* --> e.g. 39 = 40 chars per line */
//#define TCR                     43              /**< length of a line (43) - (CR +4) */
#define TCR                     85              /**< length of a line (85) - (CR +4) */
#define LF              239             /**< height (in lines) of a frame */
//#define APL             40              /**< horiz. address range - LOW */
#define APL             53              /**< horiz. address range - LOW */
#define APH             0               /**< horiz. address range - HIGH */
#define LINES                   30              /**< number of text-lines */
	
/* scroll parameters */
#define SAD1L                   0               /**< layer 1 start address - LOW */
#define SAD1H                   0               /**< layer 1 start address - HIGH */
#define SL1             0xef            /**< number of lines (pixels) of layer 1 */
//#define SAD2L                   0xb0            /**< layer 2 start address - LOW */
//#define SAD2H                   0x04            /**< layer 2 start address - HIGH */
#define SAD2L                   0x00            /**< layer 2 start address - LOW */
#define SAD2H                   0x08            /**< layer 2 start address - HIGH */
#define SL2             0xef            /**< number of lines (pixels) of layer 2 */
#define SAD3L                   0               /**< layer 3 start address - LOW, 0 disabled */
#define SAD3H                   0               /**< layer 3 start address - HIGH, 0 disabled */
#define SAD4L                   0               /**< layer 4 start address - LOW, 0 disabled */
#define SAD4H                   0               /**< layer 4 start address - HIGH, 0 disabled */

/* CSRFORM parameters */
#define CRX             0x04            /**< range: 0x00-0x0f, cursor width in pixels - 1 */
#define CRY             0x06            /**< range: 0x01-0x0f, cursor height in pixels - 1 */
#define CM              0               /**< 0 underscore cursor, 1 block cursor */

/* OVLAY parameters */
#define MX0             1               /**< combined with MX1, composition method selection */
#define MX1             0               /**< see datasheet for further details */
#define DM1             0               /**< display mode of layer 1 and 3, 0 text, 1 graphic */
#define DM2             0               /**< display mode of layer 1 and 3, 0 text, 1 graphic */
#define OV              0               /**< 0 two layer composition, 1 three layer comp.*/

/* CGRAM ADR parameters */
#define SAGL                    0               /**< character gen. RAM start address - LOW */
#define SAGH                    0xf0            /**< character gen. RAM start address - HIGH */
//#define SAGL                    0               /**< character gen. RAM start address - LOW */
//#define SAGH                    0x70            /**< character gen. RAM start address - HIGH */

/* HDOT SCR parameters */
#define SCRD                    0               /**< number of pixels to scroll down - 1 */

/* DISP ON flashing parameters */
#define FLASH                   0x16            /**< set flashing for cursor and layers, see sed1335 datasheet */


/* buffer settings */
#define TEXTSIZE        ((SAD2H << 8) + SAD2L)                  /* chars */
#define GRAPHICSIZE     ((SL2+1) * (SCR_WIDTH+1))>>3            /* pixels / 8 */
//#define MEM_END                 10800                                   /* TEXTSIZE + GRAPHICSIZE */
#define MEM_END         0x3aa0/*32000    (TEXTSIZE + GRAPHICSIZE)*/
	
/* "compiled" parameter bytes */
/* SYSTEM SET */
#define SYS_P1          0x10 | (IV << 5) | (WS << 3) | (M2 << 2) | (M1 << 1) | M0
#define SYS_P2          0x00 | (WF << 7) | FX
/* other */
#define CSRF_P2         0x00 | (CM << 7) | CRY
#define OVLAY_P1        0x00 | (OV << 4) | (DM2 << 3) | (DM1 << 2) | (MX1 << 1) | MX0

/* some useful macros */
#define hi(a) (a >> 0x08)
#define lo(a) (a & 0xff)
#define set_command()   sbi(LCD_A0_PORT, LCD_A0_PIN);         /**< enable command mode */
#define unset_command() cbi(LCD_A0_PORT, LCD_A0_PIN);         /**< disable command mode*/
#define set_write()     cbi(LCD_CTRL_PORT, LCD_WR_PIN);         /**< we want to write, low active */
#define unset_write()   sbi(LCD_CTRL_PORT, LCD_WR_PIN);         /**< writing complete, low active */
#define set_read()      cbi(LCD_CTRL_PORT, LCD_RD_PIN);         /**< we want to read, low active */
#define unset_read()    sbi(LCD_CTRL_PORT, LCD_RD_PIN);         /**< reading complete, low active */
#define enable_sed()    cbi(LCD_CTRL_PORT, LCD_CS_PIN);         /**< select sed1335 chip, low active */
#define disable_sed()   sbi(LCD_CTRL_PORT, LCD_CS_PIN);         /**< deselect sed1335 chip, low active */


/* prototypes */
void wait(uint16_t cycles);                     /* wait for "cycles" instruction cyces */
void sed1335_data(uint8_t byte);                /* send data to the controller */
void sed1335_cmd(uint8_t byte);                 /* send a command to the controller */
uint16_t sed1335_get_txcur(uint16_t addr);      /* returns absolute addr of text-layer address */
uint16_t sed1335_get_grcur(uint16_t addr);      /* returns absolute addr of graphic-layer address */
int sed1335_set_address(uint16_t addr);         /* set internal mem pointer to absolute addr */
void sed1335_enable_display(void);              /* enable the attached display */
void sed1335_disable_display(void);             /* disable the attached display */
void sed1335_lcd_init(void);                    /* initialization of the sed1335 controller */
void sed1335_sleep_enable(void);                /* enable controllers sleep mode for power save */
void sed1335_sleep_disable(void);               /* wake up, neo */
void sed1335_set_flashing(uint8_t flashing);    /* cur. and scr. flashing */
uint8_t sed1335_set_cur_dir(uint8_t byte);  	/* set the (internal memory) cursor direction */
uint8_t sed1335_read_byte();

/* write out buffer "buf" with "len" bytes to current address */
uint16_t sed1335_mem_write(uint8_t *buf, uint16_t len, uint16_t addr);
uint16_t sed1335_text_write(char *buf, uint16_t len, uint16_t add);     /* write text */
void sed1335_single_byte(uint8_t byte);         /* write a single byte to the absolute address */
void sed1335_clear_display(void);               /* clear text and graphic layer */
void sed1335_clr_display(uint16_t y);
uint16_t sed1335_read_mem(uint8_t *buf, uint16_t len, uint16_t addr);   /* read mem */

#endif
