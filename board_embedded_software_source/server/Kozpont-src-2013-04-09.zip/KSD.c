#include <stdio.h>
#include <string.h>
#include "sd/sd_raw.h"
#include "sd/sd_raw_config.h"
#include "sd/fat.h"
#include "sd/fat_config.h"
#include "sd/partition.h"
#include "KSD.h"
#include "KCom.h"
#include "Kozpont.h"

uint8_t print_disk_info(const struct fat16_fs_struct* fs);
struct fat16_dir_struct* dd;
struct fat16_fs_struct* fs;
uint32_t global_pos;

/***********************************************************
 * init resz.
 ***********************************************************/
// SD init. 
void sd_init(void)
{

	if(!sd_raw_init())
    {
#ifdef DEBUG
        PutString("MMC/SD init failed!");
#endif
        return;
    }
	  /* open first partition */
    struct partition_struct* partition = partition_open(sd_raw_read,
                                                        sd_raw_read_interval,
                                                        sd_raw_write,
                                                        sd_raw_write_interval,
                                                        0
                                                       );

    if(!partition)
    {
        /* If the partition did not open, assume the storage device
         * is a "superfloppy", i.e. has no MBR.
         */
     	partition = partition_open(sd_raw_read,
                                   sd_raw_read_interval,
                                   sd_raw_write,
                                   sd_raw_write_interval,
                                   -1
                                  );
        if(!partition)
        {
#ifdef DEBUG
            PutString("opening part. failed");
#endif
            return;
        }
    }

    /* open file system */
    fs = fat16_open(partition);
    if(!fs)
    {
#ifdef DEBUG
        PutString("opening fat16 failed");
#endif
        return;
    }

    /* open root directory */
    struct fat16_dir_entry_struct directory;
    fat16_get_dir_entry_of_path(fs, "/", &directory);

    dd = fat16_open_dir(fs, &directory);
    if(!dd)
    {
#ifdef DEBUG
        PutString("opening root dir. failed");
#endif
        return ;
    }
    
    /* print some card information as a boot message */
    //print_disk_info(fs);
#ifdef DEBUG
	PutString("SD init ready");
#endif
	global_pos = 0;
}//void sd_init(void)

uint8_t find_file_in_dir(struct fat16_fs_struct* fs, struct fat16_dir_struct* dd, const char* name, struct fat16_dir_entry_struct* dir_entry)
{
    while(fat16_read_dir(dd, dir_entry))
    {
        if(strcmp(dir_entry->long_name, name) == 0)
        {
            fat16_reset_dir(dd);
            return 1;
        }
    }

    return 0;
}//find_file_in_dir(..)

struct fat16_file_struct* open_file_in_dir(struct fat16_fs_struct* fs, struct fat16_dir_struct* dd, const char* name)
{
    struct fat16_dir_entry_struct file_entry;
    if(!find_file_in_dir(fs, dd, name, &file_entry))
        return 0;

    return fat16_open_file(fs, &file_entry);
}//open_file_in_dir(...)

uint8_t create_file(const char* file)
{
	struct fat16_dir_entry_struct file_entry;

	global_pos = 0;
    return fat16_create_file(dd, file, &file_entry);           
}//uint8_t create_file(const char* file)

struct fat16_file_struct* open_file(const char* file)
{
	return  open_file_in_dir(fs, dd, file); 
}//open_file(const char* file)

void close_file(struct fat16_file_struct* fd)
{
	fat16_close_file(fd);
}//void close_file(...)

uint8_t read_file(struct fat16_file_struct* fd, uint8_t* buffer, uint16_t buffer_len)
{	
    if(!fd || !buffer || !buffer_len)
    	return 0;
  	
    if (fat16_read_file(fd, buffer, buffer_len))
	{
		global_pos = fat16_get_pos(fd);
		return 1;
	}
	return 0;	   
	         
}//read_file(...)
/*
uint8_t read_line(uint8_t* buffer, uint16_t buffer_len)
{

	uint8_t res=0;

	struct fat16_file_struct* fd = open_file(LOGNAME);
	if(!fd)
    	return 0;
	

	int32_t offset = global_pos;
	if (!fat16_seek_file(fd,&offset, FAT16_SEEK_SET))
		return 0;

	res = fat16_read_file(fd, buffer, buffer_len);
	global_pos = fat16_get_pos(fd);
	buffer[buffer_len] = 0;
	close_file(fd);
	return res;
}//read_line(..)
*/

uint8_t seek_file(struct fat16_file_struct* fd, int32_t* offset, uint8_t whence)
{
	if(!fd)
    	return 0;

	uint8_t res = fat16_seek_file(fd,offset,whence);
	global_pos = *offset;

	return res;

}//uint8_t seek_file( int32_t* offset, uint8_t whence)

uint8_t append_file(struct fat16_file_struct* fd, uint8_t* buffer, uint16_t buffer_len)
{	
    if(!fd || !buffer || !buffer_len)
    	return 0;
	int32_t offset = 0;

	if(fat16_seek_file(fd, &offset, FAT16_SEEK_END))
    {
		if (fat16_write_file(fd, (uint8_t*) buffer, buffer_len))
		{
			global_pos = fat16_get_pos(fd);
			return 1;
		}
  	}
    return 0;            
}//append_file(...)

uint8_t remove_file(const char* file)
{
	struct fat16_dir_entry_struct file_entry;
	global_pos = 0;
    if(find_file_in_dir(fs, dd, file, &file_entry))
    {
       return fat16_delete_file(fs, &file_entry);                   
    }
	return 0;
}//uint8_t remove_file(..)

/*
void ls_dir()
{
	struct fat16_dir_entry_struct dir_entry;
	uint8_t spaces;

    while(fat16_read_dir(dd, &dir_entry))
    {
       spaces = sizeof(dir_entry.long_name) - strlen(dir_entry.long_name) + 4;

       PutString(dir_entry.long_name);
       PutChar(dir_entry.attributes & FAT16_ATTRIB_DIR ? '/' : ' ');
	   //PutChar('\n');
       while(spaces--)
       		PutChar(' ');
       PutInt32(dir_entry.file_size);
	   PutChar('\n');
               
     }
}//uint8_t ls_dir()
*/
/*
//---------------------------------------------------------------
void append_to_log(const char* msg)
{
	struct fat16_file_struct* fd = open_file("lamp.log");
	if (fd)
	{
 		append_file(fd, msg, strlen(msg));
		close_file(fd);
	}
}/void append_to_log(const char* msg)
	*/		
//---------------------------------------------------------------
void set_fd_global_pos(struct fat16_file_struct* fd,uint32_t pos)
{
	if (fd)
		global_pos = fat16_get_pos(fd);
	
}//void set_fd_global_pos(uint32_t pos)


//---------------------------------------------------------------
uint32_t get_global_pos(void)
{
	return global_pos;
	
}//uint32_t get_global_pos(void)

/*
uint8_t print_disk_info(const struct fat16_fs_struct* fs)
{
    if(!fs)
        return 0;

    struct sd_raw_info disk_info;
    if(!sd_raw_get_info(&disk_info))
        return 0;

	sprintf(msg,"manuf : 0x%x",disk_info.manufacturer);
    PutString(msg); 
	sprintf(msg,"oem   : %s",(char*) disk_info.oem);
    PutString(msg);
	sprintf(msg,"prod  : %s",(char*) (char*) disk_info.product);
    PutString(msg); 
	sprintf(msg,"rev   : 0x%x",disk_info.revision);
    PutString(msg);
	PutString(  "serial: ");
	PutInt32(disk_info.serial);
    PutString(msg);
    sprintf(msg,"date  : %d:%d", disk_info.manufacturing_month,disk_info.manufacturing_year);
    PutString(msg);
	PutString( "size  : ");
	PutInt32(disk_info.capacity);
    PutString(msg);
    sprintf(msg,"copy  : %d", disk_info.flag_copy);
    PutString(msg); 
    sprintf(msg,"wr.pr.: %d, %d", disk_info.flag_write_protect_temp,disk_info.flag_write_protect);
    PutString(msg);
    sprintf(msg,"format: %d", disk_info.format);
    PutString(msg); 
 //   PutString("free  : ");
//	PutInt32(fat16_get_fs_free(fs));
//	PutChar(' ');
//	PutInt32(fat16_get_fs_size(fs));
   
    return 1;
}*/
/*
void test()
{
	struct fat16_file_struct* fd = open_file("lamp.log");
    if(fd)
    {				
		append_file(fd, "31.12.2007-12.56:      1L<  1:T >;", 35);
		append_file(fd, "31.12.2007-13.57:      1L<  2:T >;", 35);
		append_file(fd, "31.12.2007-14.58:      1L<  3:T >;", 35);
		append_file(fd, "30.12.2007-15.59:      1L<  4:T >;", 35);
		close_file(fd);
	}
		
}
*/
