#ifndef _LOOP_H
#define _LOOP_H


// lstatus bits
#define RX				0x1
#define RX_READY		0x2
#define RX_INT			0x4
#define TX				0x8
#define TX_INT			0x10
#define TX_READY 		0x20
#define TX_KOZP_ASK		0x40
#define L1INSTALL       0x80

#define CLR_LSTATUS(x)		{_CLI(); lstatus &= (~x); _SEI();};
#define SET_LSTATUS(x)		{lstatus |= (x);};
#define CHK_LSTATUS(x)		(lstatus & (x))

// error
#define FRAME_LERROR	0x1
#define CMD_LERROR		0x2
#define BN_LERROR		0x4
#define CHS_LERROR		0x8
#define RX_LERROR		0x10

#define CLR_LERROR(x)		lerror &= (~x);
#define SET_LERROR(x)		lerror |= (x);
#define CHK_LERROR(x)   	(lerror & (x))

//#define COMM_MAX_LOOP		15
#define COMM_MAX_LOOP		25
#define COMM_MAX_ADDR		64
#define MAX_ADDR			1501

#define	S_STR_CHAR 		','		// start character
#define S1_STR_CHAR		'?'
#define	R_STR_CHAR 		';'		// start character
#define	R1_STR_CHAR 	'!'		// start character
#define	R2_STR_CHAR 	'M'		// start character
#define	R3_STR_CHAR 	'N'		// start character


#define LTX_MAX_SENDED_NUM	4
#define LRX_MAX_RECEIVE_NUM	4
#define MTX_MAX_SENDED_NUM	6
#define MRX_MAX_RECEIVE_NUM	COMM_MAX_ADDR+7
#define MRX_DEF_RECEIVE_NUM 8

typedef enum 
{
	ERR_RXflag = 0,
	ERR_TOflag,
	ERR_CONTflag,
	ERR_RESPflag,
	ERR_NONEflag
} CHERRFLAG;

typedef struct
{
	uint8_t 			addrh;
	uint8_t 			addrl;
    uint8_t 			cmd;
	uint8_t 			data; 		// in:0-3 bit, out:4-8 bit;
	uint8_t 			prev_data; 	// error:0-3 bit,in:4-8 bit; MEGSZUNT az error resze: 2007.12.17.
    uint8_t             error;
	uint8_t             stat;
} CHANNELtype;

typedef struct
{
	uint8_t 			loop;
	uint8_t 			error;
	uint8_t 			addr_num;
	uint8_t				summa_error;
	CHANNELtype			chn;
//	CHANNELtype			rchn;				 
}LOOPtype;

typedef struct
{
	CHANNELtype			chn;
	uint8_t 			loop;
	uint8_t				num;
	uint16_t			timeout;
	
}CHN_ASK;

 char l_IsRecFinished();

extern void l_com_init(unsigned int baud);
uint8_t time_out(uint8_t start,uint16_t diff);
extern int8_t 	lstatus;
extern int8_t 	lerror;
extern uint16_t l_timercount;
extern uint8_t l_recTotalTimeoutMultiplier;
extern volatile unsigned char	txBuffer[MTX_MAX_SENDED_NUM+1]; // transm. buffer
extern uint8_t	rx_ready_s;
extern  void l_tx_send_common(void);
extern void l_com_rx_tx(void);
extern unsigned char l_tx_int();
extern void l_rx_int( unsigned char ucData);
extern uint8_t tx_max_sended_num;
extern uint8_t rx_max_receive_num;
extern void l_set_error_flag(CHERRFLAG flag_a, CHANNELtype* chan);
extern unsigned char test_kliens[8];
extern void test_set_kliens_rec();
#endif
