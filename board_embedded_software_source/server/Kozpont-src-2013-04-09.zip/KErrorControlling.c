#include <inttypes.h>
#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <stdio.h>
#include "KLoop.h"
#include "kConfig.h"
#include "KMloop.h"
#include "KTouch.h"
#include "Kozpont.h"
#include "KErrorControlling.h"
#include "KCom.h"
//#include "Kozpont.h"

//extern char msg[50];
char LED_blink = 0;
//int len_a = 0;
//int len_b = 0;

////
#ifdef A_B
ABtype A_error[MAX_AB_LEN];
ABtype B_error[MAX_AB_LEN];

//--------------------------------
void A_all_clear()
{
	for (int ii=0; ii<MAX_AB_LEN; ii++)
	{
		 A_error[ii].addr  = 0;	
#ifdef TOLTESJEL
		 A_error[ii].tolt = 0;
#endif
		 A_error[ii].akku = 0;
		 A_error[ii].fenycs = 0;
		 A_error[ii].com = 0;				 
	}
}//void A_clear()


//--------------------------------
void A_set(uint8_t ii, uint8_t type, uint8_t data )
{
	if (ii<MAX_AB_LEN)
	{
		switch (type)
		{
#ifdef TOLTESJEL
			case TOLT_MASK:										
				A_error[ii].tolt = data;
				break;
#endif
			case AKKU_MASK:
				A_error[ii].akku = data;
				break;
			case FENYCS_MASK:
				A_error[ii].fenycs = data;
			break;
			case COM_MASK:
				A_error[ii].com = data;
			break;
		}
	}	
}


//--------------------------------
void A_clear(uint8_t index, uint8_t type)
{
	if (index<MAX_AB_LEN)
	{
		A_set(index, type, 0);
#ifdef TOLTESJEL
		if ((A_error[index].tolt == 0) && (A_error[index].akku == 0) && (A_error[index].fenycs == 0)  && (A_error[index].com == 0))
#else
		if ((A_error[index].akku == 0) && (A_error[index].fenycs == 0)  && (A_error[index].com == 0))
#endif
			A_error[index].addr = 0;
	}

//	LED_blink = 0;
}

//--------------------------------
void B_set(uint8_t ii, uint8_t type, uint8_t data )
{
	if (ii<MAX_AB_LEN)
	{
		switch (type)
		{
#ifdef TOLTESJEL
			case TOLT_MASK:										
				B_error[ii].tolt = data;
				break;
#endif
			case AKKU_MASK:
				B_error[ii].akku = data;
				break;
			case FENYCS_MASK:
				B_error[ii].fenycs = data;
				break;
			case COM_MASK:
				B_error[ii].com = data;
			break;
		}
	}	
}


//--------------------------------
void B_clear(uint8_t index,  uint8_t type)
{
	if (index<MAX_AB_LEN)
	{
		B_set(index, type, 0);
#ifdef TOLTESJEL
		if ((B_error[index].tolt == 0) && (B_error[index].akku == 0) && (B_error[index].fenycs == 0) && (B_error[index].com == 0))
#else
		if ((B_error[index].akku == 0) && (B_error[index].fenycs == 0) && (B_error[index].com == 0))
#endif
			B_error[index].addr = 0;
	}
}

//--------------------------------
void B_all_clear()
{
	for (int ii=0; ii<MAX_AB_LEN; ii++)
	{
		 B_error[ii].addr  = 0;	
#ifdef TOLTESJEL
		 B_error[ii].tolt = 0;
#endif
		 B_error[ii].akku = 0;
		 B_error[ii].fenycs = 0;
		 B_error[ii].com = 0;		 
	}
}//void A_clear()

//--------------------------------
void AB_init()
{
	A_all_clear();
	B_all_clear();
	LED_blink = 0;

}//void AB_init()


//--------------------------------
uint8_t Darab_A()
{	
	int ii,kk;
	for (ii=0, kk=0; ii<MAX_AB_LEN; ii++)
	{
		 if (A_error[ii].addr)
		 	kk++;				 
	}

	return kk;
}//uint8_t Darab_A()

//--------------------------------
uint8_t Darab_B()
{	
	int ii,kk;
	for (ii=0, kk=0; ii<MAX_AB_LEN; ii++)
	{
		 if (B_error[ii].addr)
		 	kk++;				 
	}

	return kk;
}//uint8_t Darab_B()

//--------------------------------
uint8_t IsEmpty_A()
{	
	return ((Darab_A() == 0)?1:0);
}//uint8_t IsEmpty_A()

//--------------------------------
uint8_t IsEmpty_B()
{	
	return ((Darab_B() == 0)?1:0);
}//uint8_t IsEmpty_B()

//--------------------------------
uint8_t IsFull_A()
{
//	return ((Len_A() == MAX_AB_LEN)?1:0);
	return ((Darab_A() == MAX_AB_LEN)?1:0);
}

//--------------------------------
uint8_t IsFull_B()
{
	return ((Darab_B() == MAX_AB_LEN)?1:0);
}

//--------------------------------
/*
uint8_t nextEmptyA()
{
	int ii;
	for(ii=0;ii<MAX_AB_LEN;ii++)
	{
		 if ((A_error[ii].addr == 0) && (A_error[ii].error == 0)))
		 	return ii;
	}
	return 255;
}*/

//--------------------------------
uint8_t	A_search(uint16_t addr )
{
	for(int ii=0;ii<MAX_AB_LEN;ii++)
	{
		if(A_error[ii].addr == addr)
			return ii;
	}
	return 255;	
}//uint8_t	A_search(uint16_t addr)

//--------------------------------
uint8_t	B_search(uint16_t addr)
{
	for(int ii=0;ii<MAX_AB_LEN;ii++)
	{
		if(B_error[ii].addr == addr)
			return ii;
	}
	return 255;	
}//uint8_t	B_search(uint16_t addr)

//--------------------------------
/*
uint8_t A_set(int addr, uint8_t error)
{	
	if (IsFull_A())
		return 0;

	uint8_t index = A_search(addr);
	
	if (index != 255)
	{
		SET_A(index,error);
	}
	else
		return 0;
	
	//sprintf(msg,"addr:%d:data:%d,error:%d",A_error[ii].addr,A_error[ii].data,A_error[ii].error);
	//PutString(msg);
	return 1;
}//uint8_t  A_set(int addr, uint8_t error)
*/

//--------------------------------
uint8_t A_add(int addr,  uint8_t type)
{	
//	if (IsFull_A())
//		return 0;
	int ii;
	for(ii=0;ii<MAX_AB_LEN;ii++)
	{
		if(A_error[ii].addr == 0)
		{
			A_error[ii].addr  = addr;			
			A_set(ii, type, 1);	
			return ii;
		}
	}	
	return -1;
}//uint8_t  A_set(int addr, uint8_t error)


//--------------------------------
void A_copyto_B()
{ //csak gombra hivodhat meg!!
	if (IsEmpty_A())
		return;
	for(int ii=0;ii<MAX_AB_LEN;ii++)
	{
		B_error[ii].addr  = A_error[ii].addr;
#ifdef TOLTESJEL
		B_error[ii].tolt = A_error[ii].tolt;
#endif
		B_error[ii].akku = A_error[ii].akku;
		B_error[ii].fenycs = A_error[ii].fenycs;
		B_error[ii].com = A_error[ii].com;	
	}
	A_all_clear();	

}//A_copyto_B()

//--------------------------------
uint8_t IsChargeError_AB()
{
	if (IsEmpty_A())
		return 0;

#ifdef TOLTESJEL
	int ii;
	for(ii=0;ii<MAX_AB_LEN;ii++)
	{
		if(A_error[ii].tolt)
			return 1;
	}
#endif
	return 0;
}//uint8_t IsChargeError_AB()

#else
uint8_t tolt_error;
//--------------------------------
void AB_init()
{
	tolt_error = 0;
}
//--------------------------------
void A_copyto_B()
{
}

//--------------------------------
uint8_t IsChargeError_AB()
{
// TOLTES HIB 
#ifdef TOLTESJEL
	return tolt_error;
/*	int ii;
	for(ii=0;ii<MAX_AB_LEN;ii++)
	{
		if(A_error[ii].tolt)
			return 1;
	}*/
#endif
	return 0;
}//uint8_t IsChargeError_AB()

#endif

//--------------------------------
void Alarm_LED_blink()
{
	static int blink = 0;

	if (LED_blink == 0)
		return;

	if (blink)
	{
		ALARM_ON
		blink = 0;
	}
	else
	{
		ALARM_OFF
		blink = 1;
	}
		
}//Alarm_LED_blink()

//--------------------------------
void Alarm_LED_fast_blink()
{
	if (LED_blink == 2)
	{	
		Alarm_LED_blink();	
	}
}


#ifdef A_B
//--------------------------------
void AB_controll(char test)
{
	int ii,aindex,bindex, flg=0;
//	char mod_bus = 0;

	if (IsFull_A())
		return;

	for(ii=0;ii < allloopnumenable;ii++)
	{						
		if( !loop_array[ii].chn.addrh && !loop_array[ii].chn.addrl)
			continue;
		
		unsigned int addr = ((unsigned int)loop_array[ii].chn.addrh)*256 + (unsigned int)loop_array[ii].chn.addrl;
		char data 	= loop_array[ii].chn.data;
	//	char cerror = loop_array[ii].chn.error & 0x07;

		aindex = A_search(addr);
		bindex = B_search(addr);


		if (loop_array[ii].error > 3)
		{
			sprintf(msg,"%01d:no respond  ",loop_array[ii].loop);
            string_write(msg,16,12,0,0, LCD_SMALLFONT );		
		}
			
		//kom.hiba
		if (loop_array[ii].chn.error & 0x07)
		{ //kom hiba
			if (aindex == 255)
			{ // A-ban nincs allomas.
				if (bindex == 255)
				{ // B-ban nincs allomas.
					flg = 1;
					A_add(addr, COM_MASK);					
				}
				else
				{ 
					if (B_error[bindex].com == 0)
					{
						flg = 1;
						A_add(addr, COM_MASK);
					}
				}
			}
			else
			{
				if (bindex != 255)
				{
					if ((A_error[aindex].com == 0) && (B_error[bindex].com == 0))
					{
						flg = 1;
						A_set(aindex, COM_MASK, 1 );
					}
				}
				else
				if (A_error[aindex].com == 0)
				{
					flg = 1;
					A_set(aindex, COM_MASK, 1 );
				}

			}
		//	if (flg)
			{			
				write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'C', 1);	
//				mod_bus |= 1;
				continue;
			}	
			
		}
		else
		if (loop_array[ii].chn.error & 0x40)
		{ //kom. hiba megszunt			
			if (aindex == 255) 
			{
				if (bindex != 255)  						
				{
					if (B_error[bindex].com == 1)
					{
					 	B_clear(bindex,COM_MASK);
					 	flg = 1;
					}
				}
			}
			else
			{
				if (A_error[aindex].com == 1)
				{
				 	A_clear(aindex,COM_MASK);				
					B_clear(bindex,COM_MASK);
					flg = 1;
				}
			}
		//	if (flg)
			{
				write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'B', 1);
//				mod_bus |= 2;
			}
		}


		flg = 0;
#ifdef TOLTESJEL
		//TOLTES	
		if (test == 0)
		{
			if ((data & TOLT_MASK) == 0)
			{ //toltes hiba
				if (aindex == 255)
				{ // A-ban nincs allomas.
					if (bindex == 255)
					{ // B-ban nincs allomas.
						flg = 1;
						A_add(addr, TOLT_MASK);					
					}
					else
					{ 
						if (B_error[bindex].tolt == 0)
						{
							flg = 1;
							A_add(addr, TOLT_MASK);
						}
					}
				}
				else
				{
					if (bindex != 255)
					{
						if ((A_error[aindex].tolt == 0) && (B_error[bindex].tolt == 0))
						{
							flg = 1;
							A_set(aindex, TOLT_MASK, 1 );
						}
					}
					else
					if (A_error[aindex].tolt == 0)
					{
						flg = 1;
						A_set(aindex, TOLT_MASK, 1 );
					}

				}
				if (flg)
				{			
					write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'T', 1);
//					mod_bus |= 4;
				}
			
			}
			else
			{ //toltes hiba megszunt			
				if (aindex == 255) 
				{
					if (bindex != 255)  						
					{
						if (B_error[bindex].tolt == 1)
						{
					 		B_clear(bindex,TOLT_MASK);
					 		flg = 1;
						}
					}
				}
				else
				{
					if (A_error[aindex].tolt == 1)
					{
				 		A_clear(aindex,TOLT_MASK);				
						B_clear(bindex,TOLT_MASK);
						flg = 1;
					}
				}
			//	if (flg)
				{
					write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 't', 1);
//					mod_bus |= 8;
				}
			}
		}
#endif								
		flg = 0;
		//AKKU
		if ((data & AKKU_MASK) == 0)
		{ //akku hiba
			if (aindex == 255)
			{ // A-ban nincs allomas.
				if (bindex == 255)
				{ // B-ban nincs allomas.
					flg = 1;
					A_add(addr, AKKU_MASK);
					
				}
				else
				{ 
					if (B_error[bindex].akku == 0)
					{
						flg = 1;
						A_add(addr, AKKU_MASK);
					}
				}
			}
			else
			{
				if (bindex != 255)
				{
					if ((A_error[aindex].akku == 0) && (B_error[bindex].akku == 0))
					{
						flg = 1;
						A_set(aindex, AKKU_MASK, 1 );
					}
				}
				if (A_error[aindex].akku == 0)
				{
					flg = 1;
					A_set(aindex, AKKU_MASK, 1 );
				}

			}
	//		if (flg)
			{			
				write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'A', 1);
//				mod_bus |= 16;
			}
			
		}
		else
		{ //akku hiba megszunt			
			if (aindex == 255) 
			{
				if (bindex != 255)  							
				{
					if (B_error[bindex].akku == 1)
					{
					 	B_clear(bindex,AKKU_MASK);					 
					}
				}
			}
			else
			{
				if (A_error[aindex].akku == 1)
				{
				 	A_clear(aindex,AKKU_MASK);
					B_clear(bindex,AKKU_MASK);				
				}
			}		
		}
					

		flg = 0;
		//FENYCSO
		if ((data & FENYCS_MASK) == 0)
		{ //fenycso hiba
			if (aindex == 255)
			{ // A-ban nincs allomas.
				if (bindex == 255)
				{ // B-ban nincs allomas.
					flg = 1;
					A_add(addr, FENYCS_MASK);					
				}
				else
				{ 
					if (B_error[bindex].fenycs == 0)
					{
						flg = 1;
						A_add(addr, FENYCS_MASK);
					}
				}
			}
			else
			{
				if (bindex != 255)
				{
					if ((A_error[aindex].fenycs == 0) && (B_error[bindex].fenycs == 0))
					{
						flg = 1;
						A_set(aindex, FENYCS_MASK, 1 );
					}
				}
				else
				if (A_error[aindex].fenycs == 0)
				{
					flg = 1;
					A_set(aindex, FENYCS_MASK, 1 );
				}
				
			}
		//	if (flg)
			{			
				write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'F', 1);
//				mod_bus |= 32;
			}
			
		}
		else
		{ //fenycso hiba megszunt			
			if (aindex == 255) 
			{
				if (bindex != 255)  			
				{
					if (B_error[bindex].fenycs == 1)
					{
					 	B_clear(bindex,FENYCS_MASK);
					 
					}
				}
			}
			else
			{
				if (A_error[aindex].fenycs == 1)
				{
				 	A_clear(aindex,FENYCS_MASK);
					B_clear(bindex,FENYCS_MASK);
					
				}
			}		
		}							
	}
	return;	
}//void AB_controll()
#else
//--------------------------------
void AB_controll(char test)
{
	unsigned int addr;
	char data;
	int ii;

	for(ii=0;ii < allloopnumenable;ii++)
	{						
		if( !loop_array[ii].chn.addrh && !loop_array[ii].chn.addrl)
			continue;
		
		addr = ((unsigned int)loop_array[ii].chn.addrh)*256 + (unsigned int)loop_array[ii].chn.addrl;
		data 	= loop_array[ii].chn.data;

		if (loop_array[ii].error > 3)
		{
			sprintf(msg,"%01d:no respond  ",loop_array[ii].loop);
            string_write(msg,16,12,0,0, LCD_SMALLFONT );		
		}

		//kom.hiba
		if (loop_array[ii].chn.error & 0x07)
		{ //kom hiba
			write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'C', 1);	
			loop_array[ii].chn.error = 0;
			continue;
		}
		else
		if (loop_array[ii].chn.error & 0x40)
		{ //kom. hiba megszunt	
			write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'B', 1);
			loop_array[ii].chn.error = 0;
		}
#ifdef TOLTESJEL
		//TOLTES	
		if (test == 0)
		{
			if ((data & TOLT_MASK) == 0)
			{ //toltes hiba
				write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'T', 1);
				loop_array[ii].chn.data |= TOLT_MASK;
				tolt_error = 1;
			}
			else
				tolt_error = 0;
		}
#endif
		if ((data & AKKU_MASK) == 0)
		{ //akku hiba
			write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'A', 1);
			loop_array[ii].chn.data |= AKKU_MASK;
		}
		if ((data & FENYCS_MASK) == 0)
		{ //fenycso hiba
			write_Allerror_to_sd("  ", loop_array[ii].chn.addrh ,loop_array[ii].chn.addrl, 'F', 1);
			loop_array[ii].chn.data |= FENYCS_MASK;
		}
	}
}
#endif

#ifdef A_B
//--------------------------------
void AB_executor()
{	
	uint8_t Aempty = 0,Bempty = 0;
	
	Aempty = IsEmpty_A();
	Bempty = IsEmpty_B(); 
	

//	char msg[100];
//	sprintf(msg,"A[%d],addr:%d:data:%d,error:%d",ii_s,A_error[ii_s].addr,A_error[ii_s].data,A_error[ii_s].error);
//	PutString(msg);

	if (IsFull_A() && IsFull_B())
	{ // A televan,B. televan
		SET_SYSSTATUS(SYS_SERVICE)
		LED_blink = 2; //gyors blink
		return;
	}

	if (IsFull_A())
	{ // A televan,A->B.
		A_copyto_B();
		lcd_A_B_write(1);
		LED_blink = 1; //alap blink
		OUT_ON
		return;
	}

	if ((Aempty) && (Bempty))
	{ // A ures, B ures
		LED_blink = 0;
		ALARM_OFF
		OUT_OFF			
	}
	else
	{ 
		if ((!Aempty) && (Bempty))
		{//A van adat, B ures
			ALARM_ON	
			LED_blink = 0;	
		}
		else
		if ((!Aempty) && (!Bempty))
		{ //A van adat, B van adat	
			LED_blink = 2; //gyors blink
		}
		else
		if ((Aempty) && (!Bempty))
		{//A ures, B van adat	
			LED_blink = 1;
		}
		OUT_ON
	}
	CLR_SYSSTATUS_(SYS_SERVICE);

}//void AB_executor()
#else
//--------------------------------
void AB_executor()
{
}
#endif
