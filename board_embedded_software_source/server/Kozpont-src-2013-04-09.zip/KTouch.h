#ifndef TOUCH_H
#define TOUCH_H


#include <avr/pgmspace.h>

//#include "lChannels.h"

#define MESS_LEN	35		//	sd len
                                
#define P_LCD_RESET			0x40	
#define LCD_RESET_ON  		PORTC &= ~P_LCD_RESET;	// LCD /Reset
#define LCD_RESET_OFF		PORTC |=  P_LCD_RESET;
                                   
#define P_LCD_RD			0x02	
#define LCD_RD_ON  			PORTG &= ~P_LCD_RD;	    // LCD /RD
#define LCD_RD_OFF			PORTG |=  P_LCD_RD;
   
#define P_LCD_WR			0x01	
#define LCD_WR_ON  			PORTG &= ~P_LCD_WR;	    // LCD /WR
#define LCD_WR_OFF			PORTG |=  P_LCD_WR;
  
#define P_LCD_CS			0x04	
#define LCD_CS_ON  			PORTG &= ~P_LCD_CS;	    // LCD /CS
#define LCD_CS_OFF			PORTG |=  P_LCD_CS;
        
#define P_LCD_C_D			0x20	
#define LCD_C_D_L  			PORTC &= ~P_LCD_C_D;    // LCD A0 (C/D)
#define LCD_C_D_H			PORTC |=  P_LCD_C_D;
                                    
#define lcd_io_out			PORTA				    // LCD 8 bit data.

#define lcd_io_dir 			DDRA 
#define lcd_io_dir_out 		lcd_io_dir = 0xff; 
#define lcd_io_dir_in 		lcd_io_dir = 0; 
	
#define lcd_io_in			PORTA

#define P_LKCS				0x01					// LCD kontraszt CS
#define OFF_LKCS			PORTC |=  P_LKCS;
#define ON_LKCS				PORTC &= ~P_LKCS;

#define P_LKINC				0x04					// LCD kontraszt INC
#define OFF_LKINC			PORTC |=  P_LKINC;
#define ON_LKINC			PORTC &= ~P_LKINC;

#define P_LKUD				0x02					// LCD kontraszt UP/DOWN
#define UP_LKUD				PORTC |=  P_LKUD;
#define DOWN_LKUD			PORTC &= ~P_LKUD;

                                
#define P_LCD_LIGHT			0x10	
#define LCD_LIGHT_OFF  		PORTF &= ~P_LCD_LIGHT;	// LCD /Reset
#define LCD_LIGHT_ON		PORTF |=  P_LCD_LIGHT;

#define P_OUT				0x01
#define OUT_ON  			PORTC &= ~P_OUT;	// OUT
#define OUT_OFF				PORTC |=  P_OUT;
#define P_ALARM				0x20	
#define ALARM_ON  			{PORTF &= ~P_ALARM;}	// ALARM
#define ALARM_OFF			{PORTF |=  P_ALARM;}
//#define OUT_ON  			PORTC &= ~P_OUT;	// OUT
//#define OUT_OFF				PORTC |=  P_OUT;


#define  tp_top              0x01                                      
#define  tp_bottom           0x02
#define  tp_left             0x04
#define  tp_right            0x08


#define  Lcd_graph_addr 		 0x0800
//#define  Lcd_graph_addr 		 0x04b0
#define  Cur_up  				 0x4E		
#define  Cur_down				 0x4F
#define  Cur_left 				 0x4D
#define  Cur_right				 0x4C

// flag
#define LCD_SMALLFONT			 0x01
#define LCD_FRAME                0x02
#define LCD_BIGFONT              0x04
#define LCD_CLR              	 0x08
#define LCD_PIXEL              	 0x10
#define LCD_EDITABLE             0x20

/*
// control flag
#define CTR_UP                   0x01
#define CTR_DOWN                 0x02
#define CTR_LEFT                 0x04
#define CTR_RIGTH                0x08
#define CTR_BEGIN                0x10
#define CTR_END                  0x20
#define CTR_ENTER                0x40
#define CTR_ESC                  0x80*/

/*
#define WT_CTR_PIX_BEGIN_X           6    
#define WT_CTR_PIX_BEGIN_Y           64
#define WT_CTR_PIX_END_X             78
#define WT_CTR_PIX_END_Y             72
#define DT_CTR_PIX_BEGIN_X           6    
#define DT_CTR_PIX_BEGIN_Y           72
#define DT_CTR_PIX_END_X             78
#define DT_CTR_PIX_END_Y             80
#define SY_CTR_PIX_BEGIN_X           6    
#define SY_CTR_PIX_BEGIN_Y           80
#define SY_CTR_PIX_END_X             78
#define SY_CTR_PIX_END_Y             88
#define INS_CTR_PIX_BEGIN_X          6    
#define INS_CTR_PIX_BEGIN_Y          88
#define INS_CTR_PIX_END_X            78
#define INS_CTR_PIX_END_Y            96
#define LOG_CTR_PIX_BEGIN_X          6    
#define LOG_CTR_PIX_BEGIN_Y          96
#define LOG_CTR_PIX_END_X            78
#define LOG_CTR_PIX_END_Y            104
#define MAN_CTR_PIX_BEGIN_X          6    
#define MAN_CTR_PIX_BEGIN_Y          104
#define MAN_CTR_PIX_END_X            78
#define MAN_CTR_PIX_END_Y            112
#define EXT_CTR_PIX_BEGIN_X          6    
#define EXT_CTR_PIX_BEGIN_Y          112
#define EXT_CTR_PIX_END_X            78
#define EXT_CTR_PIX_END_Y            120
*/

#define W__CTR_PIX_BEGIN_X           35    
#define W__CTR_PIX_BEGIN_Y           128
#define W__CTR_PIX_END_X             159
#define W__CTR_PIX_END_Y             163
#define A__CTR_PIX_BEGIN_X           179    
#define A__CTR_PIX_BEGIN_Y           128
#define A__CTR_PIX_END_X             293
#define A__CTR_PIX_END_Y             163

#define T__CTR_PIX_BEGIN_X           95    
#define T__CTR_PIX_BEGIN_Y           5
#define T__CTR_PIX_END_X             170
#define T__CTR_PIX_END_Y             48
#define D__CTR_PIX_BEGIN_X           175    
#define D__CTR_PIX_BEGIN_Y           5
#define D__CTR_PIX_END_X             315
#define D__CTR_PIX_END_Y             48

#define S__CTR_PIX_BEGIN_X           238    
#define S__CTR_PIX_BEGIN_Y           55
#define S__CTR_PIX_END_X             315
#define S__CTR_PIX_END_Y             121
//#define S__CTR_PIX_END_Y             90

#define AB__CTR_PIX_BEGIN_X           238    
#define AB__CTR_PIX_BEGIN_Y           105
#define AB__CTR_PIX_END_X             315
#define AB__CTR_PIX_END_Y             110

#define B__CTR_PIX_BEGIN_X           238    
#define B__CTR_PIX_BEGIN_Y           113
#define B__CTR_PIX_END_X             315
#define B__CTR_PIX_END_Y             125


#define LOG_CTR_PIX_BEGIN_X          5    
#define LOG_CTR_PIX_BEGIN_Y          5
#define LOG_CTR_PIX_END_X            85
#define LOG_CTR_PIX_END_Y            48


#define CL1_CTR_X           			2    
#define CL1_CTR_Y           			8

#define CL1_CTR_PIX_BEGIN_X           3    
#define CL1_CTR_PIX_BEGIN_Y           60
#define CL1_CTR_PIX_END_X             85
#define CL1_CTR_PIX_END_Y             80


#define GET_A_CTR_X          			2    
#define GET_A_CTR_Y          			10

#define GET_A_CTR_PIX_BEGIN_X          3    
#define GET_A_CTR_PIX_BEGIN_Y          81
#define GET_A_CTR_PIX_END_X            85
#define GET_A_CTR_PIX_END_Y            101

#define INS_CTR_X           			2    
#define INS_CTR_Y           			12

#define INS_CTR_PIX_BEGIN_X           3    
#define INS_CTR_PIX_BEGIN_Y           102
#define INS_CTR_PIX_END_X             85
#define INS_CTR_PIX_END_Y             112

#define MAN_CTR_X          			2    
#define MAN_CTR_Y          			14

#define MAN_CTR_PIX_BEGIN_X          3    
#define MAN_CTR_PIX_BEGIN_Y          113
#define MAN_CTR_PIX_END_X            85
#define MAN_CTR_PIX_END_Y            125
/*
#define INST_CTR_PIX_BEGIN_X          3    
#define INST_CTR_PIX_BEGIN_Y          109
#define INST_CTR_PIX_END_X            85
#define INST_CTR_PIX_END_Y            124*/

/*#define EXT_CTR_PIX_BEGIN_X          6    
#define EXT_CTR_PIX_BEGIN_Y          112
#define EXT_CTR_PIX_END_X            78
#define EXT_CTR_PIX_END_Y            120*/


#define LF_CTR_PIX_BEGIN_X           65    
#define LF_CTR_PIX_BEGIN_Y           205
#define LF_CTR_PIX_END_X             90
#define LF_CTR_PIX_END_Y             220
#define RG_CTR_PIX_BEGIN_X           95
#define RG_CTR_PIX_BEGIN_Y           205
#define RG_CTR_PIX_END_X             120
#define RG_CTR_PIX_END_Y             220
#define DW_CTR_PIX_BEGIN_X           125
#define DW_CTR_PIX_BEGIN_Y           205
#define DW_CTR_PIX_END_X             150
#define DW_CTR_PIX_END_Y             220
#define UP_CTR_PIX_BEGIN_X           155
#define UP_CTR_PIX_BEGIN_Y           205
#define UP_CTR_PIX_END_X             180
#define UP_CTR_PIX_END_Y             220
#define SV_CTR_PIX_BEGIN_X           190
#define SV_CTR_PIX_BEGIN_Y           205
#define SV_CTR_PIX_END_X             245
#define SV_CTR_PIX_END_Y             220

#define DA_CTR_PIX_BEGIN_X		  	 80
#define DA_CTR_PIX_BEGIN_Y		     155
#define DA_CTR_PIX_END_X			 220
#define DA_CTR_PIX_END_Y			 168
#define TM_CTR_PIX_BEGIN_X		  	 80
#define TM_CTR_PIX_BEGIN_Y		     170
#define TM_CTR_PIX_END_X			 220
#define TM_CTR_PIX_END_Y			 185	

#define TW_CTR_PIX_BEGIN_X		  	 80
#define TW_CTR_PIX_BEGIN_Y		     155
#define TW_CTR_PIX_END_X			 220
#define TW_CTR_PIX_END_Y			 168
#define TA_CTR_PIX_BEGIN_X		  	 80
#define TA_CTR_PIX_BEGIN_Y		     170
#define TA_CTR_PIX_END_X			 220
#define TA_CTR_PIX_END_Y			 185	

#define SSP_CTR_PIX_BEGIN_X			 88
#define SSP_CTR_PIX_BEGIN_Y			 153
#define SSP_CTR_PIX_END_X			 100
#define SSP_CTR_PIX_END_Y			 163
#define SUSB_CTR_PIX_BEGIN_X		  88
#define SUSB_CTR_PIX_BEGIN_Y		 168
#define SUSB_CTR_PIX_END_X			 100
#define SUSB_CTR_PIX_END_Y			 178
#define SETH_CTR_PIX_BEGIN_X		  88
#define SETH_CTR_PIX_BEGIN_Y		 183
#define SETH_CTR_PIX_END_X			 100
#define SETH_CTR_PIX_END_Y			 193

#define S1L_CTR_PIX_BEGIN_X		  	 175
#define S1L_CTR_PIX_BEGIN_Y		     153
#define S1L_CTR_PIX_END_X			 192
#define S1L_CTR_PIX_END_Y			 163
#define SML_CTR_PIX_BEGIN_X		  	 175
#define SML_CTR_PIX_BEGIN_Y		     168
#define SML_CTR_PIX_END_X			 192
#define SML_CTR_PIX_END_Y			 178

#define SIF_CTR_PIX_BEGIN_X		  	 245
#define SIF_CTR_PIX_BEGIN_Y		     155
#define SIF_CTR_PIX_END_X			 270
#define SIF_CTR_PIX_END_Y			 163

#define SIN_CTR_PIX_BEGIN_X		  	 245
#define SIN_CTR_PIX_BEGIN_Y		     168
#define SIN_CTR_PIX_END_X			 270
#define SIN_CTR_PIX_END_Y			 180


#define MY_CTR_PIX_BEGIN_X		  	 115
#define MY_CTR_PIX_BEGIN_Y		     160
#define MY_CTR_PIX_END_X			 160
#define MY_CTR_PIX_END_Y			 185

#define MN_CTR_PIX_BEGIN_X		  	 175
#define MN_CTR_PIX_BEGIN_Y		     160
#define MN_CTR_PIX_END_X			 210
#define MN_CTR_PIX_END_Y			 185

#define IY_CTR_PIX_BEGIN_X		  	 115
#define IY_CTR_PIX_BEGIN_Y		     160
#define IY_CTR_PIX_END_X			 160
#define IY_CTR_PIX_END_Y			 185

#define IN_CTR_PIX_BEGIN_X		  	 175
#define IN_CTR_PIX_BEGIN_Y		     160
#define IN_CTR_PIX_END_X			 210
#define IN_CTR_PIX_END_Y			 185

#define LO_CTR_PIX_BEGIN_X		  	 80
#define LO_CTR_PIX_BEGIN_Y		     170
#define LO_CTR_PIX_END_X			 120
#define LO_CTR_PIX_END_Y			 185
#define LA_CTR_PIX_BEGIN_X		  	 130
#define LA_CTR_PIX_BEGIN_Y		     170
#define LA_CTR_PIX_END_X			 170
#define LA_CTR_PIX_END_Y			 185


#define LG_CTR_PIX_BEGIN_X		  	 50
#define LG_CTR_PIX_BEGIN_Y		     160
#define LG_CTR_PIX_END_X			 270
#define LG_CTR_PIX_END_Y			 180

#define LI_CTR_PIX_BEGIN_X		  	 295
#define LI_CTR_PIX_BEGIN_Y		     210
#define LI_CTR_PIX_END_X			 315
#define LI_CTR_PIX_END_Y			 230

#define LL_CTR_PIX_BEGIN_X		  	 0
#define LL_CTR_PIX_BEGIN_Y		     210
#define LL_CTR_PIX_END_X			 20
#define LL_CTR_PIX_END_Y			 230

#define ABY_CTR_PIX_BEGIN_X		  	 115
#define ABY_CTR_PIX_BEGIN_Y		     160
#define ABY_CTR_PIX_END_X			 160
#define ABY_CTR_PIX_END_Y			 185

#define ABN_CTR_PIX_BEGIN_X		  	 115
#define ABN_CTR_PIX_BEGIN_Y		     160
#define ABN_CTR_PIX_END_X			 160
#define ABN_CTR_PIX_END_Y			 185

#define BY_CTR_PIX_BEGIN_X		  	 115
#define BY_CTR_PIX_BEGIN_Y		     160
#define BY_CTR_PIX_END_X			 160
#define BY_CTR_PIX_END_Y			 185

#define BN_CTR_PIX_BEGIN_X		  	 115
#define BN_CTR_PIX_BEGIN_Y		     160
#define BN_CTR_PIX_END_X			 160
#define BN_CTR_PIX_END_Y			 185

#define EXIT_CTR_PIX_BEGIN_X		 250
#define EXIT_CTR_PIX_BEGIN_Y		 210
#define EXIT_CTR_PIX_END_X			 290
#define EXIT_CTR_PIX_END_Y			 230


typedef enum 
{
	TESTpic = 0,					
	DATE_TIMEpic,		
	SYSTEMpic,	
	CLEARALLpic,
	GETALLpic,
	CLEAR1pic,	
	MANpic,
	LOGpic,	
	INSTALLpic,
	EXITpic,
	AcopyBpic,
	Bclearpic,
	NONEpic
} SUBPICTURE;

typedef enum 
{
	CTR_NONEctl = 0,
	CTR_LEFTctl = 1,
	CTR_RIGTHctl = 2,
	CTR_DOWNctl = 4,
	CTR_UPctl = 8,
	CTR_SAVEctl = 16,
	CTR_CLEARctl = 32,	
	CTR_NCHANGEctl = 64
}CTRL_BILL;

void lcd_init(void);
void lcd_send_cmd(int8_t cmd_a);
//void bigchar(const char* pTxt, uint8_t len, uint8_t Inverzbit);
void lcd_send_data(int8_t Value);
void Lcd_clear_graphics(void);
void Cls_all(void);
void bottom_menu(void);
void main_picture(void);
void setting_picture(void);
void log_picture(void);
//void picture_draw(const TOUCH_CONTENT** pic_array_a) ;
void  lcd_main_picture();
void  lcd_main_bottom_picture();
void  lcd_editor_picture();

//TOUCH_FUNCT charge_cb;
//TOUCH_FUNCT time_cb;

void init(void);
void Cls_graf(void) ;
void eecontentwrite(void);
void rtc_write_to_lcd(void);
void pheriph_values_string_write();
void  lcd_editor_log_picture(SUBPICTURE pict_a);
void  lcd_watest_panel_view();
void lcd_datetime_panel_ctrl();
void datetime_write(uint8_t mode_a, uint8_t* test_array);
void  lcd_datetime_panel_view();
CTRL_BILL lcd_ctrl_panel_ctrl();
void watest_write(uint8_t mode_a, uint8_t* test_array);
void switch_light(uint8_t on_off_a);
void lcd_exit_panel_ctrl() ;
void allomas_status(void);
void lcd_logger_panel_view();
void logger_write();
void loop_address_write(void);
void set_current_loop_address();
void watch_alarm(uint8_t day,uint8_t month,uint8_t year, uint8_t hour, uint8_t min);
void start_get_all_address();
void lcd_A_B_write(uint8_t mode);

extern void get_addr_datas(uint8_t loop_a);
extern void start_touch(void);
extern void touch_executor(void);
extern void init_touch(void);
extern void string_write(char* txt, uint16_t x, uint8_t y, uint16_t xe, uint8_t ye, uint8_t flag );
extern void lcd_set_loop_addr(uint8_t loop_a,uint8_t addr_a);
extern void lcd_set_chan_data(uint8_t loop_a,CHANNELtype* chan);
extern void lcd_set_chan_cmd(char* msg);
extern void time_write(uint8_t hour, uint8_t min);
extern void date_write(uint8_t day, uint8_t mounth, uint8_t year);
extern void test_write_sd(uint8_t loop_a,CHANNELtype* pChan);
extern void write_Allerror_to_sd(const char* mesg,  uint8_t addrh_a, uint8_t addrl_a, char error, char time);
extern void lcd_exit();
extern void start_test(uint8_t mode_a);
extern void end_test(void);
extern void test_executor(void);
extern uint16_t test_timersec;
extern void set_lcd_contrast(int inc_dec);
extern void  lcd_system_panel_setting(uint8_t mode_a, uint8_t isView_a);
extern void clear_all_address();
extern void lcd_clear();
extern uint8_t min_test;
extern void sd_card_off();
extern void set_install(uint8_t value);
extern void get_addr_executor();
extern void write_to_sd(const char* mesg);

//extern void set_weekly_alarm(uint8_t day);
//extern char msg[50]; 
//extern const TOUCH_CONTENT main_time PROGMEM;
//extern char get_rtc(struct _tm* gmt);

//extern void t_sed_init(void);
#endif
