#include <avr/io.h>

#include "macros.h"
#include "utils.h"
#include "pcf8583.h"


volatile uint8_t PCF8583_status;
volatile uint8_t PCF8583_alarm;

volatile uint8_t PCF8563_status1;
volatile uint8_t PCF8563_status2;
volatile uint8_t PCF8563_alarm;


/*******************************************************
 * i2c part
 *******************************************************/

void I2C_start(void)
{
  I2C_SCL_H;
  I2C_SDA_H;
  I2C_SDA_WR;
  I2C_SCL_WR;	
  delay10us();
  I2C_SDA_L;
  delay10us();
  I2C_SCL_L;
  delay10us();
}//void I2C_start(void)


void I2C_stop(void)
{
  I2C_SDA_WR;		
  I2C_SCL_H;
  delay10us();
  I2C_SDA_H;
  delay10us();
}//void I2C_stop(void)

uint8_t I2C_read(uint8_t ack)
{
  uint8_t i;
  uint8_t b = 0;
  I2C_SDA_RD;		
  I2C_SDA_H;		
  delay10us();
  for (i=0; i<8; i++)	
  {
    I2C_SCL_H;	// SCL w stan wysoki
    delay10us();
    b <<= 1;		// przesu� o 1 bit
    if (bit_is_set(I2C_PORT_I,I2C_SDA)) // je�li SDA=1 
      b |= 1;		// dodaj odczytany bit z magistrali
    I2C_SCL_L;	// SCL w stan niski
    delay10us();
  }
  I2C_SDA_WR;		// SDA na zapis
  if (ack == 0)	// ustaw bit ACK na okre�lon� warto��
    I2C_SDA_L;
  else
    I2C_SDA_H;
  delay10us();
  I2C_SCL_H;
  delay10us();
  I2C_SCL_L;
  delay10us();
  I2C_SDA_L;
  delay10us();
  return b;
}

uint8_t I2C_write(uint8_t b)
{
  uint8_t i;
  I2C_SDA_WR;		// SDA na zapis
  for (i=0; i<8; i++)	// zapis 8 bit�w
  {
    if (b & 0x80)
      I2C_SDA_H;
    else
      I2C_SDA_L;
    delay10us();
    I2C_SCL_H;
    delay10us();
    I2C_SCL_L;
    b <<= 1;		// przesu� o 1 bit
  }
  I2C_SDA_RD;		// w-�cz czytanie SDA
  I2C_SDA_H;		// podci�gnij SDA
  delay10us();
  I2C_SCL_H;		// SCL=1
  delay10us();
  i=0xFF;
  do
  {
    if (bit_is_clear(I2C_PORT_I,I2C_SDA)) break;	// je�eli jest potwierdzenie
    delay10us();
  }
  while(--i>0);
  I2C_SCL_L;		// SCL=0
  delay10us();
  return i;
}

/*******************************************************
 * pcf8583 part
 *******************************************************/
void PCF8583_init(void)
{
  PCF8583_status= 0;
  PCF8583_alarm = 0;
  PCF8583_write(0,0);
 // PCF8583_write(4,PCF8583_read(4)&0x3f);
 // PCF8583_write(8,0x90);
}


void PCF8583_start(void)
{
  PCF8583_get_status();
  PCF8583_status&=0x7f;
  PCF8583_write(0,PCF8583_status);
}

void PCF8583_stop(void)
{
return;
  PCF8583_get_status();
  PCF8583_status|=0x80;
  PCF8583_write(0,PCF8583_status);
}

uint8_t PCF8583_read(uint8_t address)
{
  uint8_t a;
  a=(PCF8583_A0<<1)|0xa0;
  I2C_start();
  I2C_write(a);
  I2C_write(address);
  I2C_start();
  I2C_write(a|1);
  a=I2C_read(1);
  I2C_stop();
  return a;
}

uint8_t PCF8583_read_bcd(uint8_t address)
{
  return bcd2bin(PCF8583_read(address));
}

void PCF8583_write(uint8_t address,uint8_t data)
{
  I2C_start();
  I2C_write((PCF8583_A0<<1)|0xa0);
  I2C_write(address);
  I2C_write(data);
  I2C_stop();
}

void PCF8583_write_bcd(uint8_t address,uint8_t data)
{
  PCF8583_write(address,bin2bcd(data));
}

void PCF8583_write_date(uint8_t address,uint8_t day,uint16_t year)
{
  PCF8583_write(address,bin2bcd(day)|(((uint8_t) year&3)<<6));
}

void PCF8583_write_word(uint8_t address,uint16_t data)
{
  PCF8583_write(address,(uint8_t) data&0xff);
  PCF8583_write(++address,(uint8_t)(data>>8));
}

void PCF8583_set_alarm_date(uint8_t day,uint8_t month)
{
  PCF8583_write_date(0xd,day,0);
  PCF8583_write_bcd(0xe,month);
}

void PCF8583_set_alarm_time(uint8_t hour,uint8_t min,uint8_t sec,uint8_t hsec)
{
  PCF8583_write_bcd(0x9,hsec);
  PCF8583_write_bcd(0xa,sec);
  PCF8583_write_bcd(0xb,min);
  PCF8583_write_bcd(0xc,hour);
}

void PCF8583_set_date(uint8_t day,uint8_t month,uint8_t year)
{
 // PCF8583_write_word(16,year);
  PCF8583_stop();
 // PCF8583_write_date(8,day,year);
  PCF8583_write_bcd(5,day);
  PCF8583_write_bcd(7,month);
  PCF8583_write_bcd(8,year);
  PCF8583_start();
}

void PCF8583_set_time(uint8_t hour,uint8_t min,uint8_t sec,uint8_t hsec)
{
  if (hour>23) hour=0;
  if (min>59) min=0;
  if (sec>59) sec=0;
//  if (hsec>100) hsec=0;
  PCF8583_stop();
  PCF8583_write_bcd(1,hsec);
  PCF8583_write_bcd(2,sec);
  PCF8583_write_bcd(3,min);
  PCF8583_write_bcd(4,hour);
  PCF8583_start();
}


void PCF8583_hold_off(void)
{
	return;
  PCF8583_get_status();
  PCF8583_status&=0xbf;
  PCF8583_write(0,PCF8583_status);
}

void PCF8583_hold_on(void)
{
	return;
  PCF8583_get_status();
  PCF8583_status|=0x40;
  PCF8583_write(0,PCF8583_status);
}

void PCF8583_get_alarm_date(uint8_t *day,uint8_t *month)
{
  *day=bcd2bin(PCF8583_read(0xd)&0x3f);
  *month=bcd2bin(PCF8583_read(0xe)&0x1f);
}

void PCF8583_get_alarm_time(uint8_t *hour,uint8_t *min,uint8_t *sec,uint8_t *hsec)
{
  *hsec=PCF8583_read_bcd(0x9);
  *sec=PCF8583_read_bcd(0xa);
  *min=PCF8583_read_bcd(0xb);
  *hour=PCF8583_read_bcd(0xc);
}
/*
void PCF8583_get_date(uint8_t *day,uint8_t *month,uint16_t *year)
{
  uint8_t dy,dday,dmonth;
  uint16_t y1;
  PCF8583_hold_on();
  dy=PCF8583_read(5);

  dmonth=bcd2bin(PCF8583_read(6)&0x1f);
  if (dmonth < 13)
  	*month = dmonth;	
  PCF8583_hold_off();  
  dday=bcd2bin(dy&0x3f);
  if (dday < 32)
  	*day = dday;
  dy>>=6;
  y1=PCF8583_read(16)|((uint16_t) PCF8583_read(17)<<8);
  if (((uint8_t) y1&3)!=dy) PCF8583_write_word(16,++y1);

  if ((y1>2006) && (y1<2050))
  	*year=y1;
}*/

void PCF8583_get_date(uint8_t *day,uint8_t *month,uint8_t *year)
{
  uint8_t dday,dmonth;
  uint8_t dyear;
  PCF8583_hold_on();

    dday = bcd2bin(PCF8583_read(5)&0x3f);
//	dday = PCF8583_read_bcd(5);
 
  if (( 0 < dday ) && (dday < 32))
  	*day = dday;

    dmonth = bcd2bin(PCF8583_read(7)&0x1f);
	//dmonth = PCF8583_read_bcd(7);

  if (( 0 < dmonth ) && (dmonth < 13))
  	*month = dmonth;
		
  //dyear = bcd2bin(PCF8583_read(8));
  dyear = PCF8583_read_bcd(8);
  
  if ((0 < dyear) && (dyear < 99))
  	*year=dyear;

	PCF8583_hold_off();  
}

uint8_t PCF8583_get_status(void)
{
  PCF8583_status=PCF8583_read(0);
  PCF8583_alarm=(PCF8583_status&2);
  return PCF8583_status;
}

void PCF8583_get_time(uint8_t *hour,uint8_t *min,uint8_t *sec,uint8_t *hsec)
{
	uint8_t thour,tmin;
  PCF8583_hold_on();
  if (hsec)  
    *hsec=PCF8583_read_bcd(1);
  if (sec)
  	*sec=bcd2bin(PCF8583_read(2)&0x7f);
  	//*sec=PCF8583_read_bcd(2);
  
  //tmin=PCF8583_read_bcd(3);
  tmin=bcd2bin(PCF8583_read(3)&0x7f);
  if (tmin<60)	
  	*min = tmin;

 //thour = PCF8583_read_bcd(4);
  thour=bcd2bin(PCF8583_read(4)&0x3f);
if (thour<24)
	*hour = thour;
  PCF8583_hold_off();
}

void PCF8583_alarm_on(void)
{
  PCF8583_get_status();
  PCF8583_status|=4;
  PCF8583_write(0,PCF8583_status);
}

void PCF8583_alarm_off(void)
{
  PCF8583_get_status();
  PCF8583_status&=0xfb;
  PCF8583_write(0,PCF8583_status);
}


//PCF8563
uint8_t PCF8563_get_status1(void)
{
  PCF8563_status1=PCF8583_read(0);
  //PCF8563_alarm=(PCF8563_status1 & 8);
  return PCF8563_status1;
}

uint8_t PCF8563_get_status2(void)
{
  PCF8563_status2=PCF8583_read(1);
  
  return PCF8563_status2;
}

void PCF8563_start(void)
{
  PCF8563_get_status1();
  PCF8563_status1 &= 0xbf;
  PCF8583_write(0,PCF8563_status1);
}

void PCF8563_stop(void)
{
  PCF8563_get_status1();
  PCF8563_status1 |= 0x40;
  PCF8583_write(0,PCF8563_status1);
}

uint8_t PCF8563_get_alarm(void)
{
	return (PCF8563_get_status2() & 8);
}

void PCF8563_set_alarm_weekday(uint8_t day)
{
  day |= 0x80; 
  PCF8583_write(0x0c,day);
}

void PCF8563_set_alarm_day(uint8_t day)
{
	if (day>31) day=0;
	uint8_t data = bin2bcd(day);
	data |= 0x80;
  
  PCF8563_stop();  
  PCF8583_write(0x0c,data);
  PCF8563_start();
}

void PCF8563_set_alarm_min(uint8_t min)
{
	if (min>59) min=0;
	uint8_t data = bin2bcd(min);
	data |= 0x80;
  
  PCF8563_stop();  
  PCF8583_write(0x09,data);
  PCF8563_start();
}

void PCF8563_set_alarm_hour(uint8_t hour)
{
	if (hour>23) hour=0;
	uint8_t data = bin2bcd(hour);
	data |= 0x80;
  
  PCF8563_stop();  
  PCF8583_write(0x0a,data);
  PCF8563_start();
}


