#ifndef _KLCD_H
#define _KLCD_H


// text part.
uint8_t text_screen(char *buffer, uint16_t len);            /* write a complete screen-page */
uint8_t text_overwrite(char *buffer, uint16_t len);         /* overwrite display */
uint8_t text_append(char *buffer, uint16_t len);            /* append text at the current position */
uint8_t text_set_pos(uint16_t x, uint16_t y);               /* set cursor position e.g. for append mode */
void txt_set_cursor(uint16_t Pix_x_a,uint16_t Pix_y_a);

// graphic part.

#define GR_WIDTH        (SCR_WIDTH+1)   /**< graphic screen width in pixels */
#define GR_HEIGHT       (SL2+1)         /**< graphic screen height in pixels */
//#define GR_OFFSET       0x2000  /**< memory offset, address where the graphic buffer begins */
#define GR_OFFSET       0x0800  /**< memory offset, address where the graphic buffer begins */
#define GR_SIZE         9600    /**< (320 * 240)/8 */
#define STACKSIZE       100     /**< stacksize for floodfill in 32-bit words */
	
/* some useful macros */
#define min(a,b) (a<b) ? a:b
#define max(a,b) (a>b) ? a:b
#define in_x_range(x)   ((x<GR_WIDTH) && (x>=0)) ? 1:0
#define in_y_range(y)   ((y<GR_HEIGHT) && (y>=0)) ? 1:0
#define gr_bit_is_set(byte, bitval)     ((byte & bitval) == bitval) ? 1:0
#define gr_bit_is_clear(byte, bitval)   ((byte & bitval) != bitval) ? 1:0

	
/* prototypes */
void gr_clear();                                /* clear graphic screen */
void gr_write_all();                                /* write graphic buffer to display */
uint8_t gr_setpixel(uint16_t x, uint16_t y);    /* set a pixel */
uint8_t gr_clearpixel(uint16_t x, uint16_t y);  /* clear a pixel */
uint8_t gr_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);    /* draw line */
uint8_t gr_circle(uint16_t xc, uint16_t yc, uint16_t r);                /* draw a circle */
uint8_t gr_ellipse(uint16_t xc, uint16_t yc, uint16_t xr, uint16_t yr); /* draw an ellipse */
uint8_t gr_rectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);       /* draw a rectangle */
uint8_t gr_getpixel(uint16_t x, uint16_t y);                            /* boolean, false on error*/
uint8_t gr_fill(uint16_t x, uint16_t y);        /* fills a graphic object */
uint8_t gr_set_draw_area(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);   /* set drawing area */
uint8_t gr_in_draw_area(uint16_t x, uint16_t y);        /* return TRUE if coords are in drawing area */
uint8_t gr_clear_area(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);              /* clear a rectangular area */
void gr_set_cursor(uint16_t Pix_x_a,uint16_t Pix_y_a);
void bigstring(const char* pTxt, uint8_t len, uint8_t Inverzbit);
#endif
