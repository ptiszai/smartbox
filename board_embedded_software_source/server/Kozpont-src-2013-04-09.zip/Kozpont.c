/*
 *	Lamp kozpont Atmega128.
 *  Tiszai I.
 *  2007
 */

 /*
 	HIBAK!!!	
	-RS232-rol taplalkozik a rendszer ha ki van kapcsolva a tap, igy az LCD is???
 */

 // || &&
#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <inttypes.h>
#include <compat\ina90.h>

#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sd/fat.h"
#include "KLoop.h"
#include "K1loop.h"
#include "KMloop.h"
#include "Kozpont.h"
#include "KCom.h"
#include "KConfig.h"
#include "KTouch.h"
#include "pcf8583.h"
#include "sed1335.h"
#include "utils.h"
#include "K1loop.h"
#include "KSD.h"
#include "adc.h"
#include "KErrorControlling.h"

/*---------------------- konstansok -----------------------------*/
#define ROOT_PASSWD	"apma0410"
/*----------------------- valtozok ------------------------------*/
volatile unsigned char		status;
volatile unsigned char 		sys_status;
volatile unsigned char		error;
volatile uint16_t 			timercount;
volatile uint16_t 			timersec;
char msg[40];
char b_root_mode = 0;
char bSD_Error = 0;
#if 0
char newaddrflg = 0;
#endif
uint8_t sd_valid;
void set_new_addr_executor();


/*
 * Read out and reset MCUCSR early during startup.
 */
 /*
 * Mirror of the MCUCSR register, taken early during startup.
 */
 /*
uint8_t mcucsr __attribute__((section(".noinit")));

void handle_mcucsr(void)
  __attribute__((section(".init3")))
  __attribute__((naked));
void handle_mcucsr(void)
{
  mcucsr = MCUCSR;
  MCUCSR = 0;
}*/
/*
const uint8_t eecontent[] =
{ 0x01,0x01,0x01,0x02,0x01,0x02,0 };*/

/*----------------------- fuggvenyek ----------------------------*/

void Reset()
{ 

	cli();
	sleep_enable();
	sleep_cpu();
	sleep_disable();
}


/***********************************************************
 * main part.
 ***********************************************************/
//res_start:
int main(void)
{ 
 	init();
	
	while(1)
	{
		wdt_reset(); 			// watch dog
		rx1_executor();			// pheripheria.
		if (!bSD_Error && sd_valid)
		{
			test_executor();		// test.
			touch_executor();
			get_addr_executor();	// get address.
#if 0
			set_new_addr_executor(); // from "ujcimek.ini"
#endif
			if (config.trial != 0x55)
				l_com_rx_tx();
		}	
		sd_cd(); // sd card out/in.
		test_set_kliens_rec();	
	}
	return 1;
}

/***********************************************************
 * "ujcimek.ini"
 ***********************************************************/
 #if 0
void set_new_addr_executor()
{
	static unsigned int cimek_st[] = {0, 0,0, 0,0, 0,0, 0,0};
	switch (newaddrflg)
	{
		case	1:
			{
				int ii,row = 0;
				struct fat16_file_struct* fd = open_file("ujcimek.ini");
    			if(fd == NULL)
				{
					while(read_file(fd, (uint8_t*)msg, 10))
					{
					//	DelayMs(2);
					//	PutString(msg);					
						wdt_reset();
						for (ii=0;ii<10;ii++)
						{
							if (msg[ii] == 0x0d)
							{
								msg[ii] = 0; 
								break;
							}
						}
						if (row == 0)
						{
							cimek_st[0] = atoi(msg);
							if ((cimek_st[0] == 0) || (cimek_st[0] > 4))
							{
									PutString("ERROR0:ujcim"); 	
									newaddrflg = 2;
							}
							else
								row = 1;
						}
						else
						if (row)
						{
							if (sscanf (msg,"%u,%u",&cimek_st[row],&cimek_st[row+1]) != 2)
{
								PutString("ERROR1:ujcim"); 	
								newaddrflg = 2;
							}
							else
								row += 2;
						}
					}
					close_file(fd);
					newaddrflg = 3;
				}
				break;
			}
		case	2:	
			{		
			 	if(!remove_file("ujcimek.ini"))
           			PutString("d'nt rm 'ujcimek.ini'"); 
				newaddrflg = 0;
				break;
			}
		case	3:	
			{ // kuldes.
				break;
			}
		default:
			break;		
	}	
}//void set_new_addr_executor()
#endif

/***********************************************************
 * init part.
 ***********************************************************/
void altalanos_init(void)
{

 // init timers
 // TIMER0 initialize - prescale:1024
 // desired value: 10 mSec
	PIEZO_OFF
	DDRE |= (1<<DDE4);	//piezo out.

	TCCR0 = 0x00; //stop
 	TCNT0 = 157; //set count
 	TCCR0 = _BV(CS02)|_BV(CS01)|_BV(CS00); //start timer
 	TIMSK = _BV(TOIE0); //timer interrupt sources:over	

	timercount = 0;
    timersec = 0;

	config.infra = 0;
	config.install = 0;
	wdt_enable(WDTO_2S);

	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//	eecontentwrite();
	//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!			
//	PutString("altalanos_init oke");
		
}//void altalanos_init(void)

void clear_msg()
{
	int ii;
	for (ii=0;ii<40;ii++)
		msg[ii]=0;
}

//--------------------------------------------------------------
void init(void)
{
	_CLI();
	delayms(100);	
	com1_init();
	altalanos_init();
	sd_init();
    config_load();

	clear_msg();

	TIMER_STOP

	delayms(40);
	struct fat16_file_struct* fd1 = open_file("lpass.dat");

//	sprintf(msg,"fd1:%d",(int)fd1);
//	PutString(msg);
	wdt_reset();
    if(fd1 == NULL)
	{
		b_root_mode = 0;
	//	create_file( "lpass.dat" );
	}
	else
	{	
		if (read_file(fd1, (uint8_t*)msg, 8))
		{

			PutString(msg);
		//	msg[8] = 0;
			if (!strcmp(msg,ROOT_PASSWD))
			{
				b_root_mode = 1;			
				PutString("ROOT set!");
			}
			PutString("'lpass.dat'is rdy");
		}
		close_file(fd1);
	}
		
	delayms(40);
	wdt_reset();
	struct fat16_file_struct* fd = open_file("lamp.log");
    if(fd == NULL)
	{
	 	if(!create_file( "lamp.log" ))
		{
//#ifdef DEBUG
           	PutString("d'nt crt lamp.log");
			
//#endif
			bSD_Error = 1;
			sd_valid = 0;
			delayms(40);
		}
		else
		{
			PutString("lamp.log crt rdy");	
			close_file(fd);
			bSD_Error = 0;
			sd_valid = 1;
			delayms(40);
			write_Allerror_to_sd("start;\r\n", 0, 0, 0, 1);
		}
	}
	else
	{			
		close_file(fd);
		//append_file(fd, "start", 5);
		PutString("'lamp.log' is rdy");	
	
		bSD_Error = 0;
		sd_valid = 1;
		delayms(40);
		write_Allerror_to_sd("start;\r\n", 0, 0, 0, 1);
	}
#if 0
	fd = open_file("ujcimek.ini");
	if (fd)
	{
		newaddrflg = 1;
		PutString("It is ujcimek.ini!");
		close_file(fd);
	}
	else
	{
		newaddrflg = 0;
	}
#endif
 	TIMER_START

	init_touch();

//	l_com_init();
/*	if (!config.loop_type)
		chl1_com_init();
	else*/
	chlm_com_init();
	configure_pin_sd_cd();
	_SEI();

#ifdef DEBUG
	PutString("init ready"); lll
#endif
//	test();
}//void init(void)

//----------------------------------
void sd_cd()
{
	// sd card out/in.
	if (get_sd_cd() == 0)
	{ // bedugva
		if (sd_valid == 0)
		{
		//	PutString("bedugva");
			cli();
			sleep_enable();
			sleep_cpu();
			sleep_disable();
		//	delayms(100);
			wdt_reset();
			init();		
		//	struct fat16_file_struct* fd = open_file("lamp.log");
    	//	if(fd == NULL)
			if(bSD_Error)
			{
				sd_card_off();
				delayms(500);
				PutString("sd hiba!");
			//	bSD_Error = 1;
			}
			else
			{
			//	sed1335_clear_display();
				sd_valid = 1;
				bSD_Error = 0;
				write_to_sd("put sd/mmc card;\r\n");				
				lcd_exit();
			}
		}
	}
	else
	{ // nincs bedugva
		if (sd_valid)
		{
			sed1335_clear_display();
			sd_card_off();
			sd_valid = 0;
			bSD_Error = 0;
		//	sprintf(msg,"kiveve:0x%x,0x%x",DDRE,PINE);	
		//	PutString(msg);		
		}
	}	
}
/*************************************************************
 * ISR part.
 *************************************************************/

ISR (TIMER0_OVF_vect)
{
//	unsigned char sreg;
	timercount++;
	ad_timercount++;
	rx1_timercount++;
	l_timercount++;
	l_recTotalTimeoutMultiplier++;

	if((timercount%100) == 0)
	{
		++timersec;
		++test_timersec;
		Alarm_LED_blink();
	}
	if (!(timercount % 50))
	{
		Alarm_LED_fast_blink();
	}
//	_CLI();
//	sreg = SREG;
	// desired value: 10mSec
	TCNT0 = 157; //reload counter value
//	TCNT0 = 0xff; //reload counter value

//	SREG = sreg;		
//	_SEI();

}//ISR (TIMER0_OVF_vect)

//--------------------------------------------------------------
// vetel ISR.

ISR(USART1_RX_vect)
{ 			

#ifdef ELSZALLT
	UCSR1B &= ~_BV(RXCIE1);
//	rx_error = UCSR1A;
	if (bit_is_set(UCSR1A, FE1) || bit_is_set(UCSR1A, DOR1) || bit_is_set(UCSR1A, PE1))
	{
//		RS485_RE0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LERROR(RX_LERROR)
		uint8_t rxbuff = UCSR1A;
		rxbuff = UDR1;				
//		RX0_OFF
//		PutString("E1");	
	}	
	else
	{
  		//rxbuff = UDR0;  
		SET_LSTATUS(RX_INT)
     	l_rx_int(UDR1);	
    }
	UCSR1B |= _BV(RXCIE1);
#else	
	if (bit_is_set(UCSR1A, FE1) || bit_is_set(UCSR1A, DOR1) || bit_is_set(UCSR1A, PE1))
	{		
		uint8_t rxbuff = UDR1;
		rxbuff = UCSR1A;
		SET_COM1(RX_ERROR)					
	}	
	else
	{   		
     	rx1_add_data(UDR1);		
		
    }
#endif
}//ISR(USART1_RX_vect)

// 1 loop.
// vetel ISR
ISR(USART0_RX_vect)
{
 //	uint8_t rxbuff;
	
	UCSR0B &= ~_BV(RXCIE0);
//	rx_error = UCSR1A;
	if (bit_is_set(UCSR0A, FE0) || bit_is_set(UCSR0A, DOR0) || bit_is_set(UCSR0A, PE0))
	{
//		RS485_RE0_OFF
		CLR_LSTATUS(RX_INT)
		SET_LERROR(RX_LERROR)
		uint8_t rxbuff = UCSR0A;
		rxbuff = UDR0;				
//		RX0_OFF
//		PutString("E1");	
	}	
	else
	{
  		//rxbuff = UDR0;  
		SET_LSTATUS(RX_INT)
     	l_rx_int(UDR0);	
    }
	UCSR0B |= _BV(RXCIE0);
	
}

// adas ISR.
ISR(USART0_UDRE_vect)
{
	unsigned char temp;
	SET_LSTATUS(TX_INT)
	temp=l_tx_int();
	if (CHK_LSTATUS(TX_READY))
		return;
	UDR0=temp;
//	PutChar(temp);
}


ISR(__vector_default)
{

}

//---------------------------------------------------------
void beep()
{
//return;
	uint16_t i;
//	_CLI();
	for (i=0;i<200;i++)
	{
		PIEZO_ON
		wdt_reset();
		delayus(100);
		PIEZO_OFF
		wdt_reset();
		delayus(100);
	}
//	_SEI();
}//void beep()

//---------------------------------------------------------
void beep_h()
{
//return;
	uint16_t i;
//	_CLI();
	for (i=0;i<1000;i++)
	{
		PIEZO_ON
		wdt_reset();
		delayus(100);
		PIEZO_OFF
		wdt_reset();
		delayus(100);
	}
//	_SEI();
}//void beep()

/*
void none(void)
{
	asm volatile
	( 
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
		"nop\n"
	);
}*/

