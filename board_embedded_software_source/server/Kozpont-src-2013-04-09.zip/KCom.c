#include <avr\io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <compat\ina90.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include 	"sd/fat.h"
#include	"macros.h"
#include 	"KLoop.h"
#include 	"K1loop.h"
#include 	"Kozpont.h"
#include 	"KTouch.h"
#include	"KCom.h"
#include 	"KSD.h"
#include 	"pcf8583.h"
#include 	"sed1335.h"
#include 	"utils.h"
#include 	"KConfig.h"
#include 	"KErrorControlling.h"
//#include 	"KMloop.h"


// com0
/*
char	com0_state;
int 	rx0_rec_index;
uint8_t	rx0_rec_buff[REC0_MAX_LENGTH+1];
*/

// com1
char	com1_state;
int 	rx1_rec_index;
uint8_t	rx1_rec_buff[REC1_MAX_LENGTH+1];

uint16_t rx1_timercount;


uint8_t uint8_1,uint8_2,uint8_3;     
static int ii;      
int PC_alive;

#ifdef SERIAL_PRINTER
void PutPrinter( const char *str);
void PutPrinter_0d_0a( const char *str);
#endif

/***********************************************************
 * init resz.
 ***********************************************************/
 /*
// COM0
void com0_init(void)
{
	unsigned int baud=BAUD9600_16;

	DDRC |= (1<<DDC3);
	DDRB |= (1<<DDB5)|(1<<DDB6)|(1<<DDB7);

 	UCSR0A = 0x00;
 	UBRR0H = (unsigned char)(baud>>8);
 	UBRR0L = (unsigned char)baud;
 //	UCSRB = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0);
	UCSR0B = (1<<TXEN0) ;
	UCSR0C = (3<<UCSZ00);
	
	
//	set_com_port(COMPORTrs232);
	com0_state = 0;
	rx0_rec_index = 0;
#ifdef DEBUG
	PutString("Com0 oke");	
#endif
}//com0_init(void)

//------------------------------------------------------------
void rx0_add_data(uint8_t data)	
{
	if (rx0_rec_index < REC0_MAX_LENGTH)
	{
		rx0_rec_buff[rx0_rec_index] = data;
		rx0_rec_index++;	
	}
#ifdef DEBUG
	else
		PutString("Com0:hosszu a radat");
#endif

}//void rx0_add_data(uint8_t data)
*/


//------------------------------------------------------------
// COM1
//------------------------------------------------------------
void com1_init(void)
{
	unsigned int baud;

 //#ifdef SERIAL_PRINTER
		//baud=BAUD115K_16;
		baud=8;
 //#else
	//	baud=BAUD9600_16;
 //#endif
//	unsigned int baud=BAUD19K_16;

	DDRC |= (1<<DDC3);
	DDRB |= (1<<DDB5)|(1<<DDB6)|(1<<DDB7);

 	UCSR1A = 0x00;
 	UBRR1H = (unsigned char)(baud>>8);
 	UBRR1L = (unsigned char)baud;
/*#ifdef SERIAL_PRINTER
	UCSR1B = (1<<TXEN1);
#else*/
 	UCSR1B = (1<<RXEN1)|(1<<TXEN1)|(1<<RXCIE1);
//#endif
//	UCSR1B = (1<<TXEN1) ;
	UCSR1C = (3<<UCSZ10) | (1<<USBS1);
	
	
	set_com_port(COMPORTrs232);
	com1_state = 0;
	rx1_rec_index = 0;
	rx1_rec_buff[0] = 0;
	PC_alive = 0;
#ifdef DEBUG	
	//PutString("Com1 init oke");	
#endif
}//com0_init(void)


//------------------------------------------------------------
void rx1_add_data(uint8_t data)	
{
	if (rx1_rec_index < REC1_MAX_LENGTH)
	{
		rx1_rec_buff[rx1_rec_index] = data;
		rx1_rec_index++;
		rx1_time_out(1,2);	
	}
	else
	{
		SET_COM1(RX_ERROR)	
#ifdef DEBUG			
	//	PutString("Com1:hosszu a vett adat");
#endif
	}
	SET_COM1(RX_DATA)

}//void rx1_add_data(uint8_t data)
	

/************************************************************
 * com1:Vetel feldolgozo resz.
 ***********************************************************/
void com1_rx_controlling(void)
{
//	PutString(rx1_rec_buff);
   // char msg[50];
   beep();
 
    if (rx1_rec_buff[0] == 'H')
    {
		if (rx1_rec_buff[1] == 'E')
		if (rx1_rec_buff[2] == 'L')
		if (rx1_rec_buff[3] == 'L')
		if (rx1_rec_buff[4] == 'O')
			PutDatas( "ELLOH", 4);
	}
	else        
    if (rx1_rec_buff[0] == 's')
    {

      /*  if (rx1_rec_buff[1] == 'l')
        {// touch.
			long x,y,xe,ye,flag;
			char txt[50];
            x  = (long)(rx1_rec_buff[2])*256 + (long)(rx1_rec_buff[3]);
            y  = (long)(rx1_rec_buff[4])*256 + (long)(rx1_rec_buff[5]);
            xe = (long)(rx1_rec_buff[6])*256 + (long)(rx1_rec_buff[7]);
            ye = (long)(rx1_rec_buff[8])*256 + (long)(rx1_rec_buff[9]);
            flag = (long)(rx1_rec_buff[10])*256 + (long)(rx1_rec_buff[11]);
			strcpy(&txt[0],(char*)(&rx1_rec_buff[12]));
            string_write(&txt[0], x, y, xe, ye, flag ); 			
          //  sprintf(msg,"kapott:x=%ld,y=%ld,xe=%ld,ye=%ld,flg=%ld,txt=%s\n",x,y,xe,ye,flag,&txt[0]);
		//	PutString(msg);           
        }
		else*/
	/*	if (rx1_rec_buff[1] == 'k')
        {// lcd kontraszt	
			if (rx1_rec_buff[2] == 1)
			// down
				set_lcd_contrast(-1);
			else
			//	up
				set_lcd_contrast(1);
			
		}*/
		if (rx1_rec_buff[1] == 'P')
		{ // PC on/off
			if (rx1_rec_buff[2] == '1')
				PC_alive = 1;
			else
				PC_alive = 0;
		}
		else
		if (rx1_rec_buff[1] == 't')
        {// pcf8583 time	
		  
			PCF8583_set_time((uint8_t)(rx1_rec_buff[2]),(uint8_t)(rx1_rec_buff[3]),(uint8_t)(rx1_rec_buff[4]),0);
		
			PCF8583_get_time(&uint8_1,&uint8_2,&uint8_3,NULL);
			//PCF8583_get_time(&hour,&min,&sec,NULL);
			sprintf(msg,"T:%02d:%02d:%02d",(int)uint8_1,(int)uint8_2,(int)uint8_3);			
			PutString(msg);
		}
		else
        if (rx1_rec_buff[1] == 'd')
        {// pcf8583 date	
            //days,months,years
			//uint8_t day = 1,month = 1;
		//	uint8_t year = 7;

		    uint8_1 =  1; 	//day
			uint8_2 =  1;	//month  
			uint8_3 =  7;   //year

			PCF8583_set_date((uint8_t)(rx1_rec_buff[2]),(uint8_t)(rx1_rec_buff[3]),(uint8_t)(rx1_rec_buff[4]));		
		/*	PCF8583_get_date(&day,&month,&year);
			date_write(day,month,year);
			sprintf(msg,"DATE:%02d:%02d:%04d",(int)day,(int)month,(int)year+2000);	*/
			PCF8583_get_date(&uint8_1,&uint8_2,&uint8_3);
			date_write(uint8_1,uint8_2,uint8_3);		
			sprintf(msg,"D:%02d:%02d:%04d",(int)uint8_1,(int)uint8_2,(int)uint8_3+2000);
			PutString(msg);	
		//	string_write(msg, 31,38, 0, 0, LCD_BIGFONT );
		}
		else
	/*	if (rx1_rec_buff[1] == 'p')
		{ // port test.
			if (rx1_rec_buff[2] == 'a')
			{	//porta				
				PORTA = rx1_rec_buff[3]; 				
			}
			if (rx1_rec_buff[2] == 'b')
			{	//portb				
				PORTB = rx1_rec_buff[3]; 				
			}
			if (rx1_rec_buff[2] == 'e')
			{	//porte				
//				PORTE = rx1_rec_buff[3]; 
#ifdef DEBUG
				sprintf(msg,"PORTE:0x%x",PORTE);
				PutString(msg);   				
#endif
			}
			if (rx1_rec_buff[2] == 'f')
			{	//portf				
			//	sbi(DDRF,DDF4);
			//	DDRF = 0xff;
				PORTF = rx1_rec_buff[3]; 
			//	sprintf(msg,"PORTF:0x%x",PORTF);
			//	PutString(msg);  				
			}
			if (rx1_rec_buff[2] == 'l')
			{	//portf				
				PORTF = rx1_rec_buff[3]; 				
			}

		}
		else*/
	/*	if (rx1_rec_buff[1] == 'e')
		// factory config setting in the eeprom.
			eecontentwrite();
	//	if (rx1_rec_buff[1] == 'E')
		// allomas hiba
//			set_allomas_error(1,rx1_rec_buff[2],rx1_rec_buff[3]);
		else*/
		if (rx1_rec_buff[1] == 'i')
		{
		// lcd init.
		
			lcd_init();
			lcd_main_picture();
			lcd_main_bottom_picture();
	//		sed1335_sleep_disable();
		}
		else
		if (rx1_rec_buff[1] == 'r')	//reset;
		{
			 Reset();
		/*	cli();
			sleep_enable();
			sleep_cpu();
			sleep_disable();*/
		}
		else
		if (rx1_rec_buff[1] == 'c')	//A -> B;
			A_copyto_B();
		else
		if (rx1_rec_buff[1] == 'a')	//set the loop address;
		{		
			config_loop_save(rx1_rec_buff[2]);
		}
		else
		if (rx1_rec_buff[1] == 'k')	//set the test kliens;
		{//';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.	
			for(int ii=0;ii<7;ii++)
				test_kliens[ii]=rx1_rec_buff[2+ii];
		//	PutString("gggg\n"); 
		}
		else
		if (rx1_rec_buff[1] == 'L')	//Alarm Ledek kapcsolasa
		{
			if (rx1_rec_buff[2] == 0xff)	//ALARM led be-kikapcsolasa
			{
			
				ALARM_ON
			}
			else
			{			
				ALARM_OFF
			}
			if (rx1_rec_buff[3] == 0xff)	//OUT be-kikapcsolasa
			{
			
				OUT_ON
			}
			else
			{			
				OUT_OFF
			}					
		}
		else
		if (rx1_rec_buff[1] == 'h')	//TEST:ora,perc
		{

			config_annual_HM_save((uint8_t)rx1_rec_buff[2], (uint8_t)rx1_rec_buff[3]);			
			sprintf(msg,"TEST:h:%d,m:%d",config.annual_HM_test[0],config.annual_HM_test[1]);
			PutString(msg);		
		}
		else
		if (rx1_rec_buff[1] == 'n')	//INSTALL stop,perc
		{
			config_install_save((uint8_t)rx1_rec_buff[2]);			
			sprintf(msg,"INST:s:%d",config.install_min);
			PutString(msg);	
		}
    }
	else
	if (rx1_rec_buff[0] == 'g')
    {
		if (rx1_rec_buff[1] == 't')
        {// pcf8583 time
			//uint8_t hour,min,sec;            
		//	PCF8583_get_time(&hour,&min,&sec,NULL);
        //    sprintf(msg,"gt,time: hour=%ld,min=%ld,sec=%ld\n",(long)hour,(long)min,(long)sec);

			PCF8583_get_time(&uint8_1,&uint8_2,&uint8_3,NULL);
            sprintf(msg,"gt time: h=%ld,m=%ld,s=%ld\n",(long)uint8_1,(long)uint8_2,(long)uint8_3);
			PutString(msg); 	
		}
		else
        if (rx1_rec_buff[1] == 'd')
        {// pcf8583 date	
            
            //days,months,years
		//	PCF8583_get_date(&day,&month,&year);
         //   sprintf(msg,"gd,date: day=%ld,month=%ld,year=%ld\n",(long)day,(long)month,(long)year);
			PCF8583_get_date(&uint8_1,&uint8_2,&uint8_3);
            sprintf(msg,"gt date: d=%ld,m=%ld,y=%ld\n",(long)uint8_1,(long)uint8_2,(long)uint8_3);
			PutString(msg); 
		}
		else
        if (rx1_rec_buff[1] == 'g')
		{ // read gr. pixel
		 	long position  = (long)(rx1_rec_buff[2])*256 + (long)(rx1_rec_buff[3]);
			sed1335_set_address(position + sed1335_get_grcur(0));
		}
		else
		if (rx1_rec_buff[1] == 'e')
		{
		//	int ii;
			uint8_t* 	ee_addr = (uint8_t*)EE_L1CH_NUM;
			for (ii=0;ii<32;ii++,ee_addr++)
			{
				sprintf(msg,"addr:%d,0x%x",ii,eeprom_read_byte(ee_addr));
				PutString(msg);
			}
		}
		else
		if (rx1_rec_buff[1] == 'c')
		{ //get A,B
		//	int ii;
#ifdef A_B
			for (ii=0;ii<MAX_AB_LEN;ii++)
			{
#ifdef TOLTESJEL
				sprintf(msg,"A[%d]:addr:%d,T:%d,A:%d,F:%d,C:%d",ii,A_error[ii].addr,A_error[ii].tolt,A_error[ii].akku,A_error[ii].fenycs,A_error[ii].com);
#else
				sprintf(msg,"A[%d]:addr:%d,A:%d,F:%d,C:%d",ii,A_error[ii].addr,A_error[ii].akku,A_error[ii].fenycs,A_error[ii].com);
#endif
				PutString(msg);
				wdt_reset();
				DelayMs(10);
			}
			for (ii=0;ii<MAX_AB_LEN;ii++)
			{
#ifdef TOLTESJEL
				sprintf(msg,"B[%d]:addr:%d,T:%d,A:%d,F:%d,C:%d",ii,B_error[ii].addr,B_error[ii].tolt,B_error[ii].akku,B_error[ii].fenycs,B_error[ii].com);
#else
				sprintf(msg,"B[%d]:addr:%d,A:%d,F:%d,C:%d",ii,B_error[ii].addr,B_error[ii].akku,B_error[ii].fenycs,B_error[ii].com);
#endif
				PutString(msg);
				wdt_reset();
				DelayMs(10);
			}
#endif
		}
		else
		if (rx1_rec_buff[1] == 'i')
		{ //konfiguracio lekerdezes.
				sprintf(msg,"Ver:%d",config.ver);
				PutString(msg);
				sprintf(msg,"Hurok sz.:%d",allloopnumenable);
				PutString(msg);
				sprintf(msg,"Interf PC:%d",config.pheriph);
				PutString(msg);
				sprintf(msg,"Infra be/ki:%d",config.infra);
				PutString(msg);
				sprintf(msg,"Inst be/ki:%d, ido:%d perc",config.install,config.install_min/60);
				PutString(msg);			
				sprintf(msg,"TEST:h:%d,m:%d",config.annual_HM_test[0],config.annual_HM_test[1]);
				PutString(msg);	
				sprintf(msg,"TEST week:20%02d.%02d.%02d",config.weekly_test[2],config.weekly_test[1],config.weekly_test[0]);
				PutString(msg);	
				sprintf(msg,"TEST ann:20%02d.%02d.%02d",config.annual_test[2],config.annual_test[1],config.annual_test[0]);
				PutString(msg);
		}
	}
	else
	if (rx1_rec_buff[0] == 'F')
    { // fat16 sd/mmc
		struct fat16_file_struct* fd;
		if (rx1_rec_buff[1] == 't')
        {// touch
			strcpy(msg,(char*)&rx1_rec_buff[2]);
			
            if(!create_file( msg))
           		PutString("d'nt create file"); 
		}
		else
	/*	if (rx1_rec_buff[1] == 'l')
        {// ls						
            ls_dir();           	
		}
		else*/
		if (rx1_rec_buff[1] == 'r')
        {// read file
		
			//strcpy(msg,&rx1_rec_buff[2]);
			fd = open_file("lamp.log");
            if(fd)
           	{
			//	int ii;
				TIMER_STOP
				PutString("!sP\n");
				DelayMs(10);
				msg[35]=0;

				while(read_file(fd, (uint8_t*)msg, 35))
				{
					DelayMs(10);
					PutString(msg);					
					wdt_reset();
					for (ii=0;ii<40;ii++)
						msg[ii] = 0; 
				}
				close_file(fd);
				DelayMs(10);
				PutString("!eP\n");
				TIMER_START
			}
			else
				PutString("d'nt op file"); 
		}
		else
		if (rx1_rec_buff[1] == 'a')
        {// append file
			//PutString("append file"); 
			strcpy(msg,(char*)&rx1_rec_buff[2]);
			int ii = 0;
			char* offset = &msg[0];
			while((*offset != ' ') && (*offset != '\0'))
			{
                ++offset;
				++ii;
			}

            if(*offset == ' ')
			{
			//	++offset;
                *offset = '\0';
				++ii;
			}
            else
                return ;
		//	PutString(&msg[0]);
			fd = open_file(&msg[0]);
            if(fd)
           	{
				strcpy(msg,(char*)&rx1_rec_buff[2+ii]);
				if (append_file(fd, (uint8_t*)msg, strlen(msg)))
				{
					PutString("app.oke");
				}
				close_file(fd);
			}
			else
				PutString("d'nt open file"); 
		}
		else
		if (rx1_rec_buff[1] == 'x')
        {// remove
			strcpy(msg,(char*)&rx1_rec_buff[2]);
			
            if(!remove_file( msg))
           		PutString("d'nt rm file"); 
		}
		else
		if (rx1_rec_buff[1] == 'p')
        {// create 	and write lpass.dat	
			if(!create_file( "lpass.dat" ))
			{
           		PutString("d'nt crt'lpass.dat'");				
			}
			else
			{
				PutString("'lpass.dat'crt rdy");				
				fd = open_file("lpass.dat");
				if (fd)
				{		
					strcpy(msg,(char*)&rx1_rec_buff[2]);
					if (append_file(fd, (uint8_t*)msg, strlen(msg)))
					{
						sprintf(msg,"lpass.dat:write:'%s'",&rx1_rec_buff[2]); 
						PutString(msg);
					}			
					close_file(fd);
					DelayMs(10);
					wdt_reset();
					fd = open_file("lpass.dat");
					if (fd)
					{
						if (read_file(fd, (uint8_t*)msg, 15))
						{				
							PutString("'lpass.dat' rdy");				
						}
						else 
							PutString("d'nt read'lpass.dat'");
						close_file(fd);
					}				
				}
								
			}		
		}
		else
		if (rx1_rec_buff[1] == 'P')
        {// remove lpass.dat					
            if(!remove_file("lpass.dat"))
           		PutString("d'nt rm'lpass.dat'"); 
			else
				PutString("rm'lpass.dat'file"); 
		}
		DelayMs(10);
	}
	else
	if (rx1_rec_buff[0] == 'A')
    {	//allomas resz.	
		if (rx1_rec_buff[1] == 'a')
        {// addr,cmd,ismetles szam.		
			if(!(rx1_rec_buff[2]))
				chn_ask.num  = 0;
			chn_ask.chn.addrh = rx1_rec_buff[2];
			chn_ask.chn.addrl = rx1_rec_buff[3];						
			chn_ask.chn.cmd  = rx1_rec_buff[4];
			chn_ask.num      = rx1_rec_buff[5];
			chn_ask.timeout  = 0;
		}
		if (rx1_rec_buff[1] == 'r')
        {// all addr torlese.
			chn_ask.chn.addrh = 0xfe;	
			chn_ask.chn.addrl = 0;					
			chn_ask.chn.cmd  = 0x90;
			chn_ask.num      = 2;
			chn_ask.timeout  = 0;
		//	config_remove_alladdr();
		}	
	/*	if (rx1_rec_buff[1] == 'd')
        {// message kuldes mod .		
			chn_ask.loop = rx1_rec_buff[2];
			if (rx1_rec_buff[3] == '1')
			//be
				chn_ask.chn.cmd = 0xa1;			
			else
			//ki
				chn_ask.chn.cmd = 0xa2;	
			chn_ask.chn.addrh = 0;	
			chn_ask.chn.addrl = 0;								
			chn_ask.num      = 2;
			chn_ask.timeout  = 0;			
		}*/		
		if (rx1_rec_buff[1] == 's')
        {// hurok reset .		
			chn_ask.loop = rx1_rec_buff[2];		
			chn_ask.chn.cmd = 0xa3;						
			chn_ask.chn.addrh = 0;	
			chn_ask.chn.addrl = 0;									
			chn_ask.num      = 1;
			chn_ask.timeout  = 0;			
		}	
		if (rx1_rec_buff[1] == 'l')
        {// hurok cimlista kerese.
	//		int ii;
			get_addr_datas(rx1_rec_buff[2]);
		}	
	}
	else
	if (rx1_rec_buff[0] == 'T')
    {	//Lcd-Touch funkcio resz.
		if (rx1_rec_buff[1] == 'M')	
		{	//Manual teszt
			start_test(SYS_TEST2);
			lcd_set_chan_cmd("Manual test start 5 min");
			beep(); 
		}
		else
		if (rx1_rec_buff[1] == 'C')	
		{	//Clear all addr.
			clear_all_address();
		}
		else
		if (rx1_rec_buff[1] == 'c')	
		{	//Clear 1 addr.
			
		}
		else
		if (rx1_rec_buff[1] == 'w')	
		{	// Next weekly	
		//	sprintf(msg,"TEST0 weekly:nap:%d,ho:%d,ev:%d",rx1_rec_buff[4], rx1_rec_buff[3], rx1_rec_buff[2]);
		//	PutString(msg);		
			config_weekly_save(rx1_rec_buff[2], rx1_rec_buff[3], rx1_rec_buff[4]);
		//	sprintf(msg,"TEST weekly:nap:%d,ho:%d,ev:%d",config.weekly_test[0],config.weekly_test[1],config.weekly_test[2]);
			sprintf(msg,"TEST week:20%02d.%02d.%02d",config.weekly_test[2],config.weekly_test[1],config.weekly_test[0]);			
			PutString(msg);	
			config_load();
			lcd_main_bottom_picture();



	/*		uint8_t hour=0,min=0;
			PCF8583_get_time(&hour,&min,NULL,NULL);
			min_test = min;	*/
//			set_weekly_alarm(rx1_rec_buff[4]);
			beep();
		}
		else
		if (rx1_rec_buff[1] == 'a')	
		{	// Next annual			
			config_annual_save(rx1_rec_buff[2], rx1_rec_buff[3], rx1_rec_buff[4]);
		//	sprintf(msg,"TEST annual:nap:%d,ho:%d,ev:%d",rx1_rec_buff[4], rx1_rec_buff[3], rx1_rec_buff[2]);
		//	PutString(msg);	
		//	sprintf(msg,"TEST annual:nap:%d,ho:%d,ev:%d",config.annual_test[0],config.annual_test[1],config.annual_test[2]);
			sprintf(msg,"TEST ann:20%02d.%02d.%02d",config.annual_test[2],config.annual_test[1],config.annual_test[0]);
			PutString(msg);	
			config_load();
			lcd_main_bottom_picture();
		/*	uint8_t hour=0,min=0;
			PCF8583_get_time(&hour,&min,NULL,NULL);
			min_test = min;	*/
			beep();
		}		
		else
		if (rx1_rec_buff[1] == 'S')	
		{	//Lcd clear .
			lcd_clear();
		//	beep_h();
		}
		else
		if (rx1_rec_buff[1] == 'L')	
		{	//switch light 
			if (rx1_rec_buff[2] == '1')
				// on.
				switch_light(1);
			else
				// off
				switch_light(0);
		}
		else
		if (rx1_rec_buff[1] == 'P')	
		{	//pheripherie.
			if (rx1_rec_buff[2] == 'I')	
			{// install
				if (rx1_rec_buff[3] == '1')
				// on
					//lcd_system_panel_setting(8, 0);
					set_install(1);	
				else
				// off
//					lcd_system_panel_setting(7, 0);	
					set_install(0);	
				beep(); 
			}
			if (rx1_rec_buff[2] == 'i')	
			{// infra
				if (rx1_rec_buff[3] == '1')
				// on
					lcd_system_panel_setting(6, 0);
				else
				// off
					lcd_system_panel_setting(5, 0);	
				beep(); 
			}
		}
		else
		if (rx1_rec_buff[1] == 'G')	
		{	//Get all addr.
			start_get_all_address();
		}
	}

/*	rx1_rec_buff[3] = 0xd;
	rx1_rec_buff[4] = 0xa;
	rx1_rec_buff[5] = 0;

   PutDatas( &rx1_rec_buff[0], 5 );*/
	rx1_rec_buff[0] = 0;
}//void com1_rx_controlling(void)

//------------------------------------------------------------
void addrlist_print_com()
{
	//TIMER_STOP
//	struct fat16_file_struct* fd = open_file("lamp.log");
//    if(!fd)
 //   	return;							
		
	if ((all_addr[1] > 0) && (all_addr[1] < COMM_MAX_ADDR))	
	{
	//	char msg[60];
	//	int ii;
		sprintf(msg,"'Loop:'%d' Addr:'%d';",all_addr[0],all_addr[1]);
	//	sprintf(msg,"loop:%d, addr num:%d--\n",all_addr[0],all_addr[1]);
		//append_file(fd, (uint8_t*)msg, strlen(msg));
		write_to_sd(msg);
		PutString(msg);
		if (!PC_alive)
			PutPrinter_0d_0a(msg);
		for (ii=0;ii<all_addr[1];ii++)	
		{
			sprintf(msg,"addr:%d;",all_addr[ii+2]);
		//	
			//append_file(fd, (uint8_t*)msg, strlen(msg));
			write_to_sd(msg);
			PutString(msg);
			if (!PC_alive)
				PutPrinter_0d_0a(msg);
		//	if (ii%16)
		//		append_file(fd, (uint8_t*)"\r\n", 2);	
		}
	}
	else
		PutString("0lista");

//	close_file(fd);
//	TIMER_START
}	

				
//------------------------------------------------------------
void com_contolling(const char* inbuf)
{  
}//void com_contolling(const char* inbuf)

//------------------------------------------------------------
void rx1_executor(void)	
{	
	if (CHK_COM1(RX_DATA))
	{
		if (rx1_time_out(0,0))
		{
			CLR_COM1(RX_DATA)
#ifdef DEBUG
			if (CHK_COM1(RX_ERROR))

				PutString("Com1:rec.hiba");
			else
			if (rx1_rec_index >= REC1_MAX_LENGTH)
				PutString("Com1:hosszu a radat");
			else
#endif
			{	
				com1_rx_controlling();
			}
			rx1_rec_index = 0;
		}
	}

}//void rx1_executor(void)

/**********************************************************
 * time out fg.
 **********************************************************/

uint8_t rx1_time_out(uint8_t start,uint8_t diff)
{	
//	static uint8_t overflow = 0;
	static uint16_t _time_out = 0;

	if (start)
	{		
		rx1_timercount = 0;
		_time_out = diff;
	//	overflow =(_time_out <= timercount)?1:0;					
	}
	else
	{
/*		if (overflow)
		{
			if (timercount > _time_out)
				return 0;
			else
				overflow = 0;
		}
		else*/
		if (rx1_timercount >= _time_out)
			return 1;
	}
	return 0;
}//uint8_t rx1_time_out(uint8_t start,uint8_t diff)


/***************************************************************
 * Usart adas a PC fele tesztmodban.com1-en.
 ***************************************************************/

/*--- void PutChar0( unsigned char byte ) ----------------------------*/
void PutChar( char byte ) 
{
	// wait for empty transmit buffer
	while ( !( UCSR1A & (1<<UDRE1) ));

	// send data
	UDR1 = byte;

}

//------------------------------------------------------------
void PutString_no0( const char *str)
{
	unsigned char i = 0;
	while ( str[i] ) {	
		PutChar( str[i] );
		i++;	
	}
}

/*--- void PutString( unsigned char *str )----------------------------*/
void PutString( const char *str)
{
	if (PC_alive)
	{
		PutString_no0(str);
		PutChar( 0x0d );
//	PutChar( 0x0a );
		PutChar( 0 );	
		DelayMs(50);
	}
}

#ifdef SERIAL_PRINTER
/*--- void PutPrinter( unsigned char *str )----------------------------*/
void PutPrinter( const char *str)
{
	PutString_no0(str);
//	PutChar( 0x0d );
//	PutChar( 0x0a );
	PutChar( 0 );	
	DelayMs(50);
}

void PutPrinter_0d_0a( const char *str)
{
	PutString_no0(str);
	PutChar( 0x0a );
	PutChar( 0x0d );
	PutChar( 0 );	
	DelayMs(50);
}
#endif

/*--- void PutDatas( unsigned char *data, uint8_t length )------------*/
void PutDatas( char *data, uint8_t length )
{
	unsigned char i = 0;

	while ( length ) 
	{	
		PutChar( data[i] );
		length--;
		i++;	
	}
}

//---------------------------------------------------------
void PutInt16( uint16_t data )
{
 uint16_t num = 10000;
    uint8_t started = 0;

    while(num > 0)
    {
        uint8_t b = data / num;
        if(b > 0 || started || num == 1)
        {
            PutChar('0' + b);
            started = 1;
        }
        data -= b * num;

        num /= 10;
    }
}

//---------------------------------------------------------
void PutInt32( uint32_t data )
{
 	uint32_t num = 1000000000;
    uint8_t started = 0;

    while(num > 0)
    {
        uint8_t b = data / num;
        if(b > 0 || started || num == 1)
        {
            PutChar('0' + b);
            started = 1;
        }
        data -= b * num;

        num /= 10;
    }
}

//---------------------------------------------------------
void set_com_port(COMPORTtype mode)
{
    COM_ALL_OFF
    switch (mode)
    {
        case COMPORTeth:
            COM_ETH_ON
            break;
        case COMPORTrs232:
            COM_RS_ON
            break;         
        case COMPORTusb:
            COM_USB_ON
            break;
        case COMPORTttl:
            COM_TTL_ON
            break;
    }
}//void set_com_port(COMPORT mode)
