/*
 *	Lamp touch lcd Atmega128.
 *  Tiszai I.
 *  2007
 */
#include <avr/io.h>
#include <inttypes.h>
#include <avr/eeprom.h>
#include <avr/wdt.h> 
#include <avr/sleep.h> 
#include <avr/interrupt.h>
#include <compat\ina90.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "transz.h"
#include "sd/fat.h"
#include "macros.h"
#include "KLoop.h"
#include "K1loop.h"
#include "KMloop.h"
#include "Kozpont.h"
#include "KTouch.h"
#include "Fonts.h"
#include "KCom.h"
#include "sed1335.h"
#include "lcd.h"
#include "adc.h"
#include "pcf8583.h"
#include "utils.h"
#include "KConfig.h"
#include "KSD.h"
#include "KErrorControlling.h"

/*----------------------- valtozok ------------------------------*/

int t_pos_x, t_pos_y;
//char msg[50]; 

uint8_t ctrl_panel, ctrl_panel_prev; 
SUBPICTURE current_pic_s;
uint8_t current_date[2][3];
//uint8_t current_date2[3];
uint8_t current_date_pos[3];
uint8_t current_time[2];
uint8_t current_clr1_pos[2];
uint8_t current_clr1[3];
uint8_t hour,min;
uint8_t month,day,year;
uint8_t up_down,num_index;
uint8_t blink;
uint8_t ctrl_offset;
uint16_t bill_time;
uint16_t test_timersec = 0;
static uint16_t prev_test_timer_sec = 0;
uint8_t min_test = 0;
static uint8_t get_max_loop_num=0;
char msg_state[25];
char install;
uint16_t inst_timer = 0;

void start_test(uint8_t mode_a);
void end_test(void);
/*
struct 
{
	uint8_t index_num;
	uint8_t index_loop;	
	uint8_t index_addr;
}clr1addr;*/

/*---------------------- konstansok -----------------------------*/


/***********************************************************
 * sd init resz.
 ***********************************************************/

void init_touch(void)
{
	
	LCD_RD_OFF
	LCD_WR_OFF
	LCD_CS_OFF
	LCD_LIGHT_OFF
	OFF_LKINC
	OFF_LKCS
	ALARM_OFF
	PORTA = 0xff;
    DDRA  = 0xff;
	//DDRF  = 0;
	DDRG  = (1<<DDG0)|(1<<DDG1)|(1<<DDG2);
	DDRC |= (1<<DDC0)|(1<<DDC5)|(1<<DDC6);   
//	DDRF |= (1<<DDF4)|(1<<DDF5);
	sbi(DDRF,DDF4);
	sbi(DDRF,DDF5);
 
	lcd_io_dir_out;

	lcd_init();

	PCF8583_init();
	
	if (bSD_Error || get_sd_cd())
	{
		sd_card_off();
		return;
	}
	/*if (bSD_Error)
	{
		string_write("NINCS SD KARTYA!", 10,100,0,0, LCD_BIGFONT );
		string_write("LEALLOK!", 10,150,0,0, LCD_BIGFONT );
		return;
	}*/

	lcd_main_picture();
	lcd_main_bottom_picture();
	ctrl_panel = CTR_NONEctl;
	ctrl_panel_prev = ctrl_panel;
	current_pic_s = NONEpic;
	switch_light(0);
    set_pushed_area(0, 0, 0, 0);
		
	t_time_out(1,150);
	hour = 0;
	min  = 0;
	month = 0;
	day = 0;
	year = 0;
	current_date_pos[0] = 15;
	current_date_pos[1] = 21;
	current_date_pos[2] = 27;
	current_clr1_pos[0] = 20;
	current_clr1_pos[1] = 28;
	blink = 0;
	bill_time = 0;
	ctrl_offset = 0;
 
	current_clr1[0] = 1;
	current_clr1[1] =  (config.loop_type) ? 0 : 1;
	current_clr1[2] = 2;

	AB_init();

#ifdef LARGE_FONT
//	string_write("1234", 0, 20, 50, 50, LCD_BIGFONT );
#else	 
//	string_write("1234", 5, 5, 91, 48, LCD_SMALLFONT );
#endif
//	gr_line(50, 50, 50, 200);
//	gr_line(50, 50, 200, 200);
//	gr_rectangle(5, 5, 91, 48);
	//string_write("1", 5, 5, 91, 48, LCD_FRAME );
//	PutString("Touch init oke");
//	PutString("lcd init");
}//t_sed_init(void)

//------------------------------------------------------------
void  lcd_init()
{
	TIMER_STOP
	wdt_reset();
	LCD_RESET_ON
 	delayms(30);
    LCD_RESET_OFF
	delayms(1000);
	wdt_reset();

	sed1335_lcd_init();	
	sed1335_set_cur_dir(CSRDIR_R);	       
	sed1335_clear_display();
//	sed1335_enable_display();
	sed1335_clear_display();
#ifdef DEBUG
//	PutString("lcd init.");
#endif
	TIMER_START
	return;
}//void lcd_init()

//-------------------------------------------------------------
// Main panel.
//-------------------------------------------------------------
void  lcd_main_picture()
{
	uint8_t hour=0,min=0;
	uint8_t month=0,day=0;
	uint8_t year=0;
	_CLI();
	TIMER_STOP
//	sed1335_disable_display();

	if (CHK_SYSSTATUS(SYS_TEST2) || CHK_SYSSTATUS(SYS_TEST40))
		string_write(TEST0_MSG, 1,24,0,0, LCD_BIGFONT );	
	else
	//	string_write("Charge", 1,24,0,0, LCD_BIGFONT );
		string_write(TEST0_MSG, 1,24,0,0, LCD_BIGFONT );
	
	string_write(NULL, LOG_CTR_PIX_BEGIN_X,LOG_CTR_PIX_BEGIN_Y,LOG_CTR_PIX_END_X,LOG_CTR_PIX_END_Y, LCD_FRAME );

	string_write("Exact time:",17,1,0,0, LCD_SMALLFONT );
	string_write(NULL,T__CTR_PIX_BEGIN_X,T__CTR_PIX_BEGIN_Y,T__CTR_PIX_END_X,T__CTR_PIX_END_Y, LCD_FRAME );
//	time_write(0, 0);
//	string_write("00:00", 17,38,0,0, LCD_BIGFONT );

	string_write("Date:",32,1,0,0, LCD_SMALLFONT );
	string_write(NULL,D__CTR_PIX_BEGIN_X,D__CTR_PIX_BEGIN_Y,D__CTR_PIX_END_X,D__CTR_PIX_END_Y, LCD_FRAME );
//	date_write(1, 1, 7);
//	string_write("00.00.0000",31,38,0,0, LCD_BIGFONT );
//	string_write(NULL,175,5,315,48, LCD_FRAME );

	string_write("section",19,8,0,0, LCD_SMALLFONT );
	lcd_A_B_write(0);
//	string_write("addr error",16,10,0,0, LCD_SMALLFONT );
//	string_write("lamp",33,8,0,0, LCD_SMALLFONT );
	//string_write("1.",15,73,0,0, LCD_BIGFONT );
	//string_write("00.",27,73,0,0, LCD_BIGFONT );
	string_write(NULL,83,55,240,121, LCD_FRAME );
	
	string_write("Menu:",2,7,00,00,LCD_SMALLFONT );
//	string_write("test dates",2,8,00,00,LCD_SMALLFONT );
//	string_write("date,time",2,9,00,00,LCD_SMALLFONT );
//	string_write("system",2,10,00,00,LCD_SMALLFONT );
	if (b_root_mode)
	{
		string_write("clr all addr",CL1_CTR_X ,CL1_CTR_Y,00,00,LCD_SMALLFONT );//2,9
		string_write("get all addr",GET_A_CTR_X,GET_A_CTR_Y,00,00,LCD_SMALLFONT );
		string_write("install",INS_CTR_X,INS_CTR_Y,00,00,LCD_SMALLFONT );//2,11
		string_write("manual test",MAN_CTR_X,MAN_CTR_Y,00,00,LCD_SMALLFONT );//2,13
	}
//	string_write("clr 1   addr",2,11,00,00,LCD_SMALLFONT );
//	string_write("log",2,12,00,00,LCD_SMALLFONT );
//	string_write("manual test",MAN_CTR_X,MAN_CTR_Y,00,00,LCD_SMALLFONT );//2,13
   // string_write("exit",2,14,00,00,LCD_SMALLFONT );
	string_write(NULL,5,55,85,121, LCD_FRAME );

	string_write("Pheripherie",41,8,00,00,LCD_SMALLFONT );
    pheriph_values_string_write();
	string_write(NULL,S__CTR_PIX_BEGIN_X,S__CTR_PIX_BEGIN_Y,S__CTR_PIX_END_X,S__CTR_PIX_END_Y, LCD_FRAME );
	
	PCF8583_get_time(&hour,&min,NULL,NULL);
	time_write(hour,min);
//	sprintf(msg,"%02d:%02d",(int)hour,(int)min);
//	string_write(msg, 17, 38, 50, 50, LCD_BIGFONT );

	PCF8583_get_date(&day,&month,&year);		
	date_write(day,month,year);
//	sprintf(msg,"%02d:%02d:%04d",(int)day,(int)month,(int)year);
//	string_write(msg, 31,38, 0, 0, LCD_BIGFONT );
//	sed1335_enable_display();
	TIMER_START
   _SEI();   
}//lcd_main_picture()

//------------------------------------------------------------
void  lcd_main_bottom_picture()
{
   // sed1335_clr_display(15);
	//sed1335_clr_display(15);
//	sed1335_disable_display();
	_CLI();
	TIMER_STOP
    string_write("Next weekly:",9,17,00,00,LCD_SMALLFONT );
    sprintf(msg,"test:%02d.%02d.%04d",config.weekly_test[0],config.weekly_test[1],config.weekly_test[2]+2000);
	string_write(msg,9,18,00,00,LCD_SMALLFONT );
	string_write(NULL,W__CTR_PIX_BEGIN_X,W__CTR_PIX_BEGIN_Y,W__CTR_PIX_END_X,W__CTR_PIX_END_Y, LCD_FRAME );

	string_write("Next annual:",31,17,00,00,LCD_SMALLFONT );
    sprintf(msg,"test:%02d.%02d.%04d",config.annual_test[0],config.annual_test[1],config.annual_test[2]+2000);
	string_write(msg,31,18,00,00,LCD_SMALLFONT );
	string_write(NULL,A__CTR_PIX_BEGIN_X,A__CTR_PIX_BEGIN_Y,A__CTR_PIX_END_X,A__CTR_PIX_END_Y, LCD_FRAME );

	string_write("Lamp Center", 18,190, 0, 0, LCD_BIGFONT );
//	string_write("Lumentron Ltd.",22,24,00,00,LCD_SMALLFONT );	
	string_write("*", 1,227, 0, 0, LCD_BIGFONT );
	TIMER_START
	_SEI();
//	sed1335_enable_display();
}//void  lcd_main_picture()

//-------------------------------------------------------------
// Weekly-annual setting subpanel.
//-------------------------------------------------------------
void lcd_watest_panel_ctrl()
{
	if ((t_pos_x >= TW_CTR_PIX_BEGIN_X) && (t_pos_x <= TW_CTR_PIX_END_X ) &&
        (t_pos_y >= TW_CTR_PIX_BEGIN_Y) && (t_pos_y <= TW_CTR_PIX_END_Y ))
	{
		up_down = 0; 
	//	num_index = 0;     
		beep();
		blink = 1;
		watest_write(1,&current_date[1][0]);
	}
    else
	if ((t_pos_x >= TA_CTR_PIX_BEGIN_X) && (t_pos_x <= TA_CTR_PIX_END_X ) &&
        (t_pos_y >= TA_CTR_PIX_BEGIN_Y) && (t_pos_y <= TA_CTR_PIX_END_Y ))
	{
		up_down = 1; 
	//	num_index = 0; 
		beep();   
		blink = 1;
		watest_write(0,&current_date[0][0]); 
	}
    else
	{
		CTRL_BILL  ctrl_bill_l =  lcd_ctrl_panel_ctrl();
		switch (ctrl_bill_l)
		{
		 	case CTR_NONEctl:
			case CTR_NCHANGEctl:
			case CTR_CLEARctl:
				return;
			case CTR_LEFTctl:
				if (num_index < 2)
				 	num_index = 1;
				else
					 --num_index;
				watest_write(up_down,&current_date[up_down][0]); 
				break;
			case CTR_RIGTHctl:
				if (num_index > 2)
					num_index = 3;
				else
					++num_index;
				watest_write(up_down,&current_date[up_down][0]); 
				break;
			case CTR_DOWNctl:
            {
                switch(num_index)
                {
                    case 1: 
                    case 2:                   
                        if (current_date[up_down][num_index - 1] <= 1)  
                            current_date[up_down][num_index - 1] = 1;
						else
							current_date[up_down][num_index - 1]--;
                    break;                    
                    case 3:
                        if (current_date[up_down][2] <= 7)  
                            current_date[up_down][2] = 7;
						else
							current_date[up_down][2]--;
                    break;					
                }				
				watest_write(up_down,&current_date[up_down][0]);
				break;
            }
			case CTR_UPctl:
            {
                switch(num_index)
                {
                    case 1: 
                        if (current_date[up_down][0] >= 31)  
                            current_date[up_down][0] = 31;
						else
							current_date[up_down][0]++;
						break;
                    case 2:                   
                        if (current_date[up_down][1] >= 12) 
                            current_date[up_down][1] = 12;
						else
							current_date[up_down][1]++;
						break;
                    break;                    
                    case 3:
                        if (current_date[up_down][2] >= 99) 
                            current_date[up_down][2] = 99;
						else
							current_date[up_down][2]++;					
                    break;
                }
				watest_write(up_down,&current_date[up_down][0]);
				break;
            }
			case CTR_SAVEctl:
			{
				blink = 1;
				watest_write(up_down,&current_date[up_down][0]);
				if (!up_down)
				{

					config_weekly_save(current_date[0][2], current_date[0][1], current_date[0][0]);
					string_write("Saved.",37,20,0,0, LCD_SMALLFONT );									
					//set_weekly_alarm(current_date[1][0]);
				/*	uint8_t hour=0,min=0;
					PCF8583_get_time(&hour,&min,NULL,NULL);
					min_test = min;		*/																
				}
				else
				if (up_down == 1)
				{
					config_annual_save(current_date[1][2], current_date[1][1], current_date[1][0]);
					string_write("Saved.",37,22,0,0, LCD_SMALLFONT );					
				
				}
				up_down = 2; 
				//PCF8583_alarm_on();
			}
			break;
		}
	}
	lcd_watest_panel_view();

}//void lcd_watest_panel_ctrl()
/*
//-------------------------------------------------------------
void set_weekly_alarm(uint8_t day)
{
// test start.
	uint8_t hour,min,sec;
	PCF8583_get_time(&hour,&min,&sec,NULL);
				
	++min;
	if (min>59)
	{
		++hour;	
		min = 0;
	}
	PCF8563_set_alarm_hour(hour);
	PCF8563_set_alarm_min(min);
	sprintf(msg,"set alarm:hour:%d,min:%d",hour,min);
	PutString(msg);
// test end

//	PCF8563_set_alarm_hour(12);
//	PCF8563_set_alarm_min(1);
	PCF8563_set_alarm_day(day);
}//void set_weekly_alarm(uint8_t day)
*/
//-------------------------------------------------------------
void watest_write(uint8_t mode_a, uint8_t* test_array)
{
	if (!mode_a)
	{
		sprintf(msg,"%02d.%02d.%04d",(int)test_array[0],(int)test_array[1],(int)test_array[2]+2000);
		string_write(msg,15,168,0,0, LCD_BIGFONT );
	}
	else
	{		
		sprintf(msg,"%02d.%02d.%04d",(int)test_array[0],(int)test_array[1],(int)test_array[2]+2000);
		string_write(msg,15,185,0,0, LCD_BIGFONT );
	}
}//void watest_write(uint8_t mode_a)

//-------------------------------------------------------------
// Weekly-annual view date in the subpanel.
void  lcd_watest_panel_view()
{

	if (!num_index || (current_pic_s != TESTpic) || (up_down > 1))
		return;

	if (blink)
	{
		if (num_index < 3)			
			sprintf(msg,"%02d",current_date[up_down][num_index - 1]);	
		else
			sprintf(msg,"%04d",current_date[up_down][num_index - 1]+2000);
		string_write(msg, current_date_pos[num_index - 1], 168 + 17*up_down, 0, 0, LCD_BIGFONT );			
	}
	else
	{
		if (num_index < 3)	
			string_write("  ", current_date_pos[num_index - 1], 168 + 17*up_down, 0, 0, LCD_BIGFONT );
		else
			string_write("    ", current_date_pos[num_index - 1], 168 + 17*up_down, 0, 0, LCD_BIGFONT );			
	}
//	lcd_exit_panel_ctrl();
}//void  lcd_watest_panel_view(uint8_t mode_a)

//-------------------------------------------------------------
// Date-time setting subpanel.
//-------------------------------------------------------------
void lcd_datetime_panel_ctrl()
{
	if ((t_pos_x >= DA_CTR_PIX_BEGIN_X) && (t_pos_x <= DA_CTR_PIX_END_X ) &&
        (t_pos_y >= DA_CTR_PIX_BEGIN_Y) && (t_pos_y <= DA_CTR_PIX_END_Y ))
	{
		up_down = 0; 
	//	num_index = 0;     
		beep();
		blink = 1;
		datetime_write(1,&current_time[0]);
	}
    else
	if ((t_pos_x >= TM_CTR_PIX_BEGIN_X) && (t_pos_x <= TM_CTR_PIX_END_X ) &&
        (t_pos_y >= TM_CTR_PIX_BEGIN_Y) && (t_pos_y <= TM_CTR_PIX_END_Y ))
	{
		up_down = 1; 
		num_index = (num_index > 2) ? 2 : num_index;  
		beep();   
		blink = 1;

		datetime_write(0,&current_date[0][0]); 
	}
    else
	{
		CTRL_BILL  ctrl_bill_l =  lcd_ctrl_panel_ctrl();
		switch (ctrl_bill_l)
		{
		 	case CTR_NONEctl:
			case CTR_NCHANGEctl:
			case CTR_CLEARctl:
				return;
			case CTR_LEFTctl:
			{
				if (up_down == 1)
				{
					if (num_index >= 2)
				 		num_index = 1;	
					datetime_write(up_down,&current_time[0]); 								
				}
				else
				if (!up_down)
				{
					if (num_index < 2)
				 		num_index = 1;
					else
					 	--num_index;					
					datetime_write(up_down,&current_date[0][0]); 
				}
				break;
			}			
			case CTR_RIGTHctl:
			{
				if (up_down == 1)
				{
					if (num_index <= 1)
				 		num_index = 2;	
					datetime_write(up_down,&current_time[0]); 
				}
				else
				if (!up_down)
				{
					if (num_index > 2)
						num_index = 3;
					else
						++num_index;
					datetime_write(up_down,&current_date[0][0]); 
				}
				break;
			}			

			case CTR_DOWNctl:
            {
                switch(num_index)
                {
                    case 1: 
					{
						if (up_down == 1)
						{
						//	if (up_down == 1)
						//	{
								if (current_time[0] > 1)
									current_time[0]--;
								datetime_write(up_down,&current_time[0]); 
						//	}							
							break;
						}
						else
						if (up_down != 0)
							break;
					}
                    case 2: 
					{        
					    if (!up_down)
						{       
                        	if (current_date[up_down][num_index - 1] <= 1)  
                            	current_date[up_down][num_index - 1] = 1;
							else
								current_date[up_down][num_index - 1]--;
							datetime_write(up_down,&current_date[0][0]);
                    	}
						else
						if (up_down == 1)
						{
							if (current_time[1] > 1)
								current_time[1]--;
							datetime_write(up_down,&current_time[0]); 
						}
						break;	                    
					}
                    case 3:
					{
						if (!up_down)
						{
                        	if (current_date[0][2] <= 7)  
                            	current_date[0][2] = 7;
							else
								current_date[0][2]--;
							datetime_write(0,&current_date[0][0]);
						}
                    	break;					
					}
                }								
				break;
            }
			case CTR_UPctl:
            {
                switch(num_index)
                {
                    case 1: 
					{
						if (!up_down)
						{
                        	if (current_date[0][0] >= 31)  
                            	current_date[0][0] = 31;
							else
								current_date[0][0]++;
							datetime_write(0,&current_date[0][0]);
						}
						else
						if (up_down == 1)
						{
							if (current_time[0] >= 23)
								current_time[0] = 23;
							else
								current_time[0]++;
							datetime_write(up_down,&current_time[0]); 
						}
						break;
					}
                    case 2: 
					{        
						if (!up_down)
						{          
                        	if (current_date[0][1] >= 12) 
                            	current_date[0][1] = 12;
							else
								current_date[0][1]++;
						}
						else
						if (up_down == 1)
						{
							if (current_time[1] >= 59)
								current_time[1] = 59;
							else
								current_time[1]++;
							datetime_write(up_down,&current_time[0]); 
						}
						break;                                   
					}
                    case 3:
					{
						if (!up_down)
						{
                        	if (current_date[0][2] >= 99) 
                            	current_date[0][2] = 99;
							else
								current_date[0][2]++;
						}					
					}
                    break;
                }
				
				break;
            }
			case CTR_SAVEctl:
			{
				blink = 1;
				
				if (!up_down)
				{				
					PCF8583_set_date(current_date[0][0],current_date[0][1],current_date[0][2]);
					string_write("Saved.",37,20,0,0, LCD_SMALLFONT );
					datetime_write(0,&current_date[0][0]);	
					date_write(current_date[0][0],current_date[0][1],current_date[0][2]);				
				}
				else
				if (up_down == 1)
				{				
					PCF8583_set_time(current_time[0],current_time[1],0,0);
					string_write("Saved.",37,22,0,0, LCD_SMALLFONT );
					datetime_write(1,&current_time[0]);
					time_write(current_time[0],current_time[1]);
				}
				up_down = 2; 
			}
			break;
		}
	}
	lcd_datetime_panel_view();
	
}//void lcd_datetime_panel_ctrl()

//-------------------------------------------------------------
void datetime_write(uint8_t mode_a, uint8_t* test_array)
{
	if (!mode_a)
	{
		sprintf(msg,"%02d.%02d.%04d",(int)test_array[0],(int)test_array[1],(int)test_array[2]+2000);
		string_write(msg,15,168,0,0, LCD_BIGFONT );
	}
	else
	{		
		sprintf(msg,"%02d:%02d",(int)test_array[0],(int)test_array[1]);
		string_write(msg,15,185,0,0, LCD_BIGFONT );
	}
}//void datetime_write(uint8_t mode_a)

//-------------------------------------------------------------
// Date-time view date in the subpanel.
void  lcd_datetime_panel_view()
{

	if (!num_index || (current_pic_s != DATE_TIMEpic) || (up_down > 1))
		return;

	if (blink)
	{
		if (!up_down)
		{
			if (num_index < 3)			
				sprintf(msg,"%02d",current_date[0][num_index - 1]);	
			else
				sprintf(msg,"%04d",current_date[0][num_index - 1]+2000);
			string_write(msg, current_date_pos[num_index - 1], 168 , 0, 0, LCD_BIGFONT );			
		}
		else
		if (up_down == 1)
		{
			if (num_index < 3)
			{
				sprintf(msg,"%02d",current_time[num_index - 1]);	
				string_write(msg, current_date_pos[num_index - 1], 185 , 0, 0, LCD_BIGFONT );
			}
		}
	}
	else
	{
		if (!up_down)
		{
			if (num_index < 3)	
				string_write("  ", current_date_pos[num_index - 1], 168, 0, 0, LCD_BIGFONT );
			else
				string_write("    ", current_date_pos[num_index - 1], 168, 0, 0, LCD_BIGFONT );
		}
		else
		if (up_down == 1)
		{
			if (num_index < 3)
			{					
				string_write("  ", current_date_pos[num_index - 1], 185 , 0, 0, LCD_BIGFONT );
			}
		}			
	}
//	lcd_exit_panel_ctrl();
}//void  lcd_datetimet_panel_view(uint8_t mode_a)

//-------------------------------------------------------------
// System setting subpanel.
//-------------------------------------------------------------
void  lcd_system_panel_setting(uint8_t mode_a,uint8_t isView_a)
{
	switch (mode_a)
	{
		case 0:
			if (isView_a)
			{
				string_write("\x8c",15,165,0,0, LCD_BIGFONT );
				string_write("\x85",15,180,0,0, LCD_BIGFONT );
			//	string_write("\x85",15,195,0,0, LCD_BIGFONT );
			}
			set_com_port(COMPORTrs232);
			break;
		case 1:
			if (isView_a)
			{
				string_write("\x85",15,165,0,0, LCD_BIGFONT );
				string_write("\x8c",15,180,0,0, LCD_BIGFONT );
			//	string_write("\x85",15,195,0,0, LCD_BIGFONT );
			}
			set_com_port(COMPORTusb);
			break;
		case 2:
	/*		if (isView_a)
			{
				string_write("\x85",15,165,0,0, LCD_BIGFONT );
				string_write("\x85",15,180,0,0, LCD_BIGFONT );
				string_write("\x8c",15,195,0,0, LCD_BIGFONT );
			}
			set_com_port(COMPORTeth);*/
			break;
		case 3:
	/*		if (isView_a)
			{
				string_write("\x8c",83,165,0,0, LCD_BIGFONT );
				string_write("\x85",83,180,0,0, LCD_BIGFONT );
			}
			SET_SYSSTATUS(SYS_1LOOP)
			CLR_SYSSTATUS(SYS_MLOOP)
			// 1 loop !!!			
			chl1_com_init();*/
			break;
		case 4:
		/*	if (isView_a)
			{
				string_write("\x85",83,165,0,0, LCD_BIGFONT );
				string_write("\x8c",83,180,0,0, LCD_BIGFONT );
			}*/
			SET_SYSSTATUS(SYS_MLOOP)
		//	CLR_SYSSTATUS(SYS_1LOOP)
			// more loop !!!
		//	chlm_com_init();
			break;
		case 5:
			if (isView_a)
			{
				string_write("\x85",95,162,0,0, LCD_BIGFONT );
			}
		//	string_write("\x85",83,180,0,0, LCD_BIGFONT );					
			chn_ask.num = 3;			
			chn_ask.chn.cmd  = 0x82;
			chn_ask.timeout  = 0;

		//	if (config.loop_type)
		//	{ // more.
				chn_ask.loop = 0xfe;
				chn_ask.chn.addrh = 0;	
				chn_ask.chn.addrl = 0;	
				chn_ask.timeout  = 0;	
		/*	}
			else
			{ // 1.
				chn_ask.loop = 1;
				chn_ask.chn.addrh = 0xfe;
				chn_ask.chn.addrl = 0;		
			}*/
			lcd_set_chan_cmd("Infra turn off.");
			config.infra = 0;
			break;
		case 6:
			if (isView_a)
			{
				string_write("\x8c",95,162,0,0, LCD_BIGFONT );
			}
		//	string_write("\x8c",83,180,0,0, LCD_BIGFONT );			
		
			chn_ask.num = 3;			
			chn_ask.chn.cmd  = 0x81;
			chn_ask.timeout  = 0;

		//	if (config.loop_type)
		//	{ // more.
				chn_ask.loop = 0xfe;
				chn_ask.chn.addrh = 0;
				chn_ask.chn.addrl = 0;
				chn_ask.timeout  = 0;			
		/*	}
			else
			{ // 1.
				chn_ask.loop = 1;
				chn_ask.chn.addrh = 0xfe;
				chn_ask.chn.addrl = 0;		
			}*/

			lcd_set_chan_cmd("Infra turn on.");
			config.infra = 1;				
			break;
		case 7:
		/*	if (isView_a)
			{
				string_write("\x85",95,180,0,0, LCD_BIGFONT );	
			}
			lcd_set_chan_cmd("Install turn off.");
			
			chn_ask.num = 2;			
			chn_ask.chn.cmd  = 0x84;
			if (config.loop_type)
			{ // more.
				chn_ask.loop = 0xfe;
				chn_ask.chn.addrh = 0;
				chn_ask.chn.addrl = 0;			
			}
			config.install = 0;*/
			break;
		case 8:
		/*	if (isView_a)
			{
				string_write("\x8c",95,180,0,0, LCD_BIGFONT );
			}						
			lcd_set_chan_cmd("Install turn on.");
			chn_ask.num = 2;			
			chn_ask.chn.cmd  = 0x83;
			if (config.loop_type)
			{ // more.
				chn_ask.loop = 0xfe;
				chn_ask.chn.addrh = 0;
				chn_ask.chn.addrl = 0;			
			}			
			config.install = 1;	*/			
			break;
	}
    if (mode_a < 3)
        config_pheriph_save(mode_a);
    else
    if (mode_a < 5)
        config_loop_type_save(mode_a-3);
    pheriph_values_string_write();
//	beep();

}//void  lcd_system_panel_setting(uint_8 mode_a)

//------------------------------------------------------------
void pheriph_values_string_write()
{
    switch(config.pheriph)
    {
        case 0:
            string_write("Serial port",41,9,00,00,LCD_SMALLFONT );
			set_com_port(COMPORTrs232);
            break;
        case 1:
            string_write("Usb port   ",41,9,00,00,LCD_SMALLFONT );
			set_com_port(COMPORTusb);
            break;
     /*   case 2:
            string_write("Eth port   ",41,9,00,00,LCD_SMALLFONT );
			set_com_port(COMPORTeth);
            break;*/		
    }
   // if (config.loop_type)
//	    string_write("More loop",41,10,00,00,LCD_SMALLFONT );
   // else
   //     string_write("1 loop   ",41,10,00,00,LCD_SMALLFONT );
	if (config.infra)
		string_write("Infra  :on ",41,10,00,00,LCD_SMALLFONT );
	else				 	 
		string_write("Infra  :off",41,10,00,00,LCD_SMALLFONT );

	string_write("A copy B   ",41,12,00,00,LCD_SMALLFONT );	
	string_write("B clear    ",41,13,00,00,LCD_SMALLFONT );
}//void pheriph_values_string_write() 

//------------------------------------------------------------
//  System subpanel control
void  lcd_system_panel_ctrl()
{
	if ((t_pos_x >= SSP_CTR_PIX_BEGIN_X) && (t_pos_x <= SSP_CTR_PIX_END_X ) &&
        (t_pos_y >= SSP_CTR_PIX_BEGIN_Y) && (t_pos_y <= SSP_CTR_PIX_END_Y ))
	{
		lcd_system_panel_setting(0,1);
		beep();      
	}
    else
	if ((t_pos_x >= SUSB_CTR_PIX_BEGIN_X) && (t_pos_x <= SUSB_CTR_PIX_END_X ) &&
        (t_pos_y >= SUSB_CTR_PIX_BEGIN_Y) && (t_pos_y <= SUSB_CTR_PIX_END_Y ))
	{
		lcd_system_panel_setting(1,1);  
		beep();    
	}
/*	else
	if ((t_pos_x >= SETH_CTR_PIX_BEGIN_X) && (t_pos_x <= SETH_CTR_PIX_END_X ) &&
        (t_pos_y >= SETH_CTR_PIX_BEGIN_Y) && (t_pos_y <= SETH_CTR_PIX_END_Y ))
	{
		lcd_system_panel_setting(2,1);   
		beep();   
	}
	else
	if ((t_pos_x >= S1L_CTR_PIX_BEGIN_X) && (t_pos_x <= S1L_CTR_PIX_END_X ) &&
        (t_pos_y >= S1L_CTR_PIX_BEGIN_Y) && (t_pos_y <= S1L_CTR_PIX_END_Y ))
	{
		lcd_system_panel_setting(3,1);  
		beep();    
	}*
	else
	if ((t_pos_x >= SML_CTR_PIX_BEGIN_X) && (t_pos_x <= SML_CTR_PIX_END_X ) &&
        (t_pos_y >= SML_CTR_PIX_BEGIN_Y) && (t_pos_y <= SML_CTR_PIX_END_Y ))
	{
		lcd_system_panel_setting(4,1); 
		beep();     
	}*/
	else
	if ((t_pos_x >= SIF_CTR_PIX_BEGIN_X) && (t_pos_x <= SIF_CTR_PIX_END_X ) &&
        (t_pos_y >= SIF_CTR_PIX_BEGIN_Y) && (t_pos_y <= SIF_CTR_PIX_END_Y ))
	{
		if (config.infra)
			lcd_system_panel_setting(5,1); 
		else 
			lcd_system_panel_setting(6,1); 
		beep();   
	}
/*	else
	if ((t_pos_x >= SIN_CTR_PIX_BEGIN_X) && (t_pos_x <= SIN_CTR_PIX_END_X ) &&
        (t_pos_y >= SIN_CTR_PIX_BEGIN_Y) && (t_pos_y <= SIN_CTR_PIX_END_Y ))
	{
		if (config.install)
			lcd_system_panel_setting(7,1); 
		else 
			lcd_system_panel_setting(8,1); 
		beep();   
	}*/
//	lcd_exit_panel_ctrl();
}//void  lcd_system_panel_ctrl()

//-------------------------------------------------------------
// Manual test subpanel.
//-------------------------------------------------------------
void lcd_manual_panel_ctrl()
{	
	if ((t_pos_x >= MY_CTR_PIX_BEGIN_X) && (t_pos_x <= MY_CTR_PIX_END_X ) &&
        (t_pos_y >= MY_CTR_PIX_BEGIN_Y) && (t_pos_y <= MY_CTR_PIX_END_Y ))
	{ 	// yes
//		chn_ask.num = 2;
//		chn_ask.chn.addr = 0xfe;
//		chn_ask.chn.cmd  = 0x70;
		start_test(SYS_TEST2);
		lcd_set_chan_cmd("Manual test start,5min");	    		  
	}
    else
	if ((t_pos_x >= MN_CTR_PIX_BEGIN_X) && (t_pos_x <= MN_CTR_PIX_END_X ) &&
        (t_pos_y >= MN_CTR_PIX_BEGIN_Y) && (t_pos_y <= MN_CTR_PIX_END_Y ))
	{	// no
//		chn_ask.num = 2;
//		chn_ask.chn.addr = 0xfe;
//		chn_ask.chn.cmd  = 0x71;
		if (CHK_SYSSTATUS(SYS_TEST2))
		{
			end_test();
			lcd_set_chan_cmd("Manual test end.");
		}
	}
	lcd_exit();
//	lcd_editor_log_picture(EXITpic);
//	lcd_exit_panel_ctrl();
}//void lcd_manual_panel_ctrl()

//-------------------------------------------------------------
// Clear all  addresses subpanel.
//-------------------------------------------------------------
void clear_all_address()
{
	if (config.loop_type)
		{ // more.
			chn_ask.loop = 0xfe;
			chn_ask.chn.addrh = 0;
			chn_ask.chn.addrl = 0;			
		}
		else
		{ // 1.
			chn_ask.loop = 1;
			chn_ask.chn.addrh = 0xfe;	
			chn_ask.chn.addrl = 0;	
		}

		chn_ask.num = 3;
	//	chn_ask.chn.addr = 0xfe;
		chn_ask.chn.cmd  = 0x90;
		chn_ask.timeout  = 0;

//		config_remove_alladdr();
//		l1channels_load(all_array);
		lcd_set_chan_cmd("All addr. clear!");
		// KELL, SD-be IR!!!!!!!!!!!!!!	
	//	write_Allerror_to_sd("Clear all", 0, 0); 
		beep();
}//void clear_all_address()

void lcd_clearall_panel_ctrl()
{
	if ((t_pos_x >= IY_CTR_PIX_BEGIN_X) && (t_pos_x <= IY_CTR_PIX_END_X ) &&
        (t_pos_y >= IY_CTR_PIX_BEGIN_Y) && (t_pos_y <= IY_CTR_PIX_END_Y ))
	{ 	// yes
	//	clear_all_address();
		
		chn_ask.loop = 0xfe;
		chn_ask.chn.addrl = 0;	
		chn_ask.chn.addrh = 0;	
		chn_ask.num = 3;
	//	chn_ask.chn.addr = 0xfe;
		chn_ask.chn.cmd  = S_ADRRES_CMD;
		chn_ask.timeout  = 0;

	//	config_remove_alladdr();
	//	l1channels_load(all_array);
		lcd_set_chan_cmd("Clear all addr.!");	
		// KELL, SD-be IR!!!!!!!!!!!!!!	
	//	write_Allerror_to_sd("Clear all", 0, 0); */   		  
	}
    else
	if ((t_pos_x >= IN_CTR_PIX_BEGIN_X) && (t_pos_x <= IN_CTR_PIX_END_X ) &&
        (t_pos_y >= IN_CTR_PIX_BEGIN_Y) && (t_pos_y <= IN_CTR_PIX_END_Y ))
	{	// no
				
		lcd_set_chan_cmd(NULL);
	}
	lcd_exit();

}//void lcd_clearall_panel_ctrl()

//-------------------------------------------------------------
// Get all  addresses subpanel.
//-------------------------------------------------------------

void lcd_getall_panel_ctrl()
{
	if ((t_pos_x >= IY_CTR_PIX_BEGIN_X) && (t_pos_x <= IY_CTR_PIX_END_X ) &&
        (t_pos_y >= IY_CTR_PIX_BEGIN_Y) && (t_pos_y <= IY_CTR_PIX_END_Y ))
	{ 	// yes
		start_get_all_address();
		lcd_set_chan_cmd("Get all addr. WAIT!");	
		  
	}
    else
	if ((t_pos_x >= IN_CTR_PIX_BEGIN_X) && (t_pos_x <= IN_CTR_PIX_END_X ) &&
        (t_pos_y >= IN_CTR_PIX_BEGIN_Y) && (t_pos_y <= IN_CTR_PIX_END_Y ))
	{	// no
				
		lcd_set_chan_cmd(NULL);
	}
	lcd_exit();

}//void lcd_getall_panel_ctrl()

//-------------------------------------------------------------
// set install  subpanel.
//-------------------------------------------------------------
void set_install(uint8_t value)
{
	if (value)
	{  //yes
		int kk;
		chn_ask.loop = 0xfe;
		chn_ask.chn.addrl = 0;	
		chn_ask.chn.addrh = 0;	
		chn_ask.num = 3;
		chn_ask.chn.cmd  = S_STARTINST_CMD;
		chn_ask.timeout  = 0;
		SET_INSTALL(1);
		for (kk = 0;kk<allloopnumenable; kk++)
		{	
			loop_array[kk].chn.stat = 1; 
				
		}
		inst_timer = 0;
		lcd_set_chan_cmd("Start Install!");	
	}
	else
	{ // no
		chn_ask.loop = 0xfe;
		chn_ask.chn.addrl = 0;	
		chn_ask.chn.addrh = 0;			
		chn_ask.num = 3;
		chn_ask.chn.cmd  = S_STOPINST_CMD;
		chn_ask.timeout  = 0;
		inst_timer = 0;
		SET_INSTALL(0);
		lcd_set_chan_cmd("Stop Install!");
		Reset();
	}
}//void set_install(uint8_t value)

void lcd_install_panel_ctrl()
{
	if ((t_pos_x >= IY_CTR_PIX_BEGIN_X) && (t_pos_x <= IY_CTR_PIX_END_X ) &&
        (t_pos_y >= IY_CTR_PIX_BEGIN_Y) && (t_pos_y <= IY_CTR_PIX_END_Y ))
	{ 	// yes
		set_install(1);
/*
	//	clear_all_address();		
		chn_ask.loop = 0xfe;
		chn_ask.chn.addrl = 0;	
		chn_ask.chn.addrh = 0;	
		chn_ask.num = 3;
	//	chn_ask.chn.addr = 0xfe;
		chn_ask.chn.cmd  = S_STARTINST_CMD;

	//	config_remove_alladdr();
	//	l1channels_load(all_array);
		lcd_set_chan_cmd("Start Install!");
		// KELL, SD-be IR!!!!!!!!!!!!!!	
	//	write_Allerror_to_sd("Clear all", 0, 0);   */		  
	}
    else
	if ((t_pos_x >= IN_CTR_PIX_BEGIN_X) && (t_pos_x <= IN_CTR_PIX_END_X ) &&
        (t_pos_y >= IN_CTR_PIX_BEGIN_Y) && (t_pos_y <= IN_CTR_PIX_END_Y ))
	{	// no
		
		set_install(0);	
/*		chn_ask.loop = 0xfe;
		chn_ask.chn.addrl = 0;	
		chn_ask.chn.addrh = 0;			
		chn_ask.num = 3;
	//	chn_ask.chn.addr = 0xfe;
		chn_ask.chn.cmd  = S_STOPINST_CMD;
		lcd_set_chan_cmd("Stop Install!");*/
	}
	lcd_exit();

}//void lcd_install_panel_ctrl()

//-------------------------------------------------------------
// Clear 1 addresses subpanel.
//-------------------------------------------------------------
void loop_address_write(void)
{
	//if (config.loop_type)
/*			
	if (!config.loop_type)
	{ //1 loop ?
	//	CHANNELtype chn = IndexAll(current_clr1[1]);
	//	if ((chn.addr == 0xaa) || (!chn.addr) || (chn.addr > COMM_MAX_ADDR))
		if (( all_addr[current_clr1[1]+2] == 0xaa) || (!all_addr[current_clr1[1]+2]) || (all_addr[current_clr1[1]+2] > COMM_MAX_ADDR))
		{		
			string_write("01  EM ",current_clr1_pos[0],185,0,0, LCD_BIGFONT );
		}
		else
		{
			sprintf(msg,"01  %02d", all_addr[current_clr1[1]+2]);
			string_write(msg,current_clr1_pos[0],185,0,0, LCD_BIGFONT );
		}
	}
	else
	{
		if (CHK_SYSSTATUS(SYS_WAIT_ADDRLIST))
			sprintf(msg,"%01d   Wt ",current_clr1[0]);
		else
		{			
			if (current_clr1[1] == 0xee)
				sprintf(msg,"%01d   All",current_clr1[0]);
			else
				sprintf(msg,"%01d   %02d ",current_clr1[0],all_addr[current_clr1[1]+2]);
		}
		string_write(msg,current_clr1_pos[0],185,0,0, LCD_BIGFONT );
	}*/
}//void loop_address_write()


//-------------------------------------------------------------
// Clear 1:loop address view date in the subpanel.
//-------------------------------------------------------------
void  lcd_loop_addr_panel_view()
{
/*
	if (!current_clr1[2] || (current_pic_s != CLEAR1pic) )
		return;

	if (CHK_SYSSTATUS(SYS_WAIT_ADDRLIST))
	{
		if (!chn_ask.num)
		{
			CLR_SYSSTATUS(SYS_WAIT_ADDRLIST)
			lcd_exit();
			current_clr1[0] = 1;//???
			return;
		}			

	}
	if (blink)
	{			
		if (current_clr1[2] == 2)
		{
			if (config.loop_type)
			{ // more
				if ( current_clr1[1] == 0xee)
					sprintf(msg,"All");
				else
				{
					if ( !all_addr[1] || (all_addr[current_clr1[1]+2] > COMM_MAX_ADDR) )
						sprintf(msg,"EM ");					
					else			
						sprintf(msg,"%02d",all_addr[current_clr1[1]+2]);
				}				
			}
			else
			{	//1 loop						
				if (( all_addr[current_clr1[1]+2] == 0xaa) || (!all_addr[current_clr1[1]+2]) || (all_addr[current_clr1[1]+2] > COMM_MAX_ADDR))
					sprintf(msg,"EM ");
				else
					sprintf(msg,"%02d",all_addr[current_clr1[1]+2]);
			}	
		}
		else
			sprintf(msg,"%01d",current_clr1[0]);	
		string_write(msg,  current_clr1_pos[current_clr1[2] - 1], 185 , 0, 0, LCD_BIGFONT );
	}
	else
	{		
		string_write("  ", current_clr1_pos[current_clr1[2] - 1], 185 , 0, 0, LCD_BIGFONT );		
	}*/
}//lcd_loop_addr_panel_view()

//-------------------------------------------------------------
// Clear 1: loop address setting subpanel.
//-------------------------------------------------------------
void lcd_loop_addr_panel_ctrl()
{
	if ((t_pos_x >= LO_CTR_PIX_BEGIN_X) && (t_pos_x <= LO_CTR_PIX_END_X ) &&
        (t_pos_y >= LO_CTR_PIX_BEGIN_Y) && (t_pos_y <= LO_CTR_PIX_END_Y ))
	{	
		current_clr1[2] = 1;     
		beep();
		blink = 1;
		loop_address_write();
	}
    else
	if ((t_pos_x >= LA_CTR_PIX_BEGIN_X) && (t_pos_x <= LA_CTR_PIX_END_X ) &&
        (t_pos_y >= LA_CTR_PIX_BEGIN_Y) && (t_pos_y <= LA_CTR_PIX_END_Y ))
	{	
		current_clr1[2] = 2;  
		beep();   
		blink = 1;
		loop_address_write();
	}
    else
	{
		CTRL_BILL  ctrl_bill_l =  lcd_ctrl_panel_ctrl();
		switch (ctrl_bill_l)
		{
		 	case CTR_NONEctl:
			case CTR_NCHANGEctl:
			case CTR_SAVEctl:
				return;	
			case CTR_LEFTctl:
			{
				
				current_clr1[2] = (current_clr1[2] <= 1) ? 1 : --current_clr1[2];				 										
				break;
			}	
			case CTR_RIGTHctl:
			{			
				current_clr1[2] = (current_clr1[2] >= 2) ? 2 : ++current_clr1[2];				 										
				break;
			}	
			case CTR_DOWNctl:
            {
                if (current_clr1[2] == 1)
                {  // loop
					if (config.loop_type)
					{	//more
						if (current_clr1[0] > 1)
							current_clr1[0]--;	
						current_clr1[1]	= 0;
						get_addr_datas(current_clr1[0]);
					}
					else 
					{
						current_clr1[0] = 1;				
						current_clr1[1]	= 1;
					}
				//	current_clr1[1]	= 1;
											
				}
				else
                if (current_clr1[2] == 2)
                {  // address     					    
					if (config.loop_type)
					{
						if (current_clr1[1] == 0xee)
							current_clr1[1] =  all_addr[1]-1;
						else	
						{
							if (current_clr1[1] > 0)
								current_clr1[1]--;																						
						}
					}
					else
					{
						if (current_clr1[1] > 0)
							current_clr1[1]--;	
					}
                }								
				break;
            }
			case CTR_UPctl:
            {
                if (current_clr1[2] == 1)
                { // loop
					if (config.loop_type)
					{ // more
						if (current_clr1[0] < allloopnumenable)
							current_clr1[0]++;
						get_addr_datas(current_clr1[0]);
							current_clr1[1]	= 0;	
					}
					else 
					{
						current_clr1[0] = 1;				
						current_clr1[1]	= 1;							
					}
				}//
				else
                if (current_clr1[2] == 2)
                { // address      					    
					if (config.loop_type)
					{
						if (current_clr1[1] < (all_addr[1] - 1))
							current_clr1[1]++;
						else												
							current_clr1[1] = 0xee;	
					}
					else
					{
						if (current_clr1[1] <= all_addr[1])
							current_clr1[1]++;							
					}
                }								
				break;
            }
			case CTR_CLEARctl:
			{
				blink = 1;
			
				if (config.loop_type)
				{ // more				
					if (current_clr1[1] == 0xee)
					{ // all cim torlese.

						chn_ask.num = 3;
						chn_ask.loop = current_clr1[0];
						chn_ask.chn.addrh = 0xfe;
						chn_ask.chn.addrl = 0;	
						chn_ask.chn.cmd  = 0x90;
						chn_ask.timeout  = 0;
						all_addr[1] = 0;
						return;
					}
				}
	
		/*		if (( all_addr[current_clr1[1]+2] == 0xaa) || (!all_addr[current_clr1[1]+2]) || (all_addr[current_clr1[1]+2] > COMM_MAX_ADDR))			
					break;
				chn_ask.num = 0;
				chn_ask.chn.addrh = all_addr[current_clr1[1]+2] 
				chn_ask.chn.addrl = 0;	
				chn_ask.chn.cmd  = 0x90;
				chn_ask.timeout  = 0;
				if (config_remove_1_addr(current_clr1[0],all_addr[current_clr1[1]+2]))
				{										
					string_write("Cleared",37,22,0,0, LCD_SMALLFONT );					
					if (config.loop_type)
					{ // more
						chn_ask.num = 3;
						chn_ask.timeout  = 0;
						chn_ask.loop = current_clr1[0];
		
					current_clr1[1] = 1;
					lcd_exit();
					return;
				// KELL, SD-be IR!!!!!!!!!!!!!!
				//	sprintf(msg,"clear %d:%d",current_clr1[0],chn.addr);					
				//	write_Allerror_to_sd(msg, 0, 0);
				}*/
							
			}
			break;
		}
	}
	//lcd_loop_addr_panel_view();
	loop_address_write();
}//void lcd_loop_addr_panel_ctrl()

//-------------------------------------------------------------
// Logger  subpanel.
//-------------------------------------------------------------
 /***************************************************/
// toltes hiba
// 31.12.2007-12.56:      1L< 12:T >; // 34 hosszu
// tesz hibak:
// 31.12.2007-12.56:Test start;      
// 31.12.2007-12.56:Test: 8L<12:ATF>;
// 31.12.2007-12.56:Test end; 

void lcd_logger_panel_ctrl(CTRL_BILL bill_a )
{	
		
		CTRL_BILL  ctrl_bill_l;
//		char* ptemp = &msg[0];
		msg[35]=0;
//		uint8_t ii = 0;

		if (bill_a == CTR_NONEctl)
			ctrl_bill_l =  lcd_ctrl_panel_ctrl();
		else
			ctrl_bill_l = bill_a;

		
		struct fat16_file_struct* fd = open_file(LOGNAME);
		if(!fd)		
    		return;

		if (fat16_get_size(fd)<=MESS_LEN)
		{
			string_write("empty lamp.log!",9,21,0,0, LCD_SMALLFONT );
			close_file(fd);
			return;
		}

		int32_t offset = get_global_pos();
//		sprintf(msg,"pos: %d", (int)get_global_pos());
//		PutString(msg);
		if (!seek_file(fd,&offset, FAT16_SEEK_SET))
		{
//			sprintf(msg,"kilep pos: %d", (int)get_global_pos());
//			PutString(msg);
			close_file(fd);
			return;
		}
		//int32_t pos = get_global_pos();
		switch (ctrl_bill_l)
		{			
			case CTR_SAVEctl:
			case CTR_CLEARctl:
		 	case CTR_NONEctl:
			case CTR_NCHANGEctl:
				close_file(fd);
				return;
			case CTR_LEFTctl:
			{	
				offset = 0;			
				seek_file(fd,&offset, FAT16_SEEK_SET);			
				break;
			}			
			case CTR_RIGTHctl:
			{		
		//		offset = 0;	
		//		seek_file(fd,&offset, FAT16_SEEK_END);
				if ((get_global_pos() - MESS_LEN) >= 0)	
				{
					offset = -1*MESS_LEN;
					if (!seek_file(fd,&offset, FAT16_SEEK_END))
					{
						offset = 0;
						seek_file(fd,&offset, FAT16_SEEK_SET);
			//			PutString("1e");
					}					
				}	
				else
				{
					close_file(fd);
					return;			
				}
				break;
			}			
			case CTR_DOWNctl:
            {
               	if ((get_global_pos() + MESS_LEN) > fat16_get_size(fd))
				{
					offset = 0;
					seek_file(fd,&offset, FAT16_SEEK_END);
					close_file(fd);
					return;
//					offset = 0;	
//					seek_file(fd,&offset, FAT16_SEEK_END);
				}					
				break;
            }
		
			case CTR_UPctl:
            {    
				offset = get_global_pos() - 2*MESS_LEN;          		
				if (offset >= 0)
				{			
						
					seek_file(fd,&offset, FAT16_SEEK_SET);
					
				//	PutString("Up");
					
				}
				else
				{
					offset = 0;			
					seek_file(fd,&offset, FAT16_SEEK_SET);							
				}
				break;
            }
		}
		if (read_file(fd,(uint8_t*)msg, MESS_LEN)>0)
		{
		/*	while ((*ptemp != ';') && *ptemp && (ii<(MESS_LEN+1)))
			{
				++ptemp;
				++ii;
			}
			*(++ptemp) = 0;	*/		
			
			string_write(msg,9,21,0,0, LCD_SMALLFONT );
		//	PutString(msg);
			
		}
		else
		{
			string_write("read error!",9,21,0,0, LCD_SMALLFONT );
	
		}
		close_file(fd);
//	logger_write();
	
}//void lcd_logger_panel_ctrl()


//-------------------------------------------------------------
// Left,rigth,up,down,save subsubpanel.
//-------------------------------------------------------------
void  lcd_ctrl_panel_view(CTRL_BILL mode_a, uint8_t offset)
{
	uint8_t right = offset + 60;
	uint8_t char_offset = offset/6;
	ctrl_offset = offset;
	ctrl_panel = mode_a;
	
	if ( mode_a & CTR_RIGTHctl )
	{
		string_write("\x1a", char_offset+17,220,0,0, LCD_BIGFONT );//right
		right += 30;
	}		
	if ( mode_a & CTR_LEFTctl )
	{
		string_write("\x1c", char_offset+12,220,0,0, LCD_BIGFONT );//left
		right += 30;
	}		
	if ( mode_a & CTR_DOWNctl )
	{
		string_write("\x1b", char_offset+22,220,0,0, LCD_BIGFONT );//down
		right += 30;
	}		
	if ( mode_a & CTR_UPctl )
	{
		string_write("\x19", char_offset+27,220,0,0, LCD_BIGFONT );//up
		right += 30;
	}
	if ( mode_a & CTR_SAVEctl )
	{
		string_write("Save", char_offset+32,220,55,0, LCD_BIGFONT );//save
		right += 65;
	}	
	else
	if ( mode_a & CTR_CLEARctl )
	{
		string_write("Clr.", char_offset+32,220,55,0, LCD_BIGFONT );//save
		right += 65;
	}
	string_write(NULL,offset+60,200,right,225, LCD_FRAME );
}//lcd_ctrl_panel_view()

//------------------------------------------------------------
CTRL_BILL lcd_ctrl_panel_ctrl()
{
	
	if (ctrl_panel == CTR_NONEctl)
		return CTR_NONEctl;

//	if 	( ctrl_panel_prev == ctrl_panel )
//		return CTR_NCHANGEctl;

//	ctrl_panel_prev = ctrl_panel;

	if ((ctrl_panel & CTR_RIGTHctl) && 
		(t_pos_x >= (ctrl_offset + RG_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + RG_CTR_PIX_END_X )) &&
        (t_pos_y >= RG_CTR_PIX_BEGIN_Y) && (t_pos_y <= RG_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_RIGTH");
		beep();
		bill_time = 0;
       /* set_pushed_area(ctrl_offset + RG_CTR_PIX_BEGIN_X, RG_CTR_PIX_BEGIN_Y, 
                        ctrl_offset + RG_CTR_PIX_END_X,   RG_CTR_PIX_END_Y);*/
        return CTR_RIGTHctl;
	}
	if ((ctrl_panel & CTR_LEFTctl) && 
		(t_pos_x >= (ctrl_offset + LF_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + LF_CTR_PIX_END_X )) &&
        (t_pos_y >= LF_CTR_PIX_BEGIN_Y) && (t_pos_y <= LF_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_LEFT");
		beep();
		bill_time = 0;
      /*  set_pushed_area(ctrl_offset + LF_CTR_PIX_BEGIN_X, LF_CTR_PIX_BEGIN_Y, 
                        ctrl_offset + LF_CTR_PIX_END_X,   LF_CTR_PIX_END_Y);*/
        return CTR_LEFTctl;
	}
	if ((ctrl_panel & CTR_DOWNctl) && 
		(t_pos_x >= (ctrl_offset + DW_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + DW_CTR_PIX_END_X )) &&
        (t_pos_y >= DW_CTR_PIX_BEGIN_Y) && (t_pos_y <= DW_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_DOWN");
		beep();
		bill_time = 0;
        return CTR_DOWNctl;
	}
	if ((ctrl_panel & CTR_UPctl) && 
		(t_pos_x >= (ctrl_offset + UP_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + UP_CTR_PIX_END_X )) &&
        (t_pos_y >= UP_CTR_PIX_BEGIN_Y) && (t_pos_y <= UP_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_UP");
		beep();
		bill_time = 0;
       /* set_pushed_area(ctrl_offset + UP_CTR_PIX_BEGIN_X, UP_CTR_PIX_BEGIN_Y, 
                        ctrl_offset + UP_CTR_PIX_END_X,   UP_CTR_PIX_END_Y);*/
        return CTR_UPctl;
	}
	if ((ctrl_panel & CTR_SAVEctl) && 
		(t_pos_x >= (ctrl_offset + SV_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + SV_CTR_PIX_END_X )) &&
        (t_pos_y >= SV_CTR_PIX_BEGIN_Y) && (t_pos_y <= SV_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_SAVE");
		beep();
		bill_time = 0;
       /* set_pushed_area(ctrl_offset + SV_CTR_PIX_BEGIN_X, SV_CTR_PIX_BEGIN_Y, 
                        ctrl_offset + SV_CTR_PIX_END_X,   SV_CTR_PIX_END_Y);*/
        return CTR_SAVEctl;
	}
	if ((ctrl_panel & CTR_CLEARctl) && 
		(t_pos_x >= (ctrl_offset + SV_CTR_PIX_BEGIN_X)) && (t_pos_x <= (ctrl_offset + SV_CTR_PIX_END_X )) &&
        (t_pos_y >= SV_CTR_PIX_BEGIN_Y) && (t_pos_y <= SV_CTR_PIX_END_Y ))
	{
	//	PutString("CTR_CLEAR");
		beep();
		bill_time = 0;
     /*   set_pushed_area(ctrl_offset + SV_CTR_PIX_BEGIN_X, SV_CTR_PIX_BEGIN_Y, 
                        ctrl_offset + SV_CTR_PIX_END_X,   SV_CTR_PIX_END_Y);*/
        return CTR_CLEARctl;
	}
	return CTR_NONEctl;
}//lcd_ctrl_panel_view()

//-------------------------------------------------------------
// Menu panel.
//-------------------------------------------------------------
void  lcd_editor_log_picture(SUBPICTURE pict_a)
{
	if (pict_a == NONEpic)
			return;

	if (pict_a == current_pic_s)
			return;

	current_pic_s = pict_a;
    //sed1335_clr_display(15);
	sed1335_clear_display();
	sed1335_clear_display();
//	lcd_init();
	lcd_main_picture();
//	sed1335_clr_display(15);	
    string_write(NULL,5,128,315,230, LCD_FRAME );
	//bill_time++;
	switch (pict_a)
	{
		case TESTpic:
			beep();
			memcpy(&current_date[0],config.weekly_test,3);
			memcpy(&current_date[1],config.annual_test,3);
			string_write("Test time setting:",15,17,00,00,LCD_SMALLFONT );
			
			string_write("Weekly:",8,20,00,00,LCD_SMALLFONT );
			watest_write(0,config.weekly_test);
		//	sprintf(msg,"%02d.%02d.%04d",(int)config.weekly_test[0],(int)config.weekly_test[1],(int)config.weekly_test[2]+2000);
		//	string_write(msg,15,170,0,0, LCD_BIGFONT );
			string_write("Annual:",8,22,00,00,LCD_SMALLFONT );
			watest_write(1,config.annual_test);
		//	sprintf(msg,"%02d.%02d.%04d",(int)config.annual_test[0],(int)config.annual_test[1],(int)config.annual_test[2]+2000);
		//	string_write(msg,15,185,0,0, LCD_BIGFONT );
			lcd_ctrl_panel_view(CTR_RIGTHctl|CTR_LEFTctl|CTR_DOWNctl|CTR_UPctl|CTR_SAVEctl,0 );
			
			up_down = 0;
			num_index = 1;
			break;
		case DATE_TIMEpic:
			beep();
			string_write("Date,time setting:",15,17,00,00,LCD_SMALLFONT );
			string_write("Date:",8,20,00,00,LCD_SMALLFONT );
			//string_write("00.00.0000",15,170,0,0, LCD_BIGFONT );
			string_write("Time:",8,22,00,00,LCD_SMALLFONT );
			//string_write("00:00",15,185,0,0, LCD_BIGFONT );
			lcd_ctrl_panel_view(CTR_RIGTHctl|CTR_LEFTctl|CTR_DOWNctl|CTR_UPctl|CTR_SAVEctl,0 );
			PCF8583_get_date(&current_date[0][0],&current_date[0][1],&current_date[0][2]);
			PCF8583_get_time(&current_time[0],&current_time[1],NULL,NULL);	
			datetime_write(0, &current_date[0][0]);	
			datetime_write(1, &current_time[0]);		
			up_down = 0;
			num_index = 1;		
			break;
		case SYSTEMpic:
		//	beep();
			string_write("Global setting:",15,17,00,00,LCD_SMALLFONT );
			string_write("Serial port:",2,19,00,00,LCD_SMALLFONT );
			string_write("Usb port   :",2,21,00,00,LCD_SMALLFONT );
		//	string_write("Eth port   :",2,23,00,00,LCD_SMALLFONT );
			string_write(NULL,7,145,107,198, LCD_FRAME );

		//	string_write("1 loop   :",20,19,00,00,LCD_SMALLFONT );		
		//	string_write("More loop:",20,21,00,00,LCD_SMALLFONT );
			string_write(NULL,115,145,200,198, LCD_FRAME );

			string_write("Infra:",35,19,00,00,LCD_SMALLFONT );
		//	string_write("Inst.:",35,21,00,00,LCD_SMALLFONT );	

			lcd_system_panel_setting(config.pheriph,1); 
		//	lcd_system_panel_setting(config.loop_type+3,1); 
			lcd_system_panel_setting(config.infra+5,1); 
		//	lcd_system_panel_setting(config.install+7,1);
			beep();

//			string_write("\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a",15,170,0,0, LCD_BIGFONT );
//			string_write("\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95",15,185,0,0, LCD_BIGFONT );
			break;
		case CLEAR1pic:
	/*		beep();
			string_write("Clear 1 address of lamp!",18,17,00,00,LCD_SMALLFONT );
			string_write("Loop/addr.:",8,22,00,00,LCD_SMALLFONT );
			
	//		CHANNELtype chn = IndexAll(1);
//			set_current_loop_address();
			if (config.loop_type)
			{// more
				if (current_clr1[0] != all_addr[0])
					get_addr_datas(current_clr1[0]);
			}
		//	else	
		//		config_l1load_addr();
			loop_address_write();
		//	if (chn.addr != 0xaa)
			lcd_ctrl_panel_view(CTR_RIGTHctl|CTR_LEFTctl|CTR_DOWNctl|CTR_UPctl|CTR_CLEARctl,0 );
			*/
			break;
		case CLEARALLpic:
			if (!b_root_mode)
				break;
			beep();
			string_write("Clear all addresses!",18,17,00,00,LCD_SMALLFONT );
			//string_write("Clear all addresses!",16,18,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,IY_CTR_PIX_BEGIN_X,IY_CTR_PIX_BEGIN_Y,IY_CTR_PIX_END_X,IY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,IN_CTR_PIX_BEGIN_X,IN_CTR_PIX_BEGIN_Y,IN_CTR_PIX_END_X,IN_CTR_PIX_END_Y, LCD_FRAME );	
			//string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );			
			break;
		case GETALLpic:
			if (!b_root_mode)
				break;
			beep();
			string_write("Get all addresses!",18,17,00,00,LCD_SMALLFONT );
			//string_write("Clear all addresses!",16,18,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,IY_CTR_PIX_BEGIN_X,IY_CTR_PIX_BEGIN_Y,IY_CTR_PIX_END_X,IY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,IN_CTR_PIX_BEGIN_X,IN_CTR_PIX_BEGIN_Y,IN_CTR_PIX_END_X,IN_CTR_PIX_END_Y, LCD_FRAME );	
			//string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );			
			break;
		case LOGpic:
			beep();
			string_write("Logger:",25,17,00,00,LCD_SMALLFONT );
			string_write(NULL,LG_CTR_PIX_BEGIN_X,LG_CTR_PIX_BEGIN_Y,LG_CTR_PIX_END_X,LG_CTR_PIX_END_Y, LCD_FRAME );
			lcd_ctrl_panel_view(CTR_RIGTHctl|CTR_LEFTctl|CTR_DOWNctl|CTR_UPctl,45);
		//	string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );
			up_down = 0;
			num_index = 1;
			lcd_logger_panel_ctrl(CTR_LEFTctl);			
			break;
		case MANpic:
			if (!b_root_mode)
				break;
			beep();
			string_write("Manual test:",21,17,00,00,LCD_SMALLFONT );
		//	string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,MY_CTR_PIX_BEGIN_X,MY_CTR_PIX_BEGIN_Y,MY_CTR_PIX_END_X,MY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,MN_CTR_PIX_BEGIN_X,MN_CTR_PIX_BEGIN_Y,MN_CTR_PIX_END_X,MN_CTR_PIX_END_Y, LCD_FRAME );			
			break;		
		case INSTALLpic:
			if (!b_root_mode)
				break;
			beep();
			string_write("Start Install:",21,17,00,00,LCD_SMALLFONT );
		//	string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,IY_CTR_PIX_BEGIN_X,IY_CTR_PIX_BEGIN_Y,IY_CTR_PIX_END_X,IY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,IN_CTR_PIX_BEGIN_X,IN_CTR_PIX_BEGIN_Y,IN_CTR_PIX_END_X,IN_CTR_PIX_END_Y, LCD_FRAME );			
			break;				
		case AcopyBpic:
			beep();
			string_write("A copy to B:",21,17,00,00,LCD_SMALLFONT );
		//	string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,ABY_CTR_PIX_BEGIN_X,ABY_CTR_PIX_BEGIN_Y,ABY_CTR_PIX_END_X,ABY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,ABN_CTR_PIX_BEGIN_X,ABN_CTR_PIX_BEGIN_Y,ABN_CTR_PIX_END_X,ABN_CTR_PIX_END_Y, LCD_FRAME );			
			break;	
		case Bclearpic:
			beep();
			string_write("B clear:",21,17,00,00,LCD_SMALLFONT );
		//	string_write("Under construction....",15,19,00,00,LCD_SMALLFONT );
			string_write("YES",20,180,0,0, LCD_BIGFONT );
			string_write(NULL,BY_CTR_PIX_BEGIN_X,BY_CTR_PIX_BEGIN_Y,BY_CTR_PIX_END_X,BY_CTR_PIX_END_Y, LCD_FRAME );
			string_write("NO",30,180,0,0, LCD_BIGFONT );
			string_write(NULL,BN_CTR_PIX_BEGIN_X,BN_CTR_PIX_BEGIN_Y,BN_CTR_PIX_END_X,BN_CTR_PIX_END_Y, LCD_FRAME );			
			break;		
		case EXITpic:
/*			beep();
			lcd_main_bottom_picture();
			ctrl_panel = CTR_NONEctl;
			current_pic_s = NONEpic;	
*/							
			//break;
		case NONEpic:
			bill_time = 0;			
			break;
	}
	//ctrl_panel_prev = ctrl_panel;
	switch_light(CHK_SYSSTATUS(SYS_LIGHT));
	// Exit.
	if ((pict_a != NONEpic) && (pict_a != EXITpic))
	{
    	string_write("Exit",43,27,00,00,LCD_SMALLFONT );
		string_write(NULL,EXIT_CTR_PIX_BEGIN_X,EXIT_CTR_PIX_BEGIN_Y,EXIT_CTR_PIX_END_X,EXIT_CTR_PIX_END_Y, LCD_FRAME );	
	}
}//void lcd_editor_picture()

//---------------------------------------------------------------- 
/***********************************************************
 * exit.
 ***********************************************************/

void lcd_exit()
{
		beep();
		sed1335_clear_display();
	//	sed1335_clear_display();
		lcd_main_picture();
		lcd_main_bottom_picture();
		ctrl_panel = CTR_NONEctl;
		current_pic_s = NONEpic;
		switch_light(CHK_SYSSTATUS(SYS_LIGHT));
		bill_time = 0;
		string_write(msg_state,16,14,00,00,LCD_SMALLFONT );
}//void lcd_exit()
	
//------------------------------------------------------------
void switch_exit_ctrl()
{
	if ((t_pos_x >= EXIT_CTR_PIX_BEGIN_X) && (t_pos_x <= EXIT_CTR_PIX_END_X ) &&
      	(t_pos_y >= EXIT_CTR_PIX_BEGIN_Y) && (t_pos_y <= EXIT_CTR_PIX_END_Y ))
	{		
        set_pushed_area(EXIT_CTR_PIX_BEGIN_X, EXIT_CTR_PIX_BEGIN_Y, EXIT_CTR_PIX_END_X, EXIT_CTR_PIX_END_Y);
		lcd_exit();	
	}       
}//void switch_light_ctrl()

//----------------------------------------------------------------               	       
// Menu panel control.
// 
SUBPICTURE lcd_mainmenu_panel_ctrl()                  
{   

    if ((t_pos_x >= W__CTR_PIX_BEGIN_X) && (t_pos_x <= W__CTR_PIX_END_X ) &&
        (t_pos_y >= W__CTR_PIX_BEGIN_Y) && (t_pos_y <= W__CTR_PIX_END_Y ))
        return TESTpic;
    else
	if ((t_pos_x >= A__CTR_PIX_BEGIN_X) && (t_pos_x <= A__CTR_PIX_END_X ) &&
        (t_pos_y >= A__CTR_PIX_BEGIN_Y) && (t_pos_y <= A__CTR_PIX_END_Y ))
        return TESTpic;
    else
	if ((t_pos_x >= T__CTR_PIX_BEGIN_X) && (t_pos_x <= T__CTR_PIX_END_X) &&
        (t_pos_y >= T__CTR_PIX_BEGIN_Y) && (t_pos_y <= T__CTR_PIX_END_Y))
        return DATE_TIMEpic;
    else
    if ((t_pos_x >= D__CTR_PIX_BEGIN_X) && (t_pos_x <= D__CTR_PIX_END_X) &&
        (t_pos_y >= D__CTR_PIX_BEGIN_Y) && (t_pos_y <= D__CTR_PIX_END_Y))
        return DATE_TIMEpic;
    else
    if ((t_pos_x >= S__CTR_PIX_BEGIN_X) && (t_pos_x <= S__CTR_PIX_END_X ) &&
        (t_pos_y >= S__CTR_PIX_BEGIN_Y) && (t_pos_y <= (S__CTR_PIX_END_Y-30)))
        return SYSTEMpic;
	else
    if ((t_pos_x >= AB__CTR_PIX_BEGIN_X) && (t_pos_x <= AB__CTR_PIX_END_X ) &&
        (t_pos_y >= AB__CTR_PIX_BEGIN_Y) && (t_pos_y <= AB__CTR_PIX_END_Y))
        return AcopyBpic;
	else
    if ((t_pos_x >= B__CTR_PIX_BEGIN_X) && (t_pos_x <= B__CTR_PIX_END_X ) &&
        (t_pos_y >= B__CTR_PIX_BEGIN_Y) && (t_pos_y <= B__CTR_PIX_END_Y))
        return Bclearpic;
    else
 	if ((t_pos_x >= INS_CTR_PIX_BEGIN_X) && (t_pos_x <= INS_CTR_PIX_END_X ) &&
        (t_pos_y >= INS_CTR_PIX_BEGIN_Y) && (t_pos_y <= INS_CTR_PIX_END_Y ) &&
		b_root_mode)
        return INSTALLpic;
	else
	if ((t_pos_x >= GET_A_CTR_PIX_BEGIN_X) && (t_pos_x <= GET_A_CTR_PIX_END_X ) &&
        (t_pos_y >= GET_A_CTR_PIX_BEGIN_Y) && (t_pos_y <= GET_A_CTR_PIX_END_Y ) &&
		b_root_mode)
        return GETALLpic;
 /*	if ((t_pos_x >= CL1_CTR_PIX_BEGIN_X) && (t_pos_x <= CL1_CTR_PIX_END_X ) &&
        (t_pos_y >= CL1_CTR_PIX_BEGIN_Y) && (t_pos_y <= CL1_CTR_PIX_END_Y))
        return CLEAR1pic;
	else*/
 	if ((t_pos_x >= LOG_CTR_PIX_BEGIN_X) && (t_pos_x <= LOG_CTR_PIX_END_X ) &&
        (t_pos_y >= LOG_CTR_PIX_BEGIN_Y) && (t_pos_y <= LOG_CTR_PIX_END_Y))
        return LOGpic;
	else
 	if ((t_pos_x >= MAN_CTR_PIX_BEGIN_X) && (t_pos_x <= MAN_CTR_PIX_END_X ) &&
        (t_pos_y >= MAN_CTR_PIX_BEGIN_Y) && (t_pos_y <= MAN_CTR_PIX_END_Y ) &&
		b_root_mode)
        return MANpic;
	else
	if ((t_pos_x >= CL1_CTR_PIX_BEGIN_X) && (t_pos_x <= CL1_CTR_PIX_END_X ) &&
        (t_pos_y >= CL1_CTR_PIX_BEGIN_Y) && (t_pos_y <= CL1_CTR_PIX_END_Y ) &&
		b_root_mode)
        return CLEARALLpic;
    
    return NONEpic;
}//uint8_t control_touch(uint16_t  x_pixel, uint8_t  y_pixel)


//----------------------------------------------------------------               	       
// Menu panel Exit control.
// 
/*
void lcd_exit_panel_ctrl()                  
{   
 	if ((t_pos_x >= EXT_CTR_PIX_BEGIN_X) && (t_pos_x <= EXT_CTR_PIX_END_X ) &&
        (t_pos_y >= EXT_CTR_PIX_BEGIN_Y) && (t_pos_y <= EXT_CTR_PIX_END_Y))
	{
		lcd_editor_log_picture(EXITpic);
//		PutString("Exit1");
	}
	else
//	PutString("Exit2");
   
	return;
}//SUBPICTURE lcd_exit_panel_ctrl()
*/
/***********************************************************
 * sd mukodteto fg.-ek resz.
 ***********************************************************/
 //------------------------------------------------------------
void switch_light(uint8_t on_off_a)
{
	if (on_off_a)
	{ // on
		string_write("\x9B",50,227,0,0, LCD_BIGFONT );
		LCD_LIGHT_ON
		bill_time = 0;
	}
	else
	{ // off
		string_write("\x9A",50,227,0,0, LCD_BIGFONT );
		LCD_LIGHT_OFF
	}
	string_write(NULL,LI_CTR_PIX_BEGIN_X,LI_CTR_PIX_BEGIN_Y,LI_CTR_PIX_END_X,LI_CTR_PIX_END_Y, LCD_FRAME );
    
}//void switch_light(uint8_t on_off_a)

//------------------------------------------------------------
void switch_light_ctrl()
{
	if ((t_pos_x >= LI_CTR_PIX_BEGIN_X) && (t_pos_x <= LI_CTR_PIX_END_X ) &&
      	(t_pos_y >= LI_CTR_PIX_BEGIN_Y) && (t_pos_y <= LI_CTR_PIX_END_Y ))
	{
		if (CHK_SYSSTATUS(SYS_LIGHT))
		{
			CLR_SYSSTATUS(SYS_LIGHT)
		//	LCD_LIGHT_OFF
			switch_light(0);
		//	end_test(); // !!!!!!!!!!!!!!!!!!!!
		}
		else
		{
			SET_SYSSTATUS(SYS_LIGHT)
		//	LCD_LIGHT_ON
			switch_light(1);
		//	start_test(SYS_TEST2);  // !!!!!!!!!!!!!!!!!!!!
		
		}
		beep();
        set_pushed_area(LI_CTR_PIX_BEGIN_X, LI_CTR_PIX_BEGIN_Y, LI_CTR_PIX_END_X, LI_CTR_PIX_END_Y);
	}       
}//void switch_light_ctrl()
//----------------------------------------------------------------
void lcd_clear()
{	
	beep();
	init_touch();
	return;
	lcd_init();
	lcd_main_picture();
	lcd_main_bottom_picture();
    //set_pushed_area(LL_CTR_PIX_BEGIN_X, LL_CTR_PIX_BEGIN_Y, LL_CTR_PIX_END_X, LL_CTR_PIX_END_Y);	
}//void lcd_clear()
//----------------------------------------------------------------
void bad_lcd_init_ctrl()
{
	if ((t_pos_x >= LL_CTR_PIX_BEGIN_X) && (t_pos_x <= LL_CTR_PIX_END_X ) &&
      	(t_pos_y >= LL_CTR_PIX_BEGIN_Y) && (t_pos_y <= LL_CTR_PIX_END_Y ))
	{
/*		beep();
		lcd_init();
		lcd_main_picture();
		lcd_main_bottom_picture();*/
		lcd_clear();
        set_pushed_area(LL_CTR_PIX_BEGIN_X, LL_CTR_PIX_BEGIN_Y, LL_CTR_PIX_END_X, LL_CTR_PIX_END_Y);	
	}
}//bad_lcd_init_ctrl()	
//----------------------------------------------------------------
void frame_draw(uint16_t Corner_balf_x_a, uint16_t Corner_balf_y_a,uint16_t Corner_jobba_x_a,uint16_t Corner_jobba_y_a)
{
//	int i;
    uint16_t Bn1;

	if (Corner_balf_x_a > Corner_jobba_x_a)
	{
		 Bn1 = Corner_balf_x_a;
		 Corner_balf_x_a = Corner_jobba_x_a;
   		 Corner_jobba_x_a = Bn1;		
	}

	if (Corner_balf_y_a > Corner_jobba_y_a)
	{
		Bn1 = Corner_balf_y_a;
   		Corner_balf_y_a = Corner_jobba_y_a;
   		Corner_jobba_y_a = Bn1;
	}
	gr_rectangle(Corner_balf_x_a, Corner_balf_y_a, Corner_jobba_x_a, Corner_jobba_y_a);

}//void Keret(void)

//----------------------------------------------------------------   
void lcd_set_loop_addr(uint8_t loop_a,uint8_t addr_a)
{
	return;//!!!! 2011-01-18
	if (loop_a > COMM_MAX_LOOP)
		loop_a = 0;
	itoa(loop_a,msg,10);
	string_write(msg,15,73,0,0, LCD_BIGFONT );

//	string_write("  ",27,73,0,0, LCD_BIGFONT );
/*	if (!addr_a)
	{
		string_write("    ",33,8,0,0, LCD_SMALLFONT );
		return;
	}
	else
	if (addr_a == 0xaa)
	{
		msg[0] = 129;
		msg[1] = 0;
	}
	else
    if (addr_a == 0xfe)
    {
		msg[0] = 128;
		msg[1] = 0;
	}
    else
		itoa(addr_a,msg,10);
	//string_write("  ",27,73,0,0, LCD_BIGFONT );
//	string_write(msg,27,73,0,0, LCD_BIGFONT );
	string_write("lamp",33,8,0,0, LCD_SMALLFONT );
	*/
}//void lcd_set_loop_addr(uint8_t,uint8_t)

/***************************************************
 * Allomas status
 ***************************************************/
// toltes hiba
// 31.12.2007-12.56:      1L< 12:T >; // 35 hosszu
// tesz hibak:
// 31.12.2007-12.56:Test start;      
// 31.12.2007-12.56:Test: 8L<12:ATF>;
// 31.12.2007-12.56:Test end; 

//----------------------------------------------------------------
void write_Allerror_to_sd(const char* mesg, uint8_t addrh_a, uint8_t addrl_a, char error, char time)
{
	char temp[40];
//	char temp1[30];
//	char loop;
//	TIMER_STOP
			
		//	sprintf(msg,"0x%x,0x%x",pChan->data,pChan->prev_data);
		//	PutString(msg);
		//	pChan->prev_data = 0x20;
	if (time)
	{
		PCF8583_get_date(&day,&month,&year);		
//	sprintf(msg,"%2d.%2d.%4d",day,month,year+2000);		
		PCF8583_get_time(&hour,&min,NULL,NULL);		
	//	sprintf(temp,"%02d.%02d.%04d-%02d.%02d:%s",day,month,year+2000,hour,min,mesg);
		sprintf(temp,"%04d.%02d.%02d-%02d.%02d:%s",year+2000,month,day,hour,min,mesg);
		strcpy(msg,temp);
	}
//	else
//		strcpy(msg,mesg);	
	if (error)
	{
	//	loop = CHK_SYSSTATUS(SYS_1LOOP)?1:0;
		sprintf(temp,"%03d:< %c >;\r\n",(int)(addrh_a)*256 + (int)addrl_a,error);
		strcat(msg,temp);	
	}

	write_to_sd(msg);
#ifdef SERIAL_PRINTER
    PutPrinter(msg);
#else
	PutString(msg);
#endif
/*	struct fat16_file_struct* fd = open_file("lamp.log");
    if(fd)
    {				
		if (append_file(fd, (uint8_t*)msg, strlen(msg)))
		{
#ifdef DEBUG
			PutString("append oke");
#endif
		}
		close_file(fd);
		TIMER_START
		return 1;
	}
#ifdef DEBUG
	else
		PutString("d'nt open file"); 
#endif*
	TIMER_START*/
	return;
}//void write_Allerror_to_sd(const char* mesg, uint8_t addr, char error)

char sd_temp_st[MESS_LEN];
//----------------------------------------------------------------
void write_to_sd(const char* mesg)
{
	//char temp[40];
	int ii;
	char flag=0;
//	char temp1[30];
//	char loop;
	TIMER_STOP
		
	strncpy(sd_temp_st,mesg,MESS_LEN);	
	for(ii=0;ii<MESS_LEN;ii++)
	{
		if(sd_temp_st[ii]==';')
			flag = 1;
		if (flag)
			sd_temp_st[ii]=' ';		
	}
	
	sd_temp_st[MESS_LEN-3]='\r';
	sd_temp_st[MESS_LEN-2]='\n';
	sd_temp_st[MESS_LEN-1]=0;

	struct fat16_file_struct* fd = open_file("lamp.log");
    if(fd)
    {				
		if (append_file(fd, (uint8_t*)sd_temp_st, MESS_LEN))
		{
#ifdef DEBUG
			PutString("append oke");
#endif
		}
		close_file(fd);
	//	TIMER_START
	//	return;
	}
//#ifdef DEBUG
	else
		PutString("d'nt open file"); 
//#endif
	TIMER_START
	DelayMs(10);
	wdt_reset();
	return;
}//void write_Allerror_to_sd(const char* mesg, uint8_t addr, char error)
//----------------------------------------------------------------
/*
 void if_error_write_sd(uint8_t loop_a,CHANNELtype* pChan)
 {
	if (pChan)
	{				
	//	char flag = 0;
		if (CHK_SYSSTATUS(SYS_TEST2) || CHK_SYSSTATUS(SYS_TEST40))
			test_write_sd(loop_a,pChan);
		else
		{		
//			sprintf(msg,"prev_data:%x:data:%x",pChan->prev_data,pChan->data);
//			PutString(msg);
	//	if ((pChan->prev_data & 0x01) != (pChan->data & 0x01) )
	//	{	// uj toltes hiba!!				
			if ((pChan->data & 0x01) == 0)
			{ // hiba!!			
				write_Allerror_to_sd("      ", pChan->addrh ,pChan->addrl, 'T', 1);				
			}			
	//		flag = 1;
	//	}			
	//	if ((pChan->prev_data & 0x02) != (pChan->data & 0x02) )
	//	{	// uj akku hiba!!					
			if ((pChan->data & 0x02) == 0)
			{ // hiba!!			
				write_Allerror_to_sd("      ", pChan->addrh ,pChan->addrl, 'A', 1);				
			}
		//	flag = 1;			
										
	//	}
	//	if ((pChan->prev_data & 0x04) != (pChan->data & 0x04) )
	//	{	// uj fenycso hiba!!					
			if ((pChan->data & 0x04) == 0)
			{ // hiba!!			
				write_Allerror_to_sd("      ", pChan->addrh ,pChan->addrl, 'F', 1);				
			}
		//	flag = 1;													
	//	}
	//	if (flag)
	//		pChan->prev_data = pChan->data;	
		}	

	}
 }//if_error_write_sd(uint8_t loop_a,CHANNELtype* pChan)
*/
//---------------------------------------------------------------- 
 void test_write_sd(uint8_t loop_a,CHANNELtype* pChan)
 { 				
	//	if ((pChan->prev_data & 0x06) != (pChan->data & 0x06) )
	//	{	 				
			if (!(pChan->data & 0x02))		
			{// akku hiba:2.bit.				
				write_Allerror_to_sd("Test: ", pChan->addrh, pChan->addrl, 'A', 1);				
			}
			if (!(pChan->data & 0x04))			
			{// fenycsohiba : 3. bit.				
				write_Allerror_to_sd("Test: ", pChan->addrh, pChan->addrl, 'F', 1);				
			}
	//		pChan->prev_data = pChan->data;			
	//	}

 }//test_write_sd(uint8_t loop_a,CHANNELtype* pChan, uint8_t prev_data)

//---------------------------------------------------------------- 
void sd_card_off()
{ 	
	sed1335_clear_display();
	sed1335_clear_display();
	string_write("NINCS SD KARTYA,", 10,100,0,0, LCD_BIGFONT );
	string_write("LEALLOK!", 10,150,0,0, LCD_BIGFONT );	
}

//---------------------------------------------------------------- 
void trial_on_display()
{ 	
	sed1335_clear_display();
	sed1335_clear_display();
	string_write("Vegzetes hiba!,", 10,100,0,0, LCD_SMALLFONT );
	string_write("A rendszer karbantartoi beavatkozast igenyel ", 10,150,0,0, LCD_SMALLFONT );	
}

//---------------------------------------------------------------- 
void lcd_A_B_write(uint8_t mode)
{ 	
#ifdef A_B
	switch (mode)
	{
		case 0:
			sprintf(msg,"A:%01d  B:%01d ",Darab_A(),Darab_B());
            string_write(msg,16,12,0,0, LCD_SMALLFONT );
			break;
		case 1:
			sprintf(msg,"A: 0  B:%01d  ",Darab_B());
            string_write(msg,16,12,0,0, LCD_SMALLFONT );
			break;
		case 2:
			sprintf(msg,"A:%01d  B: 0 ",Darab_A());
            string_write(msg,16,12,0,0, LCD_SMALLFONT );
			break;
			
	}
#endif
//	string_write("                           ",16,13,0,0, LCD_SMALLFONT );	
}
//----------------------------------------------------------------   
/*
void lcd_set_chan_data(uint8_t loop_a,CHANNELtype* pChan)
{
    char temp[30];
	temp[0]=0;
	uint8_t bback = 0;

	if (pChan && (pChan->addrh || pChan->addrl))
	{			
		if (pChan->error & 0x07)
		{			
			if (pChan->error & 0x01)
				strcpy(temp,"com error       ");
			else
			if (pChan->error & 0x02) 
				strcpy(temp,"no respond      ");
			else
			if (pChan->error & 0x04)
				strcpy(temp,"content error   ");
			lcd_A_B_write(0);	
	
			write_Allerror_to_sd("      ", pChan->addrh, pChan->addrl, 'C', 1);	
		
		}
		else
		{
			if (pChan->error & 0x40)
			{
				bback = 1;
				write_Allerror_to_sd("      ", pChan->addrh, pChan->addrl, 'B', 1);	
			}	
	}
}//void lcd_set_chan_data(uint8_t loop_a,CHANNELtype* pChan)

//----------------------------------------------------
void lcd_set_loop_error(LOOPtype* pLoop)
{
	if (pLoop)
	{
		if (pLoop->error > 3)
		{
			sprintf(msg,"%01d: no respond      ",pLoop->loop);
            string_write(msg,16,12,0,0, LCD_SMALLFONT );
		}
	}
}//void lcd_set_loop_error(LOOPtype* pLoop)

*/
//----------------------------------------------------
void allomas_status(void)
{
	int kk;
//	char temp[30];
	//static int index_s = 0;
//	static uint8_t was_install_s = 0;

	if (CHK_INSTALL)
	{
		string_write(TEST4_MSG, 1,24,0,0, LCD_BIGFONT );	
		string_write(TEST5_MSG,1,45,0,0, LCD_BIGFONT );
		for (kk = 0;kk<allloopnumenable; kk++)
		{			
			if (loop_array[kk].chn.stat && 1) 
				return;
		}

		set_install(0);
		return;
	}

	 kk = (CHK_SYSSTATUS(SYS_TEST2) || CHK_SYSSTATUS(SYS_TEST40));

	 AB_controll(kk);

	string_write(TEST0_MSG, 1,24,0,0, LCD_BIGFONT );	
	if (kk)
	{	
		string_write(TEST2_MSG,2,45,0,0, LCD_BIGFONT );		
	}
	else
	{		
		/*	if (tolteshiba)	
        		string_write(" ERROR",1,45,0,0, LCD_BIGFONT );
			else
        		string_write(" O.K. ",2,45,0,0, LCD_BIGFONT );*/		
		//	ii = AB_controll();
		
#ifdef TOLTESJEL
			if (IsChargeError_AB())
				string_write(TEST1_MSG,1,45,0,0, LCD_BIGFONT );
			else
#endif
				string_write(TEST3_MSG,2,45,0,0, LCD_BIGFONT );										
	}
	
//	ii = (ii >= allloopnumenable) ? 0 : ii;

//	lcd_set_chan_data(loop_array[ii].loop,&loop_array[ii].chn);
//	lcd_set_loop_error(&loop_array[ii]);
/*
	for (kk = 0;kk<allloopnumenable; kk++)
	{
		if (loop_array[kk].chn.addrh || loop_array[kk].chn.addrl)
		{			
			if (loop_array[kk].chn.error & 0x07)
			{			
				if (loop_array[kk].chn.error & 0x01)
					strcpy(temp,"com error       ");
				else
				if (loop_array[kk].chn.error & 0x02) 
					strcpy(temp,"no respond      ");
				else
				if (loop_array[kk].chn.error & 0x04)
					strcpy(temp,"content error   ");
				lcd_A_B_write(0);	
				write_Allerror_to_sd("      ", loop_array[kk].chn.addrh, loop_array[kk].chn.addrl, 'C', 1);			
			}
			else
			{
				if (loop_array[kk].error & 0x40)
				{
				//	bback = 1;
					write_Allerror_to_sd("      ", loop_array[kk].chn.addrh, loop_array[kk].chn.addrl, 'B', 1);	
				}	
			}
		}

		if (loop_array[kk].error > 3)
		{
			sprintf(msg,"%01d: no respond      ",loop_array[kk].loop);
            string_write(msg,16,12,0,0, LCD_SMALLFONT );
		}
	}*/

	AB_executor();

	for (kk = 0;kk<allloopnumenable; kk++)
	{
		loop_array[kk].chn.addrh = 0;
		loop_array[kk].chn.addrl = 0;
	}

	if (CHK_SYSSTATUS(SYS_SERVICE))
	{
		string_write(TEST6_MSG, 1,24,0,0, LCD_BIGFONT );
		string_write(TEST7_MSG, 2,24,0,0, LCD_BIGFONT );
	}
	
}//void allomas_status(void)

//-------------------------------------------------------------
// A->B test subpanel.
//-------------------------------------------------------------
void lcd_A_copy_B_panel_ctrl()
{	
	if ((t_pos_x >= ABY_CTR_PIX_BEGIN_X) && (t_pos_x <= ABY_CTR_PIX_END_X ) &&
        (t_pos_y >= ABY_CTR_PIX_BEGIN_Y) && (t_pos_y <= ABY_CTR_PIX_END_Y ))
	{ 	// yes
    	A_copyto_B();
		lcd_A_B_write(1);	  
	}
    else
	if ((t_pos_x >= ABN_CTR_PIX_BEGIN_X) && (t_pos_x <= ABN_CTR_PIX_END_X ) &&
        (t_pos_y >= ABN_CTR_PIX_BEGIN_Y) && (t_pos_y <= ABN_CTR_PIX_END_Y ))
	{	// no

	}
	lcd_exit();
}//void lcd_A_copy_B_panel_ctrl()

void lcd_B_clear_panel_ctrl()
{	
#ifdef A_B
	if ((t_pos_x >= BY_CTR_PIX_BEGIN_X) && (t_pos_x <= BY_CTR_PIX_END_X ) &&
        (t_pos_y >= BY_CTR_PIX_BEGIN_Y) && (t_pos_y <= BY_CTR_PIX_END_Y ))
	{ 	// yes
    	 B_all_clear();	
		lcd_A_B_write(2);  
	}
    else
	if ((t_pos_x >= BN_CTR_PIX_BEGIN_X) && (t_pos_x <= BN_CTR_PIX_END_X ) &&
        (t_pos_y >= BN_CTR_PIX_BEGIN_Y) && (t_pos_y <= BN_CTR_PIX_END_Y ))
	{	// no

	}
	lcd_exit();
#endif
}//void lcd_A_copy_B_panel_ctrl()

/***************************************************
 * Display helper.
 ***************************************************/
//----------------------------------------------------------------   
void lcd_set_chan_cmd(char* msg)
{
	if (msg)
	{
		
		strcpy(msg_state,msg);	
	}
	else
	{
		strcpy(msg_state,"                       ");	
	}
	string_write(msg_state,16,14,0,0, LCD_SMALLFONT );
}//void lcd_set_chan_cmd(char* msg)

//----------------------------------------------------------------
void bigchar(const char txt)                                            
{
    bigstring(&txt, 1, 0);
}//void bigchar(const char txt)

//----------------------------------------------------------------
void string_write(char* txt, uint16_t x, uint8_t y,uint16_t xe, uint8_t ye, uint8_t flag )                                            
{
	TIMER_STOP
	sed1335_disable_display();	
	if (flag & LCD_CLR)
	{
		if (!x)
			sed1335_clear_display();
		else
			sed1335_clr_display(x);	
	}
#ifdef LARGE_FONT
    if (flag & LCD_BIGFONT)
    {
        gr_set_cursor(x,y);
        bigstring(txt,strlen(txt),0);
    }   
#endif
    
    if (flag & LCD_FRAME)
        frame_draw(x, y, xe, ye);
	if (flag & LCD_PIXEL)
		gr_setpixel(x, y);	
	if (flag & LCD_SMALLFONT)
	{
        txt_set_cursor(x,y);
		text_set_pos(x,y);
		text_append(txt,strlen(txt));
  //      text_write(txt,strlen(txt));
//		sprintf(msg,"string_write: %s, %d",txt,strlen(txt));
//		PutString(msg);
    }
	sed1335_enable_display();
	TIMER_START
}//void bigchar(const char txt)

//---------------------------------------------------------------- 
void time_write(uint8_t hour, uint8_t min)
{
	sprintf(msg,"%02d:%02d",(int)hour,(int)min);
	string_write(msg, 17, 38, 0, 0, LCD_BIGFONT );
}//void time_write(uint8_t hour, uint8_t min)

//---------------------------------------------------------------- 
void date_write(uint8_t day, uint8_t month, uint8_t year)
{
	sprintf(msg,"%02d.%02d.%04d",(int)day,(int)month,(int)year+2000);
	string_write(msg, 31,38, 0, 0, LCD_BIGFONT );	
}//void date_write(uint8_t day, uint8_t mounth, uint8_t day)


/***********************************************************
 * Kepek.
 ***********************************************************/

/***********************************************************
 * main()-be a forutin.
 ***********************************************************/
void touch_executor(void)
{
	static uint16_t prev_timer_sec = 0;

	if (timersec != prev_timer_sec)
	{       
	// TRIAL START
		if (config.trial == 0x55)
		{		 	
			if (timersec % 2)
			{
				trial_on_display();
				LED_blink = 2;
			}
			return;
		}		
		// TRIAL END
		if (timersec % 2)
		{
			string_write(":", 21, 38, 0, 0, LCD_BIGFONT );
			blink = 1;		
		}
		else
		{
			string_write(" ", 21, 38, 0, 0, LCD_BIGFONT );
			blink = 0;	
		//	if (!IsFull_A())
			allomas_status();	
		}	

		prev_timer_sec = timersec;
		lcd_watest_panel_view();
		lcd_datetime_panel_view();
		lcd_loop_addr_panel_view();
		if (!(timersec % 7))
		{
					          
			PCF8583_get_time(&hour,&min,NULL,NULL);
			time_write(hour, min);

			PCF8583_get_date(&day,&month,&year);		//test
			watch_alarm(day, month, year, hour, min);	//test

		}
		if (!(timersec % 300))
		{					          
			PCF8583_get_date(&day,&month,&year);		
			date_write(day, month, year);	
		
		}
		if ( (current_pic_s != NONEpic) || (CHK_SYSSTATUS(SYS_LIGHT)) )
		{
			if ((bill_time / 240) >= 1)
			{
		
				lcd_exit();
				CLR_SYSSTATUS(SYS_LIGHT)
				switch_light(0);
			}
			else
				bill_time++;
		}

		if (CHK_INSTALL)
		{
			inst_timer++;
			if (inst_timer > config.install_min) // 30 perc
			{
				set_install(0);
			}	
		}

	/*	if (timersec % 3)
		{
			if (CHK_SYSSTATUS(SYS_SERVICE))
			{
					PutString("SERVICE");
			}
		}*/
	}


    if (t_a_d(&t_pos_x,&t_pos_y))
    {
	//	sprintf(msg,"t_pos_x: %d, t_pos_y:%d",t_pos_x,t_pos_y);
	//	PutString(msg);
		if (current_pic_s == NONEpic)
	 		lcd_editor_log_picture(lcd_mainmenu_panel_ctrl());
		else
		{
			if (current_pic_s == SYSTEMpic)			
				lcd_system_panel_ctrl();
			else
			if ((current_pic_s == MANpic) && b_root_mode)					
				lcd_manual_panel_ctrl();
			else	
			if ((current_pic_s == INSTALLpic) && b_root_mode)					
				lcd_install_panel_ctrl();
			else	
			if ((current_pic_s == CLEARALLpic) && b_root_mode)
				lcd_clearall_panel_ctrl();					
			else
			if ((current_pic_s == GETALLpic) && b_root_mode)
				lcd_getall_panel_ctrl();					
			else
		/*	if (current_pic_s == CLEAR1pic)	
				lcd_loop_addr_panel_ctrl();*/
			if (current_pic_s == TESTpic)					
				lcd_watest_panel_ctrl();		
			else
			if (current_pic_s == DATE_TIMEpic)					
				lcd_datetime_panel_ctrl();
			else
			if (current_pic_s == LOGpic)
				lcd_logger_panel_ctrl(CTR_NONEctl);
#ifdef A_B
			else
			if (current_pic_s == AcopyBpic)
				lcd_A_copy_B_panel_ctrl();
			else
			if (current_pic_s == Bclearpic)
				lcd_B_clear_panel_ctrl();
#endif
			//lcd_exit_panel_ctrl();
            switch_exit_ctrl();
		}
      	
	   switch_light_ctrl();	
	   bad_lcd_init_ctrl();	
    }
/*	if (!(timercount % 50))
	{
	//	if (timersec % 1)
	//	sprintf(msg,"tc:%d",timercount);
	//	PutString(msg);
		Alarm_LED_fast_blink();
	}*/

}//void touch_exe()

//-------------------------------------------------------------
// Test resz.
//-------------------------------------------------------------
void start_test(uint8_t mode_a)
{
	SET_SYSSTATUS(mode_a)
	prev_test_timer_sec = 0;
	test_timersec = 0;
	chn_ask.num = 3;
	chn_ask.chn.cmd  = 0x70;
	chn_ask.timeout  = 0;
	chn_ask.loop = 0xfe;
	chn_ask.chn.addrh = 0;	
	chn_ask.chn.addrl = 0;	


	if (CHK_SYSSTATUS(SYS_TEST2))
		write_Allerror_to_sd("Test start L;",0, 0, 0, 1);
	//	strcpy(msg,"Test start 5min;\r\n");
	else
		write_Allerror_to_sd("Test start A;",0, 0, 0, 1);
	//	strcpy(msg,"Test start25min;\r\n");
//	write_Allerror_to_sd(msg,0, 0, 0, 1);
	string_write(TEST0_MSG, 1,24,0,0, LCD_BIGFONT );
	prev_test_timer_sec = 0;	
	test_timersec 		= 0;

}//void start_test(void)


//
//-------------------------------------------------------------
void end_test(void)
{	
	chn_ask.num = 2;
	chn_ask.chn.cmd  = 0x71;
	chn_ask.timeout  = 0;

//	if (config.loop_type)
//	{ // more.
		chn_ask.loop = 0xfe;
		chn_ask.chn.addrh = 0;	
		chn_ask.chn.addrl = 0;
//	}
/*	else
	{ // 1.
		chn_ask.loop = 1;
		chn_ask.chn.addr = 0xfe;	
	}
	*/	
//	set_cmd_all_All(0);
//	string_write("Charge", 1,24,0,0, LCD_BIGFONT );	
	string_write(TEST0_MSG, 1,24,0,0, LCD_BIGFONT );	
	if (CHK_SYSSTATUS(SYS_TEST2))
	//	strcpy(msg,"Test end  5min ;\r\n");
		write_Allerror_to_sd("Test end  5min ;",0, 0, 0, 1);
	else
	//	strcpy(msg,"Test end  40min;\r\n");
		write_Allerror_to_sd("Test end 40min ;",0, 0, 0, 1);
	//write_Allerror_to_sd(msg,0, 0, 0, 1);
	CLR_SYSSTATUS(SYS_TEST2)
	CLR_SYSSTATUS(SYS_TEST40)
//	write_Allerror_to_sd("Test end       ;\r\n",0, 0, 0);
//	lcd_editor_log_picture(EXITpic);
	lcd_exit();
}//void start_test(void)

//-------------------------------------------------------------
void watch_alarm(uint8_t day,uint8_t month,uint8_t year, uint8_t hour, uint8_t min)
{
	if (CHK_SYSSTATUS(SYS_TEST40) || CHK_SYSSTATUS(SYS_TEST2))
		return;
//	if ((hour != 6) || !(min<6))
//		return;
	if ((config.annual_HM_test[0] != hour) || (config.annual_HM_test[1] != min))
		return;
//	sprintf(msg,"min:%d ,min_test:%d ",min,min_test);
//	PutString(msg);
//	if ((min!=(min_test+1)))
//		return;
//	PutString("ALARM ido");
//	sprintf(msg,"wyear:%d ,wmonth:%d, wday:%d, year:%d ,month:%d, day:%d, ",bcd2bin(config.weekly_test[2]),bcd2bin(config.weekly_test[1]),bcd2bin(config.weekly_test[0]),year,  month, day);
//	PutString(msg);
	if ((config.annual_test[2] == year) && (month == config.annual_test[1]) && (day == config.annual_test[0]))
	{ // annual alarm!
//		if (CHK_SYSSTATUS(SYS_TEST40) || CHK_SYSSTATUS(SYS_TEST2))
//			return;
// TRIAL START
		 config_trial_read(); 
		 if ((config.trial == 0xaa) || (config.trial == 0x55))
	     {
		 	config_trial_save(0x55);
			trial_on_display();
			return;
		 }		
// TRIAL END
		start_test(SYS_TEST40);
		PutString("ALARM T40!");
		++year;		

//	sprintf(msg,"year:%d ,month:%d, day:%d",year,  month, day);
//	PutString(msg);
		config_annual_save(year, month, day);
		lcd_main_bottom_picture();
		lcd_set_chan_cmd("Aut.test start,40min");	
		beep();
	}

	if ((config.weekly_test[2] == year) && (month == config.weekly_test[1]) && (day == config.weekly_test[0]))
	{ // weekly alarm!
//	if (CHK_SYSSTATUS(SYS_TEST40) || CHK_SYSSTATUS(SYS_TEST2))
//			return;
		start_test(SYS_TEST2);
		PutString("ALARM T5!");
		day += 7;
		if (day > 30)
		{
			day -= 30;
			++month;
			if (month > 12)
			{
				month = 1;
				++year;
			}
		}
		config_weekly_save(year, month, day);
		lcd_main_bottom_picture();
		lcd_set_chan_cmd("Aut.test start,5min");	
		beep();
		return;
	}	
}//void watch_alarm()

//-------------------------------------------------------------
void test_executor(void)
{		
/*	if(PCF8563_get_alarm())
	{	// weekly alarm jott!
		SET_SYSSTATUS(SYS_TEST2);
		PutString("ALARM!!!!!");
	}
	*/
	if (CHK_SYSSTATUS(SYS_TEST40) || CHK_SYSSTATUS(SYS_TEST2))
	{
#if 0
		if (!((test_timersec - prev_test_timer_sec) % 30))
		{
			chn_ask.num = 1;
			chn_ask.chn.cmd  = 0x70;
			chn_ask.timeout  = 0;
		//	if (config.loop_type)
		//	{ // more.
				chn_ask.loop = 0xfe;
				chn_ask.chn.addrh = 0;	
				chn_ask.chn.addrl = 0;
		//	}
		}
#endif
	}
	if (CHK_SYSSTATUS(SYS_TEST2))
	{
		if ((test_timersec - prev_test_timer_sec) > 500)
		{      
			prev_test_timer_sec = test_timersec; 
			//if (!(timersec % 200)) // 2 perc 20 sec
			//{
				end_test();
				lcd_set_chan_cmd("Manual test end.        ");
			//}
		}
	}
	else
	if (CHK_SYSSTATUS(SYS_TEST40))
	{
// TRIAL START
		 config_trial_read(); 
		 if (config.trial == 0x55)
	     {		 	
			return;
		 }		
// TRIAL END
		if ((test_timersec - prev_test_timer_sec) > 4000)
		{       
			prev_test_timer_sec = test_timersec; 
	//		if (!(timersec % 2430)) // 40.5 perc
	//		{
				end_test();
				lcd_set_chan_cmd("Manual test end.        ");
	//		}
		}
	}
	
}//void test_executor(void)

//-------------------------------------------------------------
// 1 Cim kerdes resz.
//-------------------------------------------------------------
void get_addr_datas(uint8_t loop_a)
{
	chn_ask.num = 3;
	chn_ask.loop = loop_a;
	chn_ask.chn.addrh = 0;	
	chn_ask.chn.addrl = 0;
	chn_ask.chn.cmd = S_ASKADDR_CMD;
	chn_ask.timeout = RX_TIME_TO_TX5;
	SET_SYSSTATUS(SYS_WAIT_ADDRLIST);
//	PutString("get_addr_list");	
}//void get_addr_datas()

//-------------------------------------------------------------
// Allomasok cimeinek a lekerese.
//-------------------------------------------------------------
void start_get_all_address()
{
	if (allloopnumenable) 
	{
		get_max_loop_num = allloopnumenable;
		get_addr_datas(loop_array[0].loop);
	//	PutString("get address!");
	}
}

void get_addr_executor()
{
	if (get_max_loop_num)
	{
		if (CHK_SYSSTATUS(SYS_WAIT_ADDRLIST))
		{ // nincs valasz
			if (!(chn_ask.num))
			{
				sprintf(msg,"D'nt get address of client '%d';",chn_ask.loop);
				write_to_sd(msg);
				PutString(msg);	
				get_max_loop_num--;
				if (get_max_loop_num)
				{   // uj lekerdezes.
					get_addr_datas(loop_array[(get_max_loop_num-allloopnumenable)*(-1)].loop);
			//	get_addr_datas(loop_array[0].loop);
				}
				else
					lcd_set_chan_cmd(NULL);
			}
		}
		else
		{// jott adat/cim.
		//	sprintf(msg,"Addr of client:'%d' loop:;\r\n",chn_ask.loop);
		//	write_Allerror_to_sd(msg, 0, 0, 0);
			get_max_loop_num--;
			if (get_max_loop_num)
			{   // uj lekerdezes.
				get_addr_datas(loop_array[(get_max_loop_num-allloopnumenable)*(-1)].loop);
	//			get_addr_datas(loop_array[0].loop);
			}
			else
				lcd_set_chan_cmd(NULL);
		}
	}
}

/*
//-------------------------------------------------------------
// LCD kontrast beallitasa.
//-------------------------------------------------------------
void set_lcd_contrast(int inc_dec)
{
	OFF_LKCS
	if (inc_dec > 0)
	{ // up
		PutString("Up");
		UP_LKUD		
	}
	else
	{ // down
		PutString("Down");
		DOWN_LKUD
	}
	OFF_LKINC
	ON_LKCS
	ON_LKINC
	DelayMs(1);
	OFF_LKINC
	DelayMs(1);
	OFF_LKCS

}//void set_lcd_contrast(int inc_dec)

void save_lcd_contrast()
{

}//void save_lcd_contrast()
*/

