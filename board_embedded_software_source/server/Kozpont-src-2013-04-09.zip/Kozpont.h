#ifndef _KOZPONT_H
#define _KOZPONT_H


#define TOLTESJEL				1
#define A_B						1

#define P_PIEZO				0x10	
#define PIEZO_OFF  			PORTE &= ~P_PIEZO;
#define PIEZO_ON			PORTE |=  P_PIEZO;

#define	SYS_1LOOP			0x01
#define	SYS_MLOOP			0x02
#define	SYS_LIGHT			0x04
#define	SYS_TEST2			0x08
#define	SYS_TEST40			0x10
#define	SYS_WAIT_ADDRLIST	0x20
#define	SYS_SERVICE			0x40

//#define	SYS_WAIT_ADDRLIST	0x40


#define CLR_SYSSTATUS(x)		{_CLI(); sys_status &= (~x); _SEI();};
#define CLR_SYSSTATUS_(x)		{sys_status &= (~x);};
#define SET_SYSSTATUS(x)		{sys_status |= (x);};
#define CHK_SYSSTATUS(x)		(sys_status & (x))

#define TIMER_STOP				TCCR0 = 0x00;TCNT0 = 0;
#define TIMER_START				TCCR0 = _BV(CS02)|_BV(CS01)|_BV(CS00);TCNT0 = 157;

void init(void);
void sd_cd();

extern volatile uint16_t 		timercount;
extern volatile uint16_t 		timersec;
extern volatile unsigned char 	sys_status;
extern void beep();
extern char msg[40];
extern char b_root_mode;
extern char bSD_Error;
extern uint8_t sd_valid;
#endif
