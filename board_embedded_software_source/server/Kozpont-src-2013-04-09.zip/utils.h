#ifndef __UTILS_H__
#define __UTILS_H__


#define CYCLES_PER_US ((F_CPU+500000)/1000000)

uint8_t bcd2bin(uint8_t bcd);
uint8_t bin2bcd(uint8_t bin);
char nibble2hex(uint8_t val);
void byte2hex(uint8_t val, char *s);
void word2hex(uint16_t val, char *s);
void byte2dec(uint8_t val, char *s);

extern void DelayMs(uint16_t ms);
void delayus(uint16_t us);
void delay10us(void);
extern void delayms(uint16_t count);


#endif 
