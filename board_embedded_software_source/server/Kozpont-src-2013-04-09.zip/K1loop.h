#ifndef _1LOOP_H
#define _1LOOP_H

#define P_RS485_DE0			0x40	
#define RS485_DE0_OFF  		PORTF &= ~P_RS485_DE0;
#define RS485_DE0_ON		PORTF |=  P_RS485_DE0;

#define P_RS485_RE0			0x80	
#define RS485_RE0_ON  		PORTF &= ~P_RS485_RE0;
#define RS485_RE0_OFF		PORTF |=  P_RS485_RE0;

//#define RX_OFF 				UCSRB &= 0x6f;
//#define RX_ON 				UCSRB |= 0x90;

#define TX0_OFF 			UCSR0B &= 0xdf;
#define TX0_ON 				UCSR0B |= 0x20;

#ifdef ELSZALLT
#define RX0_OFF 			UCSR1B &= 0x6f;
#define RX0_ON 				UCSR1B |= 0x90;
#else
#define RX0_OFF 			UCSR0B &= 0x6f;
#define RX0_ON 				UCSR0B |= 0x90;
#endif

//#define COMM_MAX_ADDR		COMM1_MAX_ADDR*COMM_MAX_LOOP

#define SEARCH_ADDRESS1 0xaa	// uj cimkeres indul be.
#define SEARCH_ADDRESS2 0x55	// uj cimkeres indul be.
#define BROAD_ADDRESS	0xfe	// broad. cim.

#define	RX_TIME_TO_TX1	150		// 1000 ms, jo vetel utan a kovetkezo adas.
#define	RX_TIME_TO_TX2	150		// 1000 ms, rossz vetel utan a kovetkezo adas.
//#define	RX_TIME_TO_TX3	150		// 2000 ms, vetel time-out utan a kovetkezo adas.
#define	RX_TIME_TO_TX3	150		// 1500 ms, vetel time-out utan a kovetkezo adas.
#define	RX_TIME_TO_TX4	600		// 6000 ms, korkerdes utan a kovetkezo adas.
#define	RX_TIME_TO_TX5	700		// 7000 ms, cimkerdes utan a kovetkezo adas.

// install	
#define START_INST		0x01
#define BEJ_INST		0x02
#define PUT_ADDR_INST	0x04
#define ASK_ADDR_INST	0x08

//#define CLR_INSTALL(x)		{install &= (~x);};
#define CLR_INSTALL		{install = 0;}
#define SET_INSTALL(x)			{install = x;}
#define CHK_INSTALL			(install)


extern uint8_t chl1_rx_data(volatile unsigned char* pData);
//uint8_t time_out(uint8_t start,uint16_t diff);
uint8_t chl1_rx_new_addr_req(volatile unsigned char* pData);
uint8_t install_receiver(volatile unsigned char* pData);
void install_error(void);
void install_sender(void);

extern void chl1_com_init();
//extern unsigned char ch1l_tx_int();
//extern char ch1l_rx_int( unsigned char ucData);
extern void chl1_com_rx_tx(void);
extern CHANNELtype IndexAll(uint8_t index);
extern CHANNELtype FirstAll(void);
extern CHANNELtype* SearchAll(uint8_t all_addressh, uint8_t all_addressl);
extern CHANNELtype* pCurrAll(void);
extern void chl1_tx_send(CHANNELtype* ptrData);
extern uint8_t alladdrnumenable;
extern uint8_t allloopnumenable;
extern uint8_t all_ask_index;


//extern uint8_t rx_error;

extern CHN_ASK chn_ask;
extern CHANNELtype all_array[COMM_MAX_ADDR+1];
extern void set_allomas_error(uint8_t loop,uint8_t addr,uint8_t err_bit);

extern CHANNELtype NextAll(void);
extern void chl1_rx_controlling(volatile unsigned char* pData);
extern void set_cmd_all_All(uint8_t cmd);
//extern void chl1_set_error_flag(CHERRFLAG flag_a);
#endif
