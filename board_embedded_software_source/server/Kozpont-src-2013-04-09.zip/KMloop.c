/*
 *	Lamp hurok com. Atmega128..
 *  Tiszai I.
 *  2007
 *
 *	Leiras:
 *	Adas: A
 *	Vetel:V
 *
 *
 *	A:',',lcim,0x00,0x0x,0x00,chs		// altalanos lekerdezes,parancsok.
 *	V:';',lcim,acimh,aciml,data,error,stat,chs 	// x: D0,D1 output,input,hiba lekerdezes, stat allapot.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,acimh,aciml,data,chs		// elozoleg megkapott hiba visszajelzese.
 *	V:';',lcim,0x00,0x00,00,00,00,chs
 *
 *	A:',',lcim,0x00,0x00,0x00,chs		// altalanos lekerdezes.
 *	V:'M',num,"uzenet.."			    // szimpla uzenet, max. 20 byte.
 *
 *	A:',',lcim,acimh,aciml,0x80,chs		// reset 1 allomasnal.
 *	V:';',lcim,0x00,00,0x80,00,00,chs	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,acimh,aciml,0x90,chs		// torli az allomas cimet a hurok kartya  eepromjaban.
 *	V:';',lcim,0x00,00,0x90,00,00,chs	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,0x00,0x91,chs		// allomas cimek szamanak a lekerdezese.
 *	V:';',lcim,0x00,0x00,0x91,num,chs   // allomas cimek szama a num-ban
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,0x00,0x92,chs		// allomas cimek lekerdezese.
 *	V:'N',lcim,0x92,num,a0..an,chs      // allomas cimek.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0x83,chs		    // install bekapcsolasa.
 *	V:';',lcim,0x00,00,0x83,00,00,chs 	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0x84,chs		    // install kikapcsolasa.
 *	V:';',lcim,0x00,00,0x84,00,00,chs 	// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs	// parancs nincs elvegezve,hiba.
 *
 *	A:',',0xfe,0x00,00,0x81,chs		    // korparancs:cim infra adas inditas.(3x)
 *	A:',',0xfe,0x00,00,0x82,chs		    // korparancs:cim infra adas leallitas.(3x)
 *	A:',',0xfe,0x00,00,0x80,chs		    // korparancs:reset mindegyik allomasnal.(3x)
 *	A:',',0xfe,0x00,00,0x70,chs		    // korparancs:test start, mindegyik allomasnal.(3x)
 *	A:',',0xfe,0x00,00,0x71,chs		    // korparancs:test stop, mindegyik allomasnal.(3x)
 *	A:',',0xfe,0x00,00,0x83,chs		// korparancs:install bekapcsolasa.(3x) 
 *	A:',',0xfe,0x00,00,0x84,chs		// korparancs:install kikapcsolasa.(3x) 
 *
 *	A:',',lcim,0x00,00,0xa1,chs		    // rendszernek: uzenet kuldes mod bekapcsolva.
 *	V:';',lcim,0x00,00,0xa1,0x00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,0x00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0xa2,chs		// rendszernek: uzenet kuldes mod kikapcsolva.
 *	V:';',lcim,0x00,00,0xa2,00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 *
 *	A:',',lcim,0x00,00,0xa3,chs		// rendszernek: reset.
 *	V:';',lcim,0x00,00,0xa3,00,00,chs 		// parancs elvegezve.
 *	V:';',lcim,0x00,00,0xf0,00,00,chs		// parancs nincs elvegezve,hiba.
 */
 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <inttypes.h>
#include <compat\ina90.h>
#include <stdio.h>

#include "macros.h"
#include "Kozpont.h"
#include "KLoop.h"
#include "K1loop.h"
#include "KMloop.h"
#include "KConfig.h"
#include "KCom.h"
#include "KTouch.h"
#include "KErrorControlling.h"

LOOPtype	loop_array[COMM_MAX_LOOP+1];
uint8_t		loop_ask_index;
CHN_ASK 	chn_ask;	
/***********************************************************
 * Hurok tomb feldolgozo fg.
 ***********************************************************/
LOOPtype* NextLoop(void)
{	
//PutString("!!!!!!!!!!!!!!");	
	if(!allloopnumenable)
		return NULL;

	++loop_ask_index;
	loop_ask_index = (loop_ask_index >= allloopnumenable) ? 0 : loop_ask_index;
//	sprintf(msg,"loop -- %d,%d",loop_ask_index,loop_array[loop_ask_index].loop);
//	PutString(msg);	
	return &loop_array[loop_ask_index];
		
}//CHANNELtype* NextAll(void)

//
//----------------------------------------------------
LOOPtype* CurrLoop(void)
{
	if (loop_ask_index <= allloopnumenable)
		return &loop_array[loop_ask_index];
	return &loop_array[0];
}//CHANNELtype* CurrAll(void)

//----------------------------------------------------
void loops_load()
{
	lmchannels_load(loop_array);
}



/***********************************************************
 * init resz.
 ***********************************************************/
void chlm_com_init(void)
{
	l_com_init(BAUD2400_16);
	loops_load();
	loop_ask_index = 0;
	tx_max_sended_num 	= MTX_MAX_SENDED_NUM;
	rx_max_receive_num 	= MRX_DEF_RECEIVE_NUM;
	


}//void chml_com_init(void)


void set_cmd_all_All(uint8_t cmd)
{
/*	uint8_t index;

	for(index=0;index <= alladdrnumenable;index++)
	{
		all_array[index].cmd = cmd;
	}*/
}//void set_cmd_all_All(uint8_t cmd)
/************************************************************
 * Vetel feldolgozo resz.
 ***********************************************************/
//----------------------------------------------------
// check summa vizsgalata.
unsigned char  MIsGoodCheckSumma(volatile unsigned char* pData, uint8_t num)
{
	unsigned char chs = 0;
	uint8_t ii;

	for (ii=0; ii<num; ii++)
		chs += pData[ii];
	return (/*(unsigned char)*/chs == pData[ii]);
//	return (*pData + *(++pData) == *(++pData));
}//IsGoodCheckSumma2(unsigned char* pData)

//

//----------------------------------------------------------
void chlm_rx_controlling(volatile unsigned char* pData, CHN_ASK* chk)
{
#ifdef DEBUG	
	//sprintf(msg,"rx -- 0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x",pData[0],pData[1],pData[2],pData[3],pData[4],pData[5],pData[6],pData[7]);
	sprintf(msg,"rx:%c,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x",pData[0],pData[1],pData[2],pData[3],pData[4],pData[5],pData[6],pData[7]);
	PutString(msg); mm
#endif

	uint8_t	loop;
	LOOPtype* lp = CurrLoop();

	if (chk && chk->num)
		loop = chk->loop;
	else
		loop = lp->loop;
		
	//	char msg[40];
	if (*pData == R2_STR_CHAR)
	{//uzenet.
		
//		pData[20] = 0;
//		PutString(pData+2);
		return;
	}	

	if (pData[0] == R_STR_CHAR)
	{
	//	pData++;
	
		if (pData[1] == loop)
		{  // kerdezett hurok cime jott.
		//	pData++;
			uint16_t  addr_l = ((unsigned int)pData[2])*256+((unsigned int)pData[3]);
			if ( (addr_l > 0) && (addr_l < MAX_ADDR) )
			{	// allomas cimes valasz jott.
				if (MIsGoodCheckSumma(pData+1,6))
				{ // valtozas,hiba.			
			//	if (!IsFull_A())	
		//		{			
					lp->chn.addrh = pData[2];
					lp->chn.addrl = pData[3];
					lp->chn.data = pData[4] & 0x3f;
			//	lp->chn.prev_data = lp->chn.data;
					lp->chn.error = pData[5];
					lp->chn.stat  = pData[6];

			//		sprintf(msg,"l -: 0x%x,0x%x,0x%x,0x%x,0x%x,0x%x",lp->chn.addrh,lp->chn.addrl,lp->chn.data,lp->chn.error,lp->chn.stat,lp->chn.prev_data);
			//		PutString(msg);
			//	temp = ~(lp->chn.data & 0x0f);
			//	temp = temp << 4;
			//	lp->chn.prev_data	= (*(++pData) | temp);				
			
				
				//visszakuldes.
					chn_ask.loop 	 = loop;
					chn_ask.chn.addrh = lp->chn.addrh;
					chn_ask.chn.addrl = lp->chn.addrl;
					chn_ask.chn.cmd  = (lp->chn.data & 0x0f);
		//		chn_ask.chn.error = lp->chn.error;
		//		chn_ask.chn.stat = lp->chn.stat;
					chn_ask.num = 1;
					chn_ask.timeout  = 0;
		//		sprintf(msg,"???:0x%x,0x%x",lp->chn.data,lp->chn.prev_data);
		//		PutString(msg);
					//l_set_error_flag(ERR_NONEflag,&lp->chn);
			//	}
				}
				else
				{
//					PutString("CHS BAD\n");
				//	l_set_error_flag(ERR_CONTflag,&lp->chn);
				}
			}	
			else
			if ((pData[2] == 0) && (pData[3] == 0))
			{			
		/*	if (*(pData+1) == R_MESSG_CMD)
			{ // szimpla uzenet, max. 20 byte.
				pData++;
				pData++;
				PutString(pData);	
				return;	
			}
			else*/		
				if (MIsGoodCheckSumma(pData+1,6))
				{				
				//	pData++;
				//	pData++;				
		
					if (pData[4] == R_ERROR_CMD)
					{ // parancs nincs elvegezve,hiba.
						l_set_error_flag(ERR_RESPflag,&lp->chn);
					}							
	
					else
					if (pData[4] == R_ASKADDRNUM_CMD)
					{	// allomas cimek szama a num-ban.
						lp->addr_num = (int)pData[5];
						if (chk)
							chk->num = 0;
					}
					else
					{
						lp->summa_error = pData[6];	
					}
					l_set_error_flag(ERR_NONEflag,&lp->chn);
				}
				else
					l_set_error_flag(ERR_CONTflag,&lp->chn);
			}
		}
	}
	else
	if (*pData == R3_STR_CHAR)
	{
		pData++;
		if (*pData == loop)
		{  // kerdezett hurok cime jott.
			pData++;				
			if (*pData == R_ADDRLST_CMD)
			{	// allomas cimek lekerdezese.
			//	if (lp->addr_num == *(pData+1))
			//	{
	//		PutString("GA:1");	
					if (MIsGoodCheckSumma(pData-1,*(pData+1)*2 + 3))
					{		
		//	PutString("GA:2");		
						uint8_t ii;
						pData++;
						all_addr[0] = loop;
					//	all_addr[1] = lp->addr_num;
						all_addr[1] = *(pData);
						pData++;
						for (ii=0;ii<all_addr[1];ii++,pData+=2)
							all_addr[ii+2] =  ((int)*pData)*256+(int)*(pData+1);
						if (chk)
							chk->num = 0;
						CLR_SYSSTATUS(SYS_WAIT_ADDRLIST);
						addrlist_print_com();
						l_set_error_flag(ERR_NONEflag,&lp->chn);
					}
					else
						l_set_error_flag(ERR_CONTflag,&lp->chn);
				}

		//	}
		}
	}


//	chl1_set_error_flag(ERR_NONEflag);
//	PutString("???????");
}//void chm1_rx_controlling(void)

/***********************************************************
 *  Adas  resz.
 ***********************************************************/
 void klm_tx_send(CHN_ASK* ptrData)
{
	if (ptrData)
	{		
		txBuffer[0] = S_STR_CHAR;
        txBuffer[1] = ptrData->loop;
//		if ((ptrData->chn.addr > 0) && (ptrData->chn.addr <= COMM_MAX_ADDR))
//		{ // van cim, nem korparancs.
			txBuffer[2] = ptrData->chn.addrh;
			txBuffer[3] = ptrData->chn.addrl;							
//		}
//		else
//		{	// korparancs.
//			txBuffer[2] = 0;				       		
//		}
		txBuffer[4] = ptrData->chn.cmd;		
		txBuffer[5] = txBuffer[1] + txBuffer[2] + txBuffer[3] + txBuffer[4];

//		char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3],txBuffer[4],txBuffer[5]);
	//	PutString(msg);	
		if (txBuffer[4] != S_ASKADDR_CMD)
			rx_max_receive_num 	= MRX_DEF_RECEIVE_NUM;
		else
		{
			LOOPtype* lp = &loop_array[ptrData->loop];
			if (lp && (lp->addr_num>0) && (lp->addr_num<COMM_MAX_ADDR))
				rx_max_receive_num 	= lp->addr_num*2 + 5;
		}
		lcd_set_loop_addr(ptrData->loop,0);
		l_tx_send_common();		
	}
}//void chlm_tx_send(CHANNELtype* ptrData)

/***********************************************************
 *	A:',',lcim,0x00,chs			// altalanos lekerdezes.
***********************************************************/
void chlm_tx_send(LOOPtype* ptrData)
{
	if (ptrData)
	{		
		txBuffer[0] = S_STR_CHAR;
        txBuffer[1] = ptrData->loop;
		txBuffer[2] = 0;
		txBuffer[3] = S_GENERAL_CMD;
		txBuffer[4] = 0;
		
		if (CHK_SYSSTATUS(SYS_TEST40) || CHK_SYSSTATUS(SYS_TEST2))
			txBuffer[4] |= 1;
		if (config.infra)
			txBuffer[4] |= 2;
		if (config.install)	
			txBuffer[4] |= 4;		       

		txBuffer[5] = txBuffer[1] + txBuffer[2] + txBuffer[3] + txBuffer[4];
		
	//	char msg[40];
	//	sprintf(msg,"ch1_tx:0x%x,0x%x,0x%x,0x%x",txBuffer[0],txBuffer[1],txBuffer[2],txBuffer[3]);
	//	PutString(msg);	
		lcd_set_loop_addr(ptrData->loop,0);
		l_tx_send_common();	
		rx_max_receive_num 	= MRX_DEF_RECEIVE_NUM;
	//	lcd_set_chan_loop(ptrData->loop);
	}
}//void chlm_tx_send(LOOPtype* ptrData)

/************************************************************
 * Error feldolgozo resz.
 ***********************************************************/
void chlm_set_error_flag(CHERRFLAG flag_a)
{
/*	if (flag_a == ERR_TOflag)
	{
		LOOPtype* cl = CurrLoop();
		cl->loop++;
		cl->loop = (cl->loop > 100) ? 4: cl->loop;
	}*/
}//void chlm_set_error_flag(CHERRFLAG flag_a)
