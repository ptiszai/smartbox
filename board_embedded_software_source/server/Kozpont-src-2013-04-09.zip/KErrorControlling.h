//#define 		MAX_AB_LEN		15
#define 		MAX_AB_LEN		6
#ifdef TOLTESJEL
#define TOLT_MASK	0x01
#endif
#define AKKU_MASK	0x02
#define FENYCS_MASK	0x04
#define COM_MASK	0x08

#define CHECK_A			(A_error[i].error & x)
#define SET_A(i,x)		{A_error[i].error |= x;}
#define CLR_A(i,x)		{A_error[i].error &= ~x;};

#define CHECK_B(i,x)	(B_error[i].error & x)
#define SET_B(i,x)		{B_error[i].error |= x;}
#define CLR_B(i,x)		{B_error[i].error &= ~x;};
 

typedef struct
{
	unsigned short 	    addr;
#ifdef TOLTESJEL
	uint8_t				tolt;
#endif
	uint8_t				akku;
	uint8_t				fenycs;
	uint8_t				com;
}ABtype;

extern void 	AB_init();
extern void 	AB_controll(char test);
extern void 	AB_executor();
//extern uint8_t A_append(int addr, uint8_t	data, uint8_t	error);
extern uint8_t IsChargeError_AB();
extern void Alarm_LED_blink();
extern void Alarm_LED_fast_blink();
extern void A_copyto_B();
extern void  B_all_clear();
extern uint8_t Darab_A();
extern uint8_t Darab_B();
extern ABtype A_error[MAX_AB_LEN];
extern ABtype B_error[MAX_AB_LEN];
extern char LED_blink;
//extern uint8_t IsFull_A();
