#ifndef TRANSZ_H
#define TRANSZ_H

#define EN		1	//angol
//#define HU		1	//magyar
//#define DE		1   //nemet

#ifdef EN
//angol
#define TEST0_MSG " TEST "
#define TEST1_MSG " DATA "
#define TEST2_MSG " MODE "
#define TEST3_MSG " O.K. "
#define TEST4_MSG " INST "
#define TEST5_MSG " ALL  "
#define TEST6_MSG " SERV-"
#define TEST7_MSG " ICE  "

#endif

#ifdef HU
//magyar
#define TEST0_MSG " TEST "
#define TEST1_MSG " DATA "
#define TEST2_MSG " MODE "
#define TEST3_MSG " O.K. "
#define TEST4_MSG " INST "
#define TEST5_MSG " ALL  "
#define TEST6_MSG " SERV-"
#define TEST7_MSG " ICE  "

#endif

#ifdef DE
//nemet
#define TEST0_MSG " TEST "
#define TEST1_MSG " DATA "
#define TEST2_MSG " MODE "
#define TEST3_MSG " O.K. "
#define TEST4_MSG " INST "
#define TEST5_MSG " ALL  "
#define TEST6_MSG " SERV-"
#define TEST7_MSG " ICE  "

#endif


#endif
