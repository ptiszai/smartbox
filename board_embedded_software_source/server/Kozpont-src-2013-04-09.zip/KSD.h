#ifndef _KSD_H
#define _KSD_H

#define  LOGNAME "lamp.log"
#define configure_pin_sd_cd() DDRE |= ~(1 << DDE2);PORTE |= (1<<PE2);
#define get_sd_cd() ((PINE >> PE2) & 0x01) 
//struct fat16_file_struct;
extern void sd_init(void);
extern uint8_t create_file(const char* file);
extern void close_file(struct fat16_file_struct* fd);
extern struct fat16_file_struct* open_file(const char* file);
extern uint8_t read_file(struct fat16_file_struct* fd, uint8_t* buffer, uint16_t buffer_len);
extern uint8_t read_line( uint8_t* buffer, uint16_t buffer_len);
extern uint8_t remove_file(const char* file);
extern uint8_t append_file(struct fat16_file_struct* fd, uint8_t* buffer, uint16_t buffer_len);
extern void ls_dir();
extern uint8_t seek_file(struct fat16_file_struct* fd, int32_t* offset, uint8_t whence);
extern uint32_t get_global_pos(void);
extern void append_to_log(const char* msg);
extern void test();
#endif
